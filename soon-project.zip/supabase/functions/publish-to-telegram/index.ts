import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const GATEWAY_URL = 'https://connector-gateway.lovable.dev/telegram';

const CURATED_ARTICLES = [
  {
    title: 'How Pets Improve Mental Health: Scientific Evidence',
    url: 'https://www.apa.org/monitor/2024/04/pets-mental-health',
    topic: 'pets-mental-health',
    source_name: 'APA Monitor',
    summary: 'Scientific evidence shows that the human-animal bond can reduce cortisol, ease loneliness, and support emotional regulation.'
  },
  {
    title: 'The Neuroscience of Mindfulness Meditation',
    url: 'https://www.sciencedaily.com/releases/2024/03/240315120000.htm',
    topic: 'psychology',
    source_name: 'ScienceDaily',
    summary: 'Brain studies suggest regular mindfulness practice can strengthen attention, self-awareness, and emotional balance.'
  },
  {
    title: 'Animal-Assisted Therapy for PTSD in Veterans',
    url: 'https://habri.org/research/ptsd',
    topic: 'pets-mental-health',
    source_name: 'HABRI Research',
    summary: 'Research suggests service dogs may reduce PTSD symptoms, improve sleep, and provide a stabilizing emotional bond.'
  },
  {
    title: 'Attachment Theory and Adult Relationships',
    url: 'https://www.psychologytoday.com/us/basics/attachment',
    topic: 'psychology',
    source_name: 'Psychology Today',
    summary: 'Attachment theory helps explain how early caregiving patterns can shape trust, intimacy, and emotional reactions in adulthood.'
  }
];

function buildSoonLink(article: { topic: string }) {
  const base = 'https://www.soonpsy.com';
  if (article.topic === 'pets-mental-health') return `${base}`;
  return `${base}`;
}

function formatArticle(article: { title: string; url: string; topic: string; summary: string; source_name?: string }) {
  const emoji = article.topic === 'psychology' ? '🧠' : '🐾';
  const hashtags = article.topic === 'psychology'
    ? '#Psychology #MentalHealth #Soon'
    : '#PetTherapy #HumanAnimalBond #MentalHealth #Soon';

  return `${emoji} <b>${article.title}</b>\n\n${article.summary}\n\n📚 Source: ${article.source_name || 'Scientific article'}\n🔗 Read the article: <a href="${article.url}">Open source</a>\n🌐 Discover more on Soon: <a href="${buildSoonLink(article)}">www.soonpsy.com</a>\n\n${hashtags}`;
}

async function sendMessage(chatId: string, text: string, lovableKey: string, telegramKey: string) {
  const response = await fetch(`${GATEWAY_URL}/sendMessage`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${lovableKey}`,
      'X-Connection-Api-Key': telegramKey,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      chat_id: chatId,
      text,
      parse_mode: 'HTML',
      disable_web_page_preview: false,
    }),
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(`Telegram sendMessage failed [${response.status}]: ${JSON.stringify(data)}`);
  }

  return data.result;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { headers: corsHeaders });

  try {
    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    const TELEGRAM_API_KEY = Deno.env.get('TELEGRAM_API_KEY');
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL');
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    if (!LOVABLE_API_KEY) throw new Error('LOVABLE_API_KEY is not configured');
    if (!TELEGRAM_API_KEY) throw new Error('TELEGRAM_API_KEY is not configured');
    if (!SUPABASE_URL) throw new Error('SUPABASE_URL is not configured');
    if (!SUPABASE_SERVICE_ROLE_KEY) throw new Error('SUPABASE_SERVICE_ROLE_KEY is not configured');

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const body = await req.json().catch(() => ({}));
    const requestedChatId = typeof body.chat_id === 'string' ? body.chat_id.trim() : '';
    const publishAll = body.publishAll === true;
    const testMessage = typeof body.testMessage === 'string' ? body.testMessage.trim() : '';

    let chatId = requestedChatId;

    if (!chatId) {
      const { data: setting, error: settingError } = await supabase
        .from('telegram_settings')
        .select('chat_id, topics')
        .eq('is_active', true)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (settingError) throw settingError;
      if (setting?.chat_id) chatId = setting.chat_id;
    }

    if (!chatId) {
      return new Response(JSON.stringify({ success: false, error: 'No Telegram channel configured. Please provide the channel username like @yourchannel or save it in backend settings.' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (testMessage) {
      const result = await sendMessage(chatId, testMessage, LOVABLE_API_KEY, TELEGRAM_API_KEY);
      return new Response(JSON.stringify({ success: true, mode: 'test', message_id: result.message_id, chat_id: chatId }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { data: publishedRows, error: publishedError } = await supabase
      .from('published_articles')
      .select('article_url');

    if (publishedError) throw publishedError;

    const publishedUrls = new Set((publishedRows || []).map((row) => row.article_url));
    let articles = CURATED_ARTICLES.filter((article) => !publishedUrls.has(article.url));
    if (articles.length === 0) articles = CURATED_ARTICLES;
    if (!publishAll) articles = articles.slice(0, 1);

    const results = [];

    for (const article of articles) {
      const text = formatArticle(article);
      const sent = await sendMessage(chatId, text, LOVABLE_API_KEY, TELEGRAM_API_KEY);

      await supabase.from('published_articles').upsert({
        article_url: article.url,
        article_title: article.title,
        topic: article.topic,
        source_name: article.source_name,
        telegram_message_id: sent.message_id,
      }, { onConflict: 'article_url' });

      results.push({ title: article.title, message_id: sent.message_id });
    }

    return new Response(JSON.stringify({ success: true, mode: 'publish', chat_id: chatId, published: results.length, results }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown error';
    console.error('publish-to-telegram error:', message);
    return new Response(JSON.stringify({ success: false, error: message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
