const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { headers: corsHeaders });

  try {
    const { url } = await req.json();
    
    const response = await fetch(url || 'https://www.meaningfulpaththerapy.com/blog');
    const html = await response.text();

    // Simple extraction of articles from blog page
    const articles: { title: string; source: string; date: string; content: string; url: string }[] = [];
    
    // Extract article links and titles using regex
    const titleRegex = /<h[23][^>]*class="[^"]*blog[^"]*"[^>]*>[\s\S]*?<a[^>]*href="([^"]*)"[^>]*>([\s\S]*?)<\/a>/gi;
    const contentRegex = /<p[^>]*class="[^"]*summary[^"]*"[^>]*>([\s\S]*?)<\/p>/gi;
    
    // Fallback: extract any article-like content
    const linkRegex = /<a[^>]*href="(\/blog\/[^"]*)"[^>]*>([\s\S]*?)<\/a>/gi;
    let match;
    const seen = new Set<string>();
    
    while ((match = linkRegex.exec(html)) !== null) {
      const href = match[1];
      const title = match[2].replace(/<[^>]*>/g, '').trim();
      if (title && title.length > 10 && !seen.has(href)) {
        seen.add(href);
        articles.push({
          title,
          source: 'Meaningful Path Therapy',
          date: new Date().toLocaleDateString(),
          content: title,
          url: `https://www.meaningfulpaththerapy.com${href}`,
        });
      }
    }

    return new Response(JSON.stringify({ articles: articles.slice(0, 10) }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Error:', error);
    return new Response(JSON.stringify({ articles: [], error: error.message }), {
      status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
