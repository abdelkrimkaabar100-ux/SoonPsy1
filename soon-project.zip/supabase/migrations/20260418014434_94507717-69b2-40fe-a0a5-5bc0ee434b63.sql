DROP POLICY IF EXISTS "Anyone can insert telegram settings" ON public.telegram_settings;
DROP POLICY IF EXISTS "Anyone can update telegram settings" ON public.telegram_settings;
DROP POLICY IF EXISTS "Anyone can delete telegram settings" ON public.telegram_settings;
DROP POLICY IF EXISTS "Anyone can insert published articles" ON public.published_articles;
DROP POLICY IF EXISTS "Service role can manage telegram settings" ON public.telegram_settings;
DROP POLICY IF EXISTS "Service role can manage published articles" ON public.published_articles;

CREATE POLICY "Service role can manage telegram settings" ON public.telegram_settings FOR ALL USING (auth.role() = 'service_role') WITH CHECK (auth.role() = 'service_role');
CREATE POLICY "Service role can manage published articles" ON public.published_articles FOR ALL USING (auth.role() = 'service_role') WITH CHECK (auth.role() = 'service_role');