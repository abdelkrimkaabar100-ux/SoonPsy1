
CREATE TABLE public.telegram_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  chat_id text NOT NULL,
  channel_name text,
  is_active boolean NOT NULL DEFAULT true,
  topics text[] NOT NULL DEFAULT ARRAY['psychology', 'pets-mental-health'],
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.published_articles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  article_url text NOT NULL UNIQUE,
  article_title text NOT NULL,
  topic text NOT NULL,
  telegram_message_id bigint,
  published_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_published_articles_url ON public.published_articles(article_url);

ALTER TABLE public.telegram_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.published_articles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view telegram settings" ON public.telegram_settings FOR SELECT USING (true);
CREATE POLICY "Anyone can insert telegram settings" ON public.telegram_settings FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can update telegram settings" ON public.telegram_settings FOR UPDATE USING (true);
CREATE POLICY "Anyone can delete telegram settings" ON public.telegram_settings FOR DELETE USING (true);

CREATE POLICY "Anyone can view published articles" ON public.published_articles FOR SELECT USING (true);
CREATE POLICY "Anyone can insert published articles" ON public.published_articles FOR INSERT WITH CHECK (true);

CREATE EXTENSION IF NOT EXISTS pg_cron;
CREATE EXTENSION IF NOT EXISTS pg_net;
