
CREATE TABLE public.holiday_greetings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_name text NOT NULL DEFAULT '',
  recipient_name text NOT NULL DEFAULT '',
  message text NOT NULL,
  occasion text NOT NULL DEFAULT 'general',
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.holiday_greetings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can insert greetings" ON public.holiday_greetings FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Anyone can read greetings" ON public.holiday_greetings FOR SELECT TO anon, authenticated USING (true);

CREATE TABLE public.groups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text NOT NULL DEFAULT '',
  group_type text NOT NULL DEFAULT 'predefined',
  invite_code text UNIQUE NOT NULL DEFAULT substr(md5(random()::text), 1, 8),
  icon text NOT NULL DEFAULT '📚',
  created_by text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.groups ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can read groups" ON public.groups FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Anyone can create groups" ON public.groups FOR INSERT TO anon, authenticated WITH CHECK (true);

CREATE TABLE public.group_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES public.groups(id) ON DELETE CASCADE,
  sender_name text NOT NULL DEFAULT 'Anonymous',
  content text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.group_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can read group messages" ON public.group_messages FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Anyone can send group messages" ON public.group_messages FOR INSERT TO anon, authenticated WITH CHECK (true);
ALTER PUBLICATION supabase_realtime ADD TABLE public.group_messages;

CREATE TABLE public.shared_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type text NOT NULL DEFAULT 'honesty',
  sender_name text NOT NULL DEFAULT '',
  recipient_name text NOT NULL DEFAULT '',
  content text NOT NULL,
  extra_data jsonb DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.shared_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can insert shared messages" ON public.shared_messages FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Anyone can read shared messages" ON public.shared_messages FOR SELECT TO anon, authenticated USING (true);

INSERT INTO public.groups (name, description, group_type, icon, invite_code) VALUES
('Book Reading Club', 'Share book recommendations and discuss what you are reading', 'predefined', '📚', 'books001'),
('Meditation Circle', 'Practice mindfulness and share meditation experiences', 'predefined', '🧘', 'meditate1'),
('Human Connection', 'Build meaningful connections and support each other', 'predefined', '🤝', 'connect1'),
('Gratitude & Joy', 'Share things you are grateful for and celebrate together', 'predefined', '🌟', 'gratitud'),
('Mental Wellness', 'Discuss mental health topics and coping strategies', 'predefined', '🧠', 'wellness1');
