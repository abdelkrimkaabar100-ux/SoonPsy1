DROP POLICY IF EXISTS "Anyone can view published articles" ON public.published_articles;
CREATE POLICY "Anyone can view published articles" ON public.published_articles FOR SELECT USING (true);