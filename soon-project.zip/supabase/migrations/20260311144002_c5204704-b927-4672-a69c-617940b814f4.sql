
CREATE TABLE public.gratitude_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_name text NOT NULL DEFAULT '',
  recipient_name text NOT NULL DEFAULT '',
  message text NOT NULL,
  is_self_thanks boolean NOT NULL DEFAULT false,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.gratitude_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert gratitude messages"
ON public.gratitude_messages
FOR INSERT
TO anon, authenticated
WITH CHECK (true);

CREATE POLICY "Anyone can read gratitude messages by id"
ON public.gratitude_messages
FOR SELECT
TO anon, authenticated
USING (true);
