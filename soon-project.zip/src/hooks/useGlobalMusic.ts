import { useState, useRef, useCallback, useEffect } from 'react';

export interface GlobalMusicState {
  isPlaying: boolean;
  isMuted: boolean;
  currentTrackName: string;
  currentTrackUrl: string;
  volume: number;
  progress: number;
  play: (url: string, name: string) => void;
  pause: () => void;
  resume: () => void;
  stop: () => void;
  toggleMute: () => void;
  setVolume: (v: number) => void;
}

let globalAudio: HTMLAudioElement | null = null;
let globalState = {
  isPlaying: false,
  isMuted: false,
  currentTrackName: '',
  currentTrackUrl: '',
  volume: 0.7,
  progress: 0,
};
const listeners = new Set<() => void>();

function notify() { listeners.forEach(l => l()); }

export function useGlobalMusic(): GlobalMusicState {
  const [, forceUpdate] = useState(0);

  useEffect(() => {
    const update = () => forceUpdate(n => n + 1);
    listeners.add(update);
    return () => { listeners.delete(update); };
  }, []);

  const play = useCallback((url: string, name: string) => {
    if (globalAudio) { globalAudio.pause(); globalAudio = null; }
    const audio = new Audio(url);
    audio.volume = globalState.isMuted ? 0 : globalState.volume;
    audio.loop = false;
    audio.ontimeupdate = () => {
      if (audio.duration) {
        globalState.progress = (audio.currentTime / audio.duration) * 100;
        notify();
      }
    };
    audio.onended = () => {
      globalState.isPlaying = false;
      globalState.currentTrackName = '';
      globalState.currentTrackUrl = '';
      globalState.progress = 0;
      notify();
    };
    globalAudio = audio;
    audio.play().catch(() => {});
    globalState.isPlaying = true;
    globalState.currentTrackName = name;
    globalState.currentTrackUrl = url;
    globalState.progress = 0;
    notify();
  }, []);

  const pause = useCallback(() => {
    if (globalAudio) { globalAudio.pause(); globalState.isPlaying = false; notify(); }
  }, []);

  const resume = useCallback(() => {
    if (globalAudio) { globalAudio.play().catch(() => {}); globalState.isPlaying = true; notify(); }
  }, []);

  const stop = useCallback(() => {
    if (globalAudio) { globalAudio.pause(); globalAudio = null; }
    globalState.isPlaying = false;
    globalState.currentTrackName = '';
    globalState.currentTrackUrl = '';
    globalState.progress = 0;
    notify();
  }, []);

  const toggleMute = useCallback(() => {
    globalState.isMuted = !globalState.isMuted;
    if (globalAudio) audio_setVol();
    notify();
  }, []);

  const setVolume = useCallback((v: number) => {
    globalState.volume = Math.max(0, Math.min(1, v));
    if (globalAudio && !globalState.isMuted) globalAudio.volume = globalState.volume;
    notify();
  }, []);

  return {
    isPlaying: globalState.isPlaying,
    isMuted: globalState.isMuted,
    currentTrackName: globalState.currentTrackName,
    currentTrackUrl: globalState.currentTrackUrl,
    volume: globalState.volume,
    progress: globalState.progress,
    play, pause, resume, stop, toggleMute, setVolume,
  };
}

function audio_setVol() {
  if (globalAudio) globalAudio.volume = globalState.isMuted ? 0 : globalState.volume;
}
