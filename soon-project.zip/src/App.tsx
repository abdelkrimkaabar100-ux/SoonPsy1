import { lazy, Suspense } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";

const SharedThanksPage = lazy(() => import("./pages/SharedThanksPage"));
const SharedGreetingPage = lazy(() => import("./pages/SharedGreetingPage"));
const SharedMessagePage = lazy(() => import("./pages/SharedMessagePage"));
const SharedGroupPage = lazy(() => import("./pages/SharedGroupPage"));

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <Toaster />
    <Sonner />
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Index />} />
        <Route path="/thanks/:id" element={<Suspense fallback={<div style={{minHeight:'100vh',display:'flex',alignItems:'center',justifyContent:'center'}}>💚</div>}><SharedThanksPage /></Suspense>} />
        <Route path="/greeting/:id" element={<Suspense fallback={<div style={{minHeight:'100vh',display:'flex',alignItems:'center',justifyContent:'center'}}>🎉</div>}><SharedGreetingPage /></Suspense>} />
        <Route path="/shared/:id" element={<Suspense fallback={<div style={{minHeight:'100vh',display:'flex',alignItems:'center',justifyContent:'center'}}>💌</div>}><SharedMessagePage /></Suspense>} />
        <Route path="/group/:inviteCode" element={<Suspense fallback={<div style={{minHeight:'100vh',display:'flex',alignItems:'center',justifyContent:'center'}}>👥</div>}><SharedGroupPage /></Suspense>} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  </QueryClientProvider>
);

export default App;
