import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';

export default function SharedMessagePage() {
  const { id } = useParams<{ id: string }>();
  const [msg, setMsg] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) return;
    supabase.from('shared_messages').select('*').eq('id', id).single()
      .then(({ data, error }) => { if (!error) setMsg(data); setLoading(false); });
  }, [id]);

  if (loading) return <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '2rem' }}>💌</div>;
  if (!msg) return <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: '10px' }}><span style={{ fontSize: '3rem' }}>😔</span><p>Message not found</p></div>;

  const isHonesty = msg.type === 'honesty';
  const colors = isHonesty ? ['#8965e0', '#5e55e0'] : ['#ff6b6b', '#ee5a24'];
  const icon = isHonesty ? '💭' : '💝';
  const title = isHonesty ? 'Honesty Message' : 'Love Message';

  return (
    <div style={{ minHeight: '100vh', background: `linear-gradient(135deg, ${colors[0]}, ${colors[1]})`, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '20px', fontFamily: 'Poppins, sans-serif' }}>
      <div style={{ background: 'white', borderRadius: '24px', padding: '40px 30px', maxWidth: '420px', width: '100%', textAlign: 'center', boxShadow: '0 20px 60px rgba(0,0,0,0.2)' }}>
        <div style={{ fontSize: '3rem', marginBottom: '15px' }}>{icon}</div>
        <h2 style={{ color: colors[0], fontSize: '1.2rem', margin: '0 0 5px' }}>{title}</h2>
        {msg.recipient_name && <p style={{ color: '#8898aa', fontSize: '0.9rem' }}>To: {msg.recipient_name} 💝</p>}
        <div style={{ background: `${colors[0]}10`, borderRadius: '16px', padding: '20px', margin: '20px 0', border: `2px solid ${colors[0]}20` }}>
          <p style={{ color: '#32325d', fontSize: '0.95rem', lineHeight: 1.8, margin: 0, whiteSpace: 'pre-wrap' }}>{msg.content}</p>
        </div>
        {msg.sender_name && <p style={{ color: '#8898aa', fontSize: '0.9rem', fontWeight: 600 }}>— {msg.sender_name}</p>}
        <div style={{ marginTop: '25px', padding: '12px', background: '#f0fdf4', borderRadius: '12px' }}>
          <a href="/" style={{ color: '#2DCE89', textDecoration: 'none', fontWeight: 600, fontSize: '0.85rem' }}>✨ Soon - Mental Wellness App</a>
        </div>
      </div>
    </div>
  );
}
