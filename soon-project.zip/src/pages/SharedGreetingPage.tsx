import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';

const occasionEmojis: Record<string, string> = {
  eid: '🌙', newyear: '🎆', birthday: '🎂', ramadan: '🕌',
  christmas: '🎄', wedding: '💍', graduation: '🎓', general: '🎉',
};

const occasionColors: Record<string, string[]> = {
  eid: ['#059669', '#10b981'], newyear: ['#7c3aed', '#8b5cf6'], birthday: ['#ec4899', '#f472b6'],
  ramadan: ['#0d9488', '#14b8a6'], christmas: ['#dc2626', '#16a34a'], wedding: ['#db2777', '#f9a8d4'],
  graduation: ['#1d4ed8', '#3b82f6'], general: ['#f59e0b', '#fbbf24'],
};

export default function SharedGreetingPage() {
  const { id } = useParams<{ id: string }>();
  const [greeting, setGreeting] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) return;
    supabase.from('holiday_greetings').select('*').eq('id', id).single()
      .then(({ data, error }) => { if (!error) setGreeting(data); setLoading(false); });
  }, [id]);

  if (loading) return <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '2rem' }}>🎉</div>;
  if (!greeting) return <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: '10px' }}><span style={{ fontSize: '3rem' }}>😔</span><p>Greeting not found</p></div>;

  const colors = occasionColors[greeting.occasion] || occasionColors.general;
  const emoji = occasionEmojis[greeting.occasion] || '🎉';

  return (
    <div style={{ minHeight: '100vh', background: `linear-gradient(135deg, ${colors[0]}, ${colors[1]})`, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '20px', fontFamily: 'Poppins, sans-serif' }}>
      <div style={{ background: 'white', borderRadius: '24px', padding: '40px 30px', maxWidth: '420px', width: '100%', textAlign: 'center', boxShadow: '0 20px 60px rgba(0,0,0,0.2)' }}>
        <div style={{ fontSize: '4rem', marginBottom: '15px', animation: 'bounce 2s infinite' }}>{emoji}</div>
        <h2 style={{ color: colors[0], fontSize: '1.3rem', margin: '0 0 5px' }}>
          {greeting.recipient_name} 💝
        </h2>
        <div style={{ background: `linear-gradient(135deg, ${colors[0]}15, ${colors[1]}15)`, borderRadius: '16px', padding: '20px', margin: '20px 0', border: `2px solid ${colors[0]}30` }}>
          <p style={{ color: '#32325d', fontSize: '1rem', lineHeight: 1.8, margin: 0, whiteSpace: 'pre-wrap' }}>{greeting.message}</p>
        </div>
        {greeting.sender_name && (
          <p style={{ color: '#8898aa', fontSize: '0.9rem', fontWeight: 600 }}>— {greeting.sender_name} 💌</p>
        )}
        <div style={{ marginTop: '25px', padding: '12px', background: '#f0fdf4', borderRadius: '12px' }}>
          <a href="/" style={{ color: '#2DCE89', textDecoration: 'none', fontWeight: 600, fontSize: '0.85rem' }}>
            ✨ Soon - Mental Wellness App
          </a>
        </div>
      </div>
      <style>{`@keyframes bounce { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-10px); } }`}</style>
    </div>
  );
}
