import { useEffect, useState, useRef } from 'react';
import { useParams } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';

export default function SharedGroupPage() {
  const { inviteCode } = useParams<{ inviteCode: string }>();
  const [group, setGroup] = useState<any>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [msgInput, setMsgInput] = useState('');
  const [userName, setUserName] = useState(() => localStorage.getItem('soon-user-name') || '');
  const [nameSet, setNameSet] = useState(!!userName);
  const [loading, setLoading] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!inviteCode) return;
    supabase.from('groups').select('*').eq('invite_code', inviteCode).single()
      .then(({ data, error }) => { if (!error) setGroup(data); setLoading(false); });
  }, [inviteCode]);

  useEffect(() => {
    if (!group) return;
    supabase.from('group_messages').select('*').eq('group_id', group.id).order('created_at').then(({ data }) => { if (data) setMessages(data); });
    const channel = supabase.channel(`group-shared-${group.id}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'group_messages', filter: `group_id=eq.${group.id}` },
        (payload) => setMessages(prev => [...prev, payload.new]))
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [group]);

  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  const sendMessage = async () => {
    if (!msgInput.trim() || !group) return;
    await supabase.from('group_messages').insert({ group_id: group.id, sender_name: userName || 'Guest', content: msgInput.trim() });
    setMsgInput('');
  };

  if (loading) return <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '2rem' }}>👥</div>;
  if (!group) return <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: '10px' }}><span style={{ fontSize: '3rem' }}>😔</span><p>Group not found</p></div>;

  if (!nameSet) return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(135deg, #6366f1, #8b5cf6)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '20px', fontFamily: 'Poppins, sans-serif' }}>
      <div style={{ background: 'white', borderRadius: '24px', padding: '40px 30px', maxWidth: '400px', width: '100%', textAlign: 'center' }}>
        <div style={{ fontSize: '3rem', marginBottom: '15px' }}>{group.icon}</div>
        <h2 style={{ color: '#6366f1', margin: '0 0 10px' }}>{group.name}</h2>
        <p style={{ color: '#8898aa', marginBottom: '20px' }}>{group.description}</p>
        <input type="text" value={userName} onChange={e => setUserName(e.target.value)} placeholder="Your name..."
          style={{ width: '100%', padding: '12px', border: '2px solid #e5e7eb', borderRadius: '12px', fontSize: '1rem', textAlign: 'center', outline: 'none', boxSizing: 'border-box', marginBottom: '12px' }} />
        <button onClick={() => { if (userName.trim()) { localStorage.setItem('soon-user-name', userName.trim()); setNameSet(true); } }}
          style={{ background: '#6366f1', color: 'white', border: 'none', borderRadius: '25px', padding: '12px 30px', fontWeight: 600, cursor: 'pointer', fontSize: '1rem' }}>
          Join Group →
        </button>
      </div>
    </div>
  );

  return (
    <div style={{ minHeight: '100vh', background: '#f8fafc', fontFamily: 'Poppins, sans-serif', display: 'flex', flexDirection: 'column' }}>
      <div style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6)', color: 'white', padding: '15px 20px', display: 'flex', alignItems: 'center', gap: '10px' }}>
        <a href="/" style={{ color: 'white', textDecoration: 'none', fontSize: '1.2rem' }}><i className="fas fa-home"></i></a>
        <div style={{ fontSize: '1.5rem' }}>{group.icon}</div>
        <div>
          <h3 style={{ margin: 0, fontSize: '1.1rem' }}>{group.name}</h3>
          <p style={{ margin: 0, fontSize: '0.75rem', opacity: 0.8 }}>{group.description}</p>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '15px', maxHeight: 'calc(100vh - 130px)' }}>
        {messages.length === 0 && <p style={{ textAlign: 'center', color: '#8898aa', padding: '40px 0' }}>No messages yet. Start the conversation! 💬</p>}
        {messages.map((m: any) => {
          const isMe = m.sender_name === userName;
          return (
            <div key={m.id} style={{ display: 'flex', justifyContent: isMe ? 'flex-end' : 'flex-start', marginBottom: '8px' }}>
              <div style={{
                background: isMe ? 'linear-gradient(135deg, #6366f1, #8b5cf6)' : 'white',
                color: isMe ? 'white' : '#32325d', borderRadius: '16px', padding: '10px 14px',
                maxWidth: '75%', boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
              }}>
                {!isMe && <div style={{ fontSize: '0.7rem', fontWeight: 700, color: '#6366f1', marginBottom: '2px' }}>{m.sender_name}</div>}
                <div style={{ fontSize: '0.85rem', lineHeight: 1.5 }}>{m.content}</div>
                <div style={{ fontSize: '0.65rem', opacity: 0.6, marginTop: '4px', textAlign: 'right' }}>
                  {new Date(m.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      <div style={{ padding: '10px 15px', borderTop: '1px solid #e5e7eb', background: 'white', display: 'flex', gap: '8px' }}>
        <input value={msgInput} onChange={e => setMsgInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && sendMessage()}
          placeholder="Type a message..." style={{ flex: 1, padding: '10px 14px', border: '1px solid #e5e7eb', borderRadius: '25px', outline: 'none', fontSize: '0.9rem' }} />
        <button onClick={sendMessage} style={{ background: '#6366f1', color: 'white', border: 'none', borderRadius: '50%', width: 40, height: 40, cursor: 'pointer', fontSize: '1rem', flexShrink: 0 }}>
          <i className="fas fa-paper-plane"></i>
        </button>
      </div>
    </div>
  );
}
