import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';

interface ThankYouMessage {
  sender_name: string;
  recipient_name: string;
  message: string;
  created_at: string;
}

export default function SharedThanksPage() {
  const { id } = useParams<{ id: string }>();
  const [msg, setMsg] = useState<ThankYouMessage | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    if (!id) { setNotFound(true); setLoading(false); return; }
    supabase.from('gratitude_messages').select('*').eq('id', id).single()
      .then(({ data, error }) => {
        if (error || !data) setNotFound(true);
        else setMsg(data as ThankYouMessage);
        setLoading(false);
      });
  }, [id]);

  if (loading) return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'linear-gradient(135deg, #f0fdf4, #ecfdf5)' }}>
      <div style={{ fontSize: '2rem', animation: 'pulse 1.5s infinite' }}>💚</div>
    </div>
  );

  if (notFound) return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'linear-gradient(135deg, #fef2f2, #fee2e2)', padding: '20px' }}>
      <div style={{ textAlign: 'center', maxWidth: '400px' }}>
        <div style={{ fontSize: '3rem', marginBottom: '15px' }}>😕</div>
        <h2 style={{ color: '#991b1b', marginBottom: '10px' }}>Message Not Found</h2>
        <p style={{ color: '#b91c1c', fontSize: '0.9rem' }}>This link may have expired or is invalid.</p>
        <a href="/" style={{ display: 'inline-block', marginTop: '20px', padding: '12px 24px', background: 'linear-gradient(135deg, #2DCE89, #1fa86d)', color: 'white', borderRadius: '14px', textDecoration: 'none', fontWeight: 600 }}>
          Open Soon App 🌿
        </a>
      </div>
    </div>
  );

  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'linear-gradient(135deg, #f0fdf4, #ecfdf5)', padding: '20px' }}>
      <div style={{ maxWidth: '480px', width: '100%', textAlign: 'center' }}>
        <div style={{
          background: 'white', borderRadius: '28px', padding: '40px 30px',
          boxShadow: '0 20px 60px rgba(45,206,137,0.15)',
          border: '2px solid rgba(45,206,137,0.2)',
        }}>
          <div style={{ fontSize: '4rem', marginBottom: '15px' }}>💚</div>
          
          <h1 style={{ fontSize: '1.5rem', color: '#32325d', margin: '0 0 5px' }}>
            {msg!.recipient_name}
          </h1>
          <p style={{ fontSize: '0.85rem', color: '#8898aa', margin: '0 0 25px' }}>
            Someone wants to thank you ✨
          </p>

          <div style={{
            background: 'linear-gradient(135deg, #f0fdf4, #ecfdf5)',
            borderRadius: '18px', padding: '25px 20px',
            marginBottom: '25px', borderLeft: '5px solid #2DCE89',
            textAlign: 'left',
          }}>
            <p style={{ margin: 0, fontSize: '1.05rem', color: '#32325d', lineHeight: 1.8, fontStyle: 'italic' }}>
              "{msg!.message}"
            </p>
          </div>

          <p style={{ fontSize: '0.9rem', color: '#2DCE89', fontWeight: 600, margin: '0 0 5px' }}>
            — {msg!.sender_name}
          </p>
          <p style={{ fontSize: '0.7rem', color: '#8898aa', margin: '0 0 25px' }}>
            {new Date(msg!.created_at).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
          </p>

          <a href="/" style={{
            display: 'inline-block', padding: '14px 28px',
            background: 'linear-gradient(135deg, #2DCE89, #1fa86d)',
            color: 'white', borderRadius: '16px', textDecoration: 'none',
            fontWeight: 600, fontSize: '0.95rem', fontFamily: 'Poppins, sans-serif',
            boxShadow: '0 4px 15px rgba(45,206,137,0.3)',
          }}>
            🌿 Open Soon App
          </a>
        </div>

        <p style={{ marginTop: '20px', fontSize: '0.75rem', color: '#8898aa' }}>
          Soon — Fostering psychological resilience for every living being.
        </p>
      </div>
    </div>
  );
}
