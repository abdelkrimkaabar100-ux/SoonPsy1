import { useState, useEffect, useCallback, useRef, lazy, Suspense } from 'react';
import { useLanguage } from '../i18n/LanguageContext';
import AppContainer, { Page } from '../components/layout/AppContainer';
import AIChat from '../components/home/AIChat';
import WelcomeGuide from '../components/home/WelcomeGuide';
import MoodTracker from '../components/home/MoodTracker';
import GratitudeCard from '../components/home/GratitudeCard';
import ScrollIndicator from '../components/home/ScrollIndicator';
import DailySuggestion from '../components/home/DailySuggestion';
import WellnessLinks from '../components/home/WellnessLinks';
import TimeTracker from '../components/home/TimeTracker';

// Lazy load heavy components
const SleepExerciseTracker = lazy(() => import('../components/home/SleepExerciseTracker'));
const RestTracker = lazy(() => import('../components/home/RestTracker'));
const FoodTracker = lazy(() => import('../components/home/FoodTracker'));
const WaterReminder = lazy(() => import('../components/home/WaterReminder'));
const StatsOverview = lazy(() => import('../components/home/StatsOverview'));
const BrainFoodGuide = lazy(() => import('../components/home/BrainFoodGuide'));
const SelfCareTracker = lazy(() => import('../components/home/SelfCareTracker'));
const HabitTracker = lazy(() => import('../components/home/HabitTracker'));
const IdentityAffirmations = lazy(() => import('../components/home/IdentityAffirmations'));
const WeeklyReport = lazy(() => import('../components/home/WeeklyReport'));
const StreakSystem = lazy(() => import('../components/home/StreakSystem'));
const NotificationSetup = lazy(() => import('../components/home/NotificationSetup'));
const InstallApp = lazy(() => import('../components/home/InstallApp'));


// Lazy load sub-pages
const JournalPage = lazy(() => import('../components/journal/JournalPage'));
const DreamsPage = lazy(() => import('../components/dreams/DreamsPage'));
const RelaxationPage = lazy(() => import('../components/relaxation/RelaxationPage'));
const MeditationPage = lazy(() => import('../components/relaxation/MeditationPage'));
const NaturePage = lazy(() => import('../components/relaxation/NaturePage'));
const MusicPage = lazy(() => import('../components/relaxation/MusicPage'));
const PianoPage = lazy(() => import('../components/relaxation/PianoPage'));
const AffirmationsPage = lazy(() => import('../components/relaxation/AffirmationsPage'));
const WalkPage = lazy(() => import('../components/relaxation/WalkPage'));
const FoodPage = lazy(() => import('../components/relaxation/FoodPage'));
const ReflectionPage = lazy(() => import('../components/relaxation/ReflectionPage'));
const MindfulnessPage = lazy(() => import('../components/relaxation/MindfulnessPage'));
const ArticlesPage = lazy(() => import('../components/articles/ArticlesPage'));
const PetPage = lazy(() => import('../components/pet/PetPage'));
const SmileChallenge = lazy(() => import('../components/challenges/SmileChallenge'));
const HonestyPage = lazy(() => import('../components/challenges/HonestyPage'));
const ResilienceStories = lazy(() => import('../components/challenges/ResilienceStories'));
const ParentChildPlay = lazy(() => import('../components/challenges/ParentChildPlay'));
const PositiveSelfPage = lazy(() => import('../components/selfwriting/PositiveSelfPage'));
const LifeStoryPage = lazy(() => import('../components/selfwriting/LifeStoryPage'));
const AttentionGamesPage = lazy(() => import('../components/games/AttentionGamesPage'));
const SpecialNeedsPage = lazy(() => import('../components/specialneeds/SpecialNeedsPage'));
const EarthCarePage = lazy(() => import('../components/earth/EarthCarePage'));
const CommunityPage = lazy(() => import('../components/community/CommunityPage'));
const SpiritualityPage = lazy(() => import('../components/spirituality/SpiritualityPage'));
const FamilyPage = lazy(() => import('../components/family/FamilyPage'));
const ExperiencesPage = lazy(() => import('../components/experiences/ExperiencesPage'));
const LovePage = lazy(() => import('../components/love/LovePage'));
const MoviesPage = lazy(() => import('../components/movies/MoviesPage'));
const HobbiesPage = lazy(() => import('../components/hobbies/HobbiesPage'));
const GoalsPage = lazy(() => import('../components/goals/GoalsPage'));
const DonatePage = lazy(() => import('../components/donate/DonatePage'));
const LearningPage = lazy(() => import('../components/learning/LearningPage'));
const WomenWellnessPage = lazy(() => import('../components/women/WomenWellnessPage'));
const FinancePage = lazy(() => import('../components/finance/FinancePage'));
const AnxietyPage = lazy(() => import('../components/anxiety/AnxietyPage'));
const ImaginationPage = lazy(() => import('../components/imagination/ImaginationPage'));
const KindWordsPage = lazy(() => import('../components/kindwords/KindWordsPage'));
const AngerPage = lazy(() => import('../components/anger/AngerPage'));
const CommunityDevPage = lazy(() => import('../components/community/CommunityDevPage'));
const SelfResponsibilityPage = lazy(() => import('../components/growth/SelfResponsibilityPage'));
const TaskManagerPage = lazy(() => import('../components/tasks/TaskManagerPage'));
const DetoxChallengePage = lazy(() => import('../components/challenges/DetoxChallengePage'));
const GratitudePage = lazy(() => import('../components/gratitude/GratitudePage'));
const HolidayGreetingsPage = lazy(() => import('../components/greetings/HolidayGreetingsPage'));
const GroupsPage = lazy(() => import('../components/groups/GroupsPage'));
const DecisionPage = lazy(() => import('../components/decision/DecisionPage'));
const CryingPage = lazy(() => import('../components/crying/CryingPage'));
const WhatNotToDoPage = lazy(() => import('../components/donts/WhatNotToDoPage'));
const FutureSelfPage = lazy(() => import('../components/futureself/FutureSelfPage'));
const TraditionalCookingPage = lazy(() => import('../components/cooking/TraditionalCookingPage'));
const ForgivenessPage = lazy(() => import('../components/forgiveness/ForgivenessPage'));
const UnconsciousMindPage = lazy(() => import('../components/unconscious/UnconsciousMindPage'));
const MythsPage = lazy(() => import('../components/myths/MythsPage'));
const SadKnowledgePage = lazy(() => import('../components/sadknowledge/SadKnowledgePage'));
const PrimordialWitnessPage = lazy(() => import('../components/witness/PrimordialWitnessPage'));
const PsycheWarsPage = lazy(() => import('../components/psychewars/PsycheWarsPage'));

export default function Index() {
  const { t, lang } = useLanguage();
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [selectedMood, setSelectedMood] = useState('');
  const [aiTrigger, setAiTrigger] = useState('');
  const [hasUnreadAI, setHasUnreadAI] = useState(false);
  const scrollPositionRef = useRef<number>(0);
  const [lastSeenMsgCount, setLastSeenMsgCount] = useState(() => {
    try { const msgs = JSON.parse(localStorage.getItem('soon-chat-messages') || '[]'); return msgs.length; } catch { return 0; }
  });

  const navigate = (page: Page) => {
    // Save scroll position when leaving home
    if (currentPage === 'home' && page !== 'home') {
      const main = document.querySelector('.soon-main');
      if (main) scrollPositionRef.current = main.scrollTop;
    }
    setCurrentPage(page);
    if (page === 'home') {
      setHasUnreadAI(false);
      // Restore scroll position
      setTimeout(() => {
        const main = document.querySelector('.soon-main');
        if (main && scrollPositionRef.current > 0) {
          main.scrollTop = scrollPositionRef.current;
        }
      }, 100);
      if (hasUnreadAI) {
        setTimeout(() => {
          const el = document.getElementById('soonpsy-chat');
          if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 200);
      }
    }
  };

  const shareWithAI = (text: string) => {
    setAiTrigger(text);
    setCurrentPage('home');
    setTimeout(() => {
      const el = document.getElementById('soonpsy-chat');
      if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 300);
  };

  useEffect(() => {
    if (currentPage === 'home') {
      try { const msgs = JSON.parse(localStorage.getItem('soon-chat-messages') || '[]'); setLastSeenMsgCount(msgs.length); } catch {}
      setHasUnreadAI(false);
      return;
    }
    const interval = setInterval(() => {
      try {
        const msgs = JSON.parse(localStorage.getItem('soon-chat-messages') || '[]');
        if (msgs.length > lastSeenMsgCount && msgs[msgs.length - 1]?.role === 'assistant') {
          setHasUnreadAI(true);
        }
      } catch {}
    }, 2000);
    return () => clearInterval(interval);
  }, [currentPage, lastSeenMsgCount]);

  const sendProactiveTip = useCallback(async () => {
    try {
      const msgs = JSON.parse(localStorage.getItem('soon-chat-messages') || '[]');
      const lastMsg = msgs[msgs.length - 1];
      if (lastMsg?.role === 'assistant' && lastMsg?.content?.includes('💡')) return;
      
      const read = (key: string, fb: any) => { try { return JSON.parse(localStorage.getItem(key) || JSON.stringify(fb)); } catch { return fb; } };
      const name = read('soon-user-name', '') || '';
      const moodHistory = read('soon-mood-history', []);
      const sleepLog = read('soon-sleep', []);
      const petData = read('soon-pet', { name: '', type: '' });
      const dreams = read('soon-dreams', []);
      const tasks = read('soon-tasks', []);
      const goals = read('soon-goals', []);
      const anxiety = read('soon-anxiety', []);
      const family = read('soon-family-members', []);
      const recentMood = moodHistory.length > 0 ? moodHistory[0].mood : '';
      const todaySleep = sleepLog.filter((e: any) => new Date(e.date).toDateString() === new Date().toDateString()).reduce((s: number, e: any) => s + e.value, 0);
      const pendingTasks = tasks.filter((t: any) => !t.completed).length;
      const isAr = lang === 'ar';
      const ft: string[] = [];
      
      if (petData.name) ft.push(isAr ? `💡 ${name}، كيف حال ${petData.name}؟ 🐾 قضاء وقت مع حيوانك يقلل الكورتيزول 23%!` : `💡 ${name}, how's ${petData.name}? 🐾 Pet time reduces cortisol by 23%!`);
      if (todaySleep > 0 && todaySleep < 6) ft.push(isAr ? `💡 ${name}، نمت ${todaySleep} ساعات فقط. جرّب تقنية 4-7-8 قبل النوم 😴` : `💡 ${name}, only ${todaySleep}h sleep. Try 4-7-8 breathing before bed 😴`);
      if (recentMood === 'bad' || recentMood === 'terrible') ft.push(isAr ? `💡 ${name}، مزاجك ليس بأفضل حال. جرّب اليوميات أو الاسترخاء 🤗` : `💡 ${name}, mood isn't great. Try journaling or relaxation 🤗`);
      if (pendingTasks > 3) ft.push(isAr ? `💡 ${name}، لديك ${pendingTasks} مهام. ابدأ بواحدة فقط! 📋` : `💡 ${name}, ${pendingTasks} tasks. Start with ONE! 📋`);
      if (dreams.length > 0) ft.push(isAr ? `💡 ${name}، سجلت ${dreams.length} أحلام. تحليلها يكشف أنماط اللاوعي 🌙` : `💡 ${name}, ${dreams.length} dreams logged. Analyze patterns! 🌙`);
      if (goals.length > 0 && goals.filter((g: any) => !g.completed).length > 0) ft.push(isAr ? `💡 ${name}، لديك أهداف في الانتظار. كل خطوة صغيرة مهمة 🎯` : `💡 ${name}, goals waiting. Every small step counts 🎯`);
      if (anxiety.length > 0) ft.push(isAr ? `💡 ${name}، سجلت ${anxiety.length} تجارب قلق. كل مرة تتعامل معه تصبح أقوى 💪` : `💡 ${name}, ${anxiety.length} coping entries. You grow stronger! 💪`);
      if (family.length > 0) ft.push(isAr ? `💡 ${name}، قل كلمة طيبة لأحد أفراد عائلتك اليوم 👨‍👩‍👧‍👦` : `💡 ${name}, say something kind to family today 👨‍👩‍👧‍👦`);

      const gen = isAr ? [
        `💡 ${name}، لم تسجل مزاجك اليوم 💚`, `💡 ${name}، الامتنان يقلل القلق 25% 🙏`,
        `💡 ${name}، خذ 5 دقائق تنفس عميق 🌬️`, `💡 ${name}، مشي 10 دقائق يرفع السعادة 🚶‍♂️`,
        `💡 ${name}، ابتسم الآن! 😊`,
      ] : [
        `💡 ${name}, log your mood! 💚`, `💡 ${name}, gratitude reduces anxiety 25% 🙏`,
        `💡 ${name}, 5 min deep breathing 🌬️`, `💡 ${name}, 10-min walk boosts happiness 🚶‍♂️`,
        `💡 ${name}, smile now! 😊`,
      ];

      const all = ft.length > 0 ? [...ft, ...gen] : gen;
      const tip = all[Math.floor(Math.random() * all.length)];
      const newMsgs = [...msgs, { role: 'assistant', content: tip }];
      localStorage.setItem('soon-chat-messages', JSON.stringify(newMsgs));
      if (currentPage !== 'home') setHasUnreadAI(true);
    } catch (e) { console.error('Proactive tip error:', e); }
  }, [lang, currentPage]);

  useEffect(() => {
    const interval = 10 * 60 * 1000;
    const lastP = localStorage.getItem('soon-last-proactive');
    const now = Date.now();
    
    if (!lastP || (now - parseInt(lastP)) > interval) {
      const timer = setTimeout(() => {
        sendProactiveTip();
        localStorage.setItem('soon-last-proactive', now.toString());
      }, 15000);
      return () => clearTimeout(timer);
    }
    const recurring = setInterval(() => {
      sendProactiveTip();
      localStorage.setItem('soon-last-proactive', Date.now().toString());
    }, interval);
    return () => clearInterval(recurring);
  }, [sendProactiveTip]);

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return (
          <div>
            <Suspense fallback={null}>
              <InstallApp />
            </Suspense>
            <WelcomeGuide />
            <Suspense fallback={null}>
              <NotificationSetup />
              <StreakSystem />
            </Suspense>
            <AIChat triggerMessage={aiTrigger} onTriggerConsumed={() => setAiTrigger('')} />
            <MoodTracker selectedMood={selectedMood} onMoodSelect={setSelectedMood}
              onShareWithAI={() => shareWithAI(`My current mood is: ${selectedMood}. Please provide insights.`)} />
            <GratitudeCard onShareWithAI={shareWithAI} />
            <Suspense fallback={<div style={{padding:'20px',textAlign:'center'}}>⏳</div>}>
              <SleepExerciseTracker onViewHistory={() => {}} />
              <RestTracker onShareWithAI={shareWithAI} />
              <FoodTracker />
              <BrainFoodGuide />
              <WaterReminder />
              <SelfCareTracker />
              <StatsOverview />
              <WeeklyReport />
            </Suspense>
            <ScrollIndicator showSoonPsyArrow={hasUnreadAI} />
            <TimeTracker />
            <DailySuggestion onNavigate={navigate} />
            <WellnessLinks onNavigate={navigate} />
            <Suspense fallback={null}>
              <HabitTracker />
              <IdentityAffirmations />
            </Suspense>
          </div>
        );
      case 'journal': return <JournalPage onShareWithAI={shareWithAI} />;
      case 'dreams': return <DreamsPage />;
      case 'relaxation': return <RelaxationPage onNavigate={navigate} />;
      case 'meditation': return <MeditationPage onBack={() => navigate('relaxation')} />;
      case 'nature': return <NaturePage onBack={() => navigate('relaxation')} />;
      case 'music': return <MusicPage onBack={() => navigate('relaxation')} />;
      case 'piano': return <PianoPage onBack={() => navigate('relaxation')} />;
      case 'affirmations-relax': return <AffirmationsPage onBack={() => navigate('relaxation')} />;
      case 'walk': return <WalkPage onBack={() => navigate('relaxation')} />;
      case 'food': return <FoodPage onBack={() => navigate('relaxation')} />;
      case 'reflection': return <ReflectionPage onBack={() => navigate('home')} onShareWithAI={shareWithAI} />;
      case 'articles': return <ArticlesPage />;
      case 'pet': return <PetPage onShareWithAI={shareWithAI} />;
      case 'smile-challenge': return <SmileChallenge />;
      case 'honesty': return <HonestyPage onShareWithAI={shareWithAI} />;
      case 'resilience': return <ResilienceStories />;
      case 'parent-child': return <ParentChildPlay />;
      case 'positive-self': return <PositiveSelfPage onShareWithAI={shareWithAI} />;
      case 'life-story': return <LifeStoryPage onShareWithAI={shareWithAI} />;
      case 'attention-games': return <AttentionGamesPage onBack={() => navigate('home')} />;
      case 'special-needs': return <SpecialNeedsPage onBack={() => navigate('home')} />;
      case 'earth-care': return <EarthCarePage onBack={() => navigate('home')} />;
      case 'community': return <CommunityPage onBack={() => navigate('home')} />;
      case 'spirituality': return <SpiritualityPage onBack={() => navigate('home')} />;
      case 'family': return <FamilyPage onBack={() => navigate('home')} />;
      case 'experiences': return <ExperiencesPage onBack={() => navigate('home')} />;
      case 'love-page': return <LovePage onBack={() => navigate('home')} />;
      case 'movies': return <MoviesPage onBack={() => navigate('relaxation')} />;
      case 'mindfulness': return <MindfulnessPage onBack={() => navigate('relaxation')} />;
      case 'hobbies': return <HobbiesPage onBack={() => navigate('home')} />;
      case 'goals': return <GoalsPage onBack={() => navigate('home')} />;
      case 'donate': return <DonatePage onBack={() => navigate('home')} />;
      case 'learning': return <LearningPage onBack={() => navigate('home')} />;
      case 'women-wellness': return <WomenWellnessPage onBack={() => navigate('home')} />;
      case 'finance': return <FinancePage onBack={() => navigate('home')} />;
      case 'anxiety': return <AnxietyPage onBack={() => navigate('home')} />;
      case 'imagination': return <ImaginationPage onBack={() => navigate('home')} />;
      case 'kind-words': return <KindWordsPage onBack={() => navigate('home')} />;
      case 'anger': return <AngerPage onBack={() => navigate('home')} />;
      case 'community-dev': return <CommunityDevPage onBack={() => navigate('home')} />;
      case 'self-responsibility': return <SelfResponsibilityPage onBack={() => navigate('home')} />;
      case 'tasks': return <TaskManagerPage onBack={() => navigate('home')} />;
      case 'detox-challenge': return <DetoxChallengePage onBack={() => navigate('home')} />;
      case 'gratitude-thanks': return <GratitudePage onBack={() => navigate('home')} />;
      case 'holiday-greetings': return <HolidayGreetingsPage onBack={() => navigate('home')} />;
      case 'groups': return <GroupsPage onBack={() => navigate('home')} />;
      case 'decision-ai': return <DecisionPage onBack={() => navigate('home')} />;
      case 'crying': return <CryingPage onBack={() => navigate('home')} />;
      case 'what-not-to-do': return <WhatNotToDoPage onBack={() => navigate('home')} />;
      case 'future-self': return <FutureSelfPage onBack={() => navigate('home')} />;
      case 'traditional-cooking': return <TraditionalCookingPage onBack={() => navigate('home')} />;
      case 'forgiveness': return <ForgivenessPage onBack={() => navigate('home')} />;
      case 'unconscious-mind': return <UnconsciousMindPage onBack={() => navigate('home')} />;
      case 'myths': return <MythsPage onBack={() => navigate('home')} />;
      case 'sad-knowledge': return <SadKnowledgePage onBack={() => navigate('home')} />;
      case 'primordial-witness': return <PrimordialWitnessPage onBack={() => navigate('home')} />;
      case 'psyche-wars': return <PsycheWarsPage onBack={() => navigate('home')} />;
    }
  };

  return (
    <AppContainer currentPage={currentPage} onNavigate={navigate} hasUnreadAI={hasUnreadAI}>
      <Suspense fallback={<div style={{padding:'40px',textAlign:'center',fontSize:'1.5rem'}}>⏳</div>}>
        {renderPage()}
      </Suspense>
    </AppContainer>
  );
}
