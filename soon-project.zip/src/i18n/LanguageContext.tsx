import React, { createContext, useContext, useState, useEffect } from 'react';
import { translations, Lang } from './translations';

interface LanguageContextType {
  lang: Lang;
  setLang: (lang: Lang) => void;
  t: (key: string) => string;
  isRTL: boolean;
}

const LanguageContext = createContext<LanguageContextType>({
  lang: 'en',
  setLang: () => {},
  t: (key) => key,
  isRTL: false,
});

function detectLanguage(): Lang {
  const browserLang = navigator.language?.split('-')[0]?.toLowerCase() || 'en';
  const saved = localStorage.getItem('soon-lang');
  if (saved && ['en', 'ar', 'es', 'fr'].includes(saved)) return saved as Lang;
  if (['en', 'ar', 'es', 'fr'].includes(browserLang)) return browserLang as Lang;
  return 'en';
}

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLangState] = useState<Lang>(detectLanguage);

  const setLang = (l: Lang) => {
    setLangState(l);
    localStorage.setItem('soon-lang', l);
  };

  useEffect(() => {
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  }, [lang]);

  const t = (key: string) => translations[lang]?.[key] || translations['en']?.[key] || key;

  return (
    <LanguageContext.Provider value={{ lang, setLang, t, isRTL: lang === 'ar' }}>
      {children}
    </LanguageContext.Provider>
  );
}

export const useLanguage = () => useContext(LanguageContext);
