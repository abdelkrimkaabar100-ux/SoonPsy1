import { useState, useEffect, useRef } from 'react';
import { Page } from '../layout/AppContainer';

interface MeditationPageProps {
  onBack: () => void;
}

export default function MeditationPage({ onBack }: MeditationPageProps) {
  const [isRunning, setIsRunning] = useState(false);
  const [phase, setPhase] = useState<'inhale' | 'hold' | 'exhale'>('inhale');
  const [instruction, setInstruction] = useState('Take a deep breath. Inhale... then exhale.');
  const [scale, setScale] = useState(1);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const phaseTexts = {
    inhale: { text: 'Inhale deeply...', nextScale: 1.3, duration: 4000, next: 'hold' as const },
    hold: { text: 'Hold your breath...', nextScale: 1.3, duration: 2000, next: 'exhale' as const },
    exhale: { text: 'Exhale slowly...', nextScale: 1, duration: 6000, next: 'inhale' as const },
  };

  const startMeditation = () => {
    setIsRunning(true);
    setPhase('inhale');
    setInstruction('Inhale deeply...');
    setScale(1.3);
  };

  const stopMeditation = () => {
    setIsRunning(false);
    setInstruction('Take a deep breath. Inhale... then exhale.');
    setScale(1);
    if (intervalRef.current) clearTimeout(intervalRef.current);
  };

  useEffect(() => {
    if (!isRunning) return;
    const current = phaseTexts[phase];
    setInstruction(current.text);
    setScale(current.nextScale);
    intervalRef.current = setTimeout(() => {
      setPhase(current.next);
    }, current.duration);
    return () => { if (intervalRef.current) clearTimeout(intervalRef.current); };
  }, [phase, isRunning]);

  return (
    <div style={{ textAlign: 'center' }}>
      <div style={{ position: 'relative', textAlign: 'center', padding: '15px 0' }}>
        <button
          onClick={onBack}
          style={{
            background: 'none', border: 'none', fontSize: '1.5rem',
            color: '#2DCE89', position: 'absolute', left: '20px', top: '20px',
            cursor: 'pointer',
          }}
        >
          <i className="fas fa-arrow-left"></i>
        </button>
        <h2 style={{ color: '#32325d', fontWeight: 700 }}>Guided Meditation</h2>
      </div>

      <div style={{
        background: 'white', borderRadius: '16px',
        padding: '25px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)',
        margin: '20px 0',
      }}>
        <p style={{ fontSize: '1.2rem', marginBottom: '20px', minHeight: '60px', color: '#32325d' }}>
          {instruction}
        </p>

        <div style={{
          width: 200, height: 200, borderRadius: '50%',
          background: 'linear-gradient(135deg, #2DCE89, #1a9f6e)',
          margin: '30px auto',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: 'white', fontSize: '1.5rem', fontWeight: 600,
          position: 'relative', overflow: 'hidden',
          boxShadow: '0 10px 30px rgba(45,206,137,0.3)',
          transform: `scale(${scale})`,
          transition: `transform ${phase === 'inhale' ? '4s' : phase === 'hold' ? '0.5s' : '6s'} ease`,
        }}>
          <span>{phase === 'inhale' ? 'Inhale' : phase === 'hold' ? 'Hold' : 'Exhale'}</span>
          <div className="breathing-animation"></div>
        </div>

        <div style={{
          width: '100%', height: '150px', borderRadius: '16px',
          margin: '20px 0',
          background: `linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.3)),
            url('https://images.unsplash.com/photo-1501854140801-50d01698950b?auto=format&fit=crop&w=1200&q=80')`,
          backgroundSize: 'cover', backgroundPosition: 'center',
        }}></div>

        <div style={{ display: 'flex', justifyContent: 'center', gap: '15px', marginTop: '20px' }}>
          <button
            onClick={startMeditation}
            disabled={isRunning}
            style={{
              background: 'linear-gradient(to right, #2DCE89, #1a9f6e)',
              color: 'white', border: 'none', borderRadius: '25px',
              padding: '12px 24px', fontWeight: 600, cursor: isRunning ? 'default' : 'pointer',
              fontFamily: 'Poppins, sans-serif', opacity: isRunning ? 0.7 : 1,
            }}
          >Begin Meditation</button>
          <button
            onClick={stopMeditation}
            style={{
              background: '#d1efe1', color: '#2DCE89',
              border: 'none', borderRadius: '25px',
              padding: '12px 24px', fontWeight: 600, cursor: 'pointer',
              fontFamily: 'Poppins, sans-serif',
            }}
          >Stop</button>
        </div>
      </div>
    </div>
  );
}
