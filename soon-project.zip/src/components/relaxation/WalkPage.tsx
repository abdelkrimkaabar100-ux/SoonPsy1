import { useState, useRef, useEffect } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';

interface WalkPageProps {
  onBack: () => void;
}

interface WalkRecord {
  id: string;
  date: string;
  duration: number; // seconds walked
  completed: boolean;
}

export default function WalkPage({ onBack }: WalkPageProps) {
  const { t, lang } = useLanguage();
  const isRTL = lang === 'ar';
  const [isRunning, setIsRunning] = useState(false);
  const [timeLeft, setTimeLeft] = useState(30 * 60);
  const [records, setRecords] = useLocalStorage<WalkRecord[]>('soon-walk-records', []);
  const [showHistory, setShowHistory] = useState(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const startTimeRef = useRef<number>(0);

  useEffect(() => {
    if (isRunning && timeLeft > 0) {
      intervalRef.current = setInterval(() => {
        setTimeLeft(t => {
          if (t <= 1) {
            setIsRunning(false);
            clearInterval(intervalRef.current!);
            saveRecord(30 * 60, true);
            return 0;
          }
          return t - 1;
        });
      }, 1000);
    }
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [isRunning]);

  const saveRecord = (duration: number, completed: boolean) => {
    setRecords(prev => [{
      id: Date.now().toString(),
      date: new Date().toISOString(),
      duration,
      completed,
    }, ...prev]);
  };

  const formatTime = (s: number) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;

  const start = () => {
    setTimeLeft(30 * 60);
    setIsRunning(true);
    startTimeRef.current = Date.now();
  };

  const stop = () => {
    setIsRunning(false);
    if (intervalRef.current) clearInterval(intervalRef.current);
    const elapsed = Math.round((Date.now() - startTimeRef.current) / 1000);
    if (elapsed > 10) saveRecord(elapsed, false);
  };

  const todayRecords = records.filter(r => new Date(r.date).toDateString() === new Date().toDateString());
  const totalCompleted = records.filter(r => r.completed).length;
  const totalMinutes = Math.round(records.reduce((s, r) => s + r.duration, 0) / 60);

  return (
    <div style={{ direction: isRTL ? 'rtl' : 'ltr' }}>
      <div style={{ position: 'relative', textAlign: 'center', padding: '15px 0' }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', fontSize: '1.5rem', color: '#2DCE89', position: 'absolute', left: isRTL ? 'auto' : '20px', right: isRTL ? '20px' : 'auto', top: '20px', cursor: 'pointer' }}>
          <i className={`fas fa-arrow-${isRTL ? 'right' : 'left'}`}></i>
        </button>
        <h2 style={{ color: '#32325d', fontWeight: 700 }}>🚶 {t('walk.title')}</h2>
      </div>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '10px', marginBottom: '20px' }}>
        {[
          { label: t('walk.today_walks'), value: todayRecords.length, color: '#2DCE89' },
          { label: t('walk.total_completed'), value: totalCompleted, color: '#5e72e4' },
          { label: t('walk.total_minutes'), value: totalMinutes, color: '#f5576c' },
        ].map((s, i) => (
          <div key={i} style={{ background: 'white', borderRadius: '12px', padding: '12px', textAlign: 'center', boxShadow: '0 4px 15px rgba(0,0,0,0.06)' }}>
            <div style={{ fontSize: '1.5rem', fontWeight: 700, color: s.color }}>{s.value}</div>
            <div style={{ fontSize: '0.7rem', color: '#8898aa' }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Timer */}
      <div style={{ background: 'white', borderRadius: '16px', padding: '25px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)', margin: '20px 0', textAlign: 'center' }}>
        <p style={{ color: '#8898aa', marginBottom: '20px' }}>{t('walk.desc')}</p>
        <div style={{ fontSize: '2.5rem', fontWeight: 700, color: '#2DCE89', margin: '20px 0' }}>
          {formatTime(timeLeft)}
        </div>
        {timeLeft === 0 && (
          <div style={{ color: '#2DCE89', fontWeight: 600, marginBottom: '15px', fontSize: '1.1rem' }}>
            🎉 {t('walk.completed')}
          </div>
        )}
        <div style={{ display: 'flex', justifyContent: 'center', gap: '15px' }}>
          <button onClick={start} disabled={isRunning} style={{
            background: 'linear-gradient(to right, #2DCE89, #1a9f6e)',
            color: 'white', border: 'none', borderRadius: '25px',
            padding: '12px 24px', fontWeight: 600, cursor: isRunning ? 'default' : 'pointer',
            fontFamily: 'Poppins, sans-serif', opacity: isRunning ? 0.7 : 1,
          }}>{t('walk.start')}</button>
          {isRunning && (
            <button onClick={stop} style={{
              background: '#d1efe1', color: '#2DCE89', border: 'none', borderRadius: '25px',
              padding: '12px 24px', fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
            }}>{t('walk.stop')}</button>
          )}
        </div>
      </div>

      {/* History toggle */}
      <button onClick={() => setShowHistory(!showHistory)} style={{
        background: 'none', border: '1px solid #2DCE89', color: '#2DCE89', borderRadius: '20px',
        padding: '8px 20px', cursor: 'pointer', fontFamily: 'Poppins, sans-serif', fontSize: '0.85rem',
        width: '100%', marginBottom: '15px',
      }}>
        📊 {showHistory ? t('walk.hide_history') : t('walk.view_history')} ({records.length})
      </button>

      {showHistory && (
        <div>
          {records.length === 0 && <p style={{ textAlign: 'center', color: '#8898aa' }}>{t('walk.no_records')}</p>}
          {records.slice(0, 20).map(r => (
            <div key={r.id} style={{
              background: r.completed ? 'linear-gradient(135deg, #e8fdf5, #d4f5e9)' : 'white',
              borderRadius: '12px', padding: '12px 15px', marginBottom: '8px',
              boxShadow: '0 2px 8px rgba(0,0,0,0.05)', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              border: r.completed ? '1px solid #2DCE89' : '1px solid #f0f0f0',
            }}>
              <div>
                <div style={{ fontSize: '0.85rem', color: '#32325d', fontWeight: 600 }}>
                  {r.completed ? '✅' : '⏸️'} {Math.round(r.duration / 60)} {t('walk.minutes')}
                </div>
                <div style={{ fontSize: '0.7rem', color: '#8898aa' }}>
                  {new Date(r.date).toLocaleDateString()} • {new Date(r.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
              {r.completed && <span style={{ fontSize: '1.2rem' }}>🏆</span>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
