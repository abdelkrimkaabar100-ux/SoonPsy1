import { Page } from '../layout/AppContainer';
import { useLanguage } from '../../i18n/LanguageContext';

interface RelaxationPageProps {
  onNavigate: (page: Page) => void;
}

export default function RelaxationPage({ onNavigate }: RelaxationPageProps) {
  const { t } = useLanguage();

  const cards = [
    { id: 'meditation' as Page, icon: 'fas fa-cloud-moon', labelKey: 'relax.meditation', gradient: 'linear-gradient(135deg, #2DCE89, #1a9f6e)' },
    { id: 'nature' as Page, icon: 'fas fa-tree', labelKey: 'relax.nature', gradient: 'linear-gradient(135deg, #11cdef, #1a9f6e)' },
    { id: 'music' as Page, icon: 'fas fa-music', labelKey: 'relax.music', gradient: 'linear-gradient(135deg, #8965e0, #2DCE89)' },
    { id: 'piano' as Page, icon: 'fas fa-piano-keyboard', labelKey: 'relax.piano', gradient: 'linear-gradient(135deg, #fb6340, #fbb140)' },
    { id: 'affirmations-relax' as Page, icon: 'fas fa-heart', labelKey: 'relax.affirmations', gradient: 'linear-gradient(135deg, #f5365c, #fb6340)' },
    { id: 'walk' as Page, icon: 'fas fa-walking', labelKey: 'relax.walk', gradient: 'linear-gradient(135deg, #2DCE89, #45b649)' },
    { id: 'movies' as Page, icon: 'fas fa-film', labelKey: 'relax.movies', gradient: 'linear-gradient(135deg, #5e72e4, #825ee4)' },
    { id: 'mindfulness' as Page, icon: 'fas fa-brain', labelKey: 'relax.awareness', gradient: 'linear-gradient(135deg, #667eea, #764ba2)' },
  ];

  return (
    <div>
      <h2 style={{
        fontSize: '1.8rem', fontWeight: 700, color: '#32325d',
        margin: '25px 0', textAlign: 'center', position: 'relative',
      }}>
        {t('wellness.relaxation')}
        <div style={{
          position: 'absolute', bottom: '-10px', left: '50%',
          transform: 'translateX(-50%)',
          width: '80px', height: '4px',
          background: '#2DCE89', borderRadius: '2px',
        }}></div>
      </h2>

      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))',
        gap: '15px', marginTop: '30px',
      }}>
        {cards.map(card => (
          <div
            key={card.id}
            onClick={() => onNavigate(card.id)}
            style={{
              position: 'relative', borderRadius: '16px',
              overflow: 'hidden', height: '150px',
              display: 'flex', alignItems: 'flex-end',
              color: 'white', boxShadow: '0 6px 20px rgba(0,0,0,0.08)',
              transition: 'all 0.3s ease',
              background: card.gradient, cursor: 'pointer',
            }}
            onMouseEnter={e => {
              e.currentTarget.style.transform = 'translateY(-5px)';
              e.currentTarget.style.boxShadow = '0 8px 25px rgba(0,0,0,0.12)';
            }}
            onMouseLeave={e => {
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = '0 6px 20px rgba(0,0,0,0.08)';
            }}
          >
            <div style={{
              position: 'absolute', top: '20px', left: 0, right: 0,
              display: 'flex', justifyContent: 'center', fontSize: '2.5rem',
            }}>
              <i className={card.icon}></i>
            </div>
            <div style={{
              padding: '15px', width: '100%',
              background: 'linear-gradient(to top, rgba(0,0,0,0.6), transparent)',
            }}>
              <h5 style={{ margin: 0, fontSize: '1rem', fontWeight: 600, textAlign: 'center' }}>
                {t(card.labelKey)}
              </h5>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
