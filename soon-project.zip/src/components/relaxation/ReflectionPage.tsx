import { useState, useEffect, useRef } from 'react';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { useLanguage } from '../../i18n/LanguageContext';

const scenarios = [
  "What if you were in a situation where you felt extremely angry? How would you manage your emotions?",
  "Imagine you made a serious mistake at work. How would you handle the consequences?",
  "What would you do if you found yourself constantly worrying about the future?",
  "How would you respond if someone you care about deeply disappointed you?",
  "What if you were faced with a difficult ethical dilemma? How would you make your decision?",
  "How would you cope with feelings of loneliness or isolation?",
  "What if you achieved all your life goals? How would you find new meaning?",
  "How would you handle a situation where you felt overwhelmed by responsibilities?",
  "What would you do if you discovered a close friend was being dishonest with you?",
  "How would you respond to criticism that you felt was unfair?",
];

const quotes = [
  "Between stimulus and response there is a space. In that space is our power to choose our response. - Viktor Frankl",
  "The greatest discovery of my generation is that a human being can alter his life by altering his attitudes. - William James",
  "Until you make the unconscious conscious, it will direct your life and you will call it fate. - Carl Jung",
];

interface ReflectionPageProps {
  onBack: () => void;
  onShareWithAI: (text: string) => void;
}

export default function ReflectionPage({ onBack, onShareWithAI }: ReflectionPageProps) {
  const { t } = useLanguage();
  const [reflections, setReflections] = useLocalStorage<string[]>('soon-reflections', []);
  const [isRunning, setIsRunning] = useState(false);
  const [timeLeft, setTimeLeft] = useState(5 * 60);
  const [scenario, setScenario] = useState(t('reflection.prompt'));
  const [response, setResponse] = useState('');
  const [quote] = useState(quotes[Math.floor(Math.random() * quotes.length)]);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (isRunning && timeLeft > 0) {
      intervalRef.current = setInterval(() => {
        setTimeLeft(t => { if (t <= 1) { setIsRunning(false); return 0; } return t - 1; });
      }, 1000);
    }
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [isRunning]);

  const start = () => {
    setTimeLeft(5 * 60);
    setScenario(scenarios[Math.floor(Math.random() * scenarios.length)]);
    setIsRunning(true);
  };

  const stop = () => {
    setIsRunning(false);
    if (intervalRef.current) clearInterval(intervalRef.current);
  };

  const saveReflection = () => {
    if (response.trim()) {
      setReflections([response.trim(), ...reflections]);
      alert(t('journal.saved'));
    }
  };

  const formatTime = (s: number) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;

  return (
    <div>
      <div style={{ position: 'relative', textAlign: 'center', padding: '15px 0' }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', fontSize: '1.5rem', color: '#2DCE89', position: 'absolute', left: '20px', top: '20px', cursor: 'pointer' }}>
          <i className="fas fa-arrow-left"></i>
        </button>
        <h2 style={{ color: '#32325d', fontWeight: 700 }}>{t('reflection.title')}</h2>
      </div>

      <div style={{ background: 'white', borderRadius: '16px', padding: '25px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)', margin: '20px 0' }}>
        <p style={{ color: '#8898aa', marginBottom: '20px' }}>{t('reflection.desc')}</p>

        <div style={{ background: '#f0f4ff', borderRadius: '16px', padding: '20px', margin: '20px 0', minHeight: '120px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.1rem', fontWeight: 500, lineHeight: 1.6, color: '#32325d' }}>
          {scenario}
        </div>

        <div style={{ fontSize: '2.5rem', fontWeight: 700, color: '#2DCE89', margin: '20px 0', textAlign: 'center' }}>{formatTime(timeLeft)}</div>

        <div style={{ display: 'flex', gap: '10px', justifyContent: 'center', marginBottom: '20px' }}>
          <button onClick={start} style={{ background: 'linear-gradient(to right, #2DCE89, #1a9f6e)', color: 'white', border: 'none', borderRadius: '25px', padding: '12px 24px', fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif' }}>{t('reflection.start')}</button>
          {isRunning && (
            <button onClick={stop} style={{ background: '#d1efe1', color: '#2DCE89', border: 'none', borderRadius: '25px', padding: '12px 24px', fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif' }}>{t('reflection.end')}</button>
          )}
        </div>

        <textarea value={response} onChange={e => setResponse(e.target.value)} placeholder={t('reflection.write')}
          style={{ width: '100%', height: '200px', border: '1px solid #ddd', borderRadius: '16px', padding: '15px', fontFamily: 'Poppins, sans-serif', fontSize: '1rem', resize: 'vertical', marginBottom: '20px', outline: 'none', boxSizing: 'border-box' }}
        />

        <div style={{ display: 'flex', gap: '10px', justifyContent: 'center', marginBottom: '20px' }}>
          <button onClick={saveReflection} style={{ background: 'linear-gradient(to right, #2DCE89, #1a9f6e)', color: 'white', border: 'none', borderRadius: '25px', padding: '12px 24px', fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif' }}>{t('reflection.save')}</button>
          <button onClick={() => onShareWithAI(`Reflection scenario: ${scenario}\nMy response: ${response}`)} style={{ background: '#d1efe1', color: '#2DCE89', border: 'none', borderRadius: '25px', padding: '12px 24px', fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif' }}>{t('reflection.share')}</button>
        </div>

        <div style={{ background: '#d1efe1', borderRadius: '16px', padding: '15px', fontSize: '0.95rem', textAlign: 'center', borderLeft: '4px solid #2DCE89', fontStyle: 'italic', color: '#32325d' }}>"{quote}"</div>
      </div>
    </div>
  );
}
