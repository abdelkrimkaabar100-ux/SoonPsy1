import { useRef } from 'react';

interface PianoPageProps {
  onBack: () => void;
}

const keys = [
  { note: 'C', isBlack: false },
  { note: 'C#', isBlack: true },
  { note: 'D', isBlack: false },
  { note: 'D#', isBlack: true },
  { note: 'E', isBlack: false },
  { note: 'F', isBlack: false },
  { note: 'F#', isBlack: true },
  { note: 'G', isBlack: false },
  { note: 'G#', isBlack: true },
  { note: 'A', isBlack: false },
  { note: 'A#', isBlack: true },
  { note: 'B', isBlack: false },
];

const noteFrequencies: Record<string, number> = {
  C: 261.63, 'C#': 277.18, D: 293.66, 'D#': 311.13, E: 329.63,
  F: 349.23, 'F#': 369.99, G: 392.00, 'G#': 415.30, A: 440.00,
  'A#': 466.16, B: 493.88,
};

export default function PianoPage({ onBack }: PianoPageProps) {
  const audioCtxRef = useRef<AudioContext | null>(null);
  const activeNodes = useRef<Map<string, OscillatorNode>>(new Map());

  const getAudioContext = () => {
    if (!audioCtxRef.current) {
      audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    return audioCtxRef.current;
  };

  const playNote = (note: string) => {
    const ctx = getAudioContext();
    const osc = ctx.createOscillator();
    const gainNode = ctx.createGain();
    osc.connect(gainNode);
    gainNode.connect(ctx.destination);
    osc.type = 'sine';
    osc.frequency.setValueAtTime(noteFrequencies[note], ctx.currentTime);
    gainNode.gain.setValueAtTime(0.5, ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.5);
    osc.start();
    osc.stop(ctx.currentTime + 1.5);
    activeNodes.current.set(note, osc);
  };

  const stopAll = () => {
    activeNodes.current.forEach(osc => { try { osc.stop(); } catch (e) {} });
    activeNodes.current.clear();
  };

  const whiteKeys = keys.filter(k => !k.isBlack);
  const keyWidth = 40;

  return (
    <div style={{ textAlign: 'center' }}>
      <div style={{ position: 'relative', textAlign: 'center', padding: '15px 0' }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', fontSize: '1.5rem', color: '#2DCE89', position: 'absolute', left: '20px', top: '20px', cursor: 'pointer' }}>
          <i className="fas fa-arrow-left"></i>
        </button>
        <h2 style={{ color: '#32325d', fontWeight: 700 }}>Interactive Piano</h2>
      </div>

      <div style={{ background: 'white', borderRadius: '16px', padding: '25px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)', margin: '20px 0' }}>
        <p style={{ color: '#8898aa', marginBottom: '20px' }}>Play the piano to relax and express your emotions</p>

        <div style={{ position: 'relative', height: '180px', display: 'flex', justifyContent: 'center', marginBottom: '20px', overflow: 'visible' }}>
          {/* White keys */}
          {whiteKeys.map((key, idx) => (
            <div
              key={key.note}
              onMouseDown={() => playNote(key.note)}
              style={{
                width: keyWidth, height: 160,
                background: 'white', border: '1px solid #ddd',
                borderRadius: '0 0 4px 4px', cursor: 'pointer',
                display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
                fontWeight: 600, color: '#8898aa', paddingBottom: '10px',
                fontSize: '0.75rem', userSelect: 'none',
                transition: 'background 0.1s',
                position: 'relative', zIndex: 1,
              }}
              onMouseEnter={e => e.currentTarget.style.background = '#f0faf5'}
              onMouseLeave={e => e.currentTarget.style.background = 'white'}
            >
              {key.note}
            </div>
          ))}
          {/* Black keys */}
          {keys.map((key, idx) => {
            if (!key.isBlack) return null;
            // Calculate position of black key
            const whiteIdx = keys.slice(0, idx).filter(k => !k.isBlack).length;
            return (
              <div
                key={key.note}
                onMouseDown={() => playNote(key.note)}
                style={{
                  width: 28, height: 100,
                  background: '#32325d', borderRadius: '0 0 4px 4px',
                  cursor: 'pointer', position: 'absolute',
                  left: `calc(50% - ${(whiteKeys.length / 2 - whiteIdx) * keyWidth - keyWidth / 2 + 14}px)`,
                  top: 0, zIndex: 2, color: 'white',
                  fontSize: '0.6rem', display: 'flex',
                  alignItems: 'flex-end', justifyContent: 'center',
                  paddingBottom: '8px', userSelect: 'none',
                }}
                onMouseEnter={e => e.currentTarget.style.background = '#2DCE89'}
                onMouseLeave={e => e.currentTarget.style.background = '#32325d'}
              >
                {key.note}
              </div>
            );
          })}
        </div>

        <button
          onClick={stopAll}
          style={{
            background: '#d1efe1', color: '#2DCE89',
            border: 'none', borderRadius: '25px', padding: '12px 24px',
            fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
          }}
        >
          <i className="fas fa-stop" style={{ marginRight: '8px' }}></i> Stop All Sounds
        </button>
      </div>
    </div>
  );
}
