import { useState, useRef, useEffect } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { useGlobalMusic } from '../../hooks/useGlobalMusic';

interface MusicPageProps { onBack: () => void; }

interface LocalTrack {
  id: string;
  name: string;
  url: string;
}

const tracks = [
  { title: { en: 'Whispering Nightfall', ar: 'همسات الليل', es: 'Susurro Nocturno', fr: 'Murmure Nocturne' }, url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3' },
  { title: { en: 'Calming Piano Melodies', ar: 'ألحان بيانو هادئة', es: 'Melodías de Piano', fr: 'Mélodies de Piano' }, url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-9.mp3' },
  { title: { en: 'Ocean Waves', ar: 'أمواج المحيط', es: 'Olas del Océano', fr: "Vagues de l'Océan" }, url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3' },
  { title: { en: 'Forest Rain', ar: 'مطر الغابة', es: 'Lluvia del Bosque', fr: 'Pluie de Forêt' }, url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3' },
  { title: { en: 'Mindful Healing', ar: 'العلاج الهادف', es: 'Sanación Consciente', fr: 'Guérison Consciente' }, url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3' },
];

export default function MusicPage({ onBack }: MusicPageProps) {
  const { t, lang } = useLanguage();
  const music = useGlobalMusic();
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [localTracks, setLocalTracks] = useLocalStorage<LocalTrack[]>('soon-local-music', []);

  const playTrack = (index: number) => {
    const track = tracks[index];
    const name = track.title[lang as keyof typeof track.title] || track.title.en;
    music.play(track.url, name);
  };

  const playLocalTrack = (track: LocalTrack) => {
    music.play(track.url, track.name);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    Array.from(files).forEach(file => {
      if (!file.type.startsWith('audio/')) return;
      const reader = new FileReader();
      // Use object URL instead of data URL to avoid localStorage quota issues
      const objectUrl = URL.createObjectURL(file);
      const newTrack: LocalTrack = {
        id: Date.now().toString() + Math.random().toString(36).slice(2),
        name: file.name.replace(/\.[^/.]+$/, ''),
        url: objectUrl,
      };
      // Store track metadata only (not the large data URL) to avoid white screen
      try {
        setLocalTracks(prev => [...prev, newTrack]);
      } catch (err) {
        alert(lang === 'ar' ? 'تعذر حفظ الملف - المساحة ممتلئة. حاول حذف بعض الملفات أولاً.' : 'Storage full. Try removing some tracks first.');
      }
    });
    e.target.value = '';
  };

  const removeLocalTrack = (id: string) => {
    const track = localTracks.find(t => t.id === id);
    if (track && music.currentTrackUrl === track.url) music.stop();
    setLocalTracks(prev => prev.filter(t => t.id !== id));
  };

  const isTrackPlaying = (url: string) => music.currentTrackUrl === url && music.isPlaying;

  return (
    <div>
      <div style={{ position: 'relative', textAlign: 'center', padding: '15px 0' }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', fontSize: '1.5rem', color: '#2DCE89', position: 'absolute', left: '20px', top: '20px', cursor: 'pointer' }}>
          <i className="fas fa-arrow-left"></i>
        </button>
        <h2 style={{ color: '#32325d', fontWeight: 700 }}>{t('relax.music')}</h2>
      </div>

      {/* Upload button */}
      <input ref={fileInputRef} type="file" accept="audio/*" multiple onChange={handleFileUpload} style={{ display: 'none' }} />
      <button onClick={() => fileInputRef.current?.click()} style={{
        width: '100%', background: 'linear-gradient(135deg, #8965e0, #6a3fbb)', color: 'white', border: 'none',
        borderRadius: '14px', padding: '14px', fontWeight: 600, cursor: 'pointer', fontSize: '0.95rem', marginBottom: '15px',
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px'
      }}>
        <i className="fas fa-upload"></i>
        {lang === 'ar' ? 'تحميل موسيقى من جهازك' : lang === 'es' ? 'Subir música desde tu dispositivo' : lang === 'fr' ? 'Télécharger de la musique' : 'Upload Music from Your Device'}
      </button>

      {/* Source attribution */}
      <div style={{ background: '#f0e6ff', borderRadius: '12px', padding: '10px', marginBottom: '15px', textAlign: 'center', fontSize: '0.8rem', color: '#8965e0' }}>
        🎵 {t('music.source')}: <a href="https://audiomack.com/meaningfulpaththerapy/album/whispering-nightfall" target="_blank" rel="noopener noreferrer" style={{ color: '#8965e0', fontWeight: 600 }}>Meaningful Path Therapy - Audiomack</a>
      </div>

      {/* Now Playing */}
      {music.currentTrackName && (
        <div style={{ background: 'linear-gradient(135deg, #8965e0, #2DCE89)', borderRadius: '16px', padding: '20px', marginBottom: '20px', color: 'white', textAlign: 'center' }}>
          <h4 style={{ color: 'white', marginBottom: '10px' }}>🎵 {music.currentTrackName}</h4>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px', margin: '12px 0' }}>
            <button onClick={() => music.isPlaying ? music.pause() : music.resume()} style={{ width: 45, height: 45, borderRadius: '50%', background: 'white', color: '#8965e0', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.1rem', flexShrink: 0 }}>
              <i className={`fas fa-${music.isPlaying ? 'pause' : 'play'}`}></i>
            </button>
            <div style={{ flexGrow: 1, height: '6px', background: 'rgba(255,255,255,0.3)', borderRadius: '3px', overflow: 'hidden' }}>
              <div style={{ height: '100%', background: 'white', width: `${music.progress}%`, transition: 'width 0.1s linear' }}></div>
            </div>
            <button onClick={music.stop} style={{ width: 35, height: 35, borderRadius: '50%', background: 'rgba(255,255,255,0.2)', color: 'white', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.9rem', flexShrink: 0 }}>
              <i className="fas fa-stop"></i>
            </button>
          </div>
          <div style={{ display: 'flex', gap: '10px', justifyContent: 'center' }}>
            <button onClick={music.toggleMute} style={{ background: music.isMuted ? 'white' : 'rgba(255,255,255,0.2)', color: music.isMuted ? '#8965e0' : 'white', border: 'none', borderRadius: '20px', padding: '6px 12px', cursor: 'pointer', fontSize: '0.8rem' }}>
              <i className={`fas fa-volume-${music.isMuted ? 'mute' : 'up'}`}></i> {music.isMuted ? (lang === 'ar' ? 'إلغاء الكتم' : 'Unmute') : (lang === 'ar' ? 'كتم' : 'Mute')}
            </button>
            <button onClick={() => music.setVolume(music.volume - 0.1)} style={{ background: 'rgba(255,255,255,0.2)', color: 'white', border: 'none', borderRadius: '20px', padding: '6px 12px', cursor: 'pointer', fontSize: '0.8rem' }}>
              <i className="fas fa-volume-down"></i>
            </button>
            <button onClick={() => music.setVolume(music.volume + 0.1)} style={{ background: 'rgba(255,255,255,0.2)', color: 'white', border: 'none', borderRadius: '20px', padding: '6px 12px', cursor: 'pointer', fontSize: '0.8rem' }}>
              <i className="fas fa-volume-up"></i>
            </button>
          </div>
        </div>
      )}

      {/* My Music (local tracks) */}
      {localTracks.length > 0 && (
        <div style={{ background: 'white', borderRadius: '16px', padding: '15px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)', marginBottom: '20px' }}>
          <h4 style={{ color: '#32325d', marginBottom: '12px' }}>📱 {lang === 'ar' ? 'موسيقاي' : lang === 'es' ? 'Mi Música' : lang === 'fr' ? 'Ma Musique' : 'My Music'}</h4>
          {localTracks.map(track => (
            <div key={track.id} style={{
              display: 'flex', alignItems: 'center', gap: '12px', padding: '12px', borderRadius: '12px', cursor: 'pointer', marginBottom: '8px',
              background: music.currentTrackUrl === track.url ? '#f0e6ff' : '#f7fafc',
              border: music.currentTrackUrl === track.url ? '2px solid #8965e0' : '2px solid transparent',
              transition: 'all 0.3s ease',
            }}>
              <div onClick={() => isTrackPlaying(track.url) ? music.pause() : playLocalTrack(track)} style={{ display: 'flex', alignItems: 'center', gap: '12px', flex: 1 }}>
                <div style={{ width: 40, height: 40, borderRadius: '50%', background: music.currentTrackUrl === track.url ? '#8965e0' : '#d1efe1', display: 'flex', alignItems: 'center', justifyContent: 'center', color: music.currentTrackUrl === track.url ? 'white' : '#2DCE89', flexShrink: 0 }}>
                  <i className={`fas fa-${isTrackPlaying(track.url) ? 'pause' : 'play'}`}></i>
                </div>
                <div style={{ fontWeight: 600, color: '#32325d', fontSize: '0.95rem', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{track.name}</div>
              </div>
              <button onClick={() => removeLocalTrack(track.id)} style={{ background: 'none', border: 'none', color: '#f5365c', fontSize: '0.9rem', cursor: 'pointer', flexShrink: 0 }}>
                <i className="fas fa-trash"></i>
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Track list */}
      <div style={{ background: 'white', borderRadius: '16px', padding: '15px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)', marginBottom: '20px' }}>
        <h4 style={{ color: '#32325d', marginBottom: '12px' }}>🎶 {t('music.playlist')}</h4>
        {tracks.map((track, i) => {
          const name = track.title[lang as keyof typeof track.title] || track.title.en;
          const active = music.currentTrackUrl === track.url;
          return (
            <div key={i} onClick={() => isTrackPlaying(track.url) ? music.pause() : playTrack(i)} style={{
              display: 'flex', alignItems: 'center', gap: '12px', padding: '12px', borderRadius: '12px', cursor: 'pointer', marginBottom: '8px',
              background: active ? '#f0e6ff' : '#f7fafc',
              border: active ? '2px solid #8965e0' : '2px solid transparent',
              transition: 'all 0.3s ease',
            }}>
              <div style={{ width: 40, height: 40, borderRadius: '50%', background: active ? '#8965e0' : '#d1efe1', display: 'flex', alignItems: 'center', justifyContent: 'center', color: active ? 'white' : '#2DCE89', flexShrink: 0 }}>
                <i className={`fas fa-${isTrackPlaying(track.url) ? 'pause' : 'play'}`}></i>
              </div>
              <div>
                <div style={{ fontWeight: 600, color: '#32325d', fontSize: '0.95rem' }}>{name}</div>
                <div style={{ fontSize: '0.75rem', color: '#8898aa' }}>Meaningful Path Therapy</div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Benefits */}
      <div style={{ background: 'white', borderRadius: '16px', padding: '20px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
        <h4 style={{ color: '#32325d', marginBottom: '12px' }}>{t('music.benefits')}</h4>
        <ul style={{ paddingLeft: '20px', margin: 0, color: '#32325d' }}>
          <li style={{ marginBottom: '6px' }}>Reduce cortisol levels by up to 25%</li>
          <li style={{ marginBottom: '6px' }}>Lower heart rate and blood pressure</li>
          <li style={{ marginBottom: '6px' }}>Improve sleep quality</li>
          <li style={{ marginBottom: '6px' }}>Decrease anxiety and depression symptoms</li>
        </ul>
      </div>
    </div>
  );
}
