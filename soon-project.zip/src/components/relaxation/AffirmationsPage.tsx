import { useState } from 'react';

const affirmations = [
  "I am worthy of love and respect.",
  "I am capable of achieving my goals.",
  "I choose to focus on what I can control.",
  "I am grateful for the good in my life.",
  "I am strong and resilient.",
  "I deserve happiness and success.",
  "I am confident in my abilities.",
  "I am at peace with my past.",
  "I embrace change and growth.",
  "I am surrounded by positive energy.",
];

interface AffirmationsPageProps {
  onBack: () => void;
}

export default function AffirmationsPage({ onBack }: AffirmationsPageProps) {
  const [current, setCurrent] = useState<string | null>(null);

  const generate = () => {
    const idx = Math.floor(Math.random() * affirmations.length);
    setCurrent(affirmations[idx]);
  };

  return (
    <div>
      <div style={{ position: 'relative', textAlign: 'center', padding: '15px 0' }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', fontSize: '1.5rem', color: '#2DCE89', position: 'absolute', left: '20px', top: '20px', cursor: 'pointer' }}>
          <i className="fas fa-arrow-left"></i>
        </button>
        <h2 style={{ color: '#32325d', fontWeight: 700 }}>Positive Affirmations</h2>
      </div>

      <div style={{ background: 'white', borderRadius: '16px', padding: '25px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)', margin: '20px 0' }}>
        <p style={{ color: '#8898aa', marginBottom: '20px' }}>
          Positive affirmations can help improve your mental health by reinforcing positive beliefs.
        </p>
        <div style={{
          background: '#d1efe1', borderRadius: '16px',
          padding: '15px', margin: '15px 0',
          fontSize: '0.95rem', textAlign: 'center',
          borderLeft: '4px solid #2DCE89', fontStyle: 'italic',
          minHeight: '80px', display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: '#32325d',
        }}>
          {current || 'Click "Generate Affirmation" to get started.'}
        </div>
        <button
          onClick={generate}
          style={{
            background: 'linear-gradient(to right, #2DCE89, #1a9f6e)',
            color: 'white', border: 'none', borderRadius: '25px',
            padding: '12px 24px', fontWeight: 600, cursor: 'pointer',
            fontFamily: 'Poppins, sans-serif', width: '100%',
          }}
        >Generate Affirmation</button>
      </div>
    </div>
  );
}
