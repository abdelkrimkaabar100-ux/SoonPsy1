import { useState } from 'react';
import { useLocalStorage } from '../../hooks/useLocalStorage';

interface FoodPageProps {
  onBack: () => void;
}

export default function FoodPage({ onBack }: FoodPageProps) {
  const [foods, setFoods] = useLocalStorage<string[]>('soon-food-today', []);
  const [input, setInput] = useState('');

  const logFood = () => {
    if (!input.trim()) return;
    setFoods([...foods, input.trim()]);
    setInput('');
  };

  return (
    <div>
      <div style={{ position: 'relative', textAlign: 'center', padding: '15px 0' }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', fontSize: '1.5rem', color: '#2DCE89', position: 'absolute', left: '20px', top: '20px', cursor: 'pointer' }}>
          <i className="fas fa-arrow-left"></i>
        </button>
        <h2 style={{ color: '#32325d', fontWeight: 700 }}>Healthy Food Tracking</h2>
      </div>

      <div style={{ background: 'white', borderRadius: '16px', padding: '25px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)', margin: '20px 0' }}>
        <p style={{ color: '#8898aa', marginBottom: '20px' }}>
          Tracking healthy food intake helps maintain good mental health by supporting brain function and energy levels.
        </p>
        <input
          type="text"
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && logFood()}
          placeholder="Enter food item (e.g., salad, fruits)"
          style={{
            width: '100%', padding: '12px 15px',
            border: '1px solid #ddd', borderRadius: '25px',
            fontFamily: 'Poppins, sans-serif', fontSize: '1rem',
            outline: 'none', marginBottom: '15px', boxSizing: 'border-box',
          }}
        />
        <button onClick={logFood} style={{
          background: 'linear-gradient(to right, #2DCE89, #1a9f6e)',
          color: 'white', border: 'none', borderRadius: '25px',
          padding: '12px 24px', fontWeight: 600, cursor: 'pointer',
          fontFamily: 'Poppins, sans-serif', width: '100%', marginBottom: '20px',
        }}>Log Food</button>

        <h4 style={{ color: '#32325d', marginBottom: '15px' }}>Today's Healthy Foods</h4>
        {foods.length === 0 ? (
          <p style={{ color: '#8898aa' }}>No foods logged yet today.</p>
        ) : (
          <ul style={{ paddingLeft: '20px', color: '#32325d' }}>
            {foods.map((food, i) => (
              <li key={i} style={{ marginBottom: '8px' }}>{food}</li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
