import { useState, useRef } from 'react';

interface NaturePageProps {
  onBack: () => void;
}

const sounds = {
  birds: {
    url: 'https://media.blubrry.com/ambience_and_nature_sounds/content.blubrry.com/ambience_and_nature_sounds/Bird_chorus_at_sunrise_in_Danish_city_1_hour_.mp3',
    bg: 'https://images.unsplash.com/photo-1501854140801-50d01698950b?auto=format&fit=crop&w=1200&q=80',
    label: 'Birds Singing',
  },
  waves: {
    url: 'https://media.blubrry.com/ambience_and_nature_sounds/content.blubrry.com/ambience_and_nature_sounds/Ambience_Calm_ocean_rock_beach.mp3',
    bg: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=800&q=80',
    label: 'Ocean Waves',
  },
};

export default function NaturePage({ onBack }: NaturePageProps) {
  const [playing, setPlaying] = useState<'birds' | 'waves' | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const playSound = (type: 'birds' | 'waves') => {
    if (audioRef.current) { audioRef.current.pause(); }
    const audio = new Audio(sounds[type].url);
    audio.loop = true;
    audio.play().catch(() => {});
    audioRef.current = audio;
    setPlaying(type);
  };

  const stopSound = () => {
    if (audioRef.current) { audioRef.current.pause(); audioRef.current = null; }
    setPlaying(null);
  };

  return (
    <div>
      <div style={{ position: 'relative', textAlign: 'center', padding: '15px 0' }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', fontSize: '1.5rem', color: '#2DCE89', position: 'absolute', left: '20px', top: '20px', cursor: 'pointer' }}>
          <i className="fas fa-arrow-left"></i>
        </button>
        <h2 style={{ color: '#32325d', fontWeight: 700 }}>Nature Sounds</h2>
      </div>

      <div style={{ background: 'white', borderRadius: '16px', padding: '25px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)', margin: '20px 0' }}>
        <div style={{
          width: '100%', height: '200px', borderRadius: '16px', marginBottom: '20px',
          background: `linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.3)), url('${playing ? sounds[playing].bg : sounds.birds.bg}')`,
          backgroundSize: 'cover', backgroundPosition: 'center',
          transition: 'background 1s ease',
        }}></div>

        {playing && (
          <div style={{ textAlign: 'center', marginBottom: '15px', color: '#2DCE89', fontWeight: 600 }}>
            🎵 Now playing: {sounds[playing].label}
          </div>
        )}

        <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', justifyContent: 'center' }}>
          <button onClick={() => playSound('birds')} style={{
            background: 'linear-gradient(to right, #2DCE89, #1a9f6e)', color: 'white',
            border: 'none', borderRadius: '25px', padding: '12px 20px',
            fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
          }}>
            <i className="fas fa-dove" style={{ marginRight: '8px' }}></i> Birds Singing
          </button>
          <button onClick={() => playSound('waves')} style={{
            background: 'linear-gradient(to right, #11cdef, #1a9f6e)', color: 'white',
            border: 'none', borderRadius: '25px', padding: '12px 20px',
            fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
          }}>
            <i className="fas fa-water" style={{ marginRight: '8px' }}></i> Ocean Waves
          </button>
          <button onClick={stopSound} style={{
            background: '#d1efe1', color: '#2DCE89',
            border: 'none', borderRadius: '25px', padding: '12px 20px',
            fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
          }}>
            <i className="fas fa-stop" style={{ marginRight: '8px' }}></i> Stop Sound
          </button>
        </div>
      </div>
    </div>
  );
}
