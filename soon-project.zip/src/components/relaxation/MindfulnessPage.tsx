import { useState, useEffect, useRef } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';

interface MindfulnessEntry {
  date: string;
  duration: number;
  thoughts?: string;
}

interface MindfulnessPageProps {
  onBack: () => void;
}

const texts: Record<string, {
  title: string; desc: string; start: string; stop: string;
  instruction: string; done: string; sessions: string;
  intro: string; tip: string; journal_title: string;
  journal_placeholder: string; save_thoughts: string; saved: string;
  past_sessions: string; no_sessions: string; thoughts_label: string;
}> = {
  en: {
    title: '🧘 Awareness',
    desc: 'Just 5 minutes. No breathing exercises, no rules. Simply sit, observe what flows through your mind, and be present.',
    start: 'Begin 5-Minute Session',
    stop: 'End Session',
    instruction: 'Close your eyes... just sit still. Watch your thoughts come and go like clouds in the sky. Don\'t chase them. Don\'t judge them. Just observe.',
    done: '✨ Beautiful. You gave yourself the gift of stillness. Now, write down the thoughts that came to you — without judging any of them.',
    sessions: 'Awareness moments this week',
    intro: 'This is YOUR moment to just... be. No breathing techniques, no meditation rules. Just sit quietly for 5 minutes and observe whatever passes through your mind without reacting.',
    tip: '💡 Tip: If a thought feels heavy, just acknowledge it and let it pass. Every thought is valid.',
    journal_title: '📝 Your Thoughts Journal',
    journal_placeholder: 'Write the thoughts that came to you during the session... without any judgment...',
    save_thoughts: 'Save Thoughts',
    saved: '✨ Your thoughts have been saved. Remember, every thought is valid and worthy of acknowledgment.',
    past_sessions: 'Past Sessions',
    no_sessions: 'No sessions yet. Start your first awareness moment!',
    thoughts_label: 'Thoughts:',
  },
  ar: {
    title: '🧘 الوعي',
    desc: '5 دقائق فقط. لا تمارين تنفس، لا قواعد. فقط اجلس، راقب ما يدور في عقلك، وكن حاضراً.',
    start: 'ابدأ جلسة 5 دقائق',
    stop: 'إنهاء الجلسة',
    instruction: 'أغلق عينيك... فقط اجلس بهدوء. راقب أفكارك تأتي وتذهب كالغيوم في السماء. لا تلاحقها. لا تحكم عليها. فقط راقب.',
    done: '✨ رائع. لقد منحت نفسك هدية السكون. الآن، اكتب الأفكار التي جاءتك — دون الحكم على أي منها.',
    sessions: 'لحظات الوعي هذا الأسبوع',
    intro: 'هذه لحظتك أنت لتكون فقط... موجوداً. لا تمارين تنفس، لا قواعد تأمل. فقط اجلس بهدوء لمدة 5 دقائق وراقب ما يمر في ذهنك دون ردة فعل.',
    tip: '💡 نصيحة: إذا شعرت بفكرة ثقيلة، فقط اعترف بها ودعها تمر. كل فكرة صالحة.',
    journal_title: '📝 دفتر أفكارك',
    journal_placeholder: 'اكتب الأفكار التي جاءتك أثناء الجلسة... بدون أي حكم...',
    save_thoughts: 'احفظ الأفكار',
    saved: '✨ تم حفظ أفكارك. تذكر، كل فكرة صالحة وتستحق الاعتراف بها.',
    past_sessions: 'الجلسات السابقة',
    no_sessions: 'لا توجد جلسات بعد. ابدأ أول لحظة وعي!',
    thoughts_label: 'الأفكار:',
  },
  es: {
    title: '🧘 Conciencia',
    desc: 'Solo 5 minutos. Sin ejercicios de respiración, sin reglas. Simplemente siéntate, observa y está presente.',
    start: 'Iniciar sesión de 5 minutos',
    stop: 'Terminar sesión',
    instruction: 'Cierra los ojos... simplemente siéntate. Observa tus pensamientos ir y venir como nubes en el cielo.',
    done: '✨ Hermoso. Ahora, escribe los pensamientos que vinieron a ti — sin juzgar ninguno.',
    sessions: 'Momentos de conciencia esta semana',
    intro: 'Este es TU momento para simplemente... ser. Sin técnicas, sin reglas. Solo 5 minutos de observar tu mente.',
    tip: '💡 Consejo: Si un pensamiento se siente pesado, solo reconócelo y déjalo pasar.',
    journal_title: '📝 Tu Diario de Pensamientos',
    journal_placeholder: 'Escribe los pensamientos que vinieron durante la sesión... sin juicio...',
    save_thoughts: 'Guardar Pensamientos',
    saved: '✨ Tus pensamientos han sido guardados.',
    past_sessions: 'Sesiones Anteriores',
    no_sessions: 'No hay sesiones aún.',
    thoughts_label: 'Pensamientos:',
  },
  fr: {
    title: '🧘 Conscience',
    desc: '5 minutes seulement. Pas d\'exercices de respiration, pas de règles. Observez simplement et soyez présent.',
    start: 'Démarrer la session de 5 min',
    stop: 'Terminer la session',
    instruction: 'Fermez les yeux... restez simplement assis. Regardez vos pensées aller et venir comme des nuages.',
    done: '✨ Magnifique. Maintenant, écrivez les pensées qui vous sont venues — sans juger.',
    sessions: 'Moments de conscience cette semaine',
    intro: 'C\'est VOTRE moment pour simplement... être. Pas de techniques, pas de règles. Juste 5 minutes d\'observation.',
    tip: '💡 Conseil: Si une pensée semble lourde, reconnaissez-la et laissez-la passer.',
    journal_title: '📝 Votre Journal de Pensées',
    journal_placeholder: 'Écrivez les pensées qui sont venues pendant la session... sans jugement...',
    save_thoughts: 'Sauvegarder',
    saved: '✨ Vos pensées ont été sauvegardées.',
    past_sessions: 'Sessions Précédentes',
    no_sessions: 'Pas encore de sessions.',
    thoughts_label: 'Pensées:',
  },
};

export default function MindfulnessPage({ onBack }: MindfulnessPageProps) {
  const { lang } = useLanguage();
  const tx = texts[lang] || texts.en;
  const [sessions, setSessions] = useLocalStorage<MindfulnessEntry[]>('soon-mindfulness', []);
  const [isRunning, setIsRunning] = useState(false);
  const [timeLeft, setTimeLeft] = useState(5 * 60);
  const [showJournal, setShowJournal] = useState(false);
  const [thoughts, setThoughts] = useState('');
  const [savedMsg, setSavedMsg] = useState('');
  const [showPast, setShowPast] = useState(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (isRunning && timeLeft > 0) {
      intervalRef.current = setInterval(() => {
        setTimeLeft(t => {
          if (t <= 1) {
            setIsRunning(false);
            setShowJournal(true);
            return 0;
          }
          return t - 1;
        });
      }, 1000);
    }
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [isRunning]);

  const start = () => {
    setTimeLeft(5 * 60);
    setIsRunning(true);
    setShowJournal(false);
    setThoughts('');
    setSavedMsg('');
  };

  const stop = () => {
    setIsRunning(false);
    if (intervalRef.current) clearInterval(intervalRef.current);
    setShowJournal(true);
  };

  const saveThoughts = () => {
    setSessions(prev => [...prev, { date: new Date().toISOString(), duration: 5, thoughts: thoughts.trim() || undefined }]);
    setSavedMsg(tx.saved);
    setThoughts('');
    setTimeout(() => { setShowJournal(false); setSavedMsg(''); }, 3000);
  };

  const formatTime = (s: number) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;

  const weekStart = new Date();
  weekStart.setDate(weekStart.getDate() - weekStart.getDay());
  weekStart.setHours(0, 0, 0, 0);
  const weekSessions = sessions.filter(s => new Date(s.date) >= weekStart).length;

  return (
    <div>
      <div style={{ position: 'relative', textAlign: 'center', padding: '15px 0' }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', fontSize: '1.5rem', color: '#667eea', position: 'absolute', left: '20px', top: '20px', cursor: 'pointer' }}>
          <i className="fas fa-arrow-left"></i>
        </button>
        <h2 style={{ color: '#32325d', fontWeight: 700 }}>{tx.title}</h2>
      </div>

      <div style={{ background: 'white', borderRadius: '16px', padding: '25px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)', margin: '20px 0' }}>
        <p style={{ color: '#8898aa', marginBottom: '20px', lineHeight: 1.7, textAlign: 'center' }}>{tx.desc}</p>

        {!isRunning && !showJournal && (
          <div>
            <div style={{ background: 'linear-gradient(135deg, #667eea22, #764ba222)', borderRadius: '16px', padding: '20px', marginBottom: '20px', borderLeft: '4px solid #667eea' }}>
              <p style={{ margin: 0, fontSize: '0.9rem', color: '#32325d', lineHeight: 1.8 }}>{tx.intro}</p>
            </div>
            <div style={{ background: '#f0fdf4', borderRadius: '12px', padding: '15px', marginBottom: '20px', borderLeft: '4px solid #10b981' }}>
              <p style={{ margin: 0, fontSize: '0.85rem', color: '#065f46', lineHeight: 1.6 }}>{tx.tip}</p>
            </div>
            <button onClick={start} style={{
              width: '100%', background: 'linear-gradient(135deg, #667eea, #764ba2)', color: 'white',
              border: 'none', borderRadius: '16px', padding: '18px', fontWeight: 700, cursor: 'pointer',
              fontSize: '1.1rem', fontFamily: 'Poppins, sans-serif',
            }}>
              🧘 {tx.start}
            </button>
          </div>
        )}

        {isRunning && (
          <div style={{ textAlign: 'center' }}>
            {/* Simple awareness circle - no breathing */}
            <div style={{
              width: '180px', height: '180px', borderRadius: '50%', margin: '0 auto 20px',
              background: 'radial-gradient(circle, #667eea22, transparent)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column',
              border: '3px solid #667eea33',
              animation: 'pulse 3s ease-in-out infinite',
            }}>
              <div style={{ fontSize: '2.5rem', fontWeight: 700, color: '#667eea' }}>{formatTime(timeLeft)}</div>
            </div>

            <p style={{ color: '#8898aa', fontSize: '0.9rem', lineHeight: 1.8, margin: '20px 0' }}>
              {tx.instruction}
            </p>

            <button onClick={stop} style={{
              background: '#f0f0f0', color: '#666', border: 'none', borderRadius: '25px',
              padding: '12px 30px', fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif', marginTop: '20px',
            }}>
              {tx.stop}
            </button>
          </div>
        )}

        {showJournal && (
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: '4rem', marginBottom: '15px' }}>🌿</div>
            <p style={{ color: '#32325d', fontSize: '1rem', lineHeight: 1.8, fontWeight: 500, marginBottom: '20px' }}>
              {tx.done}
            </p>
            
            {/* Journal for writing thoughts */}
            <div style={{ background: '#f8f9ff', borderRadius: '16px', padding: '20px', marginBottom: '20px', textAlign: 'left' }}>
              <h4 style={{ color: '#667eea', marginBottom: '12px', textAlign: 'center' }}>{tx.journal_title}</h4>
              <textarea
                value={thoughts}
                onChange={e => setThoughts(e.target.value)}
                placeholder={tx.journal_placeholder}
                style={{
                  width: '100%', minHeight: '150px', padding: '15px', border: '2px solid #667eea33',
                  borderRadius: '12px', fontSize: '0.95rem', fontFamily: 'Poppins, sans-serif',
                  resize: 'vertical', boxSizing: 'border-box', lineHeight: 1.8, outline: 'none',
                  direction: lang === 'ar' ? 'rtl' : 'ltr',
                }}
              />
              <button onClick={saveThoughts} style={{
                width: '100%', background: 'linear-gradient(135deg, #667eea, #764ba2)', color: 'white',
                border: 'none', borderRadius: '12px', padding: '14px', fontWeight: 600,
                cursor: 'pointer', fontFamily: 'Poppins, sans-serif', marginTop: '12px',
              }}>
                📝 {tx.save_thoughts}
              </button>
            </div>

            {savedMsg && (
              <div style={{ padding: '12px', background: '#ecfdf5', borderRadius: '12px', color: '#065f46', fontSize: '0.9rem', marginBottom: '15px' }}>
                {savedMsg}
              </div>
            )}

            <button onClick={() => { setShowJournal(false); }} style={{
              background: '#f0f0f0', color: '#666', border: 'none', borderRadius: '25px',
              padding: '10px 25px', fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
            }}>
              🧘 {tx.start}
            </button>
          </div>
        )}

        {/* Weekly counter */}
        <div style={{ display: 'flex', justifyContent: 'center', marginTop: '20px' }}>
          <div style={{ background: '#667eea11', borderRadius: '16px', padding: '15px 30px', textAlign: 'center' }}>
            <div style={{ fontSize: '0.75rem', color: '#8898aa' }}>{tx.sessions}</div>
            <div style={{ fontSize: '1.8rem', fontWeight: 700, color: '#667eea' }}>{weekSessions}</div>
          </div>
        </div>
      </div>

      {/* Past sessions with thoughts */}
      <button onClick={() => setShowPast(!showPast)} style={{
        width: '100%', background: showPast ? '#667eea' : 'white', color: showPast ? 'white' : '#667eea',
        border: '2px solid #667eea', borderRadius: '12px', padding: '12px', fontWeight: 600,
        cursor: 'pointer', fontFamily: 'Poppins, sans-serif', marginBottom: '15px',
      }}>
        <i className={`fas fa-${showPast ? 'chevron-up' : 'history'}`} style={{ marginRight: '8px' }}></i>
        {tx.past_sessions}
      </button>

      {showPast && (
        <div style={{ background: 'white', borderRadius: '16px', padding: '15px', marginBottom: '20px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)', maxHeight: '400px', overflowY: 'auto' }}>
          {sessions.length === 0 ? (
            <p style={{ color: '#8898aa', textAlign: 'center' }}>{tx.no_sessions}</p>
          ) : (
            [...sessions].reverse().slice(0, 20).map((s, i) => (
              <div key={i} style={{ padding: '12px', borderRadius: '12px', background: '#f8f9ff', marginBottom: '10px', borderLeft: '4px solid #667eea' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: s.thoughts ? '8px' : '0' }}>
                  <span style={{ color: '#667eea', fontWeight: 600, fontSize: '0.85rem' }}>🧘 {s.duration} min</span>
                  <span style={{ color: '#8898aa', fontSize: '0.75rem' }}>{new Date(s.date).toLocaleDateString()}</span>
                </div>
                {s.thoughts && (
                  <div style={{ color: '#32325d', fontSize: '0.85rem', lineHeight: 1.7, padding: '8px', background: 'white', borderRadius: '8px' }}>
                    <span style={{ color: '#8898aa', fontSize: '0.75rem' }}>{tx.thoughts_label}</span><br/>
                    {s.thoughts}
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}
