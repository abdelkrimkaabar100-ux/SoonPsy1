import { useState } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';

interface BirthdayData {
  userBirthday: string;
  petBirthday: string;
}

interface LoveEntry {
  target: string;
  message: string;
  date: string;
}

export default function LoveExpressionSection() {
  const { t, lang } = useLanguage();
  const [birthdays, setBirthdays] = useLocalStorage<BirthdayData>('soon-birthdays', { userBirthday: '', petBirthday: '' });
  const [loveEntries, setLoveEntries] = useLocalStorage<LoveEntry[]>('soon-love-expressions', []);
  const [selectedTarget, setSelectedTarget] = useState('');
  const [loveMessage, setLoveMessage] = useState('');

  const loveTargets = [
    { id: 'loved-ones', icon: '❤️', key: 'love.loved_ones' },
    { id: 'humanity', icon: '🌍', key: 'love.humanity' },
    { id: 'animals', icon: '🐾', key: 'love.animals' },
    { id: 'all-beings', icon: '✨', key: 'love.all_beings' },
    { id: 'universe', icon: '🌌', key: 'love.universe' },
  ];

  const addLove = () => {
    if (!selectedTarget || !loveMessage.trim()) return;
    setLoveEntries(prev => [...prev, { target: selectedTarget, message: loveMessage.trim(), date: new Date().toISOString() }]);
    setLoveMessage('');
  };

  const today = new Date().toDateString();
  const todayLove = loveEntries.filter(e => new Date(e.date).toDateString() === today);

  const getDaysUntilBirthday = (dateStr: string) => {
    if (!dateStr) return null;
    const now = new Date();
    const bd = new Date(dateStr);
    bd.setFullYear(now.getFullYear());
    if (bd < now) bd.setFullYear(now.getFullYear() + 1);
    return Math.ceil((bd.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
  };

  const userDays = getDaysUntilBirthday(birthdays.userBirthday);
  const petDays = getDaysUntilBirthday(birthdays.petBirthday);

  return (
    <>
      {/* Birthdays */}
      <div style={{
        background: 'white', borderRadius: '16px', padding: '15px', marginBottom: '20px',
        boxShadow: '0 6px 20px rgba(0,0,0,0.08)', border: '2px solid #ffe0e6',
      }}>
        <h4 style={{ color: '#ff6b6b', marginBottom: '12px', textAlign: 'center' }}>🎂 {t('love.birthdays')}</h4>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
          <div>
            <label style={{ fontSize: '0.8rem', fontWeight: 600, color: '#32325d', display: 'block', marginBottom: '4px' }}>
              🧑 {t('love.your_birthday')}
            </label>
            <input type="date" value={birthdays.userBirthday}
              onChange={e => setBirthdays({ ...birthdays, userBirthday: e.target.value })}
              style={{ width: '100%', padding: '8px', border: '1px solid #ffe0e6', borderRadius: '12px', fontFamily: 'Poppins, sans-serif', fontSize: '0.8rem', outline: 'none', boxSizing: 'border-box' }}
            />
            {userDays !== null && userDays <= 30 && (
              <div style={{ fontSize: '0.75rem', color: '#ff6b6b', marginTop: '4px', fontWeight: 600 }}>
                {userDays === 0 ? '🎉 🎂!' : `🎈 ${userDays} ${t('love.days_left')}`}
              </div>
            )}
          </div>
          <div>
            <label style={{ fontSize: '0.8rem', fontWeight: 600, color: '#32325d', display: 'block', marginBottom: '4px' }}>
              🐾 {t('love.pet_birthday')}
            </label>
            <input type="date" value={birthdays.petBirthday}
              onChange={e => setBirthdays({ ...birthdays, petBirthday: e.target.value })}
              style={{ width: '100%', padding: '8px', border: '1px solid #ffe0e6', borderRadius: '12px', fontFamily: 'Poppins, sans-serif', fontSize: '0.8rem', outline: 'none', boxSizing: 'border-box' }}
            />
            {petDays !== null && petDays <= 30 && (
              <div style={{ fontSize: '0.75rem', color: '#ff6b6b', marginTop: '4px', fontWeight: 600 }}>
                {petDays === 0 ? '🎉 🐾🎂!' : `🎈 ${petDays} ${t('love.days_left')}`}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Love Expression */}
      <div style={{
        background: 'white', borderRadius: '16px', padding: '15px', marginBottom: '20px',
        boxShadow: '0 6px 20px rgba(0,0,0,0.08)', border: '2px solid #ffe0e6',
      }}>
        <h4 style={{ color: '#ff6b6b', marginBottom: '6px', textAlign: 'center', fontSize: '1.1rem' }}>
          💝 {t('love.express_title')}
        </h4>
        <p style={{ fontSize: '0.8rem', color: '#8898aa', textAlign: 'center', marginBottom: '12px' }}>
          {t('love.express_desc')}
        </p>

        {/* Targets */}
        <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', justifyContent: 'center', marginBottom: '12px' }}>
          {loveTargets.map(lt => (
            <button key={lt.id} onClick={() => setSelectedTarget(lt.id)} style={{
              background: selectedTarget === lt.id ? 'linear-gradient(135deg, #ff6b6b, #ee5a24)' : '#fff0f3',
              color: selectedTarget === lt.id ? 'white' : '#ff6b6b',
              border: 'none', borderRadius: '20px', padding: '8px 12px', fontSize: '0.75rem', fontWeight: 600,
              cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
            }}>
              {lt.icon} {t(lt.key)}
            </button>
          ))}
        </div>

        {selectedTarget && (
          <div style={{ display: 'flex', gap: '8px' }}>
            <input type="text" value={loveMessage} onChange={e => setLoveMessage(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && addLove()}
              placeholder={t('love.message_placeholder')}
              style={{ flex: 1, padding: '10px 15px', border: '1px solid #ffe0e6', borderRadius: '25px', fontFamily: 'Poppins, sans-serif', fontSize: '0.85rem', outline: 'none' }}
            />
            <button onClick={addLove} style={{
              background: '#ff6b6b', color: 'white', border: 'none', borderRadius: '50%',
              width: 38, height: 38, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
              cursor: 'pointer',
            }}>💝</button>
          </div>
        )}

        {todayLove.length > 0 && (
          <div style={{ marginTop: '12px', display: 'flex', flexDirection: 'column', gap: '6px' }}>
            {todayLove.map((e, i) => {
              const target = loveTargets.find(lt => lt.id === e.target);
              return (
                <div key={i} style={{
                  background: 'linear-gradient(135deg, #fff0f3, #ffe0e6)', borderRadius: '12px', padding: '10px',
                  fontSize: '0.85rem', color: '#32325d',
                }}>
                  <span>{target?.icon} </span>
                  <strong>{t(target?.key || '')}: </strong>
                  {e.message}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </>
  );
}
