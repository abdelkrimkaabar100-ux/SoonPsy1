import { useState, useRef, useEffect } from 'react';

import PetNutrition from './PetNutrition';
// Note: useLocalStorage is used both in PetPage and MercyDay
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { useLanguage } from '../../i18n/LanguageContext';
import LoveExpressionSection from './LoveExpressionSection';

interface PetData { name: string; type: string; age: string; breed: string; }
interface TrackerEntry { value: number; date: string; }
interface FoodEntry { food: string; date: string; }
interface ActivityEntry { activity: string; minutes: number; date: string; }
interface PetBathroomEntry { type: string; date: string; }
interface PetBathEntry { date: string; }
interface PetPageProps { onShareWithAI: (text: string) => void; }

const petMoodFeedback: Record<string, Record<string, string>> = {
  en: { active: '⚡ Your pet is energetic! Great time for play and exercise.', lethargic: '😴 Your pet seems low energy. Check hydration and nutrition.', aggressive: '😠 Your pet may be stressed. Give them space.', friendly: '❤️ Your pet is in a great mood! Perfect time for bonding.' },
  ar: { active: '⚡ حيوانك نشيط! وقت رائع للعب.', lethargic: '😴 حيوانك منخفض الطاقة.', aggressive: '😠 حيوانك قد يكون متوتراً.', friendly: '❤️ حيوانك في مزاج رائع!' },
  es: { active: '⚡ ¡Tu mascota está enérgica!', lethargic: '😴 Tu mascota parece baja de energía.', aggressive: '😠 Tu mascota puede estar estresada.', friendly: '❤️ ¡Tu mascota está de buen humor!' },
  fr: { active: '⚡ Votre animal est énergique!', lethargic: '😴 Votre animal semble fatigué.', aggressive: '😠 Votre animal est stressé.', friendly: '❤️ Votre animal est de bonne humeur!' },
};

const presetDurations = [
  { label: { en: '5 min', ar: '5 دقائق', es: '5 min', fr: '5 min' }, value: 5 },
  { label: { en: '10 min', ar: '10 دقائق', es: '10 min', fr: '10 min' }, value: 10 },
  { label: { en: '15 min', ar: '15 دقائق', es: '15 min', fr: '15 min' }, value: 15 },
  { label: { en: '30 min', ar: '30 دقيقة', es: '30 min', fr: '30 min' }, value: 30 },
];

export default function PetPage({ onShareWithAI }: PetPageProps) {
  const { t, lang } = useLanguage();
  const [petData, setPetData] = useLocalStorage<PetData>('soon-pet', { name: '', type: '', age: '', breed: '' });
  const [petSleepLog, setPetSleepLog] = useLocalStorage<TrackerEntry[]>('soon-pet-sleep', []);
  const [petExerciseLog, setPetExerciseLog] = useLocalStorage<TrackerEntry[]>('soon-pet-exercise', []);
  const [petFoodLog] = useLocalStorage<FoodEntry[]>('soon-pet-food-log', []);
  const [petActivityLog, setPetActivityLog] = useLocalStorage<ActivityEntry[]>('soon-pet-activity-log', []);
  const [petBathroomLog, setPetBathroomLog] = useLocalStorage<PetBathroomEntry[]>('soon-pet-bathroom', []);
  const [petBathLog, setPetBathLog] = useLocalStorage<PetBathEntry[]>('soon-pet-bath', []);
  const [selectedMood, setSelectedMood] = useState('');
  const [showHistory, setShowHistory] = useState(false);
  const [petCareMsg, setPetCareMsg] = useState('');
  const [activeTimer, setActiveTimer] = useState<string | null>(null);
  const [timerMinutes, setTimerMinutes] = useState(0);
  const [timeLeft, setTimeLeft] = useState(0);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (activeTimer && timeLeft > 0) {
      intervalRef.current = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            clearInterval(intervalRef.current!);
            setPetActivityLog(old => [...old, { activity: activeTimer, minutes: timerMinutes, date: new Date().toISOString() }]);
            setPetExerciseLog(old => [...old, { value: timerMinutes, date: new Date().toISOString() }]);
            setActiveTimer(null);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [activeTimer, timeLeft]);

  const petTypes: Record<string, string> = { dog: '🐕', cat: '🐈', bird: '🦜', fish: '🐠', rabbit: '🐇', hamster: '🐹', other: '🐾' };
  const today = new Date().toDateString();
  const getTodayValue = (log: TrackerEntry[]) => log.filter(e => new Date(e.date).toDateString() === today).reduce((s, e) => s + e.value, 0);
  const formatTime = (s: number) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;

  const editPet = () => {
    const name = prompt(t('pet.name') + ':', petData.name); if (name === null) return;
    const type = prompt(t('pet.type') + ' (dog/cat/bird/fish/rabbit/hamster/other):', petData.type); if (type === null) return;
    const age = prompt(t('pet.age') + ':', petData.age);
    const breed = prompt(t('pet.breed') + ':', petData.breed);
    setPetData({ name: name || petData.name, type: type || petData.type, age: age || petData.age, breed: breed || petData.breed });
  };

  const logPetSleep = () => {
    const hrs = parseFloat(prompt(t('sleep.prompt')) || '0');
    if (hrs > 0) setPetSleepLog([...petSleepLog, { value: hrs, date: new Date().toISOString() }]);
  };


  const startActivity = (activity: string, mins: number) => {
    setTimerMinutes(mins);
    setTimeLeft(mins * 60);
    setActiveTimer(activity);
  };

  const stopActivity = () => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    const elapsed = timerMinutes - Math.ceil(timeLeft / 60);
    if (elapsed > 0 && activeTimer) {
      setPetActivityLog([...petActivityLog, { activity: activeTimer, minutes: elapsed, date: new Date().toISOString() }]);
      setPetExerciseLog([...petExerciseLog, { value: elapsed, date: new Date().toISOString() }]);
    }
    setActiveTimer(null); setTimeLeft(0);
  };

  const shareAllWithAI = () => {
    const todayFoods = petFoodLog.filter(f => new Date(f.date).toDateString() === today).map(f => f.food);
    const todayActivities = petActivityLog.filter(a => new Date(a.date).toDateString() === today);
    onShareWithAI(`My pet ${petData.name || 'N/A'} (${petData.type}, ${petData.age}, ${petData.breed}): Sleep today ${getTodayValue(petSleepLog)}h, Exercise ${getTodayValue(petExerciseLog)}min, Food: ${todayFoods.join(', ') || 'none'}, Activities: ${todayActivities.map(a => `${a.activity} ${a.minutes}min`).join(', ') || 'none'}, Mood: ${selectedMood || 'not set'}`);
  };

  // History
  const allHistory = [
    ...petSleepLog.map(e => ({ type: 'sleep', value: `${e.value}h`, date: e.date })),
    ...petExerciseLog.map(e => ({ type: 'exercise', value: `${e.value}min`, date: e.date })),
    ...petFoodLog.map(e => ({ type: 'food', value: e.food, date: e.date })),
    ...petActivityLog.map(e => ({ type: e.activity, value: `${e.minutes}min`, date: e.date })),
    ...petBathroomLog.map(e => ({ type: 'bathroom', value: t(`pet.bathroom_${e.type}`), date: e.date })),
    ...petBathLog.map(e => ({ type: 'bath', value: '🛁', date: e.date })),
  ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const groupedHistory = allHistory.reduce<Record<string, typeof allHistory>>((acc, e) => {
    const key = new Date(e.date).toLocaleDateString();
    if (!acc[key]) acc[key] = [];
    acc[key].push(e);
    return acc;
  }, {});
  const historyDates = Object.keys(groupedHistory).sort((a, b) => new Date(b).getTime() - new Date(a).getTime()).slice(0, 14);

  const typeIcons: Record<string, string> = { sleep: '💤', exercise: '💪', food: '🦴', walk: '🚶', play: '🎮', dance: '💃', groom: '✨', train: '🎓', bathroom: '🚽', bath: '🛁' };
  const petEmoji = petTypes[petData.type] || '🐾';
  const feedback = (petMoodFeedback[lang] || petMoodFeedback.en);

  const activities = [
    { id: 'walk', icon: '🚶', labelKey: 'pet.walk' },
    { id: 'play', icon: '🎮', labelKey: 'pet.play' },
    { id: 'dance', icon: '💃', labelKey: 'pet.dance' },
    { id: 'groom', icon: '✨', labelKey: 'pet.groom' },
    { id: 'train', icon: '🎓', labelKey: 'pet.train' },
  ];

  const [selectedActivity, setSelectedActivity] = useState<string | null>(null);

  return (
    <div>
      <h2 style={{ fontSize: '1.8rem', fontWeight: 700, color: '#32325d', margin: '25px 0', textAlign: 'center', position: 'relative' }}>
        ❤️ {t('pet.title')} ❤️
        <div style={{ position: 'absolute', bottom: '-10px', left: '50%', transform: 'translateX(-50%)', width: '80px', height: '4px', background: 'linear-gradient(to right, #ff6b6b, #ee5a24)', borderRadius: '2px' }}></div>
      </h2>

      {/* Pet avatar */}
      <div style={{ textAlign: 'center', marginBottom: '20px', marginTop: '20px' }}>
        <div style={{ width: 120, height: 120, borderRadius: '50%', margin: '0 auto 15px', background: 'linear-gradient(135deg, #ff9a9e, #fecfef, #a18cd1)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '3rem', border: '4px solid white', boxShadow: '0 6px 25px rgba(255,107,107,0.3)' }}>{petEmoji}</div>
        <h3 style={{ color: '#32325d', margin: '0 0 5px' }}>{petData.name || t('pet.not_set')}</h3>
        <p style={{ color: '#8898aa', margin: 0 }}>{petData.type || t('pet.not_set')}</p>
      </div>

      {/* Pet Info */}
      <div style={{ background: 'white', borderRadius: '16px', padding: '15px', marginBottom: '20px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)', border: '2px solid #ffe0e6' }}>
        <h4 style={{ color: '#ff6b6b', marginBottom: '10px', textAlign: 'center' }}>💕 {t('pet.info')}</h4>
        {[{ label: t('pet.name'), value: petData.name }, { label: t('pet.type'), value: petData.type }, { label: t('pet.age'), value: petData.age }, { label: t('pet.breed'), value: petData.breed }].map(item => (
          <div key={item.label} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px', paddingBottom: '8px', borderBottom: '1px solid #fff0f3' }}>
            <span style={{ fontWeight: 600, color: '#32325d' }}>{item.label}:</span>
            <span style={{ color: '#8898aa' }}>{item.value || t('pet.not_set')}</span>
          </div>
        ))}
        <button onClick={editPet} style={{ background: 'linear-gradient(to right, #ff6b6b, #ee5a24)', color: 'white', border: 'none', borderRadius: '25px', padding: '12px', fontWeight: 600, cursor: 'pointer', width: '100%', marginTop: '10px', fontFamily: 'Poppins, sans-serif' }}>❤️ {t('pet.edit')}</button>
        <button onClick={shareAllWithAI} style={{ background: '#ffe0e6', color: '#ff6b6b', border: 'none', borderRadius: '25px', padding: '12px', fontWeight: 600, cursor: 'pointer', width: '100%', marginTop: '10px', fontFamily: 'Poppins, sans-serif' }}>💬 {t('pet.share')}</button>
      </div>

      <MultiPetManager activePetName={petData.name} onSelect={(name) => setPetData({ ...petData, name })} lang={lang} />

      {/* Sleep & Exercise */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '20px' }}>
        <div style={{ background: 'white', borderRadius: '16px', padding: '15px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)', textAlign: 'center', border: '2px solid #e8daff' }}>
          <h4 style={{ color: '#8965e0', marginBottom: '10px', fontSize: '0.95rem' }}>💤 {t('pet.sleep')}</h4>
          <div style={{ fontSize: '2rem', fontWeight: 700, color: '#8965e0' }}>{getTodayValue(petSleepLog)}h</div>
          <button onClick={logPetSleep} style={{ background: '#8965e0', color: 'white', border: 'none', borderRadius: '25px', padding: '8px 16px', fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif', marginTop: '10px', fontSize: '0.85rem' }}>💤 {t('pet.log_sleep')}</button>
        </div>
        <div style={{ background: 'white', borderRadius: '16px', padding: '15px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)', textAlign: 'center', border: '2px solid #ffe0e6' }}>
          <h4 style={{ color: '#ff6b6b', marginBottom: '10px', fontSize: '0.95rem' }}>💪 {t('pet.exercise')}</h4>
          <div style={{ fontSize: '2rem', fontWeight: 700, color: '#ff6b6b' }}>{getTodayValue(petExerciseLog)}m</div>
          <div style={{ fontSize: '0.8rem', color: '#8898aa', marginBottom: 8 }}>{t('pet.minutes_today')}</div>
          <button onClick={() => {
            const v = parseFloat(prompt(lang === 'ar' ? 'كم دقيقة تمرّن حيوانك؟ (أدخل أي رقم)' : 'How many minutes did your pet exercise? (any number)') || '0');
            if (v > 0) setPetExerciseLog(prev => [...prev, { value: v, date: new Date().toISOString() }]);
          }} style={{ background: '#ff6b6b', color: 'white', border: 'none', borderRadius: '20px', padding: '6px 14px', fontWeight: 600, cursor: 'pointer', fontSize: '0.75rem' }}>
            ➕ {lang === 'ar' ? 'سجل يدوياً' : 'Log manually'}
          </button>
        </div>
      </div>

      {/* Pet Food is now in PetNutrition component */}

      {/* Activities with preset durations */}
      <h3 style={{ fontSize: '1.1rem', color: '#32325d', marginBottom: '15px', paddingBottom: '10px', borderBottom: '2px solid #ffe0e6', textAlign: 'center' }}>❤️ {t('pet.activities')} ❤️</h3>

      {activeTimer && (
        <div style={{ background: 'linear-gradient(135deg, #ff6b6b, #ee5a24)', borderRadius: '16px', padding: '20px', marginBottom: '15px', textAlign: 'center', color: 'white', boxShadow: '0 6px 20px rgba(255,107,107,0.3)' }}>
          <h4 style={{ color: 'white', marginBottom: '10px' }}>❤️ {activeTimer} 🐾</h4>
          <div style={{ fontSize: '2.5rem', fontWeight: 700, fontFamily: 'Poppins, sans-serif' }}>{formatTime(timeLeft)}</div>
          <button onClick={stopActivity} style={{ background: 'white', color: '#ff6b6b', border: 'none', borderRadius: '25px', padding: '10px 24px', fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif', marginTop: '15px' }}>{t('pet.walk_stop')}</button>
        </div>
      )}

      {!activeTimer && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(90px, 1fr))', gap: '10px', marginBottom: '15px' }}>
          {activities.map(a => (
            <div key={a.id} onClick={() => setSelectedActivity(selectedActivity === a.id ? null : a.id)}
              style={{ background: selectedActivity === a.id ? 'linear-gradient(135deg, #ff6b6b, #ee5a24)' : 'white', color: selectedActivity === a.id ? 'white' : '#ff6b6b', padding: '12px 8px', borderRadius: '16px', textAlign: 'center', cursor: 'pointer', transition: 'all 0.3s ease', border: '2px solid #ffe0e6', boxShadow: selectedActivity === a.id ? '0 4px 15px rgba(255,107,107,0.3)' : 'none' }}>
              <div style={{ fontSize: '1.5rem', marginBottom: '4px' }}>{a.icon}</div>
              <div style={{ fontSize: '0.75rem', fontWeight: 600 }}>{t(a.labelKey)}</div>
            </div>
          ))}
        </div>
      )}

      {selectedActivity && !activeTimer && (
        <div style={{ background: '#fff0f3', borderRadius: '16px', padding: '15px', marginBottom: '20px', textAlign: 'center' }}>
          <p style={{ color: '#ff6b6b', fontWeight: 600, marginBottom: '10px', fontSize: '0.9rem' }}>
            {lang === 'ar' ? 'اختر المدة:' : lang === 'es' ? 'Elige duración:' : lang === 'fr' ? 'Choisir la durée:' : 'Choose duration:'}
          </p>
          <div style={{ display: 'flex', gap: '8px', justifyContent: 'center', flexWrap: 'wrap' }}>
            {presetDurations.map(d => (
              <button key={d.value} onClick={() => startActivity(selectedActivity, d.value)}
                style={{ background: 'linear-gradient(135deg, #ff6b6b, #ee5a24)', color: 'white', border: 'none', borderRadius: '20px', padding: '10px 18px', fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif', fontSize: '0.85rem' }}>
                ❤️ {d.label[lang as keyof typeof d.label] || d.label.en}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Pet Mood */}
      <div style={{ background: 'white', borderRadius: '16px', padding: '20px', marginBottom: '20px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)', textAlign: 'center', border: '2px solid #ffe0e6' }}>
        <h4 style={{ color: '#ff6b6b', marginBottom: '15px' }}>❤️ {t('pet.mood_question')}</h4>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '10px', marginBottom: '15px' }}>
          {[{ mood: 'active', icon: '⚡' }, { mood: 'lethargic', icon: '😴' }, { mood: 'aggressive', icon: '😠' }, { mood: 'friendly', icon: '❤️' }].map(opt => (
            <div key={opt.mood} onClick={() => setSelectedMood(opt.mood)} style={{
              padding: '12px 8px', border: `2px solid ${selectedMood === opt.mood ? '#ff6b6b' : '#ffe0e6'}`,
              borderRadius: '12px', cursor: 'pointer', background: selectedMood === opt.mood ? '#fff0f3' : 'white',
            }}>
              <div style={{ fontSize: '1.5rem' }}>{opt.icon}</div>
              <div style={{ fontSize: '0.7rem', color: '#8898aa', marginTop: '4px' }}>{opt.mood}</div>
            </div>
          ))}
        </div>
        {selectedMood && <div style={{ padding: '12px', background: '#fff0f3', borderRadius: '12px', fontSize: '0.9rem', color: '#32325d' }}>{feedback[selectedMood]}</div>}
      </div>

      {/* Pet Bathroom Tracker */}
      <div style={{ background: 'white', borderRadius: '16px', padding: '18px', marginBottom: '20px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)', border: '2px solid #e8daff' }}>
        <h4 style={{ color: '#8965e0', marginBottom: '12px', textAlign: 'center', fontSize: '1rem' }}>🚽 {t('pet.bathroom_title')}</h4>
        <p style={{ color: '#8898aa', fontSize: '0.8rem', textAlign: 'center', marginBottom: '15px' }}>
          {lang === 'ar' ? 'تتبع عادات حيوانك لفهم مستوى راحته النفسية' : 'Track your pet\'s habits to understand their comfort level'}
        </p>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '8px', marginBottom: '12px' }}>
          {[
            { type: 'normal', icon: '✅', color: '#10b981' },
            { type: 'abnormal', icon: '⚠️', color: '#f59e0b' },
            { type: 'none', icon: '❌', color: '#ef4444' },
          ].map(bt => (
            <button key={bt.type} onClick={() => {
              setPetBathroomLog(prev => [...prev, { type: bt.type, date: new Date().toISOString() }]);
              if (bt.type === 'normal') setPetCareMsg(t('pet.bathroom_normal_msg'));
              else setPetCareMsg(t('pet.bathroom_alert'));
            }} style={{
              background: 'white', border: `2px solid ${bt.color}33`, borderRadius: '12px', padding: '12px 6px',
              cursor: 'pointer', textAlign: 'center',
            }}>
              <div style={{ fontSize: '1.5rem', marginBottom: '4px' }}>{bt.icon}</div>
              <div style={{ fontSize: '0.7rem', color: bt.color, fontWeight: 600 }}>{t(`pet.bathroom_${bt.type}`)}</div>
            </button>
          ))}
        </div>
        {/* Share bathroom data with SoonPsy */}
        <button onClick={() => {
          const recentBathroom = petBathroomLog.slice(-7).map(e => `${e.type} (${new Date(e.date).toLocaleDateString()})`).join(', ');
          onShareWithAI(lang === 'ar'
            ? `سجل دخول حيواني الأليف ${petData.name} للحمام خلال آخر 7 مرات: ${recentBathroom || 'لا يوجد سجل'}. هل هناك ما يدعو للقلق؟`
            : `My pet ${petData.name}'s bathroom log (last 7): ${recentBathroom || 'no records'}. Is there any concern?`);
        }} style={{
          width: '100%', background: '#e8daff', color: '#8965e0', border: 'none', borderRadius: '10px',
          padding: '10px', fontWeight: 600, cursor: 'pointer', fontSize: '0.8rem', marginBottom: '10px',
        }}>
          💬 {lang === 'ar' ? 'شارك مع SoonPsy' : 'Share with SoonPsy'}
        </button>
        {/* Pet bathroom frequency */}
        {(() => {
          const last7 = petBathroomLog.filter(e => {
            const d = new Date(e.date);
            const weekAgo = new Date(); weekAgo.setDate(weekAgo.getDate() - 7);
            return d >= weekAgo;
          });
          const todayPetBathroom = petBathroomLog.filter(e => new Date(e.date).toDateString() === today);
          const abnormalRecent = last7.filter(e => e.type !== 'normal');
          return (
            <>
              {todayPetBathroom.length > 0 && (
                <div style={{ padding: '10px', background: '#f3e8ff', borderRadius: '12px', marginBottom: '10px', textAlign: 'center' }}>
                  <span style={{ fontSize: '0.85rem', color: '#8965e0', fontWeight: 600 }}>
                    {lang === 'ar' ? `اليوم: ${todayPetBathroom.length} مرة` : `Today: ${todayPetBathroom.length} time(s)`}
                  </span>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px', justifyContent: 'center', marginTop: '6px' }}>
                    {todayPetBathroom.map((e, i) => (
                      <span key={i} style={{ background: '#e8daff', color: '#8965e0', padding: '2px 8px', borderRadius: '10px', fontSize: '0.7rem' }}>
                        {t(`pet.bathroom_${e.type}`)} • {new Date(e.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    ))}
                  </div>
                </div>
              )}
              {last7.length > 0 && (
                <div style={{ padding: '10px', background: last7.length > 21 || last7.length < 3 ? '#fffbeb' : '#f0fdf4', borderRadius: '12px', borderLeft: `4px solid ${last7.length > 21 || last7.length < 3 ? '#f59e0b' : '#10b981'}`, marginBottom: '10px' }}>
                  <p style={{ margin: 0, fontSize: '0.8rem', color: '#525f7f', fontWeight: 600 }}>
                    {lang === 'ar' ? `📊 خلال 7 أيام: ${last7.length} مرة (${(last7.length / 7).toFixed(1)}/يوم)` : `📊 Last 7 days: ${last7.length} times (${(last7.length / 7).toFixed(1)}/day)`}
                  </p>
                  {last7.length < 3 && <p style={{ margin: '4px 0 0', fontSize: '0.75rem', color: '#92400e' }}>{lang === 'ar' ? '⚠️ قليل — قد يكون بسبب التوتر أو تغير البيئة' : '⚠️ Low — could be due to stress or environment change'}</p>}
                  {last7.length > 21 && <p style={{ margin: '4px 0 0', fontSize: '0.75rem', color: '#92400e' }}>{lang === 'ar' ? '⚠️ كثير — قد يشير إلى قلق أو مشكلة صحية' : '⚠️ High — may indicate anxiety or health issue'}</p>}
                </div>
              )}
              {abnormalRecent.length >= 2 && (
                <div style={{ padding: '12px', background: '#fef3c7', borderRadius: '12px', borderLeft: '4px solid #f59e0b', marginBottom: '10px' }}>
                  <p style={{ margin: 0, fontSize: '0.85rem', color: '#92400e', lineHeight: 1.6 }}>⚠️ {t('pet.bathroom_alert')}</p>
                </div>
              )}
            </>
          );
        })()}
      </div>

      {/* Pet Bath Tracker */}
      <div style={{ background: 'white', borderRadius: '16px', padding: '18px', marginBottom: '20px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)', border: '2px solid #ffe0e6' }}>
        <h4 style={{ color: '#ff6b6b', marginBottom: '12px', textAlign: 'center', fontSize: '1rem' }}>🛁 {t('shower.pet_bath')}</h4>
        {(() => {
          const todayBathed = petBathLog.some(e => new Date(e.date).toDateString() === today);
          return !todayBathed ? (
            <button onClick={() => {
              setPetBathLog(prev => [...prev, { date: new Date().toISOString() }]);
            }} style={{
              width: '100%', background: 'linear-gradient(135deg, #ff6b6b, #ee5a24)', color: 'white',
              border: 'none', borderRadius: '12px', padding: '14px', fontWeight: 600, cursor: 'pointer', marginBottom: '10px',
            }}>
              🛁 {t('shower.pet_bath_log')}
            </button>
          ) : (
            <div style={{ textAlign: 'center', padding: '12px', background: '#fff0f3', borderRadius: '12px', marginBottom: '10px' }}>
              <div style={{ fontSize: '1.5rem', marginBottom: '6px' }}>🛁✨</div>
              <p style={{ margin: 0, fontSize: '0.85rem', color: '#ff6b6b', fontWeight: 500 }}>
                {t('shower.pet_bath_msg')}
              </p>
            </div>
          );
        })()}
        {/* Share bath data with SoonPsy */}
        <button onClick={() => {
          const recentBaths = petBathLog.slice(-5).map(e => new Date(e.date).toLocaleDateString()).join(', ');
          onShareWithAI(lang === 'ar'
            ? `سجل استحمام حيواني الأليف ${petData.name}: ${recentBaths || 'لا يوجد سجل'}. هل أفرط في تحميمه؟ كيف يؤثر ذلك على نفسيته؟`
            : `My pet ${petData.name}'s bathing log: ${recentBaths || 'no records'}. Am I over-bathing? How does this affect their wellbeing?`);
        }} style={{
          width: '100%', background: '#ffe0e6', color: '#ff6b6b', border: 'none', borderRadius: '10px',
          padding: '10px', fontWeight: 600, cursor: 'pointer', fontSize: '0.8rem', marginBottom: '10px',
        }}>
          💬 {lang === 'ar' ? 'شارك مع SoonPsy' : 'Share with SoonPsy'}
        </button>
        {/* Over-bathing warning */}
        {(() => {
          const thisMonth = petBathLog.filter(e => {
            const d = new Date(e.date);
            const now = new Date();
            return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
          });
          if (thisMonth.length >= 4) return (
            <div style={{ padding: '12px', background: '#fef3c7', borderRadius: '12px', borderLeft: '4px solid #f59e0b' }}>
              <p style={{ margin: 0, fontSize: '0.85rem', color: '#92400e', lineHeight: 1.6 }}>⚠️ {t('shower.pet_bath_warning')}</p>
            </div>
          );
          return null;
        })()}
        {petBathLog.length > 0 && (
          <div style={{ fontSize: '0.8rem', color: '#8898aa', textAlign: 'center', marginTop: '8px' }}>
            {lang === 'ar' ? 'آخر استحمام:' : 'Last bath:'} {new Date(petBathLog[petBathLog.length - 1].date).toLocaleDateString()}
          </div>
        )}
      </div>

      {/* History */}
      <button onClick={() => setShowHistory(!showHistory)} style={{ background: showHistory ? '#ff6b6b' : 'white', color: showHistory ? 'white' : '#ff6b6b', border: '2px solid #ff6b6b', borderRadius: '25px', padding: '12px', fontWeight: 600, cursor: 'pointer', width: '100%', fontFamily: 'Poppins, sans-serif', marginBottom: '20px', fontSize: '0.9rem' }}>
        <i className={`fas fa-${showHistory ? 'chevron-up' : 'history'}`} style={{ marginRight: '8px' }}></i>
        {showHistory ? t('mood.hide_history') : t('pet.view_history')}
      </button>

      {showHistory && (
        <div style={{ background: 'white', borderRadius: '16px', padding: '15px', marginBottom: '20px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)', maxHeight: '400px', overflowY: 'auto', border: '2px solid #ffe0e6' }}>
          {historyDates.length === 0 ? (
            <p style={{ color: '#8898aa', textAlign: 'center' }}>{t('mood.no_history')}</p>
          ) : historyDates.map(dateKey => (
            <div key={dateKey} style={{ marginBottom: '12px' }}>
              <div style={{ fontSize: '0.85rem', fontWeight: 600, color: '#ff6b6b', marginBottom: '6px', paddingBottom: '4px', borderBottom: '2px solid #ffe0e6' }}>
                📅 {dateKey}
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                {groupedHistory[dateKey].map((e, i) => (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '4px 8px', background: '#fff0f3', borderRadius: '8px', fontSize: '0.85rem' }}>
                    <span>{typeIcons[e.type] || '📋'}</span>
                    <span style={{ color: '#32325d', fontWeight: 500 }}>{e.type}</span>
                    <span style={{ color: '#ff6b6b', fontWeight: 600 }}>{e.value}</span>
                    <span style={{ color: '#8898aa', fontSize: '0.7rem', marginLeft: 'auto' }}>{new Date(e.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Birthday & Love */}
      <LoveExpressionSection />

      {/* Mercy Day */}
      <MercyDay lang={lang} t={t} />

      {/* Benefits */}
      <div style={{ background: 'linear-gradient(135deg, #fff0f3, #ffe0e6)', borderRadius: '16px', padding: '15px', marginBottom: '20px' }}>
        <h4 style={{ color: '#ff6b6b', marginBottom: '10px', textAlign: 'center' }}>❤️ {t('pet.benefits')}</h4>
        <ul style={{ paddingLeft: '20px', marginBottom: 0 }}>
          {[
            { en: 'Reducing stress and anxiety levels', ar: 'تقليل مستويات التوتر والقلق', es: 'Reducir el estrés y la ansiedad', fr: 'Réduire le stress et l\'anxiété' },
            { en: 'Providing companionship and emotional support', ar: 'توفير الرفقة والدعم العاطفي', es: 'Proporcionar compañía y apoyo emocional', fr: 'Fournir compagnie et soutien émotionnel' },
            { en: 'Encouraging physical activity', ar: 'تشجيع النشاط البدني', es: 'Fomentar la actividad física', fr: 'Encourager l\'activité physique' },
            { en: 'Providing routine and purpose', ar: 'توفير روتين وهدف', es: 'Proporcionar rutina y propósito', fr: 'Fournir routine et objectif' },
          ].map((tip, i) => (
            <li key={i} style={{ marginBottom: '6px', lineHeight: 1.5, color: '#32325d', fontSize: '0.9rem' }}>
              {tip[lang as keyof typeof tip] || tip.en}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

/* Multi-Pet Manager: list of pet names the user owns */
function MultiPetManager({ activePetName, onSelect, lang }: { activePetName: string; onSelect: (name: string) => void; lang: string }) {
  const isAr = lang === 'ar';
  const [pets, setPets] = useLocalStorage<string[]>('soon-pets-list', []);
  const [newName, setNewName] = useState('');
  const add = () => { const n = newName.trim(); if (!n || pets.includes(n)) return; setPets([...pets, n]); setNewName(''); onSelect(n); };
  const remove = (n: string) => setPets(pets.filter(p => p !== n));
  return (
    <div style={{ background: 'white', borderRadius: 16, padding: 15, marginBottom: 20, boxShadow: '0 6px 20px rgba(0,0,0,0.08)', border: '2px solid #ffe0e6' }}>
      <h4 style={{ color: '#ff6b6b', marginBottom: 10, textAlign: 'center' }}>🐾 {isAr ? 'حيواناتي الأليفة' : 'My Pets'}</h4>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 10 }}>
        {pets.map(p => (
          <span key={p} style={{
            background: p === activePetName ? '#ff6b6b' : '#fff0f3',
            color: p === activePetName ? 'white' : '#ff6b6b',
            padding: '6px 12px', borderRadius: 20, fontSize: '0.8rem', fontWeight: 600, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 6,
          }} onClick={() => onSelect(p)}>
            🐾 {p}
            <button onClick={(e) => { e.stopPropagation(); remove(p); }} style={{ background: 'none', border: 'none', color: 'inherit', cursor: 'pointer', fontWeight: 800, padding: 0, lineHeight: 1 }}>×</button>
          </span>
        ))}
        {pets.length === 0 && <span style={{ fontSize: '0.8rem', color: '#8898aa' }}>{isAr ? 'لم تضف أي حيوان بعد' : 'No pets added yet'}</span>}
      </div>
      <div style={{ display: 'flex', gap: 8 }}>
        <input value={newName} onChange={e => setNewName(e.target.value)} onKeyDown={e => e.key === 'Enter' && add()}
          placeholder={isAr ? 'اسم حيوانك الأليف...' : 'Pet name...'}
          style={{ flex: 1, padding: '8px 12px', border: '1px solid #ffe0e6', borderRadius: 20, fontSize: '0.85rem', outline: 'none' }} />
        <button onClick={add} style={{ background: '#ff6b6b', color: 'white', border: 'none', borderRadius: 20, padding: '8px 16px', fontWeight: 600, cursor: 'pointer', fontSize: '0.85rem' }}>+ {isAr ? 'إضافة' : 'Add'}</button>
      </div>
    </div>
  );
}

/* Mercy Day Component */
function MercyDay({ lang, t }: { lang: string; t: (key: string) => string }) {
  const [mercyActions, setMercyActions] = useLocalStorage<{ action: string; date: string }[]>('soon-mercy-day', []);
  const [customAction, setCustomAction] = useState('');
  const today = new Date().toDateString();
  const todayActions = mercyActions.filter(a => new Date(a.date).toDateString() === today);

  const suggestions = [
    { icon: '🍖', key: 'mercy.feed' },
    { icon: '😊', key: 'mercy.smile' },
    { icon: '🤗', key: 'mercy.hug' },
    { icon: '🎮', key: 'mercy.play' },
    { icon: '💧', key: 'mercy.water' },
    { icon: '🏠', key: 'mercy.shelter' },
  ];

  const addAction = (text: string) => {
    if (!text.trim()) return;
    setMercyActions(prev => [...prev, { action: text.trim(), date: new Date().toISOString() }]);
    setCustomAction('');
  };

  return (
    <div style={{
      background: 'white', borderRadius: '16px', padding: '20px', marginBottom: '20px',
      boxShadow: '0 6px 20px rgba(0,0,0,0.08)', border: '2px solid #ffe0e6',
    }}>
      <h4 style={{ color: '#ff6b6b', marginBottom: '6px', textAlign: 'center', fontSize: '1.1rem' }}>
        🕊️ {t('mercy.title')}
      </h4>
      <p style={{ fontSize: '0.82rem', color: '#8898aa', textAlign: 'center', marginBottom: '15px' }}>
        {t('mercy.desc')}
      </p>

      {/* Suggestions */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '8px', marginBottom: '15px' }}>
        {suggestions.map(s => {
          const done = todayActions.some(a => a.action === t(s.key));
          return (
            <div key={s.key} onClick={() => !done && addAction(t(s.key))} style={{
              padding: '12px 6px', borderRadius: '14px', textAlign: 'center', cursor: done ? 'default' : 'pointer',
              background: done ? 'linear-gradient(135deg, #e8f5e9, #c8e6c9)' : '#fff0f3',
              border: `2px solid ${done ? '#2DCE89' : '#ffe0e6'}`, transition: 'all 0.3s ease',
              opacity: done ? 0.8 : 1,
            }}>
              <div style={{ fontSize: '1.4rem', marginBottom: '4px' }}>{done ? '✅' : s.icon}</div>
              <div style={{ fontSize: '0.72rem', fontWeight: 600, color: done ? '#2DCE89' : '#ff6b6b', lineHeight: 1.3 }}>
                {t(s.key)}
              </div>
            </div>
          );
        })}
      </div>

      {/* Custom action */}
      <div style={{ display: 'flex', gap: '8px', marginBottom: '12px' }}>
        <input
          type="text" value={customAction}
          onChange={e => setCustomAction(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && addAction(customAction)}
          placeholder={t('mercy.custom_placeholder')}
          style={{
            flex: 1, padding: '10px 15px', border: '1px solid #ffe0e6', borderRadius: '25px',
            fontFamily: 'Poppins, sans-serif', fontSize: '0.85rem', outline: 'none',
          }}
        />
        <button onClick={() => addAction(customAction)} style={{
          background: '#ff6b6b', color: 'white', border: 'none', borderRadius: '50%',
          width: 38, height: 38, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
          cursor: 'pointer', fontSize: '1rem',
        }}>+</button>
      </div>

      {/* Today's mercy actions */}
      {todayActions.length > 0 && (
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginBottom: '10px' }}>
          {todayActions.map((a, i) => (
            <span key={i} style={{
              background: '#e8f5e9', color: '#2e7d32', padding: '4px 12px', borderRadius: '20px',
              fontSize: '0.82rem', fontWeight: 500,
            }}>
              🕊️ {a.action}
            </span>
          ))}
        </div>
      )}

      {todayActions.length >= 3 && (
        <div style={{
          textAlign: 'center', padding: '12px', background: 'linear-gradient(135deg, #d1efe1, #e8f5e9)',
          borderRadius: '12px', color: '#1a9f6e', fontWeight: 500, fontSize: '0.9rem',
        }}>
          🕊️ {t('mercy.complete')}
        </div>
       )}
      <PetNutrition />
    </div>
  );
}
