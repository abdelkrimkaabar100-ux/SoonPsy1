import { useState, useEffect, useCallback } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import InlineAIChat from '../shared/InlineAIChat';

interface FeedLog { type: 'food' | 'water'; time: string; date: string; amount: string; }

const vetFoodRecs: Record<string, { ar: string[]; en: string[] }> = {
  dog: {
    ar: ['🥩 بروتين حيواني (دجاج، لحم بقري، سمك)', '🥕 خضروات مسلوقة (جزر، بطاطا حلوة، بازلاء)', '🍚 أرز أبيض أو بني مطبوخ', '🥚 بيض مسلوق (مصدر بروتين ممتاز)', '🐟 زيت السمك (أوميغا 3 لصحة الفراء والدماغ)', '🫐 توت أزرق (مضاد أكسدة لصحة الدماغ)', '⚠️ تجنب: شوكولاتة، عنب، بصل، ثوم، أفوكادو'],
    en: ['🥩 Animal protein (chicken, beef, fish)', '🥕 Steamed veggies (carrots, sweet potato, peas)', '🍚 Cooked white or brown rice', '🥚 Boiled eggs (excellent protein source)', '🐟 Fish oil (omega-3 for coat & brain health)', '🫐 Blueberries (antioxidants for brain health)', '⚠️ Avoid: chocolate, grapes, onions, garlic, avocado'],
  },
  cat: {
    ar: ['🥩 بروتين حيواني عالي (دجاج، ديك رومي، سمك)', '🐟 تونة أو سلمون (مرة أسبوعياً)', '🥚 بيض مسلوق مفروم', '💧 طعام رطب لزيادة الترطيب', '🌿 عشبة القطط (مفيدة للهضم)', '⚠️ تجنب: حليب البقر، بصل، ثوم، شوكولاتة، كافيين'],
    en: ['🥩 High animal protein (chicken, turkey, fish)', '🐟 Tuna or salmon (once weekly)', '🥚 Chopped boiled eggs', '💧 Wet food for hydration', '🌿 Cat grass (aids digestion)', '⚠️ Avoid: cow milk, onions, garlic, chocolate, caffeine'],
  },
  bird: {
    ar: ['🌾 بذور مختلطة (دوار الشمس، كتان)', '🥬 خضروات ورقية (سبانخ، خس)', '🍎 فواكه طازجة مقطعة (تفاح، موز)', '🥕 جزر مبشور', '🥚 بيض مسلوق مفتت (للبروتين)', '⚠️ تجنب: أفوكادو، شوكولاتة، كافيين، ملح'],
    en: ['🌾 Mixed seeds (sunflower, flax)', '🥬 Leafy greens (spinach, lettuce)', '🍎 Fresh chopped fruits (apple, banana)', '🥕 Grated carrots', '🥚 Crumbled boiled egg (for protein)', '⚠️ Avoid: avocado, chocolate, caffeine, salt'],
  },
  fish: {
    ar: ['🐠 طعام أسماك متخصص (رقائق أو حبيبات)', '🦐 جمبري مجفف (كمكافأة)', '🥬 سبيرولينا (طحالب مغذية)', '🪱 ديدان الدم المجففة', '⚠️ لا تفرط في الإطعام (مرتين يومياً كافٍ)'],
    en: ['🐠 Specialized fish food (flakes or pellets)', '🦐 Dried shrimp (as treat)', '🥬 Spirulina (nutritious algae)', '🪱 Freeze-dried bloodworms', '⚠️ Don\'t overfeed (twice daily is enough)'],
  },
  rabbit: {
    ar: ['🥬 تبن تيموثي (80% من الغذاء)', '🥕 خضروات ورقية طازجة يومياً', '🫐 فواكه بكميات صغيرة (كمكافأة)', '🌿 أعشاب طازجة (بقدونس، نعناع)', '⚠️ تجنب: خس أيسبرغ، بطاطس، شوكولاتة'],
    en: ['🥬 Timothy hay (80% of diet)', '🥕 Fresh leafy greens daily', '🫐 Small amounts of fruit (as treats)', '🌿 Fresh herbs (parsley, mint)', '⚠️ Avoid: iceberg lettuce, potatoes, chocolate'],
  },
  hamster: {
    ar: ['🌾 خليط بذور وحبوب للهامستر', '🥕 خضروات طازجة مقطعة صغيرة', '🥚 بروتين (بيض مسلوق، دود الوجبات)', '🍎 فواكه بكميات صغيرة', '⚠️ تجنب: حمضيات، ثوم، بصل، شوكولاتة'],
    en: ['🌾 Hamster seed & grain mix', '🥕 Small fresh veggie pieces', '🥚 Protein (boiled egg, mealworms)', '🍎 Small amounts of fruit', '⚠️ Avoid: citrus, garlic, onions, chocolate'],
  },
  other: {
    ar: ['🔍 استشر طبيباً بيطرياً لمعرفة الغذاء المناسب لحيوانك', '💧 الماء النظيف ضروري دائماً', '🥗 نظام غذائي متوازن ومتنوع'],
    en: ['🔍 Consult a vet for your pet\'s specific dietary needs', '💧 Clean water is always essential', '🥗 Balanced and varied diet'],
  },
};

const waterNeedsPerKg: Record<string, { ml: number; noteAr: string; noteEn: string }> = {
  dog: { ml: 60, noteAr: '60 مل لكل كغ من الوزن يومياً', noteEn: '60ml per kg body weight daily' },
  cat: { ml: 50, noteAr: '50 مل لكل كغ من الوزن يومياً', noteEn: '50ml per kg body weight daily' },
  bird: { ml: 5, noteAr: '5% من وزن الجسم ماء يومياً', noteEn: '5% of body weight in water daily' },
  rabbit: { ml: 100, noteAr: '100 مل لكل كغ يومياً', noteEn: '100ml per kg daily' },
  hamster: { ml: 10, noteAr: '10 مل يومياً تقريباً', noteEn: 'About 10ml daily' },
  fish: { ml: 0, noteAr: 'تغيير 25% من ماء الحوض أسبوعياً', noteEn: 'Change 25% of tank water weekly' },
  other: { ml: 50, noteAr: 'استشر طبيب بيطري', noteEn: 'Consult a vet' },
};

export default function PetNutrition() {
  const { lang } = useLanguage();
  const isAr = lang === 'ar';
  const [petData] = useLocalStorage<{ name: string; type: string; age: string; breed: string }>('soon-pet', { name: '', type: '', age: '', breed: '' });
  const [feedLog, setFeedLog] = useLocalStorage<FeedLog[]>('soon-pet-feed-log', []);
  const [feedReminderOn, setFeedReminderOn] = useLocalStorage<boolean>('soon-pet-feed-remind', false);
  const [waterReminderOn, setWaterReminderOn] = useLocalStorage<boolean>('soon-pet-water-remind', false);
  const [feedInterval, setFeedInterval] = useLocalStorage<number>('soon-pet-feed-interval', 8);
  const [waterCheckInterval, setWaterCheckInterval] = useLocalStorage<number>('soon-pet-water-interval', 4);
  const [showRecs, setShowRecs] = useState(true);
  const [showHistory, setShowHistory] = useState(false);

  const petType = petData.type || 'other';
  const petName = petData.name || (isAr ? 'حيوانك' : 'your pet');
  const today = new Date().toDateString();
  const todayFeeds = feedLog.filter(f => new Date(f.date).toDateString() === today);
  const todayFood = todayFeeds.filter(f => f.type === 'food');
  const todayWater = todayFeeds.filter(f => f.type === 'water');

  const logFeed = (type: 'food' | 'water') => {
    const amount = type === 'food'
      ? prompt(isAr ? 'الكمية (مثل: كوب، نصف كوب)' : 'Amount (e.g., 1 cup, half cup)')
      : prompt(isAr ? 'الكمية (مثل: وعاء ممتلئ)' : 'Amount (e.g., full bowl)');
    if (!amount) return;
    setFeedLog([...feedLog, { type, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), date: new Date().toISOString(), amount }]);
  };

  // Feed reminder - uses service worker for background notifications
  useEffect(() => {
    if (!feedReminderOn || !('Notification' in window) || Notification.permission !== 'granted') return;
    const ms = feedInterval * 60 * 60 * 1000;
    // Register with service worker for background
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.ready.then(reg => {
        reg.active?.postMessage({
          type: 'SCHEDULE_INTERVAL_REMINDER',
          id: 'pet-feed',
          intervalMs: ms,
          title: isAr ? `🍽️ وقت إطعام ${petName}!` : `🍽️ Time to feed ${petName}!`,
          body: isAr ? 'لا تنسَ تقديم وجبة صحية لحيوانك الأليف' : 'Don\'t forget to serve a healthy meal to your pet',
        });
      });
    }
    // Fallback in-app
    const id = setInterval(() => {
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.ready.then(reg => {
          reg.showNotification(isAr ? `🍽️ وقت إطعام ${petName}!` : `🍽️ Time to feed ${petName}!`, {
            body: isAr ? 'لا تنسَ تقديم وجبة صحية لحيوانك الأليف' : 'Don\'t forget to serve a healthy meal to your pet',
            icon: '/icon.png', badge: '/icon.png', tag: 'pet-feed', renotify: true,
          } as NotificationOptions);
        }).catch(() => {
          new Notification(isAr ? `🍽️ وقت إطعام ${petName}!` : `🍽️ Time to feed ${petName}!`, { icon: '/icon.png' });
        });
      }
    }, ms);
    return () => {
      clearInterval(id);
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.ready.then(reg => {
          reg.active?.postMessage({ type: 'STOP_INTERVAL_REMINDER', id: 'pet-feed' });
        });
      }
    };
  }, [feedReminderOn, feedInterval, petName, isAr]);

  // Water reminder - uses service worker for background notifications
  useEffect(() => {
    if (!waterReminderOn || !('Notification' in window) || Notification.permission !== 'granted') return;
    const ms = waterCheckInterval * 60 * 60 * 1000;
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.ready.then(reg => {
        reg.active?.postMessage({
          type: 'SCHEDULE_INTERVAL_REMINDER',
          id: 'pet-water',
          intervalMs: ms,
          title: isAr ? `💧 تحقق من ماء ${petName}!` : `💧 Check ${petName}'s water!`,
          body: isAr ? 'تأكد أن وعاء الماء ممتلئ ونظيف' : 'Make sure the water bowl is full and clean',
        });
      });
    }
    const id = setInterval(() => {
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.ready.then(reg => {
          reg.showNotification(isAr ? `💧 تحقق من ماء ${petName}!` : `💧 Check ${petName}'s water!`, {
            body: isAr ? 'تأكد أن وعاء الماء ممتلئ ونظيف' : 'Make sure the water bowl is full and clean',
            icon: '/icon.png', badge: '/icon.png', tag: 'pet-water', renotify: true,
          } as NotificationOptions);
        }).catch(() => {
          new Notification(isAr ? `💧 تحقق من ماء ${petName}!` : `💧 Check ${petName}'s water!`, { icon: '/icon.png' });
        });
      }
    }, ms);
    return () => {
      clearInterval(id);
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.ready.then(reg => {
          reg.active?.postMessage({ type: 'STOP_INTERVAL_REMINDER', id: 'pet-water' });
        });
      }
    };
  }, [waterReminderOn, waterCheckInterval, petName, isAr]);

  const enableReminder = useCallback(async (setter: (v: boolean) => void, current: boolean) => {
    if ('Notification' in window && Notification.permission === 'default') {
      await Notification.requestPermission();
    }
    setter(!current);
  }, []);

  const recs = vetFoodRecs[petType] || vetFoodRecs.other;
  const waterInfo = waterNeedsPerKg[petType] || waterNeedsPerKg.other;
  const sorted = [...feedLog].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div style={{ marginTop: '15px' }}>
      {/* ===== PET FEEDING TRACKER ===== */}
      <div style={{ background: 'linear-gradient(135deg, #fef3c7, #fde68a)', borderRadius: '18px', padding: '18px', marginBottom: '15px', boxShadow: '0 4px 15px rgba(245,158,11,0.15)', border: '1px solid #fcd34d' }}>
        <h4 style={{ color: '#92400e', textAlign: 'center', marginBottom: '10px', fontSize: '1.05rem' }}>
          🍽️ {isAr ? `تغذية ${petName}` : `${petName}'s Nutrition`}
        </h4>

        {/* Quick log buttons */}
        <div style={{ display: 'flex', gap: '10px', marginBottom: '12px' }}>
          <button onClick={() => logFeed('food')} style={{
            flex: 1, background: '#f59e0b', color: 'white', border: 'none', borderRadius: '14px',
            padding: '12px', fontWeight: 700, cursor: 'pointer', fontSize: '0.9rem',
          }}>
            🍖 {isAr ? 'تسجيل وجبة' : 'Log Meal'}
          </button>
          <button onClick={() => logFeed('water')} style={{
            flex: 1, background: '#3b82f6', color: 'white', border: 'none', borderRadius: '14px',
            padding: '12px', fontWeight: 700, cursor: 'pointer', fontSize: '0.9rem',
          }}>
            💧 {isAr ? 'تسجيل ماء' : 'Log Water'}
          </button>
        </div>

        {/* Today's log */}
        {todayFeeds.length > 0 && (
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px', marginBottom: '10px' }}>
            {todayFeeds.map((f, i) => (
              <span key={i} style={{
                background: f.type === 'food' ? '#fef3c7' : '#dbeafe',
                color: f.type === 'food' ? '#92400e' : '#1d4ed8',
                padding: '3px 10px', borderRadius: '12px', fontSize: '0.75rem', fontWeight: 500,
                border: `1px solid ${f.type === 'food' ? '#fcd34d' : '#93c5fd'}`,
              }}>
                {f.type === 'food' ? '🍖' : '💧'} {f.amount} - {f.time}
              </span>
            ))}
          </div>
        )}

        <div style={{ display: 'flex', gap: '6px', textAlign: 'center', marginBottom: '10px' }}>
          <div style={{ flex: 1, background: 'rgba(255,255,255,0.6)', borderRadius: '12px', padding: '8px' }}>
            <div style={{ fontSize: '1.3rem', fontWeight: 700, color: '#92400e' }}>{todayFood.length}</div>
            <div style={{ fontSize: '0.7rem', color: '#a16207' }}>{isAr ? 'وجبات اليوم' : 'Meals today'}</div>
          </div>
          <div style={{ flex: 1, background: 'rgba(255,255,255,0.6)', borderRadius: '12px', padding: '8px' }}>
            <div style={{ fontSize: '1.3rem', fontWeight: 700, color: '#1d4ed8' }}>{todayWater.length}</div>
            <div style={{ fontSize: '0.7rem', color: '#1d4ed8' }}>{isAr ? 'مرات الماء' : 'Water refills'}</div>
          </div>
        </div>

        {/* Water needs info */}
        <div style={{ background: 'rgba(59,130,246,0.1)', borderRadius: '12px', padding: '10px', marginBottom: '10px', border: '1px solid rgba(59,130,246,0.2)' }}>
          <p style={{ margin: 0, fontSize: '0.8rem', color: '#1d4ed8', fontWeight: 600 }}>
            💧 {isAr ? `${petName} يحتاج: ${waterInfo.noteAr}` : `${petName} needs: ${waterInfo.noteEn}`}
          </p>
        </div>

        {/* Reminders */}
        <div style={{ display: 'flex', gap: '8px', marginBottom: '10px' }}>
          <div style={{ flex: 1, background: 'rgba(255,255,255,0.7)', borderRadius: '12px', padding: '10px' }}>
            <div style={{ fontSize: '0.75rem', fontWeight: 600, color: '#92400e', marginBottom: '6px' }}>
              🔔 {isAr ? `تذكير الطعام كل ${feedInterval}س` : `Food reminder every ${feedInterval}h`}
            </div>
            <div style={{ display: 'flex', gap: '4px', marginBottom: '6px' }}>
              {[6, 8, 12].map(h => (
                <button key={h} onClick={() => setFeedInterval(h)} style={{
                  background: feedInterval === h ? '#f59e0b' : 'white', color: feedInterval === h ? 'white' : '#92400e',
                  border: 'none', borderRadius: '8px', padding: '3px 8px', fontSize: '0.7rem', fontWeight: 600, cursor: 'pointer',
                }}>{h}{isAr ? 'س' : 'h'}</button>
              ))}
            </div>
            <button onClick={() => enableReminder(setFeedReminderOn, feedReminderOn)} style={{
              background: feedReminderOn ? '#f59e0b' : '#fef3c7', color: feedReminderOn ? 'white' : '#92400e',
              border: 'none', borderRadius: '10px', padding: '5px 12px', fontSize: '0.72rem', fontWeight: 600, cursor: 'pointer', width: '100%',
            }}>
              {feedReminderOn ? '✅' : (isAr ? 'تفعيل' : 'Enable')}
            </button>
          </div>
          <div style={{ flex: 1, background: 'rgba(255,255,255,0.7)', borderRadius: '12px', padding: '10px' }}>
            <div style={{ fontSize: '0.75rem', fontWeight: 600, color: '#1d4ed8', marginBottom: '6px' }}>
              🔔 {isAr ? `تحقق ماء كل ${waterCheckInterval}س` : `Water check every ${waterCheckInterval}h`}
            </div>
            <div style={{ display: 'flex', gap: '4px', marginBottom: '6px' }}>
              {[2, 4, 6].map(h => (
                <button key={h} onClick={() => setWaterCheckInterval(h)} style={{
                  background: waterCheckInterval === h ? '#3b82f6' : 'white', color: waterCheckInterval === h ? 'white' : '#1d4ed8',
                  border: 'none', borderRadius: '8px', padding: '3px 8px', fontSize: '0.7rem', fontWeight: 600, cursor: 'pointer',
                }}>{h}{isAr ? 'س' : 'h'}</button>
              ))}
            </div>
            <button onClick={() => enableReminder(setWaterReminderOn, waterReminderOn)} style={{
              background: waterReminderOn ? '#3b82f6' : '#dbeafe', color: waterReminderOn ? 'white' : '#1d4ed8',
              border: 'none', borderRadius: '10px', padding: '5px 12px', fontSize: '0.72rem', fontWeight: 600, cursor: 'pointer', width: '100%',
            }}>
              {waterReminderOn ? '✅' : (isAr ? 'تفعيل' : 'Enable')}
            </button>
          </div>
        </div>
      </div>

      {/* ===== VET FOOD RECOMMENDATIONS ===== */}
      <div style={{ background: 'linear-gradient(135deg, #ecfdf5, #d1fae5)', borderRadius: '18px', padding: '18px', marginBottom: '15px', boxShadow: '0 4px 15px rgba(16,185,129,0.1)', border: '1px solid #a7f3d0' }}>
        <button onClick={() => setShowRecs(!showRecs)} style={{
          background: 'none', border: 'none', cursor: 'pointer', width: '100%', textAlign: 'center',
        }}>
          <h4 style={{ color: '#065f46', marginBottom: '4px', fontSize: '1rem' }}>
            🩺 {isAr ? `طعام موصى به لـ ${petName} (${petType})` : `Vet-Recommended Food for ${petName} (${petType})`}
          </h4>
          <span style={{ fontSize: '0.75rem', color: '#6b7280' }}>{showRecs ? '▲' : '▼'}</span>
        </button>
        {showRecs && (
          <div style={{ marginTop: '10px' }}>
            {(isAr ? recs.ar : recs.en).map((rec, i) => (
              <div key={i} style={{
                background: rec.startsWith('⚠️') ? 'rgba(239,68,68,0.08)' : 'rgba(255,255,255,0.6)',
                borderRadius: '10px', padding: '8px 12px', marginBottom: '6px', fontSize: '0.82rem',
                color: rec.startsWith('⚠️') ? '#dc2626' : '#065f46', fontWeight: 500,
                border: rec.startsWith('⚠️') ? '1px solid rgba(239,68,68,0.2)' : 'none',
              }}>
                {rec}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ===== HISTORY ===== */}
      {feedLog.length > 0 && (
        <button onClick={() => setShowHistory(!showHistory)} style={{
          background: 'none', border: '1px solid #f59e0b', color: '#f59e0b', borderRadius: '20px',
          padding: '8px 16px', fontWeight: 600, cursor: 'pointer', width: '100%', fontSize: '0.8rem', marginBottom: '15px',
        }}>
          <i className={`fas fa-${showHistory ? 'chevron-up' : 'history'}`} style={{ marginRight: '6px' }}></i>
          {showHistory ? (isAr ? 'إخفاء' : 'Hide') : (isAr ? 'سجل التغذية' : 'Feeding History')}
        </button>
      )}
      {showHistory && (
        <div style={{ maxHeight: '200px', overflowY: 'auto', marginBottom: '15px' }}>
          {sorted.slice(0, 30).map((f, i) => (
            <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: '#f9fafb', borderRadius: '10px', padding: '8px 12px', marginBottom: '4px', fontSize: '0.78rem' }}>
              <span style={{ color: '#6b7280' }}>{new Date(f.date).toLocaleDateString(isAr ? 'ar' : 'en')} {f.time}</span>
              <span style={{ fontWeight: 600, color: f.type === 'food' ? '#92400e' : '#1d4ed8' }}>
                {f.type === 'food' ? '🍖' : '💧'} {f.amount}
              </span>
            </div>
          ))}
        </div>
      )}

      {/* AI support for personalized nutrition */}
      <InlineAIChat
        context="pet"
        lang={lang}
        initialPrompt={petData.name ? (isAr
          ? `حيواني الأليف اسمه ${petData.name}، نوعه ${petData.type}، عمره ${petData.age}، سلالته ${petData.breed}. ما هو أفضل نظام غذائي له لصحة دماغه وجسمه؟`
          : `My pet's name is ${petData.name}, type: ${petData.type}, age: ${petData.age}, breed: ${petData.breed}. What's the best diet for their brain and body health?`)
          : undefined}
      />
    </div>
  );
}
