import { useState } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { supabase } from '@/integrations/supabase/client';

interface DecisionPageProps { onBack: () => void; }

export default function DecisionPage({ onBack }: DecisionPageProps) {
  const { lang } = useLanguage();
  const [userName] = useLocalStorage<string>('soon-user-name', '');
  const [decision, setDecision] = useState('');
  const [option1, setOption1] = useState('');
  const [option2, setOption2] = useState('');
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useLocalStorage<{ q: string; a: string; date: string }[]>('soon-decisions', []);
  const isAr = lang === 'ar';

  const labels = {
    en: { title: '🤔 Decision Helper', subtitle: 'AI helps you make better decisions based on your data', decision: 'What decision are you facing?', option1: 'Option 1', option2: 'Option 2', analyze: 'Analyze with AI', back: 'Back', history: 'Previous Decisions', thinking: 'Analyzing your situation...' },
    ar: { title: '🤔 مساعد القرار', subtitle: 'الذكاء الاصطناعي يساعدك في اتخاذ قرارات أفضل', decision: 'ما القرار الذي تواجهه؟', option1: 'الخيار الأول', option2: 'الخيار الثاني', analyze: 'تحليل مع AI', back: 'رجوع', history: 'قرارات سابقة', thinking: 'جاري تحليل وضعك...' },
    es: { title: '🤔 Ayuda para Decidir', subtitle: 'La IA te ayuda a tomar mejores decisiones', decision: '¿Qué decisión enfrentas?', option1: 'Opción 1', option2: 'Opción 2', analyze: 'Analizar con IA', back: 'Volver', history: 'Decisiones anteriores', thinking: 'Analizando tu situación...' },
    fr: { title: '🤔 Aide à la Décision', subtitle: 'L\'IA vous aide à prendre de meilleures décisions', decision: 'Quelle décision devez-vous prendre?', option1: 'Option 1', option2: 'Option 2', analyze: 'Analyser avec IA', back: 'Retour', history: 'Décisions précédentes', thinking: 'Analyse en cours...' },
  };
  const l = labels[lang] || labels.en;

  const analyze = async () => {
    if (!decision.trim()) return;
    setLoading(true);
    setResponse('');

    // Gather user data for context
    const read = (key: string, fb: any) => { try { return JSON.parse(localStorage.getItem(key) || JSON.stringify(fb)); } catch { return fb; } };
    const moodHistory = read('soon-mood-history', []);
    const goals = read('soon-goals', []);
    const values = read('soon-love-page', []);
    const recentMood = moodHistory.length > 0 ? moodHistory[0]?.mood : '';

    const prompt = `${isAr ? 'أنا' : 'I am'} ${userName || 'someone'}. ${isAr ? 'أحتاج مساعدة في قرار' : 'I need help with a decision'}:

${isAr ? 'القرار' : 'Decision'}: ${decision}
${option1 ? `${isAr ? 'الخيار 1' : 'Option 1'}: ${option1}` : ''}
${option2 ? `${isAr ? 'الخيار 2' : 'Option 2'}: ${option2}` : ''}

${isAr ? 'سياق عني' : 'Context about me'}:
- ${isAr ? 'المزاج الحالي' : 'Current mood'}: ${recentMood || 'N/A'}
- ${isAr ? 'الأهداف' : 'Goals'}: ${goals.length > 0 ? goals.slice(0, 3).map((g: any) => g.title || g.text).join(', ') : 'N/A'}
- ${isAr ? 'القيم' : 'Values'}: ${values.length > 0 ? values.slice(0, 3).map((v: any) => v.target).join(', ') : 'N/A'}

${isAr ? 'حلل هذا القرار نفسياً وقدم نصيحة واضحة مع إيجابيات وسلبيات كل خيار.' : 'Analyze this decision psychologically and provide clear advice with pros and cons of each option.'}`;

    try {
      const { data, error } = await supabase.functions.invoke('ai-assistant', { body: { prompt, context: 'decision-making' } });
      if (error) throw error;
      const content = (data.content || '').replace(/#{1,6}\s*/g, '').replace(/\*\*(.*?)\*\*/g, '$1').replace(/\*(.*?)\*/g, '$1').trim();
      setResponse(content);
      setHistory(prev => [{ q: decision, a: content, date: new Date().toISOString() }, ...prev.slice(0, 9)]);
    } catch (err) {
      console.error(err);
      setResponse(isAr ? '❌ حدث خطأ، حاول مرة أخرى' : '❌ Error, please try again');
    } finally {
      setLoading(false);
    }
  };

  const inputStyle = { width: '100%', padding: '12px 15px', border: '1px solid #e5e7eb', borderRadius: '12px', fontFamily: 'Poppins, sans-serif', fontSize: '0.9rem', outline: 'none', marginBottom: '10px', boxSizing: 'border-box' as const, direction: isAr ? 'rtl' as const : 'ltr' as const };

  return (
    <div style={{ paddingTop: '20px', direction: isAr ? 'rtl' : 'ltr' }}>
      <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#8b5cf6', fontSize: '1rem', cursor: 'pointer', marginBottom: '15px', fontFamily: 'Poppins, sans-serif' }}>
        <i className={`fas fa-arrow-${isAr ? 'right' : 'left'}`}></i> {l.back}
      </button>

      <div style={{ textAlign: 'center', marginBottom: '20px' }}>
        <h2 style={{ color: '#8b5cf6', fontSize: '1.5rem', margin: '0 0 5px' }}>{l.title}</h2>
        <p style={{ color: '#8898aa', fontSize: '0.85rem', margin: 0 }}>{l.subtitle}</p>
      </div>

      <div style={{ background: 'white', borderRadius: '16px', padding: '20px', marginBottom: '15px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
        <textarea value={decision} onChange={e => setDecision(e.target.value)} placeholder={l.decision}
          style={{ ...inputStyle, height: '80px', resize: 'vertical' as const }} />
        <input type="text" value={option1} onChange={e => setOption1(e.target.value)} placeholder={l.option1} style={inputStyle} />
        <input type="text" value={option2} onChange={e => setOption2(e.target.value)} placeholder={l.option2} style={inputStyle} />
        <button onClick={analyze} disabled={loading || !decision.trim()} style={{
          background: 'linear-gradient(135deg, #8b5cf6, #6d28d9)', color: 'white', border: 'none',
          borderRadius: '25px', padding: '12px', fontWeight: 600, cursor: 'pointer', width: '100%',
          fontFamily: 'Poppins, sans-serif', opacity: loading ? 0.6 : 1,
        }}>
          {loading ? `⏳ ${l.thinking}` : `🤖 ${l.analyze}`}
        </button>
      </div>

      {response && (
        <div style={{ background: 'linear-gradient(135deg, rgba(139,92,246,0.95), rgba(109,40,217,0.95))', borderRadius: '16px', padding: '20px', marginBottom: '15px', color: 'white' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px' }}>
            <span style={{ fontSize: '1.2rem' }}>🤖</span>
            <span style={{ fontWeight: 700, fontSize: '0.9rem' }}>SoonPsy AI</span>
          </div>
          <p style={{ fontSize: '0.85rem', lineHeight: 1.8, whiteSpace: 'pre-wrap', margin: 0 }}>{response}</p>
        </div>
      )}

      {history.length > 0 && (
        <div style={{ background: 'white', borderRadius: '16px', padding: '15px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
          <h4 style={{ color: '#8b5cf6', marginBottom: '10px' }}>📋 {l.history}</h4>
          {history.slice(0, 5).map((h, i) => (
            <div key={i} style={{ background: '#f5f3ff', borderRadius: '12px', padding: '12px', marginBottom: '8px', borderLeft: '3px solid #8b5cf6' }}>
              <div style={{ fontSize: '0.85rem', color: '#32325d', fontWeight: 600, marginBottom: '4px' }}>{h.q}</div>
              <div style={{ fontSize: '0.75rem', color: '#8898aa' }}>{new Date(h.date).toLocaleDateString()}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
