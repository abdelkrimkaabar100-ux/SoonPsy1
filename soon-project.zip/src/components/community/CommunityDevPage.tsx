import { useState } from 'react';
import InlineAIChat from '../shared/InlineAIChat';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';

interface CommunityAction {
  id: string;
  category: string;
  action: string;
  impact: string;
  date: string;
}

interface CommunityDevPageProps {
  onBack: () => void;
}

export default function CommunityDevPage({ onBack }: CommunityDevPageProps) {
  const { lang } = useLanguage();
  const isRTL = lang === 'ar';
  const [actions, setActions] = useLocalStorage<CommunityAction[]>('soon-community-dev', []);
  const [category, setCategory] = useState('volunteer');
  const [action, setAction] = useState('');
  const [impact, setImpact] = useState('');

  const categories = [
    { id: 'volunteer', icon: '🤝', label: isRTL ? 'تطوع' : 'Volunteer' },
    { id: 'educate', icon: '📚', label: isRTL ? 'تعليم' : 'Educate' },
    { id: 'environment', icon: '🌱', label: isRTL ? 'بيئة' : 'Environment' },
    { id: 'support', icon: '💛', label: isRTL ? 'دعم' : 'Support' },
    { id: 'build', icon: '🏗️', label: isRTL ? 'بناء' : 'Build' },
    { id: 'inspire', icon: '✨', label: isRTL ? 'إلهام' : 'Inspire' },
  ];

  const save = () => {
    if (!action.trim()) return;
    setActions(prev => [{ id: Date.now().toString(), category, action: action.trim(), impact: impact.trim(), date: new Date().toISOString() }, ...prev]);
    setAction(''); setImpact('');
  };

  const ideas = isRTL ? [
    'علّم طفلاً مهارة جديدة', 'ازرع شجرة في حيّك', 'تبرع بكتبك القديمة', 'ساعد جاراً مسناً', 
    'نظّم حملة نظافة', 'شارك في بنك الطعام', 'ادعم مشروعاً محلياً', 'انشر الوعي الصحي'
  ] : [
    'Teach a child a new skill', 'Plant a tree in your neighborhood', 'Donate old books', 'Help an elderly neighbor',
    'Organize a cleanup', 'Join a food bank', 'Support a local project', 'Spread health awareness'
  ];

  return (
    <div style={{ paddingTop: '20px', direction: isRTL ? 'rtl' : 'ltr' }}>
      <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#f59e0b', fontSize: '1rem', cursor: 'pointer', marginBottom: '15px' }}>
        <i className={`fas fa-arrow-${isRTL ? 'right' : 'left'}`}></i> {isRTL ? 'الرئيسية' : 'Home'}
      </button>

      <div style={{ background: 'linear-gradient(135deg, #f59e0b, #d97706)', borderRadius: '20px', padding: '25px', color: 'white', textAlign: 'center', marginBottom: '20px' }}>
        <div style={{ fontSize: '2.5rem', marginBottom: '10px' }}>🏘️🌍</div>
        <h2 style={{ fontSize: '1.3rem', fontWeight: 700, margin: '0 0 8px' }}>{isRTL ? 'تنمية مجتمعي' : 'Community Development'}</h2>
        <p style={{ fontSize: '0.85rem', opacity: 0.9, margin: 0 }}>{isRTL ? 'ساهم في بناء مجتمعك ووطنك 🇸🇦' : 'Contribute to building your community & country'}</p>
      </div>

      <div style={{ background: 'white', borderRadius: '16px', padding: '20px', marginBottom: '15px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)' }}>
        <h4 style={{ color: '#d97706', marginBottom: '15px' }}>💡 {isRTL ? 'أفكار ملهمة' : 'Inspiring Ideas'}</h4>
        <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', marginBottom: '15px' }}>
          {ideas.map((idea, i) => (
            <span key={i} onClick={() => setAction(idea)} style={{ padding: '6px 12px', background: '#fffbeb', borderRadius: '20px', fontSize: '0.75rem', color: '#92400e', cursor: 'pointer', border: '1px solid #fde68a' }}>
              {idea}
            </span>
          ))}
        </div>
      </div>

      <div style={{ background: 'white', borderRadius: '16px', padding: '20px', marginBottom: '15px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)' }}>
        <h4 style={{ color: '#d97706', marginBottom: '15px' }}>✍️ {isRTL ? 'سجّل مساهمتك' : 'Log Your Contribution'}</h4>
        <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', marginBottom: '15px' }}>
          {categories.map(c => (
            <button key={c.id} onClick={() => setCategory(c.id)} style={{
              padding: '8px 12px', borderRadius: '20px', border: 'none', cursor: 'pointer',
              background: category === c.id ? '#f59e0b' : '#f7f8fa',
              color: category === c.id ? 'white' : '#32325d', fontSize: '0.75rem', fontWeight: 600
            }}>{c.icon} {c.label}</button>
          ))}
        </div>
        <input type="text" value={action} onChange={e => setAction(e.target.value)} 
          placeholder={isRTL ? 'ماذا فعلت لمجتمعك؟' : 'What did you do for your community?'}
          style={{ width: '100%', padding: '12px', border: '2px solid #fef3c7', borderRadius: '12px', marginBottom: '10px', fontSize: '0.95rem', boxSizing: 'border-box' }} />
        <input type="text" value={impact} onChange={e => setImpact(e.target.value)}
          placeholder={isRTL ? 'ما الأثر الذي أحدثته؟ (اختياري)' : 'What impact did it have? (optional)'}
          style={{ width: '100%', padding: '12px', border: '2px solid #fef3c7', borderRadius: '12px', marginBottom: '15px', fontSize: '0.9rem', boxSizing: 'border-box' }} />
        <button onClick={save} style={{ width: '100%', background: 'linear-gradient(135deg, #f59e0b, #d97706)', color: 'white', border: 'none', borderRadius: '12px', padding: '14px', fontWeight: 600, cursor: 'pointer' }}>
          {isRTL ? '💪 سجّل مساهمتي' : '💪 Log Contribution'}
        </button>
      </div>

      <h4 style={{ color: '#32325d', marginBottom: '10px' }}>📋 {isRTL ? 'مساهماتي' : 'My Contributions'} ({actions.length})</h4>
      {actions.length === 0 && <p style={{ textAlign: 'center', color: '#8898aa' }}>{isRTL ? 'ابدأ بالمساهمة في مجتمعك!' : 'Start contributing to your community!'}</p>}
      {actions.slice(0, 15).map(a => (
        <div key={a.id} style={{ background: 'white', borderRadius: '12px', padding: '15px', marginBottom: '10px', borderLeft: '4px solid #f59e0b' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px' }}>
            <span style={{ fontSize: '0.75rem', background: '#fffbeb', color: '#92400e', padding: '2px 8px', borderRadius: '10px' }}>
              {categories.find(c => c.id === a.category)?.icon} {categories.find(c => c.id === a.category)?.label}
            </span>
            <span style={{ fontSize: '0.7rem', color: '#aaa' }}>{new Date(a.date).toLocaleDateString()}</span>
          </div>
          <p style={{ color: '#32325d', margin: '5px 0', fontWeight: 500 }}>{a.action}</p>
          {a.impact && <p style={{ color: '#8898aa', margin: 0, fontSize: '0.8rem' }}>✨ {a.impact}</p>}
        </div>
      ))}
      <InlineAIChat context="community-dev" lang={lang} />
    </div>
  );
}
