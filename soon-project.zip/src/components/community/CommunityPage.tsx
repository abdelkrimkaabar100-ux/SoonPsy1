import { useState, useEffect } from 'react';
import InlineAIChat from '../shared/InlineAIChat';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { supabase } from '@/integrations/supabase/client';

interface Post {
  id: string;
  content: string;
  anonymous_name: string;
  category: string;
  hearts: number;
  created_at: string;
}

interface Comment {
  id: string;
  post_id: string;
  content: string;
  anonymous_name: string;
  created_at: string;
}

interface CommunityPageProps {
  onBack: () => void;
}

export default function CommunityPage({ onBack }: CommunityPageProps) {
  const { t, lang } = useLanguage();
  const [userName] = useLocalStorage<string>('soon-user-name', '');
  const [posts, setPosts] = useState<Post[]>([]);
  const [comments, setComments] = useState<Record<string, Comment[]>>({});
  const [loading, setLoading] = useState(true);
  const [newPost, setNewPost] = useState('');
  const [isAnonymous, setIsAnonymous] = useState(true);
  const [category, setCategory] = useState('general');
  const [showComments, setShowComments] = useState<string | null>(null);
  const [commentInput, setCommentInput] = useState('');
  const [commentAnonymous, setCommentAnonymous] = useState(true);
  const [hearted, setHearted] = useLocalStorage<string[]>('soon-community-hearts', []);

  const categories = [
    { id: 'general', icon: '💬', labelKey: 'community.cat_general' },
    { id: 'achievement', icon: '🏆', labelKey: 'community.cat_achievement' },
    { id: 'concern', icon: '💭', labelKey: 'community.cat_concern' },
    { id: 'gratitude', icon: '🙏', labelKey: 'community.cat_gratitude' },
    { id: 'support', icon: '🤝', labelKey: 'community.cat_support' },
  ];

  useEffect(() => {
    fetchPosts();
  }, []);

  const fetchPosts = async () => {
    setLoading(true);
    const { data } = await supabase.from('community_posts').select('*').order('created_at', { ascending: false }).limit(50);
    if (data) setPosts(data);
    setLoading(false);
  };

  const fetchComments = async (postId: string) => {
    const { data } = await supabase.from('community_comments').select('*').eq('post_id', postId).order('created_at', { ascending: true });
    if (data) setComments(prev => ({ ...prev, [postId]: data }));
  };

  const submitPost = async () => {
    if (!newPost.trim()) return;
    const displayName = isAnonymous
      ? (lang === 'ar' ? 'مجهول' : lang === 'es' ? 'Anónimo' : lang === 'fr' ? 'Anonyme' : 'Anonymous')
      : (userName || (lang === 'ar' ? 'مجهول' : 'Anonymous'));

    await supabase.from('community_posts').insert({
      content: newPost.trim(),
      anonymous_name: displayName,
      category,
    });
    setNewPost('');
    fetchPosts();
  };

  const toggleHeart = async (postId: string, currentHearts: number) => {
    if (hearted.includes(postId)) return;
    setHearted(prev => [...prev, postId]);
    await supabase.from('community_posts').update({ hearts: currentHearts + 1 }).eq('id', postId);
    setPosts(prev => prev.map(p => p.id === postId ? { ...p, hearts: p.hearts + 1 } : p));
  };

  const submitComment = async (postId: string) => {
    if (!commentInput.trim()) return;
    const displayName = commentAnonymous
      ? (lang === 'ar' ? 'مجهول' : lang === 'es' ? 'Anónimo' : lang === 'fr' ? 'Anonyme' : 'Anonymous')
      : (userName || (lang === 'ar' ? 'مجهول' : 'Anonymous'));

    await supabase.from('community_comments').insert({
      post_id: postId,
      content: commentInput.trim(),
      anonymous_name: displayName,
    });
    setCommentInput('');
    fetchComments(postId);
  };

  const toggleComments = (postId: string) => {
    if (showComments === postId) {
      setShowComments(null);
    } else {
      setShowComments(postId);
      if (!comments[postId]) fetchComments(postId);
    }
  };

  const timeAgo = (dateStr: string) => {
    const diff = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return lang === 'ar' ? 'الآن' : 'now';
    if (mins < 60) return `${mins}${lang === 'ar' ? 'د' : 'm'}`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}${lang === 'ar' ? 'س' : 'h'}`;
    const days = Math.floor(hrs / 24);
    return `${days}${lang === 'ar' ? 'ي' : 'd'}`;
  };

  const catIcon = (cat: string) => categories.find(c => c.id === cat)?.icon || '💬';

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px', margin: '20px 0' }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', fontSize: '1.5rem', cursor: 'pointer', color: '#8965e0' }}>
          <i className="fas fa-arrow-left"></i>
        </button>
        <h2 style={{ fontSize: '1.5rem', fontWeight: 700, color: '#32325d', margin: 0 }}>
          🌐 {t('community.title')}
        </h2>
      </div>

      <p style={{ color: '#8898aa', fontSize: '0.85rem', textAlign: 'center', marginBottom: '20px' }}>
        {t('community.subtitle')}
      </p>

      {/* New Post */}
      <div style={{ background: 'white', borderRadius: '16px', padding: '15px', marginBottom: '20px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)', border: '2px solid #e8daff' }}>
        <textarea
          value={newPost} onChange={e => setNewPost(e.target.value)}
          placeholder={t('community.write_placeholder')}
          style={{ width: '100%', minHeight: '80px', border: '1px solid #e8daff', borderRadius: '12px', padding: '12px', fontFamily: 'Poppins, sans-serif', fontSize: '0.9rem', outline: 'none', resize: 'vertical', boxSizing: 'border-box' }}
        />

        {/* Categories */}
        <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', margin: '10px 0' }}>
          {categories.map(c => (
            <button key={c.id} onClick={() => setCategory(c.id)} style={{
              background: category === c.id ? '#8965e0' : '#f0f4ff', color: category === c.id ? 'white' : '#8965e0',
              border: 'none', borderRadius: '20px', padding: '6px 12px', fontSize: '0.75rem', fontWeight: 600,
              cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
            }}>
              {c.icon} {t(c.labelKey)}
            </button>
          ))}
        </div>

        {/* Anonymous toggle */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px' }}>
          <button onClick={() => setIsAnonymous(!isAnonymous)} style={{
            background: isAnonymous ? '#ffe0e6' : '#e8f5e9', color: isAnonymous ? '#ff6b6b' : '#2e7d32',
            border: 'none', borderRadius: '20px', padding: '6px 14px', fontSize: '0.8rem', fontWeight: 600,
            cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
          }}>
            {isAnonymous ? `🎭 ${t('community.anonymous')}` : `👤 ${userName || t('community.anonymous')}`}
          </button>
          <button onClick={submitPost} disabled={!newPost.trim()} style={{
            background: newPost.trim() ? 'linear-gradient(135deg, #8965e0, #6c47c7)' : '#ddd',
            color: 'white', border: 'none', borderRadius: '25px', padding: '10px 24px', fontWeight: 600,
            cursor: newPost.trim() ? 'pointer' : 'default', fontFamily: 'Poppins, sans-serif', fontSize: '0.85rem',
          }}>
            {t('community.post')}
          </button>
        </div>
      </div>

      {/* Posts */}
      {loading ? (
        <div style={{ textAlign: 'center', padding: '40px', color: '#8898aa' }}>
          <i className="fas fa-spinner fa-spin" style={{ fontSize: '2rem', marginBottom: '10px' }}></i>
          <p>{t('community.loading')}</p>
        </div>
      ) : posts.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '40px', color: '#8898aa' }}>
          <div style={{ fontSize: '3rem', marginBottom: '10px' }}>🌱</div>
          <p>{t('community.empty')}</p>
        </div>
      ) : (
        posts.map(post => (
          <div key={post.id} style={{
            background: 'white', borderRadius: '16px', padding: '15px', marginBottom: '12px',
            boxShadow: '0 4px 15px rgba(0,0,0,0.06)', border: '1px solid #f0f4ff',
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <div style={{
                  width: 36, height: 36, borderRadius: '50%', background: 'linear-gradient(135deg, #8965e0, #6c47c7)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontSize: '0.9rem', fontWeight: 700,
                }}>
                  {post.anonymous_name.charAt(0).toUpperCase()}
                </div>
                <div>
                  <div style={{ fontWeight: 600, fontSize: '0.9rem', color: '#32325d' }}>{post.anonymous_name}</div>
                  <div style={{ fontSize: '0.7rem', color: '#8898aa' }}>{timeAgo(post.created_at)}</div>
                </div>
              </div>
              <span style={{ fontSize: '0.75rem', background: '#f0f4ff', padding: '3px 10px', borderRadius: '12px', color: '#8965e0' }}>
                {catIcon(post.category)} {t(`community.cat_${post.category}`)}
              </span>
            </div>

            <p style={{ color: '#32325d', fontSize: '0.95rem', lineHeight: 1.6, margin: '10px 0', whiteSpace: 'pre-wrap' }}>
              {post.content}
            </p>

            <div style={{ display: 'flex', gap: '15px', alignItems: 'center', paddingTop: '8px', borderTop: '1px solid #f0f4ff' }}>
              <button onClick={() => toggleHeart(post.id, post.hearts)} style={{
                background: 'none', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '4px',
                color: hearted.includes(post.id) ? '#ff6b6b' : '#8898aa', fontSize: '0.9rem',
              }}>
                <i className={`fa${hearted.includes(post.id) ? 's' : 'r'} fa-heart`}></i>
                <span style={{ fontSize: '0.8rem', fontWeight: 600 }}>{post.hearts}</span>
              </button>
              <button onClick={() => toggleComments(post.id)} style={{
                background: 'none', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '4px',
                color: showComments === post.id ? '#8965e0' : '#8898aa', fontSize: '0.9rem',
              }}>
                <i className="far fa-comment"></i>
                <span style={{ fontSize: '0.8rem' }}>{t('community.comment')}</span>
              </button>
            </div>

            {/* Comments section */}
            {showComments === post.id && (
              <div style={{ marginTop: '12px', paddingTop: '12px', borderTop: '1px solid #f0f4ff' }}>
                {(comments[post.id] || []).map(c => (
                  <div key={c.id} style={{
                    background: '#f8f9fe', borderRadius: '12px', padding: '10px', marginBottom: '8px',
                  }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                      <span style={{ fontWeight: 600, fontSize: '0.8rem', color: '#8965e0' }}>{c.anonymous_name}</span>
                      <span style={{ fontSize: '0.7rem', color: '#8898aa' }}>{timeAgo(c.created_at)}</span>
                    </div>
                    <p style={{ margin: 0, fontSize: '0.85rem', color: '#32325d' }}>{c.content}</p>
                  </div>
                ))}

                <div style={{ display: 'flex', gap: '8px', alignItems: 'center', marginTop: '8px' }}>
                  <button onClick={() => setCommentAnonymous(!commentAnonymous)} style={{
                    background: commentAnonymous ? '#ffe0e6' : '#e8f5e9', border: 'none', borderRadius: '50%',
                    width: 32, height: 32, display: 'flex', alignItems: 'center', justifyContent: 'center',
                    cursor: 'pointer', fontSize: '0.8rem', flexShrink: 0,
                  }}>
                    {commentAnonymous ? '🎭' : '👤'}
                  </button>
                  <input
                    type="text" value={commentInput}
                    onChange={e => setCommentInput(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && submitComment(post.id)}
                    placeholder={t('community.comment_placeholder')}
                    style={{
                      flex: 1, padding: '8px 14px', border: '1px solid #e8daff', borderRadius: '25px',
                      fontFamily: 'Poppins, sans-serif', fontSize: '0.8rem', outline: 'none',
                    }}
                  />
                  <button onClick={() => submitComment(post.id)} style={{
                    background: '#8965e0', color: 'white', border: 'none', borderRadius: '50%',
                    width: 32, height: 32, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
                    cursor: 'pointer',
                  }}>
                    <i className="fas fa-paper-plane" style={{ fontSize: '0.75rem' }}></i>
                  </button>
                </div>
              </div>
            )}
          </div>
        ))
      )}
      <InlineAIChat context="community" lang={lang} />
    </div>
  );
}
