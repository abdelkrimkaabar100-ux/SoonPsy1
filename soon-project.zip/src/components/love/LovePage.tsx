import { useState } from 'react';
import InlineAIChat from '../shared/InlineAIChat';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { supabase } from '@/integrations/supabase/client';

interface LoveEntry {
  target: string;
  message: string;
  date: string;
}

const loveTargets = [
  { id: 'self', icon: '🪞', key: 'lp.self' },
  { id: 'partner', icon: '💑', key: 'lp.partner' },
  { id: 'friend', icon: '👫', key: 'lp.friend' },
  { id: 'family', icon: '👨‍👩‍👧‍👦', key: 'lp.family' },
  { id: 'pet', icon: '🐾', key: 'lp.pet' },
  { id: 'humanity', icon: '🌍', key: 'lp.humanity' },
  { id: 'animals', icon: '🐻', key: 'lp.animals' },
  { id: 'earth', icon: '🌎', key: 'lp.earth' },
  { id: 'all_beings', icon: '✨', key: 'lp.all_beings' },
  { id: 'god', icon: '🤲', key: 'lp.god' },
  { id: 'universe', icon: '🌌', key: 'lp.universe' },
];

interface LovePageProps {
  onBack: () => void;
}

export default function LovePage({ onBack }: LovePageProps) {
  const { t, lang } = useLanguage();
  const [entries, setEntries] = useLocalStorage<LoveEntry[]>('soon-love-page', []);
  const [selected, setSelected] = useState('');
  const [message, setMessage] = useState('');
  const [personName, setPersonName] = useState('');
  const isRTL = lang === 'ar';

  const needsName = ['partner', 'friend', 'family'].includes(selected);
  const today = new Date().toDateString();
  const todayEntries = entries.filter(e => new Date(e.date).toDateString() === today);

  const addEntry = () => {
    if (!selected || !message.trim()) return;
    const targetLabel = needsName && personName.trim() ? `${selected}:${personName.trim()}` : selected;
    setEntries(prev => [...prev, { target: targetLabel, message: message.trim(), date: new Date().toISOString() }]);
    setMessage('');
  };

  const getTargetDisplay = (target: string) => {
    if (target.includes(':')) {
      const [id, name] = target.split(':');
      const tg = loveTargets.find(l => l.id === id);
      return `${tg?.icon || '❤️'} ${name}`;
    }
    const tg = loveTargets.find(l => l.id === target);
    return `${tg?.icon || '❤️'} ${t(tg?.key || '')}`;
  };

  const prompts: Record<string, string[]> = {
    self: ['lp.prompt_self_1', 'lp.prompt_self_2', 'lp.prompt_self_3'],
    partner: ['lp.prompt_partner_1', 'lp.prompt_partner_2'],
    friend: ['lp.prompt_friend_1', 'lp.prompt_friend_2'],
    humanity: ['lp.prompt_humanity_1', 'lp.prompt_humanity_2'],
    animals: ['lp.prompt_animals_1'],
    earth: ['lp.prompt_earth_1'],
    god: ['lp.prompt_god_1', 'lp.prompt_god_2'],
    universe: ['lp.prompt_universe_1'],
    all_beings: ['lp.prompt_all_1'],
    pet: ['lp.prompt_pet_1'],
    family: ['lp.prompt_family_1'],
  };

  return (
    <div style={{ paddingTop: '20px', direction: isRTL ? 'rtl' : 'ltr' }}>
      <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#ff6b6b', fontSize: '1rem', cursor: 'pointer', marginBottom: '15px', fontFamily: 'Poppins, sans-serif' }}>
        <i className={`fas fa-arrow-${isRTL ? 'right' : 'left'}`}></i> {t('nav.home')}
      </button>

      <div style={{ textAlign: 'center', marginBottom: '20px' }}>
        <h2 style={{ color: '#ff6b6b', fontSize: '1.5rem', margin: '0 0 5px' }}>💝 {t('lp.title')}</h2>
        <p style={{ color: '#8898aa', fontSize: '0.85rem', margin: 0 }}>{t('lp.subtitle')}</p>
      </div>

      {/* Stats */}
      <div style={{ background: 'linear-gradient(135deg, #ff6b6b, #ee5a24)', borderRadius: '16px', padding: '15px', marginBottom: '20px', color: 'white', textAlign: 'center' }}>
        <div style={{ fontSize: '2rem', fontWeight: 700 }}>{todayEntries.length}</div>
        <div style={{ fontSize: '0.85rem', opacity: 0.9 }}>{t('lp.today_count')}</div>
      </div>

      {/* Targets */}
      <div style={{ background: 'white', borderRadius: '16px', padding: '15px', marginBottom: '15px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
        <h4 style={{ color: '#ff6b6b', marginBottom: '10px', textAlign: 'center' }}>{t('lp.who')}</h4>
        <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', justifyContent: 'center' }}>
          {loveTargets.map(lt => (
            <button key={lt.id} onClick={() => { setSelected(lt.id); setPersonName(''); }} style={{
              background: selected === lt.id ? 'linear-gradient(135deg, #ff6b6b, #ee5a24)' : '#fff0f3',
              color: selected === lt.id ? 'white' : '#ff6b6b',
              border: 'none', borderRadius: '20px', padding: '8px 12px', fontSize: '0.75rem', fontWeight: 600,
              cursor: 'pointer', fontFamily: 'Poppins, sans-serif', transition: 'all 0.3s ease',
            }}>
              {lt.icon} {t(lt.key)}
            </button>
          ))}
        </div>
      </div>

      {/* Name input for specific people */}
      {selected && needsName && (
        <div style={{ background: 'white', borderRadius: '16px', padding: '15px', marginBottom: '15px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
          <input type="text" value={personName} onChange={e => setPersonName(e.target.value)}
            placeholder={t('lp.name_placeholder')}
            style={{ width: '100%', padding: '10px 15px', border: '1px solid #ffe0e6', borderRadius: '25px', fontFamily: 'Poppins, sans-serif', fontSize: '0.85rem', outline: 'none', boxSizing: 'border-box' }}
          />
        </div>
      )}

      {/* Prompts */}
      {selected && prompts[selected] && (
        <div style={{ background: 'white', borderRadius: '16px', padding: '15px', marginBottom: '15px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
          <h5 style={{ color: '#32325d', marginBottom: '8px', fontSize: '0.85rem' }}>💡 {t('lp.ideas')}</h5>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
            {prompts[selected].map((p, i) => (
              <button key={i} onClick={() => setMessage(t(p))} style={{
                background: '#fff0f3', border: 'none', borderRadius: '12px', padding: '8px 12px',
                fontSize: '0.8rem', color: '#ff6b6b', cursor: 'pointer', textAlign: isRTL ? 'right' : 'left', fontFamily: 'Poppins, sans-serif',
              }}>
                {t(p)}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Message Input */}
      {selected && (
        <div style={{ background: 'white', borderRadius: '16px', padding: '15px', marginBottom: '20px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
          <div style={{ display: 'flex', gap: '8px' }}>
            <input type="text" value={message} onChange={e => setMessage(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && addEntry()}
              placeholder={t('lp.message_placeholder')}
              style={{ flex: 1, padding: '10px 15px', border: '1px solid #ffe0e6', borderRadius: '25px', fontFamily: 'Poppins, sans-serif', fontSize: '0.85rem', outline: 'none' }}
            />
            <button onClick={addEntry} style={{
              background: '#ff6b6b', color: 'white', border: 'none', borderRadius: '50%',
              width: 40, height: 40, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
              cursor: 'pointer', fontSize: '1.2rem',
            }}>💝</button>
          </div>
        </div>
      )}

      {/* Today's entries */}
      {todayEntries.length > 0 && (
        <div style={{ background: 'white', borderRadius: '16px', padding: '15px', marginBottom: '20px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
          <h4 style={{ color: '#ff6b6b', marginBottom: '10px' }}>💌 {t('lp.today_love')}</h4>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {todayEntries.map((e, i) => (
              <div key={i} style={{
                background: 'linear-gradient(135deg, #fff0f3, #ffe0e6)', borderRadius: '12px', padding: '12px',
                fontSize: '0.85rem', color: '#32325d',
              }}>
                <strong>{getTargetDisplay(e.target)}: </strong>
                {e.message}
                <button onClick={async () => {
                  try {
                    const { data } = await supabase.from('shared_messages').insert({
                      type: 'love', recipient_name: e.target.includes(':') ? e.target.split(':')[1] : '',
                      content: e.message, sender_name: localStorage.getItem('soon-user-name') || '',
                    }).select('id').single();
                    if (data) {
                      const link = `${window.location.origin}/shared/${data.id}`;
                      if (navigator.share) navigator.share({ url: link });
                      else { navigator.clipboard.writeText(link); alert(isRTL ? 'تم نسخ الرابط!' : 'Link copied!'); }
                    }
                  } catch (err) { console.error(err); }
                }} style={{ background: '#f59e0b', color: 'white', border: 'none', borderRadius: '15px', padding: '4px 10px', fontSize: '0.7rem', cursor: 'pointer', fontFamily: 'Poppins, sans-serif', marginInlineStart: '8px' }}>
                  🔗 {isRTL ? 'مشاركة' : 'Share'}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Total */}
      <div style={{ textAlign: 'center', padding: '20px', color: '#8898aa', fontSize: '0.85rem' }}>
        {t('lp.total')}: {entries.length} 💝
      </div>
      <InlineAIChat context="love" lang={lang} />
    </div>
  );
}
