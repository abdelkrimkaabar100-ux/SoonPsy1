import { useState, useMemo, useEffect } from 'react';
import InlineAIChat from '../shared/InlineAIChat';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { supabase } from '@/integrations/supabase/client';

interface WeightEntry {
  id: string;
  weight: number;
  date: string;
  note?: string;
}

interface PregnancyData {
  startDate: string;
  dueDate: string;
  currentWeek: number;
  notes: string[];
}

interface FeelingsEntry {
  id: string;
  text: string;
  date: string;
  mood?: number;
}

interface CycleData {
  lastPeriodStart: string;
  cycleLength: number;
  periodLength: number;
  periodHistory: string[];
}

interface ChildPlanItem {
  id: string;
  category: string;
  text: string;
  amount?: number;
  done: boolean;
  date: string;
}

interface ChildPlanData {
  enabled: boolean;
  targetDate: string;
  monthlySaving: number;
  items: ChildPlanItem[];
  notes: string[];
}

interface WomenWellnessPageProps {
  onBack: () => void;
}

export default function WomenWellnessPage({ onBack }: WomenWellnessPageProps) {
  const { t, lang } = useLanguage();
  const isRTL = lang === 'ar';
  
  const [weightEntries, setWeightEntries] = useLocalStorage<WeightEntry[]>('soon-women-weight', []);
  const [pregnancy, setPregnancy] = useLocalStorage<PregnancyData | null>('soon-women-pregnancy', null);
  const [feelings, setFeelings] = useLocalStorage<FeelingsEntry[]>('soon-women-feelings', []);
  const [cycleData, setCycleData] = useLocalStorage<CycleData | null>('soon-women-cycle', null);
  const [childPlan, setChildPlan] = useLocalStorage<ChildPlanData | null>('soon-child-plan', null);
  const [cycleAIEnabled, setCycleAIEnabled] = useLocalStorage<boolean>('soon-cycle-ai-enabled', false);
  const [childPlanAIEnabled, setChildPlanAIEnabled] = useLocalStorage<boolean>('soon-childplan-ai-enabled', false);
  const [cycleAIResponse, setCycleAIResponse] = useState('');
  const [cycleAILoading, setCycleAILoading] = useState(false);
  const [childPlanAIResponse, setChildPlanAIResponse] = useState('');
  const [childPlanAILoading, setChildPlanAILoading] = useState(false);
  const [activeSection, setActiveSection] = useState<'home' | 'feelings' | 'weight' | 'pregnancy' | 'chat' | 'affirmations' | 'map' | 'cycle' | 'child-plan'>('home');
  
  const [weight, setWeight] = useState('');
  const [weightNote, setWeightNote] = useState('');
  const [pregnancyStart, setPregnancyStart] = useState('');
  const [pregnancyNote, setPregnancyNote] = useState('');
  const [feelingsText, setFeelingsText] = useState('');
  const [feelingsMood, setFeelingsMood] = useState(3);
  
  const [chatMessages, setChatMessages] = useState<{role: string; content: string}[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [pendingShare, setPendingShare] = useState<string | null>(null);

  const affirmationsList = [
    t('women.aff1'), t('women.aff2'), t('women.aff3'), t('women.aff4'),
    t('women.aff5'), t('women.aff6'), t('women.aff7'), t('women.aff8'),
  ];

  const moodEmojis = ['😢', '😟', '😐', '🙂', '😊'];

  // Cycle phase calculator
  const getCyclePhase = () => {
    if (!cycleData?.lastPeriodStart) return null;
    const start = new Date(cycleData.lastPeriodStart);
    const today = new Date();
    const daysSinceStart = Math.floor((today.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
    const dayInCycle = daysSinceStart % cycleData.cycleLength;
    
    if (dayInCycle < cycleData.periodLength) return { phase: 'menstrual', day: dayInCycle + 1 };
    if (dayInCycle < 13) return { phase: 'follicular', day: dayInCycle + 1 };
    if (dayInCycle < 16) return { phase: 'ovulation', day: dayInCycle + 1 };
    return { phase: 'luteal', day: dayInCycle + 1 };
  };

  const getNextPeriodDate = () => {
    if (!cycleData?.lastPeriodStart) return null;
    const start = new Date(cycleData.lastPeriodStart);
    const today = new Date();
    const daysSinceStart = Math.floor((today.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
    const currentCycleDay = daysSinceStart % cycleData.cycleLength;
    const daysUntilNext = cycleData.cycleLength - currentCycleDay;
    const nextDate = new Date(today);
    nextDate.setDate(nextDate.getDate() + daysUntilNext);
    return { date: nextDate, daysUntil: daysUntilNext };
  };

  const [cycleStartInput, setCycleStartInput] = useState('');
  const [cycleLengthInput, setCycleLengthInput] = useState('28');
  const [periodLengthInput, setPeriodLengthInput] = useState('5');

  const saveCycleSettings = () => {
    if (!cycleStartInput) return;
    setCycleData({
      lastPeriodStart: cycleStartInput,
      cycleLength: parseInt(cycleLengthInput) || 28,
      periodLength: parseInt(periodLengthInput) || 5,
      periodHistory: [...(cycleData?.periodHistory || []), cycleStartInput],
    });
    setCycleStartInput('');
  };

  const logNewPeriod = () => {
    const todayStr = new Date().toISOString().split('T')[0];
    if (cycleData) {
      setCycleData({
        ...cycleData,
        lastPeriodStart: todayStr,
        periodHistory: [...cycleData.periodHistory, todayStr],
      });
    }
  };

  const fetchCycleAIAdvice = async () => {
    const phase = getCyclePhase();
    if (!phase || cycleAILoading) return;
    setCycleAILoading(true);
    try {
      const systemPrompt = lang === 'ar'
        ? `أنتِ مستشارة نفسية حنونة متخصصة في صحة المرأة. قدمي نصائح نفسية لطيفة بناءً على مرحلة الدورة الشهرية الحالية. كوني دافئة ومتعاطفة. لا تشخصي. ردي بالعربية.`
        : `You are a compassionate women's wellness advisor. Give gentle psychological advice based on the current menstrual cycle phase. Be warm and empathetic. Don't diagnose. Respond in ${lang === 'es' ? 'Spanish' : lang === 'fr' ? 'French' : 'English'}.`;
      const msg = lang === 'ar'
        ? `أنا في مرحلة ${phase.phase === 'menstrual' ? 'الحيض' : phase.phase === 'follicular' ? 'الجريبية' : phase.phase === 'ovulation' ? 'الإباضة' : 'اللوتينية'}، اليوم ${phase.day} من الدورة. أعطيني نصائح نفسية مناسبة لهذه المرحلة.`
        : `I'm in the ${phase.phase} phase, day ${phase.day} of my cycle. Give me psychological tips for this phase.`;
      const { data, error } = await supabase.functions.invoke('groq-chat', {
        body: { messages: [{ role: 'user', content: msg }], systemPrompt }
      });
      if (error) throw error;
      setCycleAIResponse(data.content || '');
    } catch {
      setCycleAIResponse(lang === 'ar' ? 'حدث خطأ. يرجى المحاولة لاحقاً.' : 'An error occurred. Please try again.');
    } finally { setCycleAILoading(false); }
  };

  const fetchChildPlanAIAdvice = async () => {
    if (childPlanAILoading) return;
    setChildPlanAILoading(true);
    try {
      const systemPrompt = lang === 'ar'
        ? `أنتِ مستشارة نفسية حنونة متخصصة في التخطيط للأمومة. قدمي نصائح نفسية حول الاستعداد العاطفي والنفسي لقدوم طفل، مستوحاة من أفكار ملاني كلاين. كوني لطيفة وداعمة. ردي بالعربية.`
        : `You are a compassionate family planning advisor. Give psychological advice on emotional readiness for a child, inspired by Melanie Klein. Be kind and supportive. Respond in ${lang === 'es' ? 'Spanish' : lang === 'fr' ? 'French' : 'English'}.`;
      const planInfo = childPlan ? `Target date: ${childPlan.targetDate}, Monthly saving: ${childPlan.monthlySaving}, Items planned: ${childPlan.items.length}, Completed: ${childPlan.items.filter(i => i.done).length}` : 'No plan started yet.';
      const msg = lang === 'ar'
        ? `أنا أخطط لإنجاب طفل. هذه معلومات خطتي: ${planInfo}. أعطيني نصائح نفسية حول الاستعداد العاطفي.`
        : `I'm planning for a child. My plan info: ${planInfo}. Give me psychological advice on emotional readiness.`;
      const { data, error } = await supabase.functions.invoke('groq-chat', {
        body: { messages: [{ role: 'user', content: msg }], systemPrompt }
      });
      if (error) throw error;
      setChildPlanAIResponse(data.content || '');
    } catch {
      setChildPlanAIResponse(lang === 'ar' ? 'حدث خطأ. يرجى المحاولة لاحقاً.' : 'An error occurred. Please try again.');
    } finally { setChildPlanAILoading(false); }
  };

  const phaseColors: Record<string, string> = {
    menstrual: '#ef4444',
    follicular: '#f59e0b',
    ovulation: '#10b981',
    luteal: '#8b5cf6',
  };

  const phaseEmojis: Record<string, string> = {
    menstrual: '🩸',
    follicular: '🌱',
    ovulation: '🌸',
    luteal: '🌙',
  };

  const logWeight = () => {
    if (!weight) return;
    setWeightEntries(prev => [{ id: Date.now().toString(), weight: parseFloat(weight), date: new Date().toISOString(), note: weightNote.trim() || undefined }, ...prev]);
    setWeight(''); setWeightNote('');
  };

  const startPregnancy = () => {
    if (!pregnancyStart) return;
    const start = new Date(pregnancyStart);
    const due = new Date(start); due.setDate(due.getDate() + 280);
    const weeksDiff = Math.floor((new Date().getTime() - start.getTime()) / (7 * 24 * 60 * 60 * 1000));
    setPregnancy({ startDate: pregnancyStart, dueDate: due.toISOString(), currentWeek: Math.max(1, Math.min(40, weeksDiff + 1)), notes: [] });
    setPregnancyStart('');
  };

  const addPregnancyNote = () => {
    if (!pregnancyNote.trim() || !pregnancy) return;
    setPregnancy({ ...pregnancy, notes: [...pregnancy.notes, pregnancyNote.trim()] });
    setPregnancyNote('');
  };

  const saveFeelings = () => {
    if (!feelingsText.trim()) return;
    setFeelings(prev => [{ id: Date.now().toString(), text: feelingsText.trim(), date: new Date().toISOString(), mood: feelingsMood }, ...prev]);
    setFeelingsText(''); setFeelingsMood(3);
  };

  const shareOneFeeling = (entry: FeelingsEntry) => {
    const msg = lang === 'ar' ? `مشاعري: ${entry.text}` : `My feelings: ${entry.text}`;
    setChatMessages([{ role: 'user', content: msg }]);
    setPendingShare(msg);
    setActiveSection('chat');
  };

  // Auto-send when feelings are shared with AI
  useEffect(() => {
    if (pendingShare && activeSection === 'chat') {
      const sendShared = async () => {
        setIsLoading(true);
        try {
          const systemPrompt = `أنتِ مساعدة نفسية حنونة ومتعاطفة مخصصة للنساء. اسمك "سون للمرأة". 
تتحدثين بلطف شديد وحنان. تدعمين المرأة نفسياً وعاطفياً.
تذكريها دائماً بأنها رائعة وقوية ومهمة.
"حين تكون المرأة بخير… يصبح العالم بخير."
كوني داعمة، متفهمة، ولطيفة جداً في ردودك. ردي بنفس لغة الرسالة.`;
          const { data, error } = await supabase.functions.invoke('groq-chat', {
            body: { messages: [{ role: 'user', content: pendingShare }], systemPrompt }
          });
          if (error) throw error;
          setChatMessages(prev => [...prev, { role: 'assistant', content: data.content }]);
        } catch {
          setChatMessages(prev => [...prev, { role: 'assistant', content: t('women.chat_error') }]);
        } finally {
          setIsLoading(false);
          setPendingShare(null);
        }
      };
      sendShared();
    }
  }, [pendingShare, activeSection]);

  const sendChat = async () => {
    if (!chatInput.trim() || isLoading) return;
    const userMsg = chatInput.trim();
    setChatInput('');
    const newMessages = [...chatMessages, { role: 'user', content: userMsg }];
    setChatMessages(newMessages);
    setIsLoading(true);
    try {
      const systemPrompt = `أنتِ مساعدة نفسية حنونة ومتعاطفة مخصصة للنساء. اسمك "سون للمرأة". 
تتحدثين بلطف شديد وحنان. تدعمين المرأة نفسياً وعاطفياً.
تذكريها دائماً بأنها رائعة وقوية ومهمة.
"حين تكون المرأة بخير… يصبح العالم بخير."
كوني داعمة، متفهمة، ولطيفة جداً في ردودك. ردي بنفس لغة الرسالة.`;
      const { data, error } = await supabase.functions.invoke('groq-chat', {
        body: { messages: newMessages.map(m => ({ role: m.role, content: m.content })), systemPrompt }
      });
      if (error) throw error;
      setChatMessages(prev => [...prev, { role: 'assistant', content: data.content }]);
    } catch {
      setChatMessages(prev => [...prev, { role: 'assistant', content: t('women.chat_error') }]);
    } finally { setIsLoading(false); }
  };

  const calculatePregnancyProgress = () => pregnancy ? Math.min(100, (pregnancy.currentWeek / 40) * 100) : 0;

  const feelingsMap = useMemo(() => {
    const last7 = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(); d.setDate(d.getDate() - i);
      const dayStr = d.toISOString().split('T')[0];
      const dayFeelings = feelings.filter(f => f.date.startsWith(dayStr));
      const avgMood = dayFeelings.length > 0 ? dayFeelings.reduce((s, f) => s + (f.mood || 3), 0) / dayFeelings.length : null;
      last7.push({ date: dayStr, day: d.toLocaleDateString(lang, { weekday: 'short' }), mood: avgMood, count: dayFeelings.length });
    }
    return last7;
  }, [feelings, lang]);

  const pinkGradient = 'linear-gradient(135deg, #ec4899, #f472b6)';
  const pinkLight = '#fdf2f8';
  const pinkAccent = '#ec4899';

  return (
    <div style={{ paddingTop: '20px', direction: isRTL ? 'rtl' : 'ltr' }}>
      <button onClick={onBack} style={{ background: 'none', border: 'none', color: pinkAccent, fontSize: '1rem', cursor: 'pointer', marginBottom: '15px' }}>
        <i className={`fas fa-arrow-${isRTL ? 'right' : 'left'}`}></i> {t('nav.home')}
      </button>

      <div style={{ background: pinkGradient, borderRadius: '20px', padding: '25px 20px', color: 'white', textAlign: 'center', marginBottom: '20px', boxShadow: '0 8px 25px rgba(236, 72, 153, 0.3)' }}>
        <div style={{ fontSize: '2.5rem', marginBottom: '10px' }}>👩‍🦰💖</div>
        <h2 style={{ fontSize: '1.4rem', fontWeight: 700, margin: '0 0 8px' }}>{t('women.title')}</h2>
        <p style={{ fontSize: '0.9rem', opacity: 0.95, margin: '0 0 10px', fontStyle: 'italic' }}>"{t('women.motto')}"</p>
        <p style={{ fontSize: '0.75rem', opacity: 0.85, margin: 0 }}>{t('women.subtitle')}</p>
      </div>

      <div style={{ background: pinkLight, borderRadius: '16px', padding: '15px', marginBottom: '20px', borderLeft: `4px solid ${pinkAccent}` }}>
        <p style={{ color: pinkAccent, fontSize: '0.95rem', fontWeight: 600, margin: 0, textAlign: 'center' }}>
          ✨ {affirmationsList[Math.floor(Math.random() * affirmationsList.length)]}
        </p>
      </div>

      <div style={{ display: 'flex', gap: '6px', marginBottom: '20px', flexWrap: 'wrap' }}>
        {(['home', 'cycle', 'feelings', 'map', 'weight', 'pregnancy', 'child-plan', 'chat', 'affirmations'] as const).map(s => (
          <button key={s} onClick={() => setActiveSection(s)} style={{
            flex: 1, minWidth: '40px', padding: '10px 3px', borderRadius: '12px', border: 'none', cursor: 'pointer',
            background: activeSection === s ? pinkGradient : '#fff',
            color: activeSection === s ? 'white' : '#32325d', fontWeight: 600, fontSize: '0.55rem',
            boxShadow: activeSection === s ? '0 4px 15px rgba(236,72,153,0.3)' : '0 2px 8px rgba(0,0,0,0.05)'
          }}>
            {s === 'home' && '🏠'}{s === 'cycle' && '🩸'}{s === 'feelings' && '💭'}{s === 'map' && '📊'}{s === 'weight' && '⚖️'}{s === 'pregnancy' && '🤰'}{s === 'child-plan' && '👶'}{s === 'chat' && '💬'}{s === 'affirmations' && '💖'}
            <br/>{s === 'child-plan' ? (lang === 'ar' ? 'تخطيط' : 'Plan') : t(`women.tab_${s}`)}
          </button>
        ))}
      </div>

      {activeSection === 'home' && (
        <div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '20px' }}>
            {[
              { section: 'cycle' as const, icon: '🩸', label: t('women.cycle_tracker'), sub: getCyclePhase() ? t(`women.phase_${getCyclePhase()!.phase}`) : t('women.not_started'), pink: true },
              { section: 'feelings' as const, icon: '💭', label: t('women.feelings_space'), sub: `${feelings.length} ${t('women.entries')}` },
              { section: 'map' as const, icon: '📊', label: t('women.feelings_map'), sub: t('women.weekly_view') },
              { section: 'weight' as const, icon: '⚖️', label: t('women.weight_tracker'), sub: `${weightEntries.length} ${t('women.entries')}` },
              { section: 'pregnancy' as const, icon: '🤰', label: t('women.pregnancy_tracker'), sub: pregnancy ? `${t('women.week')} ${pregnancy.currentWeek}` : t('women.not_started') },
              { section: 'chat' as const, icon: '💬', label: t('women.ai_support'), sub: t('women.compassionate') },
              { section: 'child-plan' as const, icon: '👶', label: lang === 'ar' ? 'تخطيط للأولاد' : 'Child Planning', sub: childPlan?.enabled ? (lang === 'ar' ? 'مفعّل' : 'Active') : (lang === 'ar' ? 'غير مفعّل' : 'Not started') },
            ].map(item => (
              <div key={item.section} onClick={() => setActiveSection(item.section)} style={{ background: 'white', borderRadius: '16px', padding: '20px', textAlign: 'center', cursor: 'pointer', boxShadow: '0 4px 15px rgba(0,0,0,0.05)', border: item.pink ? `2px solid ${pinkAccent}` : 'none' }}>
                <div style={{ fontSize: '2rem', marginBottom: '8px' }}>{item.icon}</div>
                <div style={{ color: item.pink ? pinkAccent : '#32325d', fontWeight: 600, fontSize: '0.85rem' }}>{item.label}</div>
                <div style={{ color: '#8898aa', fontSize: '0.7rem' }}>{item.sub}</div>
              </div>
            ))}
            <div onClick={() => setActiveSection('affirmations')} style={{ background: 'white', borderRadius: '16px', padding: '20px', textAlign: 'center', cursor: 'pointer', boxShadow: '0 4px 15px rgba(0,0,0,0.05)' }}>
              <div style={{ fontSize: '2rem', marginBottom: '8px' }}>💖</div>
              <div style={{ color: '#32325d', fontWeight: 600, fontSize: '0.85rem' }}>{t('women.affirmations')}</div>
              <div style={{ color: '#8898aa', fontSize: '0.7rem' }}>{t('women.daily_love')}</div>
            </div>
          </div>
          <div style={{ background: pinkGradient, borderRadius: '16px', padding: '20px', color: 'white', textAlign: 'center' }}>
            <div style={{ fontSize: '1.5rem', marginBottom: '10px' }}>👑</div>
            <p style={{ fontSize: '1rem', fontWeight: 600, margin: 0, lineHeight: 1.6 }}>{t('women.empower_quote')}</p>
          </div>
          <InlineAIChat context="women" lang={lang} />
        </div>
      )}

      {activeSection === 'cycle' && (
        <div>
          {!cycleData ? (
            <div style={{ background: 'white', borderRadius: '16px', padding: '25px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)' }}>
              <div style={{ textAlign: 'center', marginBottom: '20px' }}>
                <div style={{ fontSize: '3rem', marginBottom: '10px' }}>🩸🌙</div>
                <h4 style={{ color: pinkAccent, marginBottom: '10px' }}>{t('women.cycle_tracker')}</h4>
                <p style={{ color: '#8898aa', fontSize: '0.85rem', lineHeight: 1.6 }}>{t('women.cycle_desc')}</p>
              </div>
              <div style={{ marginBottom: '15px' }}>
                <label style={{ display: 'block', fontSize: '0.85rem', color: '#32325d', fontWeight: 600, marginBottom: '6px' }}>{t('women.cycle_start')}</label>
                <input type="date" value={cycleStartInput} onChange={e => setCycleStartInput(e.target.value)}
                  style={{ width: '100%', padding: '12px', border: `2px solid ${pinkLight}`, borderRadius: '12px', boxSizing: 'border-box' }} />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginBottom: '15px' }}>
                <div>
                  <label style={{ display: 'block', fontSize: '0.8rem', color: '#32325d', fontWeight: 600, marginBottom: '6px' }}>{t('women.cycle_length')}</label>
                  <input type="number" value={cycleLengthInput} onChange={e => setCycleLengthInput(e.target.value)}
                    style={{ width: '100%', padding: '12px', border: `2px solid ${pinkLight}`, borderRadius: '12px', boxSizing: 'border-box' }} />
                </div>
                <div>
                  <label style={{ display: 'block', fontSize: '0.8rem', color: '#32325d', fontWeight: 600, marginBottom: '6px' }}>{t('women.period_length')}</label>
                  <input type="number" value={periodLengthInput} onChange={e => setPeriodLengthInput(e.target.value)}
                    style={{ width: '100%', padding: '12px', border: `2px solid ${pinkLight}`, borderRadius: '12px', boxSizing: 'border-box' }} />
                </div>
              </div>
              <button onClick={saveCycleSettings} style={{ width: '100%', background: pinkGradient, color: 'white', border: 'none', borderRadius: '12px', padding: '14px', fontWeight: 600, cursor: 'pointer', fontSize: '1rem' }}>
                {t('women.save_cycle')}
              </button>
            </div>
          ) : (
            <div>
              {/* Current Phase */}
              {(() => {
                const phase = getCyclePhase();
                const next = getNextPeriodDate();
                if (!phase) return null;
                return (
                  <>
                    <div style={{ background: `linear-gradient(135deg, ${phaseColors[phase.phase]}, ${phaseColors[phase.phase]}aa)`, borderRadius: '20px', padding: '25px', color: 'white', textAlign: 'center', marginBottom: '15px', boxShadow: `0 8px 25px ${phaseColors[phase.phase]}44` }}>
                      <div style={{ fontSize: '3rem', marginBottom: '10px' }}>{phaseEmojis[phase.phase]}</div>
                      <div style={{ fontSize: '0.8rem', opacity: 0.9, marginBottom: '4px' }}>{t('women.cycle_phase')}</div>
                      <h3 style={{ fontSize: '1.3rem', fontWeight: 700, margin: '0 0 8px' }}>{t(`women.phase_${phase.phase}`)}</h3>
                      <div style={{ fontSize: '0.9rem', opacity: 0.9 }}>
                        {lang === 'ar' ? `اليوم ${phase.day} من الدورة` : `Day ${phase.day} of cycle`}
                      </div>
                    </div>
                    
                    {/* Empathetic message for current phase */}
                    <div style={{ background: 'white', borderRadius: '16px', padding: '20px', marginBottom: '15px', borderLeft: `4px solid ${phaseColors[phase.phase]}`, boxShadow: '0 4px 15px rgba(0,0,0,0.05)' }}>
                      <p style={{ color: '#32325d', fontSize: '0.9rem', lineHeight: 1.8, margin: 0 }}>
                        {t(`women.phase_${phase.phase}_desc`)}
                      </p>
                    </div>

                    {/* Next period countdown */}
                    {next && (
                      <div style={{ background: pinkLight, borderRadius: '16px', padding: '18px', marginBottom: '15px', textAlign: 'center' }}>
                        <div style={{ fontSize: '0.8rem', color: '#8898aa', marginBottom: '6px' }}>{t('women.next_period')}</div>
                        <div style={{ fontSize: '2rem', fontWeight: 700, color: pinkAccent }}>{next.daysUntil}</div>
                        <div style={{ fontSize: '0.8rem', color: '#8898aa' }}>{t('women.days_until')} {next.date.toLocaleDateString()}</div>
                      </div>
                    )}

                    {/* Phase visual timeline */}
                    <div style={{ background: 'white', borderRadius: '16px', padding: '15px', marginBottom: '15px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)' }}>
                      <div style={{ display: 'flex', gap: '4px', marginBottom: '10px' }}>
                        {['menstrual', 'follicular', 'ovulation', 'luteal'].map(p => (
                          <div key={p} style={{
                            flex: p === 'menstrual' ? 1 : p === 'follicular' ? 2 : p === 'ovulation' ? 0.5 : 2,
                            height: '8px', borderRadius: '4px',
                            background: phase.phase === p ? phaseColors[p] : `${phaseColors[p]}33`,
                            transition: 'all 0.3s',
                          }} />
                        ))}
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.6rem', color: '#8898aa' }}>
                        <span>🩸</span><span>🌱</span><span>🌸</span><span>🌙</span>
                      </div>
                    </div>

                    {/* Log new period */}
                    <button onClick={logNewPeriod} style={{ width: '100%', background: pinkGradient, color: 'white', border: 'none', borderRadius: '12px', padding: '14px', fontWeight: 600, cursor: 'pointer', marginBottom: '15px' }}>
                      🩸 {t('women.log_period')}
                    </button>

                    {/* Mood-cycle connection */}
                    {(phase.phase === 'luteal' || phase.phase === 'menstrual') && (
                      <div style={{ background: '#fef3c7', borderRadius: '12px', padding: '15px', marginBottom: '15px', borderLeft: '4px solid #f59e0b' }}>
                        <p style={{ color: '#92400e', fontSize: '0.85rem', margin: 0, lineHeight: 1.6 }}>
                          💡 {t('women.cycle_mood_link')}
                        </p>
                      </div>
                    )}

                    {/* AI Toggle for Cycle */}
                    <div style={{ background: 'white', borderRadius: '16px', padding: '18px', marginBottom: '15px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)', border: `2px solid ${pinkAccent}33` }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: cycleAIEnabled ? '15px' : '0' }}>
                        <div>
                          <h4 style={{ color: pinkAccent, margin: 0, fontSize: '0.9rem' }}>🤖 {lang === 'ar' ? 'مساعدة الذكاء الاصطناعي' : 'AI Assistant'}</h4>
                          <p style={{ color: '#8898aa', fontSize: '0.7rem', margin: '4px 0 0' }}>
                            {!cycleAIEnabled 
                              ? (lang === 'ar' ? '⚠️ معطل — أنتِ من تفعّلينه إذا أردتِ' : '⚠️ Disabled — Enable it if you want')
                              : (lang === 'ar' ? '✅ مفعّل' : '✅ Enabled')}
                          </p>
                        </div>
                        <button onClick={() => setCycleAIEnabled(!cycleAIEnabled)} style={{
                          background: cycleAIEnabled ? pinkGradient : '#f0f0f0',
                          color: cycleAIEnabled ? 'white' : '#666',
                          border: 'none', borderRadius: '20px', padding: '8px 16px',
                          fontWeight: 600, cursor: 'pointer', fontSize: '0.8rem',
                        }}>
                          {cycleAIEnabled ? (lang === 'ar' ? 'إيقاف' : 'OFF') : (lang === 'ar' ? 'تفعيل' : 'ON')}
                        </button>
                      </div>
                      {cycleAIEnabled && (
                        <div>
                          <button onClick={fetchCycleAIAdvice} disabled={cycleAILoading} style={{
                            width: '100%', background: pinkGradient, color: 'white',
                            border: 'none', borderRadius: '12px', padding: '12px', fontWeight: 600,
                            cursor: 'pointer', fontSize: '0.9rem', marginBottom: '10px',
                          }}>
                            {cycleAILoading ? '💭...' : (lang === 'ar' ? '💡 احصلي على نصيحة نفسية' : '💡 Get Psychological Advice')}
                          </button>
                          {cycleAIResponse && (
                            <div style={{ background: pinkLight, borderRadius: '12px', padding: '15px', borderLeft: `4px solid ${pinkAccent}`, lineHeight: 1.8, fontSize: '0.85rem', color: '#32325d', whiteSpace: 'pre-wrap' }}>
                              {cycleAIResponse}
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Period history */}
                    {cycleData.periodHistory.length > 0 && (
                      <div style={{ background: 'white', borderRadius: '16px', padding: '15px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)' }}>
                        <h4 style={{ color: pinkAccent, marginBottom: '10px', fontSize: '0.95rem' }}>📅 {t('women.cycle_history')}</h4>
                        {cycleData.periodHistory.slice(-10).reverse().map((d, i) => (
                          <div key={i} style={{ padding: '8px 12px', background: i % 2 === 0 ? pinkLight : 'white', borderRadius: '8px', marginBottom: '4px', fontSize: '0.85rem', color: '#32325d' }}>
                            🩸 {new Date(d).toLocaleDateString()}
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Reset */}
                    <button onClick={() => setCycleData(null)} style={{ background: '#fee2e2', color: '#dc2626', border: 'none', borderRadius: '10px', padding: '10px', width: '100%', cursor: 'pointer', marginTop: '15px', fontSize: '0.85rem' }}>
                      {t('women.end_tracking')}
                    </button>
                  </>
                );
              })()}
            </div>
          )}
        </div>
      )}


      {activeSection === 'feelings' && (
        <div>
          <div style={{ background: 'white', borderRadius: '16px', padding: '20px', marginBottom: '15px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)' }}>
            <h4 style={{ color: pinkAccent, marginBottom: '15px' }}>💭 {t('women.feelings_title')}</h4>
            <p style={{ color: '#8898aa', fontSize: '0.85rem', marginBottom: '15px' }}>{t('women.feelings_desc')}</p>
            <div style={{ display: 'flex', justifyContent: 'center', gap: '12px', marginBottom: '15px' }}>
              {moodEmojis.map((emoji, i) => (
                <button key={i} onClick={() => setFeelingsMood(i + 1)} style={{
                  fontSize: '1.8rem', background: feelingsMood === i + 1 ? pinkLight : 'transparent',
                  border: feelingsMood === i + 1 ? `2px solid ${pinkAccent}` : '2px solid transparent',
                  borderRadius: '50%', width: '50px', height: '50px', cursor: 'pointer', transition: 'all 0.2s'
                }}>{emoji}</button>
              ))}
            </div>
            <textarea value={feelingsText} onChange={e => setFeelingsText(e.target.value)} placeholder={t('women.feelings_placeholder')}
              style={{ width: '100%', padding: '15px', border: `2px solid ${pinkLight}`, borderRadius: '12px', fontSize: '0.95rem', minHeight: '120px', resize: 'vertical', boxSizing: 'border-box' }} />
            <button onClick={saveFeelings} style={{ width: '100%', background: pinkGradient, color: 'white', border: 'none', borderRadius: '12px', padding: '12px', fontWeight: 600, cursor: 'pointer', marginTop: '15px' }}>
              {t('women.save_feelings')}
            </button>
          </div>

          <h4 style={{ color: '#32325d', marginBottom: '10px' }}>📖 {t('women.feelings_history')}</h4>
          {feelings.length === 0 && <p style={{ textAlign: 'center', color: '#8898aa' }}>{t('women.no_feelings')}</p>}
          {feelings.slice(0, 15).map(f => (
            <div key={f.id} style={{ background: 'white', borderRadius: '12px', padding: '15px', marginBottom: '10px', borderLeft: `4px solid ${pinkAccent}` }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                <span style={{ fontSize: '1.3rem' }}>{moodEmojis[(f.mood || 3) - 1]}</span>
                <button onClick={() => shareOneFeeling(f)} style={{ background: pinkLight, border: 'none', borderRadius: '20px', padding: '4px 12px', color: pinkAccent, fontSize: '0.7rem', fontWeight: 600, cursor: 'pointer' }}
                  aria-label={t('women.share_ai')}>
                  💬 {t('women.share_ai')}
                </button>
              </div>
              <p style={{ color: '#32325d', margin: 0, lineHeight: 1.6 }}>{f.text}</p>
              <span style={{ fontSize: '0.7rem', color: '#aaa' }}>{new Date(f.date).toLocaleDateString()}</span>
            </div>
          ))}
        </div>
      )}

      {activeSection === 'map' && (
        <div>
          <div style={{ background: 'white', borderRadius: '16px', padding: '20px', marginBottom: '15px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)' }}>
            <h4 style={{ color: pinkAccent, marginBottom: '15px' }}>📊 {t('women.feelings_map')}</h4>
            <p style={{ color: '#8898aa', fontSize: '0.85rem', marginBottom: '20px' }}>{t('women.map_desc')}</p>
            <div style={{ display: 'flex', alignItems: 'flex-end', gap: '8px', height: '160px', padding: '0 10px' }}>
              {feelingsMap.map((day, i) => (
                <div key={i} style={{ flex: 1, textAlign: 'center', display: 'flex', flexDirection: 'column', justifyContent: 'flex-end', height: '100%' }}>
                  {day.mood !== null ? (
                    <>
                      <div style={{ fontSize: '1rem', marginBottom: '4px' }}>{moodEmojis[Math.round(day.mood) - 1]}</div>
                      <div style={{
                        height: `${(day.mood / 5) * 100}px`, background: pinkGradient,
                        borderRadius: '8px 8px 0 0', transition: 'height 0.5s', minHeight: '20px'
                      }} />
                    </>
                  ) : (
                    <div style={{ height: '20px', background: '#f0f0f0', borderRadius: '8px 8px 0 0' }} />
                  )}
                  <div style={{ fontSize: '0.65rem', color: '#8898aa', marginTop: '4px' }}>{day.day}</div>
                  <div style={{ fontSize: '0.55rem', color: '#bbb' }}>{day.count > 0 ? `${day.count}` : '-'}</div>
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '15px', padding: '10px', background: pinkLight, borderRadius: '10px' }}>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: '0.7rem', color: '#8898aa' }}>{t('women.total_entries')}</div>
                <div style={{ fontWeight: 700, color: pinkAccent }}>{feelings.length}</div>
              </div>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: '0.7rem', color: '#8898aa' }}>{t('women.avg_mood')}</div>
                <div style={{ fontWeight: 700, color: pinkAccent }}>
                  {feelings.length > 0 ? moodEmojis[Math.round(feelings.reduce((s, f) => s + (f.mood || 3), 0) / feelings.length) - 1] : '-'}
                </div>
              </div>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: '0.7rem', color: '#8898aa' }}>{t('women.this_week')}</div>
                <div style={{ fontWeight: 700, color: pinkAccent }}>{feelingsMap.reduce((s, d) => s + d.count, 0)}</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeSection === 'weight' && (
        <div>
          <div style={{ background: 'white', borderRadius: '16px', padding: '20px', marginBottom: '15px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)' }}>
            <h4 style={{ color: pinkAccent, marginBottom: '15px' }}>⚖️ {t('women.log_weight')}</h4>
            <div style={{ display: 'flex', gap: '10px', marginBottom: '10px' }}>
              <input type="number" value={weight} onChange={e => setWeight(e.target.value)} placeholder={t('women.weight_kg')}
                style={{ flex: 1, padding: '12px', border: `2px solid ${pinkLight}`, borderRadius: '12px', fontSize: '1rem' }} />
              <button onClick={logWeight} style={{ background: pinkGradient, color: 'white', border: 'none', borderRadius: '12px', padding: '12px 20px', fontWeight: 600, cursor: 'pointer' }}>
                {t('women.save')}
              </button>
            </div>
            <input type="text" value={weightNote} onChange={e => setWeightNote(e.target.value)} placeholder={t('women.note_optional')}
              style={{ width: '100%', padding: '10px', border: `1px solid ${pinkLight}`, borderRadius: '10px', fontSize: '0.85rem', boxSizing: 'border-box' }} />
          </div>
          <h4 style={{ color: '#32325d', marginBottom: '10px' }}>📊 {t('women.weight_history')}</h4>
          {weightEntries.length === 0 && <p style={{ textAlign: 'center', color: '#8898aa' }}>{t('women.no_entries')}</p>}
          {weightEntries.slice(0, 10).map(e => (
            <div key={e.id} style={{ background: 'white', borderRadius: '10px', padding: '12px', marginBottom: '8px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <span style={{ fontSize: '1.1rem', fontWeight: 700, color: pinkAccent }}>{e.weight} kg</span>
                {e.note && <div style={{ fontSize: '0.75rem', color: '#8898aa' }}>{e.note}</div>}
              </div>
              <span style={{ fontSize: '0.7rem', color: '#aaa' }}>{new Date(e.date).toLocaleDateString()}</span>
            </div>
          ))}
        </div>
      )}

      {activeSection === 'pregnancy' && (
        <div>
          {!pregnancy ? (
            <div style={{ background: 'white', borderRadius: '16px', padding: '25px', textAlign: 'center', boxShadow: '0 4px 15px rgba(0,0,0,0.05)' }}>
              <div style={{ fontSize: '3rem', marginBottom: '15px' }}>🤰💕</div>
              <h4 style={{ color: pinkAccent, marginBottom: '15px' }}>{t('women.start_pregnancy')}</h4>
              <input type="date" value={pregnancyStart} onChange={e => setPregnancyStart(e.target.value)}
                style={{ padding: '12px', border: `2px solid ${pinkLight}`, borderRadius: '12px', marginBottom: '15px', width: '100%', boxSizing: 'border-box' }} />
              <button onClick={startPregnancy} style={{ background: pinkGradient, color: 'white', border: 'none', borderRadius: '12px', padding: '12px 30px', fontWeight: 600, cursor: 'pointer', width: '100%' }}>
                {t('women.start_tracking')}
              </button>
            </div>
          ) : (
            <div>
              <div style={{ background: pinkGradient, borderRadius: '16px', padding: '25px', color: 'white', textAlign: 'center', marginBottom: '15px' }}>
                <div style={{ fontSize: '2.5rem', marginBottom: '10px' }}>👶</div>
                <div style={{ fontSize: '2rem', fontWeight: 700 }}>{t('women.week')} {pregnancy.currentWeek}</div>
                <div style={{ fontSize: '0.85rem', opacity: 0.9 }}>{t('women.due_date')}: {new Date(pregnancy.dueDate).toLocaleDateString()}</div>
                <div style={{ background: 'rgba(255,255,255,0.3)', borderRadius: '20px', height: '10px', marginTop: '15px', overflow: 'hidden' }}>
                  <div style={{ background: 'white', height: '100%', width: `${calculatePregnancyProgress()}%`, borderRadius: '20px' }} />
                </div>
                <div style={{ fontSize: '0.75rem', marginTop: '8px', opacity: 0.9 }}>{Math.round(calculatePregnancyProgress())}% {t('women.complete')}</div>
              </div>
              <div style={{ background: 'white', borderRadius: '16px', padding: '15px', marginBottom: '15px' }}>
                <div style={{ display: 'flex', gap: '10px' }}>
                  <input type="text" value={pregnancyNote} onChange={e => setPregnancyNote(e.target.value)} placeholder={t('women.pregnancy_note_placeholder')}
                    style={{ flex: 1, padding: '10px', border: `1px solid ${pinkLight}`, borderRadius: '10px' }} />
                  <button onClick={addPregnancyNote} style={{ background: pinkGradient, color: 'white', border: 'none', borderRadius: '10px', padding: '10px 15px', cursor: 'pointer' }}>
                    <i className="fas fa-plus"></i>
                  </button>
                </div>
              </div>
              {pregnancy.notes.map((n, i) => (
                <div key={i} style={{ background: 'white', borderRadius: '10px', padding: '12px', marginBottom: '8px', borderLeft: `3px solid ${pinkAccent}` }}>{n}</div>
              ))}
              <button onClick={() => setPregnancy(null)} style={{ background: '#fee2e2', color: '#dc2626', border: 'none', borderRadius: '10px', padding: '10px', width: '100%', cursor: 'pointer', marginTop: '15px' }}>
                {t('women.end_tracking')}
              </button>
            </div>
          )}
        </div>
      )}

      {activeSection === 'chat' && (
        <div>
          <div style={{ background: 'white', borderRadius: '16px', padding: '15px', marginBottom: '15px', minHeight: '300px', maxHeight: '400px', overflowY: 'auto' }}>
            {chatMessages.length === 0 && (
              <div style={{ textAlign: 'center', padding: '40px 20px', color: '#8898aa' }}>
                <div style={{ fontSize: '3rem', marginBottom: '15px' }}>💝</div>
                <p style={{ fontSize: '0.9rem', lineHeight: 1.6 }}>{t('women.chat_welcome')}</p>
              </div>
            )}
            {chatMessages.map((m, i) => (
              <div key={i} style={{
                padding: '12px 15px', borderRadius: '16px', marginBottom: '10px', maxWidth: '85%',
                background: m.role === 'user' ? pinkGradient : pinkLight,
                color: m.role === 'user' ? 'white' : '#32325d',
                marginLeft: m.role === 'user' ? 'auto' : '0', marginRight: m.role === 'user' ? '0' : 'auto',
                whiteSpace: 'pre-wrap', lineHeight: 1.6
              }}>{m.content}</div>
            ))}
            {isLoading && <div style={{ textAlign: 'center', color: pinkAccent }}>💭 {t('women.typing')}...</div>}
          </div>
          <div style={{ display: 'flex', gap: '10px' }}>
            <input type="text" value={chatInput} onChange={e => setChatInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && sendChat()}
              placeholder={t('women.chat_placeholder')} style={{ flex: 1, padding: '14px', border: `2px solid ${pinkLight}`, borderRadius: '25px', fontSize: '0.9rem' }} />
            <button onClick={sendChat} disabled={isLoading} style={{ background: pinkGradient, color: 'white', border: 'none', borderRadius: '50%', width: '50px', height: '50px', cursor: 'pointer' }}>
              <i className="fas fa-paper-plane"></i>
            </button>
          </div>
        </div>
      )}

      {activeSection === 'affirmations' && (
        <div>
          <div style={{ background: pinkGradient, borderRadius: '16px', padding: '25px', color: 'white', textAlign: 'center', marginBottom: '20px' }}>
            <div style={{ fontSize: '2.5rem', marginBottom: '10px' }}>👑💖</div>
            <h3 style={{ margin: '0 0 10px', fontSize: '1.2rem' }}>{t('women.you_are_amazing')}</h3>
            <p style={{ margin: 0, fontSize: '0.9rem', opacity: 0.95 }}>{t('women.existence_gift')}</p>
          </div>
          <div style={{ display: 'grid', gap: '12px' }}>
            {affirmationsList.map((aff, i) => (
              <div key={i} style={{ background: 'white', borderRadius: '14px', padding: '18px', boxShadow: '0 4px 12px rgba(0,0,0,0.05)', borderLeft: `4px solid ${pinkAccent}` }}>
                <span style={{ fontSize: '1.2rem', marginRight: '10px' }}>💖</span>
                <span style={{ color: '#32325d', fontSize: '0.9rem', fontWeight: 500 }}>{aff}</span>
              </div>
            ))}
          </div>
          <div style={{ background: pinkLight, borderRadius: '16px', padding: '20px', marginTop: '20px', textAlign: 'center' }}>
            <p style={{ color: pinkAccent, fontSize: '1rem', fontWeight: 600, margin: 0, lineHeight: 1.6 }}>🌸 {t('women.deserve_best')} 🌸</p>
          </div>
        </div>
      )}

      {activeSection === 'child-plan' && (
        <ChildPlanSection
          lang={lang}
          childPlan={childPlan}
          setChildPlan={setChildPlan}
          pinkGradient={pinkGradient}
          pinkLight={pinkLight}
          pinkAccent={pinkAccent}
          aiEnabled={childPlanAIEnabled}
          setAIEnabled={setChildPlanAIEnabled}
          aiResponse={childPlanAIResponse}
          aiLoading={childPlanAILoading}
          fetchAIAdvice={fetchChildPlanAIAdvice}
        />
      )}
    </div>
  );
}

/* Child Planning Section */
function ChildPlanSection({ lang, childPlan, setChildPlan, pinkGradient, pinkLight, pinkAccent, aiEnabled, setAIEnabled, aiResponse, aiLoading, fetchAIAdvice }: {
  lang: string;
  childPlan: ChildPlanData | null;
  setChildPlan: (v: ChildPlanData | null | ((prev: ChildPlanData | null) => ChildPlanData | null)) => void;
  pinkGradient: string;
  pinkLight: string;
  pinkAccent: string;
  aiEnabled: boolean;
  setAIEnabled: (v: boolean) => void;
  aiResponse: string;
  aiLoading: boolean;
  fetchAIAdvice: () => void;
}) {
  const [newItemText, setNewItemText] = useState('');
  const [newItemAmount, setNewItemAmount] = useState('');
  const [newItemCategory, setNewItemCategory] = useState('financial');
  const [newNote, setNewNote] = useState('');
  const [targetDate, setTargetDate] = useState('');
  const [monthlySaving, setMonthlySaving] = useState('');

  const isRTL = lang === 'ar';

  const tx: Record<string, Record<string, string>> = {
    en: {
      title: '👶 Child Planning',
      quote: '"A child\'s mental health begins before birth. Planning with love ensures they enter a world ready for them." — Inspired by Melanie Klein',
      desc: 'This isn\'t just financial planning. It\'s building a foundation of love, stability, and psychological safety for your future child.',
      enable: 'Start Planning Together',
      disable: 'Pause Planning',
      klein_insight: '🧒 Melanie Klein, pioneer of child psychoanalysis, taught us that a child\'s emotional world forms from the very beginning. The environment we prepare — emotionally and practically — shapes their sense of security and self-worth.',
      target_date: 'Planned date',
      monthly_saving: 'Monthly saving for child',
      categories: 'Planning Categories',
      cat_financial: '💰 Financial',
      cat_emotional: '💝 Emotional Readiness',
      cat_health: '🏥 Health',
      cat_home: '🏠 Home Environment',
      add_item: 'Add planning item',
      item_placeholder: 'What needs to be prepared?',
      amount_placeholder: 'Cost (optional)',
      total_saved: 'Total projected savings by age 18',
      no_pressure: '💝 Remember: This is about thoughtful preparation, not pressure. Take your time. Every step of planning is an act of love.',
      add_note: 'Add a thought or reflection',
      note_placeholder: 'Your thoughts about this journey...',
      progress: 'Planning Progress',
      months_until: 'months until planned date',
      projected_18: 'Projected savings by age 18',
    },
    ar: {
      title: '👶 تخطيط لازدياد الأولاد',
      quote: '"الصحة النفسية للطفل تبدأ قبل ولادته. التخطيط بحب يضمن أنه سيأتي إلى عالم مُهيأ له." — مستوحى من ملاني كلاين',
      desc: 'هذا ليس مجرد تخطيط مالي. إنه بناء أساس من الحب والاستقرار والأمان النفسي لطفلك المستقبلي.',
      enable: 'ابدأ التخطيط معاً',
      disable: 'إيقاف التخطيط',
      klein_insight: '🧒 ملاني كلاين، رائدة التحليل النفسي للأطفال، علّمتنا أن العالم العاطفي للطفل يتشكل منذ البداية. البيئة التي نُعدّها — عاطفياً وعملياً — تشكّل إحساسه بالأمان وقيمة ذاته.',
      target_date: 'التاريخ المخطط',
      monthly_saving: 'الادخار الشهري للطفل',
      categories: 'فئات التخطيط',
      cat_financial: '💰 مالي',
      cat_emotional: '💝 الجاهزية العاطفية',
      cat_health: '🏥 الصحة',
      cat_home: '🏠 بيئة المنزل',
      add_item: 'أضف عنصر تخطيط',
      item_placeholder: 'ما الذي يحتاج للتحضير؟',
      amount_placeholder: 'التكلفة (اختياري)',
      total_saved: 'إجمالي المدخرات المتوقعة عند سن 18',
      no_pressure: '💝 تذكّري: هذا عن التحضير المدروس وليس الضغط. خذي وقتك. كل خطوة تخطيط هي فعل حب.',
      add_note: 'أضف فكرة أو تأمل',
      note_placeholder: 'أفكارك حول هذه الرحلة...',
      progress: 'تقدم التخطيط',
      months_until: 'شهر حتى التاريخ المخطط',
      projected_18: 'المدخرات المتوقعة عند سن 18',
    },
    es: {
      title: '👶 Planificación Familiar',
      quote: '"La salud mental de un niño comienza antes de nacer." — Inspirado en Melanie Klein',
      desc: 'No es solo planificación financiera. Es construir una base de amor y seguridad psicológica.',
      enable: 'Comenzar a planificar juntos',
      disable: 'Pausar planificación',
      klein_insight: '🧒 Melanie Klein nos enseñó que el mundo emocional del niño se forma desde el principio.',
      target_date: 'Fecha planeada',
      monthly_saving: 'Ahorro mensual para el niño',
      categories: 'Categorías',
      cat_financial: '💰 Financiero',
      cat_emotional: '💝 Emocional',
      cat_health: '🏥 Salud',
      cat_home: '🏠 Hogar',
      add_item: 'Agregar elemento',
      item_placeholder: '¿Qué necesita prepararse?',
      amount_placeholder: 'Costo (opcional)',
      total_saved: 'Ahorro total proyectado a los 18 años',
      no_pressure: '💝 Recuerda: esto es preparación consciente, no presión.',
      add_note: 'Agregar reflexión',
      note_placeholder: 'Tus pensamientos...',
      progress: 'Progreso',
      months_until: 'meses hasta la fecha',
      projected_18: 'Ahorro proyectado a los 18',
    },
    fr: {
      title: '👶 Planification Familiale',
      quote: '"La santé mentale d\'un enfant commence avant la naissance." — Inspiré de Melanie Klein',
      desc: 'Ce n\'est pas juste financier. C\'est construire une base d\'amour et de sécurité psychologique.',
      enable: 'Commencer à planifier ensemble',
      disable: 'Mettre en pause',
      klein_insight: '🧒 Melanie Klein nous a appris que le monde émotionnel de l\'enfant se forme dès le début.',
      target_date: 'Date prévue',
      monthly_saving: 'Épargne mensuelle',
      categories: 'Catégories',
      cat_financial: '💰 Financier',
      cat_emotional: '💝 Émotionnel',
      cat_health: '🏥 Santé',
      cat_home: '🏠 Maison',
      add_item: 'Ajouter un élément',
      item_placeholder: 'Que faut-il préparer?',
      amount_placeholder: 'Coût (optionnel)',
      total_saved: 'Épargne projetée à 18 ans',
      no_pressure: '💝 Rappelez-vous: c\'est une préparation réfléchie, pas de la pression.',
      add_note: 'Ajouter une réflexion',
      note_placeholder: 'Vos pensées...',
      progress: 'Progrès',
      months_until: 'mois jusqu\'à la date',
      projected_18: 'Épargne projetée à 18 ans',
    },
  };

  const t = tx[lang] || tx.en;

  const enablePlan = () => {
    setChildPlan({
      enabled: true,
      targetDate: targetDate || '',
      monthlySaving: parseFloat(monthlySaving) || 0,
      items: [],
      notes: [],
    });
  };

  const addItem = () => {
    if (!newItemText.trim() || !childPlan) return;
    const item: ChildPlanItem = {
      id: Date.now().toString(),
      category: newItemCategory,
      text: newItemText.trim(),
      amount: parseFloat(newItemAmount) || undefined,
      done: false,
      date: new Date().toISOString(),
    };
    setChildPlan(prev => prev ? { ...prev, items: [...prev.items, item] } : prev);
    setNewItemText('');
    setNewItemAmount('');
  };

  const toggleItem = (id: string) => {
    setChildPlan(prev => prev ? {
      ...prev,
      items: prev.items.map(i => i.id === id ? { ...i, done: !i.done } : i),
    } : prev);
  };

  const addNote = () => {
    if (!newNote.trim() || !childPlan) return;
    setChildPlan(prev => prev ? { ...prev, notes: [...prev.notes, newNote.trim()] } : prev);
    setNewNote('');
  };

  const updateSettings = () => {
    if (!childPlan) return;
    setChildPlan(prev => prev ? {
      ...prev,
      targetDate: targetDate || prev.targetDate,
      monthlySaving: parseFloat(monthlySaving) || prev.monthlySaving,
    } : prev);
  };

  // Calculate projections
  const monthsUntilTarget = childPlan?.targetDate
    ? Math.max(0, Math.floor((new Date(childPlan.targetDate).getTime() - Date.now()) / (30 * 24 * 60 * 60 * 1000)))
    : 0;
  const projectedAt18 = childPlan ? (childPlan.monthlySaving * (monthsUntilTarget + 18 * 12)) : 0;
  const totalItemCost = childPlan?.items.reduce((s, i) => s + (i.amount || 0), 0) || 0;
  const completedItems = childPlan?.items.filter(i => i.done).length || 0;
  const totalItems = childPlan?.items.length || 0;

  const categories = [
    { id: 'financial', label: t.cat_financial },
    { id: 'emotional', label: t.cat_emotional },
    { id: 'health', label: t.cat_health },
    { id: 'home', label: t.cat_home },
  ];

  if (!childPlan || !childPlan.enabled) {
    return (
      <div>
        <div style={{ background: 'white', borderRadius: '16px', padding: '25px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)', textAlign: 'center' }}>
          <div style={{ fontSize: '4rem', marginBottom: '15px' }}>👶💝</div>
          <h3 style={{ color: pinkAccent, marginBottom: '15px' }}>{t.title}</h3>
          <div style={{ background: pinkLight, borderRadius: '12px', padding: '15px', marginBottom: '20px', borderLeft: `4px solid ${pinkAccent}` }}>
            <p style={{ color: '#32325d', fontSize: '0.9rem', lineHeight: 1.8, margin: 0, fontStyle: 'italic' }}>{t.quote}</p>
          </div>
          <p style={{ color: '#8898aa', fontSize: '0.85rem', lineHeight: 1.7, marginBottom: '20px' }}>{t.desc}</p>
          <div style={{ background: '#eff6ff', borderRadius: '12px', padding: '15px', marginBottom: '20px', borderLeft: '4px solid #3b82f6' }}>
            <p style={{ color: '#1e40af', fontSize: '0.85rem', lineHeight: 1.8, margin: 0 }}>{t.klein_insight}</p>
          </div>

          <div style={{ marginBottom: '15px' }}>
            <label style={{ display: 'block', fontSize: '0.85rem', color: '#32325d', fontWeight: 600, marginBottom: '6px' }}>{t.target_date}</label>
            <input type="date" value={targetDate} onChange={e => setTargetDate(e.target.value)}
              style={{ width: '100%', padding: '12px', border: `2px solid ${pinkLight}`, borderRadius: '12px', boxSizing: 'border-box' }} />
          </div>
          <div style={{ marginBottom: '20px' }}>
            <label style={{ display: 'block', fontSize: '0.85rem', color: '#32325d', fontWeight: 600, marginBottom: '6px' }}>{t.monthly_saving}</label>
            <input type="number" value={monthlySaving} onChange={e => setMonthlySaving(e.target.value)} placeholder="0"
              style={{ width: '100%', padding: '12px', border: `2px solid ${pinkLight}`, borderRadius: '12px', boxSizing: 'border-box' }} />
          </div>

          <button onClick={enablePlan} style={{ width: '100%', background: pinkGradient, color: 'white', border: 'none', borderRadius: '12px', padding: '14px', fontWeight: 600, cursor: 'pointer', fontSize: '1rem' }}>
            💝 {t.enable}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div>
      {/* Quote */}
      <div style={{ background: pinkGradient, borderRadius: '16px', padding: '20px', color: 'white', textAlign: 'center', marginBottom: '15px' }}>
        <div style={{ fontSize: '2.5rem', marginBottom: '10px' }}>👶💝</div>
        <p style={{ fontSize: '0.85rem', fontStyle: 'italic', margin: 0, lineHeight: 1.7, opacity: 0.95 }}>{t.quote}</p>
      </div>

      {/* Progress Overview */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginBottom: '15px' }}>
        <div style={{ background: 'white', borderRadius: '12px', padding: '15px', textAlign: 'center', boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }}>
          <div style={{ fontSize: '0.7rem', color: '#8898aa' }}>{t.progress}</div>
          <div style={{ fontSize: '1.5rem', fontWeight: 700, color: pinkAccent }}>{completedItems}/{totalItems}</div>
        </div>
        <div style={{ background: 'white', borderRadius: '12px', padding: '15px', textAlign: 'center', boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }}>
          <div style={{ fontSize: '0.7rem', color: '#8898aa' }}>{monthsUntilTarget} {t.months_until}</div>
          <div style={{ fontSize: '1.5rem', fontWeight: 700, color: '#10b981' }}>{childPlan.monthlySaving}/mo</div>
        </div>
      </div>

      {/* Projected savings */}
      {projectedAt18 > 0 && (
        <div style={{ background: '#ecfdf5', borderRadius: '12px', padding: '15px', marginBottom: '15px', textAlign: 'center', borderLeft: '4px solid #10b981' }}>
          <div style={{ fontSize: '0.8rem', color: '#065f46' }}>{t.projected_18}</div>
          <div style={{ fontSize: '1.8rem', fontWeight: 700, color: '#10b981' }}>{projectedAt18.toLocaleString()}</div>
          <div style={{ fontSize: '0.7rem', color: '#8898aa', marginTop: '4px' }}>
            {lang === 'ar' ? 'عندما يبلغ طفلك 18 سنة سيجد مالاً يبدأ به حياته بثقة' : 'When your child turns 18, they\'ll have savings to start their life with confidence'}
          </div>
        </div>
      )}

      {/* Categories & Items */}
      <div style={{ background: 'white', borderRadius: '16px', padding: '18px', marginBottom: '15px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)' }}>
        <h4 style={{ color: pinkAccent, marginBottom: '15px' }}>{t.categories}</h4>
        
        <div style={{ display: 'flex', gap: '6px', marginBottom: '15px', flexWrap: 'wrap' }}>
          {categories.map(c => (
            <button key={c.id} onClick={() => setNewItemCategory(c.id)} style={{
              padding: '8px 12px', borderRadius: '20px', border: 'none', cursor: 'pointer',
              background: newItemCategory === c.id ? pinkGradient : pinkLight,
              color: newItemCategory === c.id ? 'white' : '#32325d', fontSize: '0.75rem', fontWeight: 600,
            }}>
              {c.label}
            </button>
          ))}
        </div>

        <div style={{ display: 'flex', gap: '8px', marginBottom: '10px' }}>
          <input type="text" value={newItemText} onChange={e => setNewItemText(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && addItem()} placeholder={t.item_placeholder}
            style={{ flex: 2, padding: '10px', border: `2px solid ${pinkLight}`, borderRadius: '10px', fontSize: '0.85rem' }} />
          <input type="number" value={newItemAmount} onChange={e => setNewItemAmount(e.target.value)}
            placeholder={t.amount_placeholder}
            style={{ flex: 1, padding: '10px', border: `2px solid ${pinkLight}`, borderRadius: '10px', fontSize: '0.85rem' }} />
          <button onClick={addItem} style={{ background: pinkGradient, color: 'white', border: 'none', borderRadius: '10px', padding: '10px 15px', cursor: 'pointer' }}>
            <i className="fas fa-plus"></i>
          </button>
        </div>

        {/* Items by category */}
        {categories.map(cat => {
          const catItems = childPlan.items.filter(i => i.category === cat.id);
          if (catItems.length === 0) return null;
          return (
            <div key={cat.id} style={{ marginBottom: '12px' }}>
              <div style={{ fontSize: '0.8rem', fontWeight: 600, color: pinkAccent, marginBottom: '6px' }}>{cat.label}</div>
              {catItems.map(item => (
                <div key={item.id} onClick={() => toggleItem(item.id)} style={{
                  display: 'flex', alignItems: 'center', gap: '10px', padding: '10px', borderRadius: '10px',
                  background: item.done ? '#ecfdf5' : pinkLight, marginBottom: '6px', cursor: 'pointer',
                }}>
                  <span style={{ fontSize: '1.2rem' }}>{item.done ? '✅' : '⬜'}</span>
                  <div style={{ flex: 1 }}>
                    <span style={{ color: '#32325d', fontSize: '0.85rem', textDecoration: item.done ? 'line-through' : 'none' }}>{item.text}</span>
                  </div>
                  {item.amount && (
                    <span style={{ color: '#10b981', fontWeight: 600, fontSize: '0.8rem' }}>{item.amount}</span>
                  )}
                </div>
              ))}
            </div>
          );
        })}

        {totalItemCost > 0 && (
          <div style={{ textAlign: 'center', padding: '10px', background: '#f0fdf4', borderRadius: '10px', marginTop: '10px' }}>
            <span style={{ fontSize: '0.8rem', color: '#065f46' }}>
              {lang === 'ar' ? 'إجمالي التكلفة المقدرة:' : 'Estimated total cost:'} <strong>{totalItemCost.toLocaleString()}</strong>
            </span>
          </div>
        )}
      </div>

      {/* Notes / Reflections */}
      <div style={{ background: 'white', borderRadius: '16px', padding: '18px', marginBottom: '15px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)' }}>
        <h4 style={{ color: pinkAccent, marginBottom: '10px' }}>📝 {t.add_note}</h4>
        <div style={{ display: 'flex', gap: '8px', marginBottom: '10px' }}>
          <input type="text" value={newNote} onChange={e => setNewNote(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && addNote()} placeholder={t.note_placeholder}
            style={{ flex: 1, padding: '10px', border: `2px solid ${pinkLight}`, borderRadius: '10px', fontSize: '0.85rem' }} />
          <button onClick={addNote} style={{ background: pinkGradient, color: 'white', border: 'none', borderRadius: '10px', padding: '10px 15px', cursor: 'pointer' }}>
            <i className="fas fa-plus"></i>
          </button>
        </div>
        {childPlan.notes.map((n, i) => (
          <div key={i} style={{ padding: '10px', background: pinkLight, borderRadius: '10px', marginBottom: '6px', borderLeft: `3px solid ${pinkAccent}` }}>
            <p style={{ margin: 0, fontSize: '0.85rem', color: '#32325d', lineHeight: 1.6 }}>{n}</p>
          </div>
        ))}
      </div>

      {/* AI Toggle for Child Planning */}
      <div style={{ background: 'white', borderRadius: '16px', padding: '18px', marginBottom: '15px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)', border: `2px solid ${pinkAccent}33` }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: aiEnabled ? '15px' : '0' }}>
          <div>
            <h4 style={{ color: pinkAccent, margin: 0, fontSize: '0.9rem' }}>🤖 {lang === 'ar' ? 'مساعدة الذكاء الاصطناعي' : 'AI Assistant'}</h4>
            <p style={{ color: '#8898aa', fontSize: '0.7rem', margin: '4px 0 0' }}>
              {!aiEnabled
                ? (lang === 'ar' ? '⚠️ معطل — أنتِ من تفعّلينه إذا أردتِ' : '⚠️ Disabled — Enable it if you want')
                : (lang === 'ar' ? '✅ مفعّل' : '✅ Enabled')}
            </p>
          </div>
          <button onClick={() => setAIEnabled(!aiEnabled)} style={{
            background: aiEnabled ? pinkGradient : '#f0f0f0',
            color: aiEnabled ? 'white' : '#666',
            border: 'none', borderRadius: '20px', padding: '8px 16px',
            fontWeight: 600, cursor: 'pointer', fontSize: '0.8rem',
          }}>
            {aiEnabled ? (lang === 'ar' ? 'إيقاف' : 'OFF') : (lang === 'ar' ? 'تفعيل' : 'ON')}
          </button>
        </div>
        {aiEnabled && (
          <div>
            <button onClick={fetchAIAdvice} disabled={aiLoading} style={{
              width: '100%', background: pinkGradient, color: 'white',
              border: 'none', borderRadius: '12px', padding: '12px', fontWeight: 600,
              cursor: 'pointer', fontSize: '0.9rem', marginBottom: '10px',
            }}>
              {aiLoading ? '💭...' : (lang === 'ar' ? '💡 احصلي على نصيحة نفسية' : '💡 Get Psychological Advice')}
            </button>
            {aiResponse && (
              <div style={{ background: pinkLight, borderRadius: '12px', padding: '15px', borderLeft: `4px solid ${pinkAccent}`, lineHeight: 1.8, fontSize: '0.85rem', color: '#32325d', whiteSpace: 'pre-wrap' }}>
                {aiResponse}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Klein insight */}
      <div style={{ background: '#eff6ff', borderRadius: '12px', padding: '15px', marginBottom: '15px', borderLeft: '4px solid #3b82f6' }}>
        <p style={{ color: '#1e40af', fontSize: '0.85rem', lineHeight: 1.8, margin: 0 }}>{t.klein_insight}</p>
      </div>

      {/* No pressure message */}
      <div style={{ background: pinkLight, borderRadius: '12px', padding: '15px', marginBottom: '15px', textAlign: 'center' }}>
        <p style={{ color: pinkAccent, fontSize: '0.85rem', lineHeight: 1.7, margin: 0 }}>{t.no_pressure}</p>
      </div>

      {/* Disable */}
      <button onClick={() => setChildPlan(prev => prev ? { ...prev, enabled: false } : prev)} style={{
        background: '#fee2e2', color: '#dc2626', border: 'none', borderRadius: '10px', padding: '10px',
        width: '100%', cursor: 'pointer', fontSize: '0.85rem',
      }}>
        {t.disable}
      </button>
    </div>
  );
}
