import { useState, useEffect } from 'react';
import InlineAIChat from '../shared/InlineAIChat';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';

interface FamilyPageProps {
  onBack: () => void;
}

interface FamilyMember {
  id: string;
  name: string;
  relation: string;
  isAlive: boolean;
}

interface DailySuggestion {
  text: string;
  icon: string;
  done: boolean;
}

const RELATIONS = [
  { key: 'mother', icon: '👩' },
  { key: 'father', icon: '👨' },
  { key: 'grandmother', icon: '👵' },
  { key: 'grandfather', icon: '👴' },
  { key: 'son', icon: '👦' },
  { key: 'daughter', icon: '👧' },
  { key: 'brother', icon: '🧑' },
  { key: 'sister', icon: '👩' },
  { key: 'uncle', icon: '👨' },
  { key: 'aunt', icon: '👩' },
  { key: 'husband', icon: '👨' },
  { key: 'wife', icon: '👩' },
  { key: 'cousin', icon: '🧑' },
  { key: 'other', icon: '❤️' },
];

export default function FamilyPage({ onBack }: FamilyPageProps) {
  const { t, lang } = useLanguage();
  const [members, setMembers] = useLocalStorage<FamilyMember[]>('soon-family-members', []);
  const [todaySuggestions, setTodaySuggestions] = useLocalStorage<{ date: string; suggestions: DailySuggestion[] }>('soon-family-suggestions', { date: '', suggestions: [] });
  const [showAddForm, setShowAddForm] = useState(false);
  const [newName, setNewName] = useState('');
  const [newRelation, setNewRelation] = useState('mother');
  const [newIsAlive, setNewIsAlive] = useState(true);
  const [editingId, setEditingId] = useState<string | null>(null);

  const today = new Date().toISOString().slice(0, 10);

  const aliveSuggestions = (name: string, relation: string) => [
    { text: t('family.sug_visit').replace('{name}', name).replace('{relation}', t(`family.rel_${relation}`)), icon: '🏠' },
    { text: t('family.sug_call').replace('{name}', name).replace('{relation}', t(`family.rel_${relation}`)), icon: '📞' },
    { text: t('family.sug_message').replace('{name}', name).replace('{relation}', t(`family.rel_${relation}`)), icon: '💬' },
    { text: t('family.sug_gift').replace('{name}', name).replace('{relation}', t(`family.rel_${relation}`)), icon: '🎁' },
    { text: t('family.sug_eat').replace('{name}', name).replace('{relation}', t(`family.rel_${relation}`)), icon: '🍽️' },
    { text: t('family.sug_hug').replace('{name}', name).replace('{relation}', t(`family.rel_${relation}`)), icon: '🤗' },
  ];

  const deceasedSuggestions = (name: string, relation: string) => [
    { text: t('family.sug_pray').replace('{name}', name).replace('{relation}', t(`family.rel_${relation}`)), icon: '🤲' },
    { text: t('family.sug_visit_grave').replace('{name}', name).replace('{relation}', t(`family.rel_${relation}`)), icon: '🕊️' },
    { text: t('family.sug_charity').replace('{name}', name).replace('{relation}', t(`family.rel_${relation}`)), icon: '💝' },
    { text: t('family.sug_remember').replace('{name}', name).replace('{relation}', t(`family.rel_${relation}`)), icon: '📖' },
  ];

  useEffect(() => {
    if (members.length > 0 && todaySuggestions.date !== today) {
      generateDailySuggestions();
    }
  }, [members, today]);

  const generateDailySuggestions = () => {
    const suggestions: DailySuggestion[] = [];
    members.forEach(member => {
      const pool = member.isAlive
        ? aliveSuggestions(member.name || t(`family.rel_${member.relation}`), member.relation)
        : deceasedSuggestions(member.name || t(`family.rel_${member.relation}`), member.relation);
      const randomIdx = Math.floor(Math.random() * pool.length);
      suggestions.push({ ...pool[randomIdx], done: false });
    });
    setTodaySuggestions({ date: today, suggestions });
  };

  const addMember = () => {
    const member: FamilyMember = {
      id: Date.now().toString(),
      name: newName.trim(),
      relation: newRelation,
      isAlive: newIsAlive,
    };
    setMembers(prev => [...prev, member]);
    setNewName('');
    setNewRelation('mother');
    setNewIsAlive(true);
    setShowAddForm(false);
  };

  const removeMember = (id: string) => {
    setMembers(prev => prev.filter(m => m.id !== id));
  };

  const toggleSuggestion = (idx: number) => {
    const updated = { ...todaySuggestions };
    updated.suggestions = [...updated.suggestions];
    updated.suggestions[idx] = { ...updated.suggestions[idx], done: !updated.suggestions[idx].done };
    setTodaySuggestions(updated);
  };

  const getRelationIcon = (relation: string) => {
    return RELATIONS.find(r => r.key === relation)?.icon || '❤️';
  };

  const completedCount = todaySuggestions.suggestions.filter(s => s.done).length;

  return (
    <div>
      {/* Header */}
      <div style={{ textAlign: 'center', margin: '20px 0' }}>
        <button onClick={onBack} style={{
          position: 'absolute', left: '25px', background: 'none', border: 'none',
          fontSize: '1.2rem', color: '#2DCE89', cursor: 'pointer',
        }}>
          <i className="fas fa-arrow-left"></i>
        </button>
        <h2 style={{ fontSize: '1.6rem', fontWeight: 700, color: '#32325d', margin: '0 0 5px' }}>
          👨‍👩‍👧‍👦 {t('family.title')}
        </h2>
        <p style={{ color: '#8898aa', fontSize: '0.9rem', margin: 0 }}>{t('family.subtitle')}</p>
      </div>

      {/* Stats */}
      <div style={{ display: 'flex', gap: '12px', marginBottom: '20px' }}>
        <div style={{
          flex: 1, background: 'linear-gradient(135deg, #f5365c, #d32f5a)', borderRadius: '16px',
          padding: '15px', color: 'white', textAlign: 'center',
        }}>
          <div style={{ fontSize: '1.8rem', fontWeight: 700 }}>{members.length}</div>
          <div style={{ fontSize: '0.8rem', opacity: 0.9 }}>{t('family.members_count')}</div>
        </div>
        <div style={{
          flex: 1, background: 'linear-gradient(135deg, #fb6340, #f56036)', borderRadius: '16px',
          padding: '15px', color: 'white', textAlign: 'center',
        }}>
          <div style={{ fontSize: '1.8rem', fontWeight: 700 }}>{completedCount}</div>
          <div style={{ fontSize: '0.8rem', opacity: 0.9 }}>{t('family.today_done')}</div>
        </div>
      </div>

      {/* Inspiration */}
      <div style={{
        background: 'linear-gradient(135deg, #fff5f5, #ffe0e0)', borderRadius: '16px',
        padding: '18px', marginBottom: '20px', textAlign: 'center',
        border: '1px solid #ffcdd2',
      }}>
        <p style={{ margin: 0, fontSize: '0.95rem', color: '#c62828', fontStyle: 'italic', lineHeight: 1.6 }}>
          {t('family.quote')}
        </p>
      </div>

      {/* Daily Suggestions */}
      {todaySuggestions.suggestions.length > 0 && (
        <>
          <h3 style={{ fontSize: '1.1rem', color: '#32325d', marginBottom: '15px' }}>
            💡 {t('family.daily_suggestions')}
          </h3>
          {todaySuggestions.suggestions.map((sug, idx) => (
            <div key={idx} onClick={() => toggleSuggestion(idx)} style={{
              display: 'flex', alignItems: 'center', gap: '14px',
              padding: '14px', marginBottom: '12px',
              background: sug.done ? 'linear-gradient(135deg, #e8f5e9, #c8e6c9)' : 'white',
              borderRadius: '16px', boxShadow: '0 4px 15px rgba(0,0,0,0.06)',
              cursor: 'pointer', borderLeft: `4px solid ${sug.done ? '#2DCE89' : '#f5365c'}`,
              transition: 'all 0.3s ease',
            }}>
              <div style={{
                width: 45, height: 45, borderRadius: '12px',
                background: sug.done ? '#2DCE89' : '#fff5f5',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: '1.4rem', flexShrink: 0,
              }}>
                {sug.done ? '✅' : sug.icon}
              </div>
              <p style={{
                margin: 0, fontSize: '0.9rem', color: '#32325d', lineHeight: 1.5,
                textDecoration: sug.done ? 'line-through' : 'none', flex: 1,
              }}>
                {sug.text}
              </p>
            </div>
          ))}

          <button onClick={generateDailySuggestions} style={{
            width: '100%', padding: '10px', background: 'none', border: '2px dashed #ffcdd2',
            borderRadius: '12px', color: '#f5365c', fontWeight: 600, cursor: 'pointer',
            fontSize: '0.85rem', fontFamily: 'Poppins, sans-serif', marginBottom: '20px',
          }}>
            🔄 {t('family.new_suggestions')}
          </button>
        </>
      )}

      {/* Family Members */}
      <h3 style={{ fontSize: '1.1rem', color: '#32325d', marginBottom: '15px' }}>
        {t('family.my_family')}
      </h3>

      {members.map(member => (
        <div key={member.id} style={{
          display: 'flex', alignItems: 'center', gap: '14px',
          padding: '14px', marginBottom: '12px',
          background: 'white', borderRadius: '16px',
          boxShadow: '0 4px 15px rgba(0,0,0,0.06)',
          borderLeft: `4px solid ${member.isAlive ? '#2DCE89' : '#8898aa'}`,
        }}>
          <div style={{
            width: 50, height: 50, borderRadius: '14px',
            background: member.isAlive ? '#f0f4ff' : '#f5f5f5',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: '1.6rem', flexShrink: 0,
          }}>
            {getRelationIcon(member.relation)}
          </div>
          <div style={{ flex: 1 }}>
            <h5 style={{ margin: '0 0 4px', fontSize: '1rem', color: '#32325d' }}>
              {member.name || t(`family.rel_${member.relation}`)}
            </h5>
            <p style={{ margin: 0, fontSize: '0.82rem', color: '#8898aa' }}>
              {t(`family.rel_${member.relation}`)} • {member.isAlive ? `💚 ${t('family.alive')}` : `🕊️ ${t('family.deceased')}`}
            </p>
          </div>
          <button onClick={() => removeMember(member.id)} style={{
            background: 'none', border: 'none', color: '#e0e0e0', fontSize: '1.1rem',
            cursor: 'pointer', padding: '5px',
          }}>
            <i className="fas fa-times"></i>
          </button>
        </div>
      ))}

      {/* Add Member Button / Form */}
      {showAddForm ? (
        <div style={{
          background: 'white', borderRadius: '16px', padding: '20px',
          boxShadow: '0 4px 15px rgba(0,0,0,0.06)', marginBottom: '20px',
        }}>
          <h4 style={{ margin: '0 0 15px', color: '#32325d', fontSize: '1rem' }}>
            {t('family.add_member')}
          </h4>

          <input
            type="text" value={newName} onChange={e => setNewName(e.target.value)}
            placeholder={t('family.name_placeholder')}
            style={{
              width: '100%', padding: '10px 14px', borderRadius: '12px',
              border: '1px solid #e0e0e0', fontSize: '0.9rem',
              fontFamily: 'Poppins, sans-serif', outline: 'none', marginBottom: '12px',
              boxSizing: 'border-box',
            }}
          />

          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginBottom: '12px' }}>
            {RELATIONS.map(rel => (
              <button key={rel.key} onClick={() => setNewRelation(rel.key)} style={{
                padding: '6px 12px', borderRadius: '10px', border: 'none',
                background: newRelation === rel.key ? 'linear-gradient(135deg, #f5365c, #d32f5a)' : '#f0f4ff',
                color: newRelation === rel.key ? 'white' : '#32325d',
                fontWeight: 600, fontSize: '0.75rem', cursor: 'pointer',
                fontFamily: 'Poppins, sans-serif',
              }}>
                {rel.icon} {t(`family.rel_${rel.key}`)}
              </button>
            ))}
          </div>

          <div style={{ display: 'flex', gap: '8px', marginBottom: '15px' }}>
            <button onClick={() => setNewIsAlive(true)} style={{
              flex: 1, padding: '10px', borderRadius: '12px', border: 'none',
              background: newIsAlive ? 'linear-gradient(135deg, #2DCE89, #1a9f6e)' : '#f0f4ff',
              color: newIsAlive ? 'white' : '#32325d',
              fontWeight: 600, fontSize: '0.85rem', cursor: 'pointer',
              fontFamily: 'Poppins, sans-serif',
            }}>
              💚 {t('family.alive')}
            </button>
            <button onClick={() => setNewIsAlive(false)} style={{
              flex: 1, padding: '10px', borderRadius: '12px', border: 'none',
              background: !newIsAlive ? 'linear-gradient(135deg, #8898aa, #6c7c8a)' : '#f0f4ff',
              color: !newIsAlive ? 'white' : '#32325d',
              fontWeight: 600, fontSize: '0.85rem', cursor: 'pointer',
              fontFamily: 'Poppins, sans-serif',
            }}>
              🕊️ {t('family.deceased')}
            </button>
          </div>

          <div style={{ display: 'flex', gap: '8px' }}>
            <button onClick={addMember} style={{
              flex: 1, padding: '12px', background: 'linear-gradient(135deg, #f5365c, #d32f5a)',
              border: 'none', borderRadius: '12px', color: 'white', fontWeight: 600,
              fontSize: '0.9rem', cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
            }}>
              {t('family.save')}
            </button>
            <button onClick={() => setShowAddForm(false)} style={{
              padding: '12px 20px', background: '#f0f4ff', border: 'none', borderRadius: '12px',
              color: '#8898aa', fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
            }}>
              {t('family.cancel')}
            </button>
          </div>
        </div>
      ) : (
        <button onClick={() => setShowAddForm(true)} style={{
          width: '100%', padding: '14px', background: 'linear-gradient(135deg, #f5365c, #d32f5a)',
          border: 'none', borderRadius: '14px', color: 'white', fontWeight: 600,
          fontSize: '1rem', cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
          marginBottom: '20px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
        }}>
          <i className="fas fa-plus"></i> {t('family.add_member')}
        </button>
      )}

      {/* Bottom message */}
      <div style={{
        background: 'linear-gradient(135deg, #f5365c, #fb6340)', borderRadius: '16px',
        padding: '20px', color: 'white', textAlign: 'center', marginBottom: '20px',
      }}>
        <h3 style={{ margin: '0 0 10px', fontSize: '1.2rem' }}>❤️ {t('family.bond_title')}</h3>
        <p style={{ margin: 0, fontSize: '0.9rem', opacity: 0.95, lineHeight: 1.6 }}>
          {t('family.bond_desc')}
        </p>
      </div>
      <InlineAIChat context="family" lang={lang} />
    </div>
  );
}
