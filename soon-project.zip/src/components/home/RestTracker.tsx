import { useState } from 'react';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { useLanguage } from '../../i18n/LanguageContext';

interface TrackerEntry { value: number; date: string; }
interface RestTrackerProps { onShareWithAI: (text: string) => void; }

export default function RestTracker({ onShareWithAI }: RestTrackerProps) {
  const { t } = useLanguage();
  const [restLog, setRestLog] = useLocalStorage<TrackerEntry[]>('soon-rest', []);
  const [restInput, setRestInput] = useState('');

  const getTodayRest = () => {
    const today = new Date().toDateString();
    return restLog.filter(e => new Date(e.date).toDateString() === today).reduce((sum, e) => sum + e.value, 0);
  };

  const todayRest = getTodayRest();
  const radius = 40;
  const circumference = 2 * Math.PI * radius;
  const progress = Math.min(todayRest / 60, 1);
  const dashArray = `${progress * circumference} ${circumference}`;

  const logRest = () => {
    const mins = parseInt(restInput);
    if (!isNaN(mins) && mins > 0) {
      setRestLog([...restLog, { value: mins, date: new Date().toISOString() }]);
      setRestInput('');
      alert(t('rest.logged').replace('{0}', String(mins)));
    }
  };

  const viewHistory = () => {
    const history = restLog.slice(-5).map(e => `${new Date(e.date).toLocaleDateString()}: ${e.value} min`).join('\n');
    alert(history || 'No rest history yet.');
  };

  return (
    <div style={{
      background: 'white', borderRadius: '16px', padding: '15px',
      boxShadow: '0 6px 20px rgba(0,0,0,0.08)', textAlign: 'center', marginBottom: '20px',
    }}>
      <h4 style={{ color: '#1a9f6e', marginBottom: '15px' }}>{t('rest.title')}</h4>
      <div style={{ width: 100, height: 100, margin: '0 auto 15px', position: 'relative' }}>
        <svg viewBox="0 0 100 100" style={{ width: '100%', height: '100%', transform: 'rotate(-90deg)' }}>
          <circle cx="50" cy="50" r={radius} fill="none" stroke="#eee" strokeWidth="8" />
          <circle cx="50" cy="50" r={radius} fill="none" stroke="#8965e0" strokeWidth="8"
            strokeLinecap="round" strokeDasharray={dashArray} style={{ transition: 'stroke-dasharray 0.5s ease' }} />
        </svg>
        <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', fontSize: '1.2rem', fontWeight: 700, color: '#8965e0' }}>
          {todayRest}m
        </div>
      </div>
      <p style={{ fontSize: '0.9rem', color: '#8898aa', margin: '5px 0 15px' }}>
        {t('rest.today')}: <strong>{todayRest} min</strong>
      </p>
      <input type="number" value={restInput} onChange={e => setRestInput(e.target.value)}
        placeholder={t('rest.placeholder')} min="0" max="1440" step="5"
        style={{ width: '100%', padding: '10px 15px', border: '1px solid #ddd', borderRadius: '25px',
          fontFamily: 'Poppins, sans-serif', fontSize: '0.9rem', outline: 'none', marginBottom: '10px', boxSizing: 'border-box' }}
      />
      <button onClick={logRest} style={{ background: '#8965e0', color: 'white', border: 'none', borderRadius: '25px', padding: '10px 20px', fontWeight: 600, cursor: 'pointer', width: '100%', fontFamily: 'Poppins, sans-serif', marginBottom: '10px' }}>{t('rest.log')}</button>
      <button onClick={() => onShareWithAI(`Today I rested for ${todayRest} minutes.`)} style={{ background: '#8965e0', color: 'white', border: 'none', borderRadius: '25px', padding: '10px 20px', fontWeight: 600, cursor: 'pointer', width: '100%', fontFamily: 'Poppins, sans-serif', marginBottom: '10px' }}>{t('rest.share')}</button>
      <button onClick={viewHistory} style={{ background: '#d1efe1', color: '#2DCE89', border: 'none', borderRadius: '25px', padding: '10px 20px', fontWeight: 600, cursor: 'pointer', width: '100%', fontFamily: 'Poppins, sans-serif' }}>{t('rest.view_history')}</button>
    </div>
  );
}
