import { useState, useCallback } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';

interface BathroomEntry {
  type: string;
  date: string;
}

interface ShowerEntry {
  date: string;
}

export default function SelfCareTracker() {
  const { t, lang } = useLanguage();
  const [bathroomLog, setBathroomLog] = useLocalStorage<BathroomEntry[]>('soon-bathroom-log', []);
  const [showerLog, setShowerLog] = useLocalStorage<ShowerEntry[]>('soon-shower-log', []);
  const [showBathroomSection, setShowBathroomSection] = useState(false);
  const [showShowerSection, setShowShowerSection] = useState(false);
  const [feedback, setFeedback] = useState('');
  const [showerJustLogged, setShowerJustLogged] = useState(false);
  const [renderKey, setRenderKey] = useState(0);

  const today = new Date().toDateString();
  const todayBathroom = bathroomLog.filter(e => new Date(e.date).toDateString() === today);
  const todayShowered = showerLog.some(e => new Date(e.date).toDateString() === today);

  const lastShower = showerLog.length > 0 ? new Date(showerLog[showerLog.length - 1].date) : null;
  const daysSinceShower = lastShower ? Math.floor((Date.now() - lastShower.getTime()) / (1000 * 60 * 60 * 24)) : 999;
  const showGentleReminder = daysSinceShower >= 3 && !todayShowered;

  // Bathroom frequency analysis
  const weekAgo = new Date();
  weekAgo.setDate(weekAgo.getDate() - 7);
  weekAgo.setHours(0, 0, 0, 0);
  const last7Days = bathroomLog.filter(e => new Date(e.date) >= weekAgo);
  const avgPerDay = last7Days.length > 0 ? (last7Days.length / 7) : 0;

  const getFrequencyInsight = useCallback(() => {
    if (last7Days.length === 0) return null;
    if (avgPerDay < 1) return { level: 'low', color: '#f59e0b', msg: lang === 'ar' ? '⚠️ معدل منخفض — قد يكون بسبب قلة الألياف أو الماء أو التوتر' : '⚠️ Low frequency — could be due to low fiber, hydration, or stress' };
    if (avgPerDay <= 3) return { level: 'normal', color: '#10b981', msg: lang === 'ar' ? '✅ معدل طبيعي وصحي' : '✅ Normal and healthy frequency' };
    return { level: 'high', color: '#ef4444', msg: lang === 'ar' ? '⚠️ معدل مرتفع — قد يكون بسبب القلق أو حساسية غذائية' : '⚠️ High frequency — could be due to anxiety or food sensitivity' };
  }, [last7Days.length, avgPerDay, lang]);
  const freqInsight = getFrequencyInsight();

  const checkStressConnection = (type: string) => {
    if (type === 'normal') {
      setFeedback(t('bath.normal_msg'));
      return;
    }
    try {
      const moodHistory = JSON.parse(localStorage.getItem('soon-mood-history') || '[]');
      const todayMood = moodHistory.find((m: any) => new Date(m.date).toDateString() === today);
      if (todayMood && (todayMood.mood === 'bad' || todayMood.mood === 'terrible')) {
        setFeedback(t('bath.stress_notice'));
      } else {
        setFeedback(lang === 'ar'
          ? `تم تسجيل: ${t(`bath.type_${type}`)}. تابع ملاحظة جسمك — فهو يتحدث إليك. 💙`
          : `Logged: ${t(`bath.type_${type}`)}. Keep listening to your body — it speaks to you. 💙`);
      }
    } catch { setFeedback(''); }
  };

  const logBathroom = (type: string) => {
    setBathroomLog(prev => [...prev, { type, date: new Date().toISOString() }]);
    checkStressConnection(type);
    setRenderKey(k => k + 1);
  };

  const logShower = () => {
    const entry = { date: new Date().toISOString() };
    setShowerLog(prev => [...prev, entry]);
    setShowerJustLogged(true);
    setRenderKey(k => k + 1);
  };

  // Count shower days this week - normalize to midnight
  const weekStart = new Date();
  weekStart.setDate(weekStart.getDate() - weekStart.getDay());
  weekStart.setHours(0, 0, 0, 0);
  const showerDaysThisWeek = new Set(
    showerLog.filter(e => new Date(e.date) >= weekStart).map(e => new Date(e.date).toDateString())
  ).size;

  const bathroomTypes = [
    { type: 'normal', icon: '✅', color: '#10b981' },
    { type: 'constipation', icon: '😣', color: '#f59e0b' },
    { type: 'diarrhea', icon: '💧', color: '#3b82f6' },
    { type: 'ibs', icon: '🌀', color: '#8b5cf6' },
  ];

  return (
    <div key={renderKey} style={{ marginBottom: '20px' }}>
      {/* Gut-Brain Tracker */}
      <div style={{ background: 'white', borderRadius: '16px', padding: '18px', marginBottom: '15px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)', borderLeft: '4px solid #8b5cf6' }}>
        <div onClick={() => setShowBathroomSection(!showBathroomSection)} style={{ cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <h4 style={{ color: '#8b5cf6', margin: '0 0 4px', fontSize: '1rem' }}>🧠🔗 {t('bath.title')}</h4>
            <p style={{ color: '#8898aa', margin: 0, fontSize: '0.75rem' }}>{t('bath.subtitle')}</p>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span style={{ background: '#f3e8ff', color: '#8b5cf6', padding: '4px 10px', borderRadius: '20px', fontSize: '0.75rem', fontWeight: 600 }}>
              {todayBathroom.length}x
            </span>
            <i className={`fas fa-chevron-${showBathroomSection ? 'up' : 'down'}`} style={{ color: '#8898aa' }}></i>
          </div>
        </div>

        {showBathroomSection && (
          <div style={{ marginTop: '15px' }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '8px', marginBottom: '12px' }}>
              {bathroomTypes.map(bt => (
                <button key={bt.type} onClick={() => logBathroom(bt.type)} style={{
                  background: 'white', border: `2px solid ${bt.color}22`, borderRadius: '12px', padding: '12px 6px',
                  cursor: 'pointer', textAlign: 'center', transition: 'all 0.2s',
                }}>
                  <div style={{ fontSize: '1.5rem', marginBottom: '4px' }}>{bt.icon}</div>
                  <div style={{ fontSize: '0.65rem', color: bt.color, fontWeight: 600 }}>{t(`bath.type_${bt.type}`)}</div>
                </button>
              ))}
            </div>

            {feedback && (
              <div style={{ padding: '12px', background: '#f8f4ff', borderRadius: '12px', borderLeft: '4px solid #8b5cf6', marginBottom: '10px' }}>
                <p style={{ margin: 0, fontSize: '0.85rem', color: '#32325d', lineHeight: 1.6 }}>{feedback}</p>
              </div>
            )}

            {freqInsight && (
              <div style={{ padding: '12px', background: freqInsight.level === 'normal' ? '#f0fdf4' : '#fffbeb', borderRadius: '12px', borderLeft: `4px solid ${freqInsight.color}`, marginBottom: '10px' }}>
                <p style={{ margin: '0 0 4px', fontSize: '0.85rem', color: '#32325d', fontWeight: 600 }}>
                  {lang === 'ar' ? `📊 المعدل الأسبوعي: ${last7Days.length} مرات (${avgPerDay.toFixed(1)}/يوم)` : `📊 Weekly: ${last7Days.length} times (${avgPerDay.toFixed(1)}/day)`}
                </p>
                <p style={{ margin: 0, fontSize: '0.8rem', color: '#525f7f', lineHeight: 1.5 }}>{freqInsight.msg}</p>
              </div>
            )}

            {todayBathroom.length > 0 && (
              <div>
                <div style={{ fontSize: '0.8rem', color: '#8898aa', marginBottom: '6px' }}>{t('bath.today')}:</div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                  {todayBathroom.map((e, i) => (
                    <span key={i} style={{ background: '#f3e8ff', color: '#8b5cf6', padding: '4px 10px', borderRadius: '15px', fontSize: '0.75rem' }}>
                      {t(`bath.type_${e.type}`)} • {new Date(e.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Shower/Self-Care Tracker */}
      <div style={{ background: 'white', borderRadius: '16px', padding: '18px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)', borderLeft: '4px solid #06b6d4' }}>
        <div onClick={() => setShowShowerSection(!showShowerSection)} style={{ cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <h4 style={{ color: '#06b6d4', margin: '0 0 4px', fontSize: '1rem' }}>🚿 {t('shower.title')}</h4>
            <p style={{ color: '#8898aa', margin: 0, fontSize: '0.75rem' }}>{t('shower.subtitle')}</p>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            {todayShowered && <span style={{ fontSize: '1.2rem' }}>✅</span>}
            <span style={{ background: '#e0f7fa', color: '#06b6d4', padding: '4px 10px', borderRadius: '20px', fontSize: '0.75rem', fontWeight: 600 }}>
              {showerDaysThisWeek}/7
            </span>
            <i className={`fas fa-chevron-${showShowerSection ? 'up' : 'down'}`} style={{ color: '#8898aa' }}></i>
          </div>
        </div>

        {showShowerSection && (
          <div style={{ marginTop: '15px' }}>
            {showGentleReminder && (
              <div style={{ padding: '15px', background: '#eff6ff', borderRadius: '12px', borderLeft: '4px solid #3b82f6', marginBottom: '12px' }}>
                <p style={{ margin: 0, fontSize: '0.85rem', color: '#1e40af', lineHeight: 1.7 }}>
                  💙 {t('shower.gentle_reminder')}
                </p>
              </div>
            )}

            {!todayShowered ? (
              <button onClick={logShower} style={{
                width: '100%', background: 'linear-gradient(135deg, #06b6d4, #0891b2)', color: 'white',
                border: 'none', borderRadius: '12px', padding: '16px', fontWeight: 600, cursor: 'pointer',
                fontSize: '1rem', marginBottom: '10px',
              }}>
                🚿 {t('shower.log')}
              </button>
            ) : (
              <div style={{ textAlign: 'center', padding: '15px', background: '#ecfdf5', borderRadius: '12px', marginBottom: '10px' }}>
                <div style={{ fontSize: '2rem', marginBottom: '8px' }}>🚿✨</div>
                <p style={{ color: '#065f46', fontSize: '0.9rem', margin: 0, lineHeight: 1.6 }}>
                  {showerJustLogged
                    ? (lang === 'ar' ? 'أحسنتِ! الماء يغسل التوتر أيضاً ✨🚿' : 'Well done! Water washes away stress too ✨🚿')
                    : t('shower.logged')}
                </p>
              </div>
            )}

            <div style={{ display: 'flex', justifyContent: 'center', gap: '15px', marginTop: '10px' }}>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: '0.7rem', color: '#8898aa' }}>{t('shower.streak')}</div>
                <div style={{ fontWeight: 700, color: '#06b6d4', fontSize: '1.2rem' }}>{showerDaysThisWeek}</div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
