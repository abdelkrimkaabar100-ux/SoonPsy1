import { useLocalStorage } from '../../hooks/useLocalStorage';
import { useLanguage } from '../../i18n/LanguageContext';
import { useState } from 'react';

interface TrackerEntry { value: number; date: string; }
interface SleepExerciseTrackerProps { onViewHistory: (type: 'sleep' | 'exercise') => void; }

function CircleProgress({ value, max, color, unit }: { value: number; max: number; color: string; unit: string }) {
  const radius = 40;
  const circumference = 2 * Math.PI * radius;
  const progress = Math.min(value / max, 1);
  const dashArray = `${progress * circumference} ${circumference}`;

  return (
    <div style={{ width: 100, height: 100, margin: '0 auto 15px', position: 'relative' }}>
      <svg viewBox="0 0 100 100" style={{ width: '100%', height: '100%', transform: 'rotate(-90deg)' }}>
        <circle cx="50" cy="50" r={radius} fill="none" stroke="#eee" strokeWidth="8" />
        <circle cx="50" cy="50" r={radius} fill="none" stroke={color} strokeWidth="8"
          strokeLinecap="round" strokeDasharray={dashArray} style={{ transition: 'stroke-dasharray 0.5s ease' }} />
      </svg>
      <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', fontSize: '1.2rem', fontWeight: 700, color }}>
        {value}{unit}
      </div>
    </div>
  );
}

export default function SleepExerciseTracker({ onViewHistory }: SleepExerciseTrackerProps) {
  const { t } = useLanguage();
  const [sleepLog, setSleepLog] = useLocalStorage<TrackerEntry[]>('soon-sleep', []);
  const [exerciseLog, setExerciseLog] = useLocalStorage<TrackerEntry[]>('soon-exercise', []);
  const [showSleepHistory, setShowSleepHistory] = useState(false);
  const [showExerciseHistory, setShowExerciseHistory] = useState(false);

  const getTodayValue = (log: TrackerEntry[]) => {
    const today = new Date().toDateString();
    return log.filter(e => new Date(e.date).toDateString() === today).reduce((sum, e) => sum + e.value, 0);
  };

  const todaySleep = getTodayValue(sleepLog);
  const todayExercise = getTodayValue(exerciseLog);

  const logSleep = () => {
    const hours = parseFloat(prompt(t('sleep.prompt')) || '0');
    if (hours > 0) {
      setSleepLog([...sleepLog, { value: hours, date: new Date().toISOString() }]);
      alert(t('sleep.logged').replace('{0}', String(hours)));
    }
  };

  const logExercise = () => {
    const mins = parseInt(prompt(t('exercise.prompt')) || '0');
    if (mins > 0) {
      setExerciseLog([...exerciseLog, { value: mins, date: new Date().toISOString() }]);
      alert(t('exercise.logged').replace('{0}', String(mins)));
    }
  };

  const lastSleep = sleepLog.length > 0 ? `${sleepLog[sleepLog.length - 1].value}h` : t('sleep.not_tracked');

  const getHistory = (log: TrackerEntry[], unit: string) => {
    const grouped = log.reduce<Record<string, number>>((acc, e) => {
      const dateKey = new Date(e.date).toLocaleDateString();
      acc[dateKey] = (acc[dateKey] || 0) + e.value;
      return acc;
    }, {});
    return Object.entries(grouped).sort((a, b) => new Date(b[0]).getTime() - new Date(a[0]).getTime()).slice(0, 14);
  };

  return (
    <div style={{ marginBottom: '20px' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px' }}>
        <div style={{ background: 'white', borderRadius: '16px', padding: '15px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)', textAlign: 'center' }}>
          <h4 style={{ color: '#1a9f6e', marginBottom: '15px', fontSize: '0.95rem' }}>{t('sleep.title')}</h4>
          <CircleProgress value={todaySleep} max={8} color="#2DCE89" unit="h" />
          <p style={{ fontSize: '0.8rem', color: '#8898aa', margin: '5px 0' }}>{t('sleep.last')}: <strong>{lastSleep}</strong></p>
          <div style={{ display: 'flex', justifyContent: 'center', gap: '8px', marginTop: '10px' }}>
            <button onClick={logSleep} style={{ background: '#2DCE89', color: 'white', border: 'none', borderRadius: '25px', padding: '6px 12px', fontWeight: 600, fontSize: '0.8rem', cursor: 'pointer', fontFamily: 'Poppins, sans-serif' }}>{t('sleep.log')}</button>
            <button onClick={() => setShowSleepHistory(!showSleepHistory)} style={{ background: '#d1efe1', color: '#2DCE89', border: 'none', borderRadius: '25px', padding: '6px 12px', fontWeight: 600, fontSize: '0.8rem', cursor: 'pointer', fontFamily: 'Poppins, sans-serif' }}>{t('history')}</button>
          </div>
        </div>

        <div style={{ background: 'white', borderRadius: '16px', padding: '15px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)', textAlign: 'center' }}>
          <h4 style={{ color: '#1a9f6e', marginBottom: '15px', fontSize: '0.95rem' }}>{t('exercise.title')}</h4>
          <CircleProgress value={todayExercise} max={30} color="#2DCE89" unit="m" />
          <p style={{ fontSize: '0.8rem', color: '#8898aa', margin: '5px 0' }}>{t('exercise.today')}: <strong>{todayExercise} min</strong></p>
          <div style={{ display: 'flex', justifyContent: 'center', gap: '8px', marginTop: '10px' }}>
            <button onClick={logExercise} style={{ background: '#2DCE89', color: 'white', border: 'none', borderRadius: '25px', padding: '6px 12px', fontWeight: 600, fontSize: '0.8rem', cursor: 'pointer', fontFamily: 'Poppins, sans-serif' }}>{t('exercise.log')}</button>
            <button onClick={() => setShowExerciseHistory(!showExerciseHistory)} style={{ background: '#d1efe1', color: '#2DCE89', border: 'none', borderRadius: '25px', padding: '6px 12px', fontWeight: 600, fontSize: '0.8rem', cursor: 'pointer', fontFamily: 'Poppins, sans-serif' }}>{t('history')}</button>
          </div>
        </div>
      </div>

      {showSleepHistory && (
        <div style={{ background: 'white', borderRadius: '16px', padding: '15px', marginTop: '10px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
          <h5 style={{ color: '#1a9f6e', marginBottom: '10px' }}>{t('sleep.title')} - {t('history')}</h5>
          {getHistory(sleepLog, 'h').length === 0 ? (
            <p style={{ color: '#8898aa', fontSize: '0.85rem' }}>{t('mood.no_history')}</p>
          ) : (
            getHistory(sleepLog, 'h').map(([date, total]) => (
              <div key={date} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: '1px solid #f0f0f0', fontSize: '0.85rem' }}>
                <span style={{ color: '#32325d' }}>{date}</span>
                <span style={{ color: '#2DCE89', fontWeight: 600 }}>{total}h</span>
              </div>
            ))
          )}
        </div>
      )}

      {showExerciseHistory && (
        <div style={{ background: 'white', borderRadius: '16px', padding: '15px', marginTop: '10px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
          <h5 style={{ color: '#1a9f6e', marginBottom: '10px' }}>{t('exercise.title')} - {t('history')}</h5>
          {getHistory(exerciseLog, 'm').length === 0 ? (
            <p style={{ color: '#8898aa', fontSize: '0.85rem' }}>{t('mood.no_history')}</p>
          ) : (
            getHistory(exerciseLog, 'm').map(([date, total]) => (
              <div key={date} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: '1px solid #f0f0f0', fontSize: '0.85rem' }}>
                <span style={{ color: '#32325d' }}>{date}</span>
                <span style={{ color: '#2DCE89', fontWeight: 600 }}>{total} min</span>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}
