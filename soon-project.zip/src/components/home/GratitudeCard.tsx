import { useState } from 'react';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { useLanguage } from '../../i18n/LanguageContext';

interface GratitudeEntry {
  id: string;
  content: string;
  date: string;
  formattedDate: string;
}

interface GratitudeCardProps {
  onShareWithAI: (text: string) => void;
}

export default function GratitudeCard({ onShareWithAI }: GratitudeCardProps) {
  const { t } = useLanguage();
  const [entries, setEntries] = useLocalStorage<GratitudeEntry[]>('soon-gratitude', []);
  const [input, setInput] = useState('');
  const [showHistory, setShowHistory] = useState(false);

  const saveGratitude = () => {
    if (!input.trim()) return;
    const newEntry: GratitudeEntry = {
      id: Date.now().toString(),
      content: input.trim(),
      date: new Date().toISOString(),
      formattedDate: new Date().toLocaleDateString(),
    };
    setEntries([...entries, newEntry]);
    setInput('');
    alert(t('gratitude.saved'));
  };

  const getWeekCount = () => {
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
    return entries.filter(e => new Date(e.date) >= oneWeekAgo).length;
  };

  const groupedEntries = entries.reduce<Record<string, GratitudeEntry[]>>((groups, entry) => {
    const dateKey = new Date(entry.date).toLocaleDateString();
    if (!groups[dateKey]) groups[dateKey] = [];
    groups[dateKey].push(entry);
    return groups;
  }, {});

  const sortedDates = Object.keys(groupedEntries).sort((a, b) =>
    new Date(groupedEntries[b][0].date).getTime() - new Date(groupedEntries[a][0].date).getTime()
  );

  return (
    <div style={{
      background: 'white', borderRadius: '16px',
      padding: '20px', marginBottom: '20px',
      boxShadow: '0 6px 20px rgba(0,0,0,0.08)',
    }}>
      <h4 style={{ color: '#32325d', marginBottom: '15px', fontSize: '1.1rem' }}>
        <i className="fas fa-heart" style={{ color: '#2DCE89', marginRight: '8px' }}></i>
        {t('gratitude.title')}
      </h4>
      <textarea
        value={input}
        onChange={e => setInput(e.target.value)}
        placeholder={t('gratitude.placeholder')}
        style={{
          width: '100%', padding: '12px',
          border: '2px solid #e1e8ed', borderRadius: '12px',
          fontFamily: 'Poppins, sans-serif', fontSize: '0.95rem',
          resize: 'vertical', minHeight: '100px',
          outline: 'none', transition: 'border-color 0.3s ease',
          boxSizing: 'border-box',
        }}
        onFocus={e => e.target.style.borderColor = '#2DCE89'}
        onBlur={e => e.target.style.borderColor = '#e1e8ed'}
      />
      <button onClick={saveGratitude} style={{
        background: '#8965e0', color: 'white', border: 'none', borderRadius: '25px',
        padding: '10px 20px', fontWeight: 600, cursor: 'pointer', width: '100%',
        fontFamily: 'Poppins, sans-serif', transition: 'all 0.3s ease', marginBottom: '10px',
      }}>{t('gratitude.save')}</button>
      <button onClick={() => onShareWithAI(`My gratitude today: ${input}`)} style={{
        background: '#2DCE89', color: 'white', border: 'none', borderRadius: '25px',
        padding: '10px 20px', fontWeight: 600, cursor: 'pointer', width: '100%',
        fontFamily: 'Poppins, sans-serif', transition: 'all 0.3s ease',
      }}>{t('gratitude.share')}</button>
      <div style={{ display: 'flex', justifyContent: 'space-around', marginTop: '15px' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '1.5rem', fontWeight: 700, color: '#8965e0' }}>{getWeekCount()}</div>
          <div style={{ fontSize: '0.8rem', color: '#8898aa' }}>{t('gratitude.this_week')}</div>
        </div>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '1.5rem', fontWeight: 700, color: '#8965e0' }}>{entries.length}</div>
          <div style={{ fontSize: '0.8rem', color: '#8898aa' }}>{t('gratitude.total')}</div>
        </div>
      </div>

      {entries.length > 0 && (
        <button onClick={() => setShowHistory(!showHistory)} style={{
          background: 'none', border: '1px solid #8965e0', color: '#8965e0', borderRadius: '25px',
          padding: '8px 16px', fontWeight: 600, cursor: 'pointer', width: '100%',
          fontFamily: 'Poppins, sans-serif', marginTop: '15px', fontSize: '0.9rem',
        }}>
          <i className={`fas fa-${showHistory ? 'chevron-up' : 'history'}`} style={{ marginRight: '8px' }}></i>
          {showHistory ? t('gratitude.hide_history') : t('gratitude.view_history')}
        </button>
      )}

      {showHistory && (
        <div style={{ marginTop: '15px', maxHeight: '400px', overflowY: 'auto' }}>
          {sortedDates.map(dateKey => (
            <div key={dateKey} style={{ marginBottom: '15px' }}>
              <div style={{
                fontSize: '0.85rem', fontWeight: 600, color: '#8965e0',
                marginBottom: '8px', paddingBottom: '5px', borderBottom: '2px solid #f0e6ff',
              }}>
                <i className="fas fa-calendar-alt" style={{ marginRight: '6px' }}></i>
                {dateKey}
              </div>
              {groupedEntries[dateKey].map(entry => (
                <div key={entry.id} style={{
                  background: '#f8f5ff', borderRadius: '10px',
                  padding: '10px 12px', marginBottom: '6px',
                  fontSize: '0.9rem', color: '#32325d', lineHeight: 1.5,
                  borderLeft: '3px solid #8965e0',
                }}>
                  {entry.content}
                </div>
              ))}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
