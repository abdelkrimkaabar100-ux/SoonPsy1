import { useState, useEffect } from 'react';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { useLanguage } from '../../i18n/LanguageContext';

const psychologyQuotes: Record<string, { text: string; author: string }[]> = {
  en: [
    { text: "The greatest discovery of my generation is that a human being can alter his life by altering his attitudes.", author: "William James" },
    { text: "What lies behind us and what lies before us are tiny matters compared to what lies within us.", author: "Ralph Waldo Emerson" },
    { text: "The curious paradox is that when I accept myself just as I am, then I can change.", author: "Carl Rogers" },
    { text: "Between stimulus and response there is a space. In that space is our power to choose our response.", author: "Viktor Frankl" },
    { text: "Happiness is not something ready made. It comes from your own actions.", author: "Dalai Lama" },
    { text: "You don't have to control your thoughts. You just have to stop letting them control you.", author: "Dan Millman" },
    { text: "The only journey is the one within.", author: "Rainer Maria Rilke" },
    { text: "Knowing yourself is the beginning of all wisdom.", author: "Aristotle" },
  ],
  ar: [
    { text: "أعظم اكتشاف هو أن الإنسان يمكنه تغيير حياته بتغيير مواقفه.", author: "ويليام جيمس" },
    { text: "ما يكمن خلفنا وأمامنا أمور صغيرة مقارنة بما يكمن بداخلنا.", author: "رالف والدو إيمرسون" },
    { text: "المفارقة هي أنني عندما أتقبل نفسي كما أنا، أستطيع التغيير.", author: "كارل روجرز" },
    { text: "بين المثير والاستجابة هناك مساحة. في تلك المساحة قوتنا في اختيار استجابتنا.", author: "فيكتور فرانكل" },
    { text: "السعادة ليست شيئاً جاهزاً. إنها تأتي من أفعالك.", author: "الدالاي لاما" },
    { text: "لا يجب أن تتحكم في أفكارك. فقط توقف عن السماح لها بالتحكم فيك.", author: "دان ميلمان" },
    { text: "الرحلة الوحيدة هي التي بداخلك.", author: "راينر ماريا ريلكه" },
    { text: "معرفة نفسك هي بداية كل حكمة.", author: "أرسطو" },
  ],
  es: [
    { text: "El mayor descubrimiento es que un ser humano puede cambiar su vida cambiando sus actitudes.", author: "William James" },
    { text: "Lo que hay detrás y delante de nosotros son cosas pequeñas comparadas con lo que hay dentro de nosotros.", author: "Ralph Waldo Emerson" },
    { text: "La curiosa paradoja es que cuando me acepto tal como soy, entonces puedo cambiar.", author: "Carl Rogers" },
    { text: "Entre el estímulo y la respuesta hay un espacio. En ese espacio está nuestro poder de elegir.", author: "Viktor Frankl" },
  ],
  fr: [
    { text: "La plus grande découverte est qu'un être humain peut changer sa vie en changeant ses attitudes.", author: "William James" },
    { text: "Ce qui est derrière et devant nous sont de petites choses comparées à ce qui est en nous.", author: "Ralph Waldo Emerson" },
    { text: "Le curieux paradoxe est que lorsque je m'accepte tel que je suis, alors je peux changer.", author: "Carl Rogers" },
    { text: "Entre le stimulus et la réponse, il y a un espace. Dans cet espace réside notre pouvoir de choisir.", author: "Viktor Frankl" },
  ],
};

export default function WelcomeGuide() {
  const { t, lang } = useLanguage();
  const [dismissed, setDismissed] = useLocalStorage<boolean>('soon-welcome-dismissed', false);
  const [quote, setQuote] = useState({ text: '', author: '' });

  useEffect(() => {
    const quotes = psychologyQuotes[lang] || psychologyQuotes.en;
    const today = new Date().getDate();
    setQuote(quotes[today % quotes.length]);
  }, [lang]);

  if (dismissed) {
    return (
      <div style={{
        background: 'linear-gradient(135deg, #f0fdf4, #dcfce7)',
        borderRadius: '16px', padding: '15px', marginBottom: '20px',
        border: '1px solid #bbf7d0', textAlign: 'center',
      }}>
        <p style={{ margin: 0, fontSize: '0.9rem', color: '#166534', fontStyle: 'italic', lineHeight: 1.6 }}>
          "{quote.text}"
        </p>
        <p style={{ margin: '8px 0 0', fontSize: '0.8rem', color: '#15803d', fontWeight: 600 }}>
          — {quote.author}
        </p>
      </div>
    );
  }

  const steps = [
    { icon: '😊', textKey: 'welcome.step1' },
    { icon: '💤', textKey: 'welcome.step2' },
    { icon: '🍎', textKey: 'welcome.step3' },
    { icon: '💬', textKey: 'welcome.step4' },
    { icon: '🐾', textKey: 'welcome.step5' },
  ];

  return (
    <div style={{
      background: 'linear-gradient(135deg, #f0fdf4, #dcfce7)',
      borderRadius: '16px', padding: '20px', marginBottom: '20px',
      border: '1px solid #bbf7d0',
    }}>
      <h4 style={{ color: '#166534', marginTop: 0, marginBottom: '15px', textAlign: 'center', fontSize: '1.1rem' }}>
        👋 {t('welcome.title')}
      </h4>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', marginBottom: '15px' }}>
        {steps.map((step, i) => (
          <div key={i} style={{
            display: 'flex', alignItems: 'center', gap: '10px',
            background: 'white', borderRadius: '12px', padding: '10px 12px',
          }}>
            <span style={{ fontSize: '1.3rem' }}>{step.icon}</span>
            <span style={{ fontSize: '0.9rem', color: '#32325d' }}>{t(step.textKey)}</span>
          </div>
        ))}
      </div>
      <div style={{
        background: 'white', borderRadius: '12px', padding: '12px',
        marginBottom: '12px', textAlign: 'center',
      }}>
        <p style={{ margin: 0, fontSize: '0.85rem', color: '#166534', fontStyle: 'italic', lineHeight: 1.5 }}>
          "{quote.text}"
        </p>
        <p style={{ margin: '6px 0 0', fontSize: '0.75rem', color: '#15803d', fontWeight: 600 }}>
          — {quote.author}
        </p>
      </div>
      <button onClick={() => setDismissed(true)} style={{
        background: '#2DCE89', color: 'white', border: 'none', borderRadius: '25px',
        padding: '10px 20px', fontWeight: 600, cursor: 'pointer', width: '100%',
        fontFamily: 'Poppins, sans-serif', fontSize: '0.9rem',
      }}>
        {t('welcome.got_it')}
      </button>
    </div>
  );
}
