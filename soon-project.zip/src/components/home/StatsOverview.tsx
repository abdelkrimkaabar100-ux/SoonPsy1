import { useState } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';

interface StatItem {
  icon: string;
  labelAr: string;
  labelEn: string;
  value: number;
  unit: string;
  unitAr: string;
  color: string;
  max?: number;
}

export default function StatsOverview() {
  const { lang } = useLanguage();
  const isAr = lang === 'ar';
  const [expanded, setExpanded] = useState(false);

  // Read all data
  const read = (key: string, fb: any) => { try { return JSON.parse(localStorage.getItem(key) || JSON.stringify(fb)); } catch { return fb; } };

  const moodHistory = read('soon-mood-history', []);
  const sleepLog = read('soon-sleep', []);
  const exerciseLog = read('soon-exercise', []);
  const gratitude = read('soon-gratitude', []);
  const dreams = read('soon-dreams', []);
  const tasks = read('soon-tasks', []);
  const goals = read('soon-goals', []);
  const journal = read('soon-journal', []);
  const foods = read('soon-food-log', []);
  const waterDays = read('soon-water-days', []);
  const detoxDays = read('soon-detox-days', []);
  const fastingLog = read('soon-fasting-log', []);
  const hobbies = read('soon-hobbies', []);
  const anxiety = read('soon-anxiety', []);
  const smileChallenge = read('soon-smile-days', []);
  const kindWords = read('soon-kind-words', []);
  const movies = read('soon-movies', []);
  const family = read('soon-family-members', []);
  const streak = read('soon-streak', 0);
  const restLog = read('soon-rest', []);
  const selfCare = read('soon-selfcare-log', []);

  const completedTasks = tasks.filter((t: any) => t.completed).length;
  const completedGoals = goals.filter((g: any) => g.completed).length;
  const sugarFreeDays = detoxDays.filter((d: any) => d.sugarFree).length;
  const dopamineFreeDays = detoxDays.filter((d: any) => d.dopamineFree).length;
  const completedFasts = fastingLog.filter((f: any) => f.completed).length;
  const waterGoalDays = waterDays.filter((d: any) => {
    const t = (d.logs || []).reduce((s: number, l: any) => s + (l.amount || 0), 0);
    return t >= (d.goal || 2000) * 0.8;
  }).length;

  const stats: StatItem[] = [
    { icon: '🔥', labelAr: 'أيام الاستمرار', labelEn: 'Streak Days', value: streak, unit: 'days', unitAr: 'يوم', color: '#f59e0b' },
    { icon: '😊', labelAr: 'سجلات المزاج', labelEn: 'Mood Logs', value: moodHistory.length, unit: '', unitAr: '', color: '#ec4899' },
    { icon: '😴', labelAr: 'سجلات النوم', labelEn: 'Sleep Logs', value: sleepLog.length, unit: '', unitAr: '', color: '#6366f1' },
    { icon: '🏃', labelAr: 'سجلات التمارين', labelEn: 'Exercise Logs', value: exerciseLog.length, unit: '', unitAr: '', color: '#10b981' },
    { icon: '🙏', labelAr: 'سجلات الامتنان', labelEn: 'Gratitude Entries', value: gratitude.length, unit: '', unitAr: '', color: '#f97316' },
    { icon: '📝', labelAr: 'سجلات اليوميات', labelEn: 'Journal Entries', value: journal.length, unit: '', unitAr: '', color: '#8b5cf6' },
    { icon: '🌙', labelAr: 'أحلام مسجلة', labelEn: 'Dreams Logged', value: dreams.length, unit: '', unitAr: '', color: '#3b82f6' },
    { icon: '✅', labelAr: 'مهام مكتملة', labelEn: 'Tasks Completed', value: completedTasks, unit: `/${tasks.length}`, unitAr: `/${tasks.length}`, color: '#0ea5e9' },
    { icon: '🎯', labelAr: 'أهداف محققة', labelEn: 'Goals Achieved', value: completedGoals, unit: `/${goals.length}`, unitAr: `/${goals.length}`, color: '#14b8a6' },
    { icon: '🍽️', labelAr: 'وجبات صحية', labelEn: 'Healthy Meals', value: foods.length, unit: '', unitAr: '', color: '#22c55e' },
    { icon: '💧', labelAr: 'أيام شرب كافٍ', labelEn: 'Hydrated Days', value: waterGoalDays, unit: `/${waterDays.length}`, unitAr: `/${waterDays.length}`, color: '#3b82f6' },
    { icon: '🍬', labelAr: 'أيام بدون سكر', labelEn: 'Sugar-Free Days', value: sugarFreeDays, unit: '', unitAr: '', color: '#e11d48' },
    { icon: '🧠', labelAr: 'صيام الدوبامين', labelEn: 'Dopamine Detox', value: dopamineFreeDays, unit: '', unitAr: '', color: '#6366f1' },
    { icon: '🌙', labelAr: 'صيام مكتمل', labelEn: 'Fasts Completed', value: completedFasts, unit: '', unitAr: '', color: '#7c3aed' },
    { icon: '🎨', labelAr: 'هوايات مسجلة', labelEn: 'Hobbies Logged', value: hobbies.length, unit: '', unitAr: '', color: '#d946ef' },
    { icon: '💆', labelAr: 'سجلات الراحة', labelEn: 'Rest Logs', value: restLog.length, unit: '', unitAr: '', color: '#0891b2' },
    { icon: '😰', labelAr: 'مواجهة القلق', labelEn: 'Anxiety Coping', value: anxiety.length, unit: '', unitAr: '', color: '#64748b' },
    { icon: '😊', labelAr: 'تحدي الابتسامة', labelEn: 'Smile Challenge', value: smileChallenge.length, unit: '', unitAr: '', color: '#fbbf24' },
    { icon: '💕', labelAr: 'كلمات طيبة', labelEn: 'Kind Words', value: kindWords.length, unit: '', unitAr: '', color: '#f472b6' },
    { icon: '🎬', labelAr: 'أفلام مسجلة', labelEn: 'Movies Logged', value: movies.length, unit: '', unitAr: '', color: '#a855f7' },
    { icon: '👨‍👩‍👧', labelAr: 'أفراد العائلة', labelEn: 'Family Members', value: family.length, unit: '', unitAr: '', color: '#ef4444' },
    { icon: '🛁', labelAr: 'عناية شخصية', labelEn: 'Self-Care Logs', value: selfCare.length, unit: '', unitAr: '', color: '#06b6d4' },
  ];

  const activeStats = stats.filter(s => s.value > 0);
  const displayStats = expanded ? activeStats : activeStats.slice(0, 8);
  const totalActivities = activeStats.reduce((s, st) => s + st.value, 0);

  return (
    <div style={{ background: 'linear-gradient(135deg, #1e1b4b, #312e81)', borderRadius: '20px', padding: '20px', marginBottom: '20px', boxShadow: '0 8px 25px rgba(30,27,75,0.3)', color: 'white' }}>
      <h4 style={{ textAlign: 'center', marginBottom: '6px', fontSize: '1.1rem' }}>
        📊 {isAr ? 'إحصائياتك الشاملة' : 'Your Complete Stats'}
      </h4>
      <p style={{ textAlign: 'center', fontSize: '0.78rem', color: '#a5b4fc', marginBottom: '14px' }}>
        {isAr ? `${totalActivities} نشاط مسجل عبر ${activeStats.length} خاصية` : `${totalActivities} activities across ${activeStats.length} features`}
      </p>

      {activeStats.length === 0 ? (
        <p style={{ textAlign: 'center', color: '#a5b4fc', fontSize: '0.85rem', padding: '20px 0' }}>
          {isAr ? 'ابدأ باستخدام ميزات التطبيق لرؤية إحصائياتك هنا!' : 'Start using app features to see your stats here!'}
        </p>
      ) : (
        <>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
            {displayStats.map((stat, i) => (
              <div key={i} style={{
                background: 'rgba(255,255,255,0.08)', borderRadius: '14px', padding: '12px',
                borderLeft: `4px solid ${stat.color}`, transition: 'all 0.2s',
              }}>
                <div style={{ fontSize: '1.2rem', marginBottom: '2px' }}>{stat.icon}</div>
                <div style={{ fontSize: '1.1rem', fontWeight: 700, color: 'white' }}>
                  {stat.value}<span style={{ fontSize: '0.7rem', color: '#a5b4fc' }}>{isAr ? stat.unitAr : stat.unit}</span>
                </div>
                <div style={{ fontSize: '0.7rem', color: '#c4b5fd' }}>{isAr ? stat.labelAr : stat.labelEn}</div>
              </div>
            ))}
          </div>

          {activeStats.length > 8 && (
            <button onClick={() => setExpanded(!expanded)} style={{
              background: 'rgba(255,255,255,0.1)', border: 'none', color: '#a5b4fc', borderRadius: '20px',
              padding: '8px 16px', fontWeight: 600, cursor: 'pointer', width: '100%', marginTop: '10px', fontSize: '0.8rem',
            }}>
              {expanded ? (isAr ? 'عرض أقل ▲' : 'Show Less ▲') : (isAr ? `عرض الكل (${activeStats.length}) ▼` : `Show All (${activeStats.length}) ▼`)}
            </button>
          )}

          {/* Mini chart - last 7 days activity */}
          <div style={{ marginTop: '14px', background: 'rgba(255,255,255,0.05)', borderRadius: '14px', padding: '12px' }}>
            <p style={{ fontSize: '0.75rem', color: '#a5b4fc', marginBottom: '8px', fontWeight: 600 }}>
              {isAr ? 'نشاطك في آخر 7 أيام' : 'Activity Last 7 Days'}
            </p>
            <div style={{ display: 'flex', alignItems: 'flex-end', gap: '4px', height: '60px' }}>
              {Array.from({ length: 7 }, (_, i) => {
                const d = new Date(); d.setDate(d.getDate() - (6 - i));
                const ds = d.toDateString();
                let count = 0;
                count += moodHistory.filter((m: any) => new Date(m.date || m.timestamp).toDateString() === ds).length;
                count += sleepLog.filter((s: any) => new Date(s.date).toDateString() === ds).length;
                count += foods.filter((f: any) => new Date(f.date).toDateString() === ds).length;
                count += waterDays.filter((w: any) => w.date === ds).length;
                const h = Math.min(100, count * 20);
                return (
                  <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '2px' }}>
                    <div style={{
                      width: '100%', height: `${Math.max(4, h)}%`, borderRadius: '4px',
                      background: count > 0 ? `linear-gradient(to top, ${count > 3 ? '#22c55e' : '#3b82f6'}, ${count > 3 ? '#4ade80' : '#60a5fa'})` : 'rgba(255,255,255,0.1)',
                      transition: 'height 0.3s',
                    }}></div>
                    <span style={{ fontSize: '0.55rem', color: '#a5b4fc' }}>
                      {d.toLocaleDateString(isAr ? 'ar' : 'en', { weekday: 'narrow' })}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
