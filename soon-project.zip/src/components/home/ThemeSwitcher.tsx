import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { useToast } from '../../hooks/use-toast';

export type AppTheme = 'default' | 'dark' | 'pink' | 'blue' | 'purple' | 'sunset';

const themes: { id: AppTheme; icon: string; color: string; labelAr: string; labelEn: string }[] = [
  { id: 'default', icon: '☀️', color: '#2DCE89', labelAr: 'الافتراضي', labelEn: 'Default' },
  { id: 'dark', icon: '🌙', color: '#1a1a2e', labelAr: 'ليلي', labelEn: 'Dark' },
  { id: 'pink', icon: '🌸', color: '#ec4899', labelAr: 'وردي', labelEn: 'Pink' },
  { id: 'blue', icon: '🌊', color: '#3b82f6', labelAr: 'أزرق', labelEn: 'Blue' },
  { id: 'purple', icon: '💜', color: '#8b5cf6', labelAr: 'بنفسجي', labelEn: 'Purple' },
  { id: 'sunset', icon: '🌅', color: '#f97316', labelAr: 'غروب', labelEn: 'Sunset' },
];

export function useAppTheme() {
  // Theme selection removed; always use the default theme.
  return { theme: 'default' as AppTheme, setTheme: (_: AppTheme) => {} };
}


export function getThemeStyles(theme: AppTheme) {
  switch (theme) {
    case 'dark':
      return {
        appBg: 'linear-gradient(135deg, #0f0f23, #1a1a2e)',
        containerBg: '#16213e',
        headerGradient: 'linear-gradient(135deg, #1a1a2e, #0f3460)',
        cardBg: '#1a1a2e',
        textPrimary: '#e2e8f0',
        textSecondary: '#94a3b8',
        accent: '#3b82f6',
        navBg: '#16213e',
        navBorder: '#1e293b',
      };
    case 'pink':
      return {
        appBg: 'linear-gradient(135deg, #fdf2f8, #fce7f3)',
        containerBg: '#fff',
        headerGradient: 'linear-gradient(135deg, #ec4899, #db2777)',
        cardBg: '#ffffff',
        textPrimary: '#831843',
        textSecondary: '#9d174d',
        accent: '#ec4899',
        navBg: '#fff',
        navBorder: '#fce7f3',
      };
    case 'blue':
      return {
        appBg: 'linear-gradient(135deg, #eff6ff, #dbeafe)',
        containerBg: '#fff',
        headerGradient: 'linear-gradient(135deg, #3b82f6, #1d4ed8)',
        cardBg: '#ffffff',
        textPrimary: '#1e3a5f',
        textSecondary: '#3b82f6',
        accent: '#3b82f6',
        navBg: '#fff',
        navBorder: '#dbeafe',
      };
    case 'purple':
      return {
        appBg: 'linear-gradient(135deg, #f5f3ff, #ede9fe)',
        containerBg: '#fff',
        headerGradient: 'linear-gradient(135deg, #8b5cf6, #6d28d9)',
        cardBg: '#ffffff',
        textPrimary: '#4c1d95',
        textSecondary: '#7c3aed',
        accent: '#8b5cf6',
        navBg: '#fff',
        navBorder: '#ede9fe',
      };
    case 'sunset':
      return {
        appBg: 'linear-gradient(135deg, #fff7ed, #fed7aa)',
        containerBg: '#fff',
        headerGradient: 'linear-gradient(135deg, #f97316, #ea580c)',
        cardBg: '#ffffff',
        textPrimary: '#7c2d12',
        textSecondary: '#c2410c',
        accent: '#f97316',
        navBg: '#fff',
        navBorder: '#fed7aa',
      };
    default:
      return {
        appBg: 'linear-gradient(135deg, #f0f4f8, #e6eef7)',
        containerBg: '#fff',
        headerGradient: 'linear-gradient(135deg, #2DCE89, #1a9f6e)',
        cardBg: '#ffffff',
        textPrimary: '#32325d',
        textSecondary: '#8898aa',
        accent: '#2DCE89',
        navBg: '#fff',
        navBorder: '#eee',
      };
  }
}

export default function ThemeSwitcher() {
  // Theme switcher UI removed — app now uses the default theme only.
  return null;
}

