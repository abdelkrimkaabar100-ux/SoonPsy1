import { Page } from '../layout/AppContainer';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';

interface WellnessLinksProps {
  onNavigate: (page: Page) => void;
}

export default function WellnessLinks({ onNavigate }: WellnessLinksProps) {
  const { t } = useLanguage();
  const [favorites, setFavorites] = useLocalStorage<string[]>('soon-favorites', []);

  const toggleFavorite = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setFavorites(prev => prev.includes(id) ? prev.filter(f => f !== id) : [...prev, id]);
  };

  const links = [
    { id: 'women-wellness' as Page, icon: 'fas fa-venus', titleKey: 'women.title', descKey: 'women.subtitle', isPink: true },
    { id: 'special-needs' as Page, icon: 'fas fa-heart', titleKey: 'special.title', descKey: 'special.subtitle', isSpecial: true },
    { id: 'tasks' as Page, icon: 'fas fa-tasks', titleKey: 'tasks.title', descKey: 'tasks.subtitle', color: '#0ea5e9' },
    { id: 'self-responsibility' as Page, icon: 'fas fa-shield-alt', titleKey: 'resp.title', descKey: 'resp.subtitle', color: '#6366f1' },
    { id: 'community-dev' as Page, icon: 'fas fa-city', titleKey: 'comdev.title', descKey: 'comdev.subtitle', color: '#f59e0b' },
    { id: 'crying' as Page, icon: 'fas fa-tint', titleKey: 'cry.title', descKey: 'cry.subtitle', color: '#3b82f6' },
    { id: 'what-not-to-do' as Page, icon: 'fas fa-ban', titleKey: 'donts.title', descKey: 'donts.subtitle', color: '#dc2626' },
    { id: 'future-self' as Page, icon: 'fas fa-magic', titleKey: 'future.title', descKey: 'future.subtitle', color: '#8b5cf6' },
    { id: 'reflection' as Page, icon: 'fas fa-lightbulb', titleKey: 'wellness.reflection', descKey: 'wellness.reflection_desc' },
    { id: 'smile-challenge' as Page, icon: 'fas fa-smile', titleKey: 'smile.title', descKey: 'wellness.smile_desc' },
    { id: 'honesty' as Page, icon: 'fas fa-heart', titleKey: 'honesty.title', descKey: 'wellness.honesty_desc' },
    { id: 'resilience' as Page, icon: 'fas fa-fist-raised', titleKey: 'resilience.title', descKey: 'wellness.resilience_desc' },
    { id: 'parent-child' as Page, icon: 'fas fa-child', titleKey: 'wellness.parent_child', descKey: 'wellness.parent_child_desc' },
    { id: 'positive-self' as Page, icon: 'fas fa-star', titleKey: 'positive.title', descKey: 'wellness.positive_desc' },
    { id: 'life-story' as Page, icon: 'fas fa-book-open', titleKey: 'story.title', descKey: 'wellness.story_desc' },
    { id: 'attention-games' as Page, icon: 'fas fa-brain', titleKey: 'games.title', descKey: 'wellness.games_desc' },
    { id: 'earth-care' as Page, icon: 'fas fa-globe-americas', titleKey: 'earth.title', descKey: 'earth.subtitle' },
    { id: 'community' as Page, icon: 'fas fa-users', titleKey: 'community.title', descKey: 'community.subtitle' },
    { id: 'spirituality' as Page, icon: 'fas fa-pray', titleKey: 'spirit.title', descKey: 'spirit.subtitle' },
    { id: 'family' as Page, icon: 'fas fa-home', titleKey: 'family.title', descKey: 'wellness.family_desc' },
    { id: 'experiences' as Page, icon: 'fas fa-compass', titleKey: 'exp.title', descKey: 'exp.subtitle' },
    { id: 'love-page' as Page, icon: 'fas fa-heart', titleKey: 'lp.title', descKey: 'lp.subtitle' },
    { id: 'hobbies' as Page, icon: 'fas fa-palette', titleKey: 'hobbies.title', descKey: 'hobbies.subtitle' },
    { id: 'goals' as Page, icon: 'fas fa-bullseye', titleKey: 'goals.title', descKey: 'goals.subtitle' },
    { id: 'donate' as Page, icon: 'fas fa-hand-holding-heart', titleKey: 'donate.title', descKey: 'donate.subtitle' },
    { id: 'learning' as Page, icon: 'fas fa-graduation-cap', titleKey: 'learn.title', descKey: 'learn.subtitle' },
    { id: 'finance' as Page, icon: 'fas fa-wallet', titleKey: 'fin.title', descKey: 'fin.subtitle' },
    { id: 'anxiety' as Page, icon: 'fas fa-wind', titleKey: 'anx.title', descKey: 'anx.subtitle' },
    { id: 'imagination' as Page, icon: 'fas fa-cloud', titleKey: 'imag.title', descKey: 'imag.subtitle' },
    { id: 'kind-words' as Page, icon: 'fas fa-feather-alt', titleKey: 'kind.title', descKey: 'kind.subtitle' },
    { id: 'anger' as Page, icon: 'fas fa-fire-alt', titleKey: 'anger.title', descKey: 'anger.subtitle' },
    { id: 'detox-challenge' as Page, icon: 'fas fa-ban', titleKey: 'detox.title', descKey: 'detox.subtitle', color: '#e11d48' },
    { id: 'gratitude-thanks' as Page, icon: 'fas fa-praying-hands', titleKey: 'grat.title', descKey: 'grat.subtitle', color: '#2DCE89' },
    { id: 'holiday-greetings' as Page, icon: 'fas fa-gift', titleKey: 'greet.title', descKey: 'greet.subtitle', color: '#f59e0b' },
    { id: 'groups' as Page, icon: 'fas fa-users-cog', titleKey: 'groups.title', descKey: 'groups.subtitle', color: '#6366f1' },
    { id: 'decision-ai' as Page, icon: 'fas fa-balance-scale', titleKey: 'decide.title', descKey: 'decide.subtitle', color: '#8b5cf6' },
    { id: 'traditional-cooking' as Page, icon: 'fas fa-fire', titleKey: 'cook.title', descKey: 'cook.subtitle', color: '#ea580c' },
    { id: 'forgiveness' as Page, icon: 'fas fa-dove', titleKey: 'forgive.title', descKey: 'forgive.subtitle', color: '#7c3aed' },
    { id: 'unconscious-mind' as Page, icon: 'fas fa-brain', titleKey: 'unconscious.title', descKey: 'unconscious.subtitle', color: '#4c1d95' },
    { id: 'myths' as Page, icon: 'fas fa-landmark', titleKey: 'myths.title', descKey: 'myths.subtitle', color: '#6d28d9' },
    { id: 'sad-knowledge' as Page, icon: 'fas fa-key', titleKey: 'sadknow.title', descKey: 'sadknow.subtitle', color: '#7c3aed' },
    { id: 'primordial-witness' as Page, icon: 'fas fa-eye', titleKey: 'witness.title', descKey: 'witness.subtitle', color: '#334155' },
    { id: 'psyche-wars' as Page, icon: 'fas fa-khanda', titleKey: 'psyche.title', descKey: 'psyche.subtitle', color: '#6d28d9' },
  ];

  // Sort: favorites first, then original order
  const sortedLinks = [...links].sort((a, b) => {
    const aFav = favorites.includes(a.id) ? 0 : 1;
    const bFav = favorites.includes(b.id) ? 0 : 1;
    return aFav - bFav;
  });

  const getColor = (link: any) => {
    if (link.isPink) return '#ec4899';
    if (link.isSpecial) return '#e11d48';
    if (link.color) return link.color;
    return '#2DCE89';
  };

  const getBg = (link: any) => {
    if (link.isPink) return 'linear-gradient(135deg, #fdf2f8, #fce7f3)';
    if (link.isSpecial) return 'linear-gradient(135deg, #fff1f2, #ffe4e6)';
    return 'white';
  };

  return (
    <div>
      <h3 style={{ fontSize: '1.3rem', color: '#32325d', margin: '30px 0 20px', paddingBottom: '10px', borderBottom: '2px solid #f0f4ff' }}>
        {t('wellness.title')}
      </h3>
      {sortedLinks.map(link => {
        const isFav = favorites.includes(link.id);
        return (
          <div key={link.id} onClick={() => onNavigate(link.id)} style={{
            display: 'flex', alignItems: 'center', gap: '15px',
            padding: '15px', marginBottom: '15px',
            background: getBg(link), borderRadius: '16px',
            boxShadow: isFav ? '0 6px 20px rgba(245,158,11,0.15)' : '0 6px 20px rgba(0,0,0,0.08)',
            cursor: 'pointer', borderLeft: `4px solid ${getColor(link)}`,
            transition: 'all 0.3s ease',
            border: isFav ? '2px solid #f59e0b' : undefined,
          }}
          onMouseEnter={e => (e.currentTarget.style.transform = 'translateY(-5px)')}
          onMouseLeave={e => (e.currentTarget.style.transform = 'translateY(0)')}
          >
            <div style={{
              width: 60, height: 60, background: link.isPink ? '#fce7f3' : link.isSpecial ? '#ffe4e6' : '#f0f4ff', borderRadius: '15px',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: '1.8rem', color: getColor(link), flexShrink: 0,
            }}><i className={link.icon}></i></div>
            <div style={{ flex: 1 }}>
              <h5 style={{ margin: '0 0 5px', fontSize: '1.1rem', color: getColor(link) }}>{t(link.titleKey)}</h5>
              <p style={{ margin: 0, fontSize: '0.85rem', color: '#8898aa' }}>{t(link.descKey)}</p>
            </div>
            <button onClick={(e) => toggleFavorite(link.id, e)} style={{
              background: 'none', border: 'none', cursor: 'pointer', fontSize: '1.3rem',
              color: isFav ? '#f59e0b' : '#d1d5db', flexShrink: 0, transition: 'all 0.3s ease',
              transform: isFav ? 'scale(1.2)' : 'scale(1)',
            }}>
              <i className={`fa${isFav ? 's' : 'r'} fa-star`}></i>
            </button>
          </div>
        );
      })}

      <div style={{
        background: 'linear-gradient(135deg, #8965e0, #2DCE89)',
        color: 'white', padding: '20px', borderRadius: '16px',
        textAlign: 'center', marginBottom: '20px',
      }}>
        <h3 style={{ marginBottom: '10px' }}>{t('wellness.therapy')}</h3>
        <p>{t('wellness.therapy_desc')}</p>
        <button style={{
          background: 'white', color: '#8965e0', border: 'none', borderRadius: '25px',
          padding: '12px 24px', fontWeight: 600, cursor: 'pointer', marginTop: '15px',
          fontFamily: 'Poppins, sans-serif',
        }}>{t('wellness.book')}</button>
      </div>
    </div>
  );
}
