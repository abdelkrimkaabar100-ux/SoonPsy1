import { useState, useEffect } from 'react';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { useLanguage } from '../../i18n/LanguageContext';

interface NotifSettings {
  enabled: boolean;
  time: string;
  types: string[];
}

export default function NotificationSetup() {
  const { lang } = useLanguage();
  const [settings, setSettings] = useLocalStorage<NotifSettings>('soon-notif-settings', { enabled: false, time: '09:00', types: ['general'] });
  const [showSetup, setShowSetup] = useState(false);
  const [permission, setPermission] = useState<string>('default');
  const userName = (() => { try { return JSON.parse(localStorage.getItem('soon-user-name') || '""'); } catch { return ''; } })();

  useEffect(() => { if ('Notification' in window) setPermission(Notification.permission); }, []);

  // Schedule notifications using the device's time
  useEffect(() => {
    if (!settings.enabled || !('Notification' in window) || Notification.permission !== 'granted') return;

    const scheduleNext = () => {
      const now = new Date();
      const [h, m] = settings.time.split(':').map(Number);
      const target = new Date(now);
      target.setHours(h, m, 0, 0);
      
      // If time already passed today, schedule for tomorrow
      if (target <= now) {
        target.setDate(target.getDate() + 1);
      }
      
      const delay = target.getTime() - now.getTime();
      
      const timer = setTimeout(() => {
        sendNotification();
        // Schedule next day
        scheduleNext();
      }, delay);

      return timer;
    };

    const timer = scheduleNext();
    return () => { if (timer) clearTimeout(timer); };
  }, [settings, lang, userName]);

  // Also register with service worker for background notifications
  useEffect(() => {
    if (!settings.enabled || !('serviceWorker' in navigator)) return;
    
    navigator.serviceWorker.ready.then(reg => {
      // Send settings to service worker
      reg.active?.postMessage({
        type: 'SCHEDULE_NOTIFICATION',
        time: settings.time,
        lang,
        userName,
        types: settings.types,
      });
    }).catch(() => {});
  }, [settings, lang, userName]);

  const sendNotification = () => {
    const name = userName ? ` ${userName}` : '';
    const types = settings.types || ['general'];
    const msgs: Record<string, Record<string, string[]>> = {
      general: {
        ar: [`كيف حالك${name}؟ 💚`, `لا تنسَ أن تبتسم${name} 😊`, `خذ لحظة للامتنان${name} 🙏`],
        en: [`How are you${name}? 💚`, `Don't forget to smile${name} 😊`, `Take a moment for gratitude${name} 🙏`],
        es: [`¿Cómo estás${name}? 💚`, `No olvides sonreír${name} 😊`],
        fr: [`Comment allez-vous${name}? 💚`, `N'oubliez pas de sourire${name} 😊`],
      },
      tasks: {
        ar: [`${name}، لديك مهام تنتظرك! 📋`],
        en: [`${name}, you have tasks waiting! 📋`],
        es: [`${name}, ¡tienes tareas pendientes! 📋`],
        fr: [`${name}, vous avez des tâches en attente! 📋`],
      },
      dreams: {
        ar: [`${name}، هل تذكرت حلمك اليوم؟ 🌙`],
        en: [`${name}, did you remember your dream today? 🌙`],
        es: [`${name}, ¿recordaste tu sueño hoy? 🌙`],
        fr: [`${name}, vous souvenez-vous de votre rêve? 🌙`],
      },
      mood: {
        ar: [`${name}، كيف مزاجك الآن؟ 🎭`],
        en: [`${name}, how's your mood right now? 🎭`],
        es: [`${name}, ¿cómo es tu ánimo ahora? 🎭`],
        fr: [`${name}, comment est votre humeur? 🎭`],
      },
      detox: {
        ar: [`${name}، هل سجلت تحدي الامتناع اليوم؟ 🚫🍬`, `${name}، حافظ على صيام الدوبامين! 🧠`, `${name}، ابتعد عن السوشال ميديا وعش اللحظة 📱❌`],
        en: [`${name}, did you log your detox challenge today? 🚫🍬`, `${name}, keep up the dopamine fast! 🧠`, `${name}, stay off social media and live the moment 📱❌`],
        es: [`${name}, ¿registraste tu desafío detox hoy? 🚫🍬`],
        fr: [`${name}, avez-vous enregistré votre défi détox? 🚫🍬`],
      },
      fasting: {
        ar: [`${name}، هل بدأت صيامك اليوم؟ 🌙`, `${name}، الصيام يعيد ضبط دوبامينك! 🧘`, `${name}، تذكر: الصيام يُنشط الأوتوفاجي بعد 12 ساعة 🔄`],
        en: [`${name}, did you start your fast today? 🌙`, `${name}, fasting resets your dopamine! 🧘`, `${name}, remember: autophagy activates after 12h fasting 🔄`],
        es: [`${name}, ¿comenzaste tu ayuno hoy? 🌙`],
        fr: [`${name}, avez-vous commencé votre jeûne? 🌙`],
      },
      water: {
        ar: [`${name}، لا تنسَ شرب الماء! 💧`, `${name}، جسمك يحتاج الماء لأداء أفضل 💧🧠`],
        en: [`${name}, don't forget to drink water! 💧`, `${name}, your body needs water for peak performance 💧🧠`],
        es: [`${name}, ¡no olvides beber agua! 💧`],
        fr: [`${name}, n'oubliez pas de boire de l'eau! 💧`],
      },
    };
    const selectedType = types[Math.floor(Math.random() * types.length)];
    const langMsgs = msgs[selectedType]?.[lang] || msgs[selectedType]?.en || msgs.general.en;
    const msg = langMsgs[Math.floor(Math.random() * langMsgs.length)];
    
    // Try service worker notification first (works in background)
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.ready.then(reg => {
        reg.showNotification('Soon 🌿', {
          body: msg,
          icon: '/icon.png',
          badge: '/icon.png',
          tag: 'soon-daily',
          renotify: true,
        } as NotificationOptions);
      }).catch(() => {
        new Notification('Soon 🌿', { body: msg, icon: '/icon.png' });
      });
    } else {
      new Notification('Soon 🌿', { body: msg, icon: '/icon.png' });
    }
  };

  const enableNotifications = async () => {
    if (!('Notification' in window)) return;
    const perm = await Notification.requestPermission();
    setPermission(perm);
    if (perm === 'granted') {
      setSettings({ ...settings, enabled: true });
      // Send test notification via service worker
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.ready.then(reg => {
          reg.showNotification('Soon 🌿', {
            body: lang === 'ar' ? 'تم تفعيل الإشعارات بنجاح! 💚' : 'Notifications enabled! 💚',
            icon: '/icon.png',
          });
        }).catch(() => {
          new Notification('Soon 🌿', { body: lang === 'ar' ? 'تم تفعيل الإشعارات بنجاح! 💚' : 'Notifications enabled! 💚', icon: '/icon.png' });
        });
      }
    }
  };

  const toggleType = (type: string) => {
    const types = settings.types || ['general'];
    setSettings({ ...settings, types: types.includes(type) ? types.filter(t => t !== type) : [...types, type] });
  };

  const isAr = lang === 'ar';
  const l = {
    title: isAr ? '🔔 إشعارات يومية' : '🔔 Daily Reminders',
    desc: isAr ? 'اختر ما تريد التذكير به' : 'Choose what to be reminded about',
    enable: isAr ? 'تفعيل الإشعارات' : 'Enable Notifications',
    time: isAr ? 'وقت التذكير' : 'Reminder Time',
    active: isAr ? 'الإشعارات مفعّلة ✅' : 'Notifications Active ✅',
    disable: isAr ? 'إيقاف' : 'Disable',
  };

  const typeOptions = [
    { id: 'general', label: isAr ? '👋 سؤال عام (كيف حالك)' : '👋 General check-in', icon: '💬' },
    { id: 'tasks', label: isAr ? '📋 تذكير بالمهام' : '📋 Task reminders', icon: '✅' },
    { id: 'dreams', label: isAr ? '🌙 تسجيل الأحلام' : '🌙 Dream logging', icon: '✨' },
    { id: 'mood', label: isAr ? '🎭 تسجيل المزاج' : '🎭 Mood tracking', icon: '💚' },
    { id: 'detox', label: isAr ? '🚫 تحدي الامتناع (سكر + دوبامين)' : '🚫 Detox challenge (sugar + dopamine)', icon: '🍬' },
    { id: 'fasting', label: isAr ? '🌙 تذكير بالصيام' : '🌙 Fasting reminder', icon: '🕌' },
    { id: 'water', label: isAr ? '💧 تذكير شرب الماء' : '💧 Water reminder', icon: '💧' },
  ];

  // Use device locale for time display
  const formattedTime = (() => {
    try {
      const [h, m] = settings.time.split(':').map(Number);
      const d = new Date();
      d.setHours(h, m, 0);
      return d.toLocaleTimeString(navigator.language, { hour: '2-digit', minute: '2-digit' });
    } catch { return settings.time; }
  })();

  if (!showSetup && !settings.enabled) {
    return (
      <button onClick={() => setShowSetup(true)} style={{
        width: '100%', background: 'linear-gradient(135deg, #2DCE89, #1a9f6e)', color: 'white',
        border: 'none', borderRadius: '16px', padding: '15px', cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '10px',
        fontFamily: 'Poppins, sans-serif', fontWeight: 600, fontSize: '0.9rem',
        boxShadow: '0 4px 15px rgba(45,206,137,0.3)', marginBottom: '15px'
      }}>
        <i className="fas fa-bell"></i> {l.title}
      </button>
    );
  }

  return (
    <div style={{ background: 'white', borderRadius: '16px', padding: '20px', marginBottom: '15px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)', borderLeft: '4px solid #2DCE89' }}>
      <h4 style={{ color: '#32325d', marginBottom: '10px' }}>{l.title}</h4>
      <p style={{ color: '#8898aa', fontSize: '0.85rem', marginBottom: '15px' }}>{l.desc}</p>

      <div style={{ marginBottom: '15px' }}>
        {typeOptions.map(opt => (
          <label key={opt.id} style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 10px', background: (settings.types || ['general']).includes(opt.id) ? '#f0fdf4' : '#f9fafb', borderRadius: '8px', marginBottom: '6px', cursor: 'pointer', border: (settings.types || ['general']).includes(opt.id) ? '1px solid #2DCE89' : '1px solid #e5e7eb' }}>
            <input type="checkbox" checked={(settings.types || ['general']).includes(opt.id)} onChange={() => toggleType(opt.id)} style={{ accentColor: '#2DCE89' }} />
            <span style={{ fontSize: '0.8rem', color: '#32325d' }}>{opt.label}</span>
          </label>
        ))}
      </div>

      {!settings.enabled ? (
        <div>
          <div style={{ marginBottom: '15px' }}>
            <label style={{ display: 'block', marginBottom: '5px', fontWeight: 500, color: '#32325d', fontSize: '0.85rem' }}>{l.time}</label>
            <input type="time" value={settings.time} onChange={e => setSettings({ ...settings, time: e.target.value })}
              style={{ padding: '10px', border: '2px solid #e1e8ed', borderRadius: '10px', fontSize: '1rem', width: '100%', boxSizing: 'border-box' }} />
          </div>
          <button onClick={enableNotifications} style={{
            width: '100%', background: 'linear-gradient(135deg, #2DCE89, #1a9f6e)', color: 'white',
            border: 'none', borderRadius: '12px', padding: '12px', fontWeight: 600, cursor: 'pointer'
          }}>
            <i className="fas fa-bell"></i> {l.enable}
          </button>
          {permission === 'denied' && (
            <p style={{ color: '#f5365c', fontSize: '0.8rem', marginTop: '10px', textAlign: 'center' }}>
              {isAr ? 'تم رفض الإذن. يرجى تفعيله من إعدادات المتصفح.' : 'Permission denied. Please enable in browser settings.'}
            </p>
          )}
        </div>
      ) : (
        <div>
          <div style={{ background: '#d1efe1', borderRadius: '12px', padding: '12px', textAlign: 'center', marginBottom: '10px' }}>
            <span style={{ color: '#1a9f6e', fontWeight: 600 }}>{l.active}</span>
            <div style={{ color: '#1a9f6e', fontSize: '0.85rem', marginTop: '5px' }}>⏰ {formattedTime}</div>
          </div>
          <div style={{ display: 'flex', gap: '10px' }}>
            <input type="time" value={settings.time} onChange={e => setSettings({ ...settings, time: e.target.value })}
              style={{ flex: 1, padding: '10px', border: '2px solid #e1e8ed', borderRadius: '10px' }} />
            <button onClick={() => { setSettings({ enabled: false, time: '09:00', types: ['general'] }); setShowSetup(false); }}
              style={{ background: '#fee2e2', color: '#dc2626', border: 'none', borderRadius: '10px', padding: '10px 15px', cursor: 'pointer', fontWeight: 600, fontSize: '0.8rem' }}>
              {l.disable}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
