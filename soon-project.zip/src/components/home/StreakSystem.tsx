import { useEffect } from 'react';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { useLanguage } from '../../i18n/LanguageContext';

interface StreakData { lastVisit: string; totalDays: number; currentStreak: number; }

const titles: { days: number; title: Record<string, string>; icon: string }[] = [
  { days: 3, title: { en: 'Cute Kitten 🐱', ar: 'قطة لطيفة 🐱', es: 'Gatito Lindo 🐱', fr: 'Chaton Mignon 🐱' }, icon: '🐱' },
  { days: 7, title: { en: 'Loyal Puppy 🐶', ar: 'جرو وفي 🐶', es: 'Cachorro Leal 🐶', fr: 'Chiot Fidèle 🐶' }, icon: '🐶' },
  { days: 14, title: { en: 'Wise Owl 🦉', ar: 'بومة حكيمة 🦉', es: 'Búho Sabio 🦉', fr: 'Hibou Sage 🦉' }, icon: '🦉' },
  { days: 30, title: { en: 'Brave Lion 🦁', ar: 'أسد شجاع 🦁', es: 'León Valiente 🦁', fr: 'Lion Courageux 🦁' }, icon: '🦁' },
  { days: 60, title: { en: 'Soaring Eagle 🦅', ar: 'نسر محلق 🦅', es: 'Águila Voladora 🦅', fr: 'Aigle Planant 🦅' }, icon: '🦅' },
  { days: 100, title: { en: 'Majestic Dolphin 🐬', ar: 'دلفين مهيب 🐬', es: 'Delfín Majestuoso 🐬', fr: 'Dauphin Majestueux 🐬' }, icon: '🐬' },
  { days: 365, title: { en: 'Phoenix Rising 🔥', ar: 'طائر الفينيق 🔥', es: 'Fénix Renaciente 🔥', fr: 'Phénix Renaissant 🔥' }, icon: '🔥' },
  { days: 1000, title: { en: 'The Great Challenge 💎', ar: 'التحدي العظيم 💎', es: 'El Gran Desafío 💎', fr: 'Le Grand Défi 💎' }, icon: '💎' },
];

export default function StreakSystem() {
  const { t, lang } = useLanguage();
  const [streakData, setStreakData] = useLocalStorage<StreakData>('soon-streak', { lastVisit: '', totalDays: 0, currentStreak: 0 });

  useEffect(() => {
    const today = new Date().toDateString();
    if (streakData.lastVisit === today) return;
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const isConsecutive = streakData.lastVisit === yesterday.toDateString();
    setStreakData({
      lastVisit: today,
      totalDays: streakData.totalDays + 1,
      currentStreak: isConsecutive ? streakData.currentStreak + 1 : 1,
    });
  }, []);

  const currentTitle = [...titles].reverse().find(t => streakData.currentStreak >= t.days);
  const nextTitle = titles.find(t => t.days > streakData.currentStreak);
  const progress = nextTitle ? ((streakData.currentStreak / nextTitle.days) * 100) : 100;

  return (
    <div style={{ background: 'linear-gradient(135deg, #ff9a56, #ff6b6b, #ee5a24)', borderRadius: '20px', padding: '24px', marginBottom: '20px', color: 'white', textAlign: 'center', boxShadow: '0 8px 30px rgba(238,90,36,0.3)', position: 'relative', overflow: 'hidden' }}>
      {/* Decorative particles */}
      <div style={{ position: 'absolute', top: '10%', left: '10%', fontSize: '1.5rem', opacity: 0.2, animation: 'float 3s ease-in-out infinite' }}>✨</div>
      <div style={{ position: 'absolute', top: '20%', right: '15%', fontSize: '1rem', opacity: 0.15, animation: 'float 4s ease-in-out infinite 1s' }}>🌟</div>
      <div style={{ position: 'absolute', bottom: '15%', left: '20%', fontSize: '1.2rem', opacity: 0.15, animation: 'float 3.5s ease-in-out infinite 0.5s' }}>💫</div>

      {/* Flame animation */}
      <div style={{ fontSize: '3.5rem', marginBottom: '8px', filter: 'drop-shadow(0 0 15px rgba(255,165,0,0.8))', animation: 'pulse 2s ease-in-out infinite' }}>
        {currentTitle?.icon || '🐣'}
      </div>

      <h4 style={{ color: 'white', margin: '5px 0', fontSize: '1.1rem', textShadow: '0 2px 4px rgba(0,0,0,0.2)' }}>
        {currentTitle ? (currentTitle.title[lang] || currentTitle.title.en) : (lang === 'ar' ? 'فرخ صغير 🐣' : 'Little Chick 🐣')}
      </h4>

      <div style={{ display: 'flex', justifyContent: 'center', gap: '24px', margin: '18px 0' }}>
        <div>
          <div style={{ fontSize: '2.2rem', fontWeight: 700, textShadow: '0 2px 8px rgba(0,0,0,0.2)' }}>🔥 {streakData.currentStreak}</div>
          <div style={{ fontSize: '0.75rem', opacity: 0.9 }}>{t('streak.current')}</div>
        </div>
        <div>
          <div style={{ fontSize: '2.2rem', fontWeight: 700, textShadow: '0 2px 8px rgba(0,0,0,0.2)' }}>📅 {streakData.totalDays}</div>
          <div style={{ fontSize: '0.75rem', opacity: 0.9 }}>{t('streak.total')}</div>
        </div>
      </div>

      {nextTitle && (
        <div style={{ marginTop: '12px' }}>
          <div style={{ background: 'rgba(255,255,255,0.15)', borderRadius: '20px', height: '10px', overflow: 'hidden', marginBottom: '8px' }}>
            <div style={{ height: '100%', background: 'linear-gradient(to right, #ffd700, #ffffff)', borderRadius: '20px', width: `${progress}%`, transition: 'width 0.5s ease', boxShadow: '0 0 10px rgba(255,215,0,0.5)' }}></div>
          </div>
          <div style={{ fontSize: '0.8rem', opacity: 0.9 }}>
            {t('streak.next')}: {nextTitle.icon} {nextTitle.title[lang] || nextTitle.title.en} ({nextTitle.days - streakData.currentStreak} {t('data.days')})
          </div>
        </div>
      )}

      <style>{`
        @keyframes float { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-10px); } }
        @keyframes pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.1); } }
      `}</style>
    </div>
  );
}
