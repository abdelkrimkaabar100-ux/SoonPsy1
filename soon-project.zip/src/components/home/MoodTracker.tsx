import { useState } from 'react';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { useLanguage } from '../../i18n/LanguageContext';

interface MoodEntry {
  id: string;
  mood: string;
  date: string;
}

interface MoodTrackerProps {
  selectedMood: string;
  onMoodSelect: (mood: string) => void;
  onShareWithAI: () => void;
}

export default function MoodTracker({ selectedMood, onMoodSelect, onShareWithAI }: MoodTrackerProps) {
  const { t } = useLanguage();
  const [moodHistory, setMoodHistory] = useLocalStorage<MoodEntry[]>('soon-mood-history', []);
  const [showHistory, setShowHistory] = useState(false);

  const moods = [
    { id: 'excellent', emoji: '😁', labelKey: 'mood.excellent' },
    { id: 'good', emoji: '😊', labelKey: 'mood.good' },
    { id: 'neutral', emoji: '😐', labelKey: 'mood.neutral' },
    { id: 'bad', emoji: '😔', labelKey: 'mood.bad' },
    { id: 'terrible', emoji: '😢', labelKey: 'mood.terrible' },
  ];

  const handleMoodSelect = (moodId: string) => {
    onMoodSelect(moodId);
    // Save to history
    const today = new Date().toDateString();
    const alreadyToday = moodHistory.some(e => new Date(e.date).toDateString() === today && e.mood === moodId);
    if (!alreadyToday) {
      setMoodHistory([{ id: Date.now().toString(), mood: moodId, date: new Date().toISOString() }, ...moodHistory]);
    }
  };

  const getMoodEmoji = (moodId: string) => moods.find(m => m.id === moodId)?.emoji || '😐';

  // Group by date
  const grouped = moodHistory.reduce<Record<string, MoodEntry[]>>((acc, entry) => {
    const dateKey = new Date(entry.date).toLocaleDateString();
    if (!acc[dateKey]) acc[dateKey] = [];
    acc[dateKey].push(entry);
    return acc;
  }, {});

  const sortedDates = Object.keys(grouped).sort((a, b) =>
    new Date(grouped[b][0].date).getTime() - new Date(grouped[a][0].date).getTime()
  );

  return (
    <div style={{
      background: 'white', borderRadius: '16px',
      padding: '20px', margin: '30px 0',
      boxShadow: '0 6px 20px rgba(0,0,0,0.08)',
    }}>
      <h3 style={{ fontSize: '1.3rem', color: '#32325d', marginTop: 0, marginBottom: '20px', textAlign: 'center' }}>
        {t('mood.title')}
      </h3>
      <div style={{ display: 'flex', justifyContent: 'space-around', flexWrap: 'wrap' }}>
        {moods.map(mood => (
          <div
            key={mood.id}
            onClick={() => handleMoodSelect(mood.id)}
            style={{
              display: 'flex', flexDirection: 'column', alignItems: 'center',
              cursor: 'pointer', padding: '10px', borderRadius: '50%',
              width: '70px', transition: 'all 0.3s ease',
              background: selectedMood === mood.id ? '#f0f4ff' : 'transparent',
              transform: selectedMood === mood.id ? 'scale(1.1)' : 'scale(1)',
            }}
          >
            <div style={{ fontSize: '2.2rem', marginBottom: '8px' }}>{mood.emoji}</div>
            <div style={{ fontSize: '0.85rem', color: '#8898aa', fontWeight: 600 }}>{t(mood.labelKey)}</div>
          </div>
        ))}
      </div>
      <button
        onClick={onShareWithAI}
        style={{
          background: 'linear-gradient(to right, #2DCE89, #1a9f6e)',
          color: 'white', border: 'none',
          borderRadius: '25px', padding: '12px 24px',
          fontWeight: 600, fontSize: '1rem',
          cursor: 'pointer', width: '100%',
          marginTop: '15px', fontFamily: 'Poppins, sans-serif',
          boxShadow: '0 4px 15px rgba(45,206,137,0.3)',
          transition: 'all 0.3s ease',
        }}
      >
        {t('mood.share')}
      </button>

      {/* History Toggle */}
      {moodHistory.length > 0 && (
        <button
          onClick={() => setShowHistory(!showHistory)}
          style={{
            background: 'none', border: '1px solid #2DCE89',
            color: '#2DCE89', borderRadius: '25px',
            padding: '8px 16px', fontWeight: 600,
            cursor: 'pointer', width: '100%',
            fontFamily: 'Poppins, sans-serif',
            marginTop: '10px', fontSize: '0.9rem',
          }}
        >
          <i className={`fas fa-${showHistory ? 'chevron-up' : 'history'}`} style={{ marginRight: '8px' }}></i>
          {showHistory ? t('mood.hide_history') : t('mood.history')}
        </button>
      )}

      {showHistory && (
        <div style={{ marginTop: '15px', maxHeight: '300px', overflowY: 'auto' }}>
          {sortedDates.length === 0 && (
            <p style={{ color: '#8898aa', textAlign: 'center', fontSize: '0.9rem' }}>{t('mood.no_history')}</p>
          )}
          {sortedDates.map(dateKey => (
            <div key={dateKey} style={{ marginBottom: '10px' }}>
              <div style={{
                fontSize: '0.85rem', fontWeight: 600, color: '#1a9f6e',
                marginBottom: '6px', paddingBottom: '4px',
                borderBottom: '2px solid #d1efe1',
              }}>
                <i className="fas fa-calendar-alt" style={{ marginRight: '6px' }}></i>
                {dateKey}
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                {grouped[dateKey].map(entry => (
                  <span key={entry.id} style={{
                    background: '#f0fdf4', padding: '4px 10px', borderRadius: '12px',
                    fontSize: '0.85rem', display: 'flex', alignItems: 'center', gap: '4px',
                    border: '1px solid #bbf7d0',
                  }}>
                    {getMoodEmoji(entry.mood)} {t(`mood.${entry.mood}`)}
                    <span style={{ fontSize: '0.7rem', color: '#8898aa', marginLeft: '4px' }}>
                      {new Date(entry.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
