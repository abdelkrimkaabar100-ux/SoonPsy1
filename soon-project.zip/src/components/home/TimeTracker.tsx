import { useState, useEffect } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';

export default function TimeTracker() {
  const { lang } = useLanguage();
  const isAr = lang === 'ar';
  const [monthlyMinutes, setMonthlyMinutes] = useLocalStorage<number>('soon-monthly-minutes', 0);
  const [lastUpdate, setLastUpdate] = useLocalStorage<string>('soon-time-last-update', '');
  const [sessionStart] = useState(Date.now());

  const labels: Record<string, Record<string, string>> = {
    en: { title: 'Time Invested in My Wellbeing', share: 'Share', month: 'This month', hours: 'hours', mins: 'minutes', shareText: 'I spent {time} this month on Soon improving my mental health and my pet\'s wellbeing! 🧠💚🐾' },
    ar: { title: 'الوقت المستثمر في صحتي النفسية', share: 'مشاركة', month: 'هذا الشهر', hours: 'ساعة', mins: 'دقيقة', shareText: 'قضيت {time} هذا الشهر على Soon لتعزيز صحتي النفسية وصحة حيواني الأليف! 🧠💚🐾' },
    es: { title: 'Tiempo Invertido en Mi Bienestar', share: 'Compartir', month: 'Este mes', hours: 'horas', mins: 'minutos', shareText: '¡Pasé {time} este mes en Soon mejorando mi salud mental! 🧠💚🐾' },
    fr: { title: 'Temps Investi dans Mon Bien-être', share: 'Partager', month: 'Ce mois', hours: 'heures', mins: 'minutes', shareText: 'J\'ai passé {time} ce mois sur Soon pour ma santé mentale! 🧠💚🐾' },
  };
  const l = labels[lang] || labels.en;

  // Reset monthly if new month
  useEffect(() => {
    const now = new Date();
    const currentMonth = `${now.getFullYear()}-${now.getMonth()}`;
    if (lastUpdate !== currentMonth) {
      setMonthlyMinutes(0);
      setLastUpdate(currentMonth);
    }
  }, []);

  // Track session time
  useEffect(() => {
    const interval = setInterval(() => {
      setMonthlyMinutes(prev => prev + 1);
    }, 60000); // every minute
    return () => clearInterval(interval);
  }, []);

  const hours = Math.floor(monthlyMinutes / 60);
  const mins = monthlyMinutes % 60;
  const timeStr = hours > 0 ? `${hours} ${l.hours} ${mins} ${l.mins}` : `${mins} ${l.mins}`;

  const handleShare = () => {
    const text = l.shareText.replace('{time}', timeStr);
    if (navigator.share) {
      navigator.share({ text, url: 'https://soonpsy.lovable.app' });
    } else {
      navigator.clipboard.writeText(text + ' https://soonpsy.lovable.app');
      alert(isAr ? 'تم النسخ!' : 'Copied!');
    }
  };

  return (
    <div style={{
      background: 'linear-gradient(135deg, #ecfdf5, #d1fae5)', borderRadius: '16px',
      padding: '15px 18px', marginBottom: '15px', display: 'flex', alignItems: 'center', gap: '12px',
      direction: isAr ? 'rtl' : 'ltr',
    }}>
      <div style={{ fontSize: '1.8rem' }}>⏱️</div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: '0.7rem', color: '#065f46', fontWeight: 600, textTransform: 'uppercase' }}>{l.month}</div>
        <div style={{ fontSize: '1.1rem', fontWeight: 700, color: '#047857' }}>{timeStr}</div>
        <div style={{ fontSize: '0.7rem', color: '#059669', opacity: 0.8 }}>{l.title}</div>
      </div>
      <button onClick={handleShare} style={{
        background: '#059669', color: 'white', border: 'none', borderRadius: '20px',
        padding: '6px 14px', fontSize: '0.75rem', fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
      }}>
        📤 {l.share}
      </button>
    </div>
  );
}
