import { useState, useEffect } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';

export default function InstallApp() {
  const { lang } = useLanguage();
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [showGuide, setShowGuide] = useState(false);
  const isAr = lang === 'ar';

  useEffect(() => {
    // Check if already installed
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstalled(true);
      return;
    }

    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handler);

    const installed = () => setIsInstalled(true);
    window.addEventListener('appinstalled', installed);

    return () => {
      window.removeEventListener('beforeinstallprompt', handler);
      window.removeEventListener('appinstalled', installed);
    };
  }, []);

  const handleInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const result = await deferredPrompt.userChoice;
      if (result.outcome === 'accepted') setIsInstalled(true);
      setDeferredPrompt(null);
    } else {
      setShowGuide(true);
    }
  };

  if (isInstalled) return null;

  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
  const isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);

  return (
    <div style={{ marginBottom: '15px' }}>
      <button onClick={handleInstall} style={{
        width: '100%', background: 'linear-gradient(135deg, #2DCE89, #1a9f6e)', color: 'white',
        border: 'none', borderRadius: '16px', padding: '16px', cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '10px',
        fontFamily: 'Poppins, sans-serif', fontWeight: 600, fontSize: '1rem',
        boxShadow: '0 4px 15px rgba(45,206,137,0.3)',
      }}>
        <i className="fas fa-download"></i>
        {isAr ? '📲 تنزيل التطبيق على هاتفك' : '📲 Install App on Your Phone'}
      </button>

      {showGuide && (
        <div style={{
          background: 'white', borderRadius: '16px', padding: '18px', marginTop: '10px',
          boxShadow: '0 6px 20px rgba(0,0,0,0.08)', borderLeft: '4px solid #2DCE89',
        }}>
          <h4 style={{ color: '#32325d', marginBottom: '12px', fontSize: '1rem' }}>
            {isAr ? '📱 كيفية التثبيت' : '📱 How to Install'}
          </h4>
          {isIOS || isSafari ? (
            <div>
              <p style={{ color: '#525f7f', fontSize: '0.85rem', lineHeight: 1.7, margin: '0 0 8px' }}>
                {isAr ? '1. اضغط على زر المشاركة' : '1. Tap the Share button'} <i className="fas fa-share-square" style={{ color: '#007AFF' }}></i>
              </p>
              <p style={{ color: '#525f7f', fontSize: '0.85rem', lineHeight: 1.7, margin: '0 0 8px' }}>
                {isAr ? '2. اختر "إضافة إلى الشاشة الرئيسية"' : '2. Select "Add to Home Screen"'} <i className="fas fa-plus-square" style={{ color: '#007AFF' }}></i>
              </p>
              <p style={{ color: '#525f7f', fontSize: '0.85rem', lineHeight: 1.7, margin: 0 }}>
                {isAr ? '3. اضغط "إضافة"' : '3. Tap "Add"'}
              </p>
            </div>
          ) : (
            <div>
              <p style={{ color: '#525f7f', fontSize: '0.85rem', lineHeight: 1.7, margin: '0 0 8px' }}>
                {isAr ? '1. اضغط على ⋮ (قائمة المتصفح)' : '1. Tap ⋮ (browser menu)'}
              </p>
              <p style={{ color: '#525f7f', fontSize: '0.85rem', lineHeight: 1.7, margin: '0 0 8px' }}>
                {isAr ? '2. اختر "تثبيت التطبيق" أو "إضافة إلى الشاشة الرئيسية"' : '2. Select "Install app" or "Add to Home Screen"'}
              </p>
              <p style={{ color: '#525f7f', fontSize: '0.85rem', lineHeight: 1.7, margin: 0 }}>
                {isAr ? '3. اضغط "تثبيت"' : '3. Tap "Install"'}
              </p>
            </div>
          )}
          <button onClick={() => setShowGuide(false)} style={{
            marginTop: '12px', background: 'none', border: '1px solid #e5e7eb',
            borderRadius: '10px', padding: '8px 16px', cursor: 'pointer', color: '#8898aa',
            fontSize: '0.8rem', width: '100%',
          }}>
            {isAr ? 'حسناً، فهمت' : 'Got it'}
          </button>
        </div>
      )}
    </div>
  );
}
