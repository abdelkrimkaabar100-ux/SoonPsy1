import { useLocalStorage } from '../../hooks/useLocalStorage';
import { useLanguage } from '../../i18n/LanguageContext';

interface HabitData {
  lastChecked: string;
  streak: number;
}

export default function HabitTracker() {
  const { t } = useLanguage();
  const [habitData, setHabitData] = useLocalStorage<HabitData>('soon-habit', { lastChecked: '', streak: 0 });

  const today = new Date().toDateString();
  const isCheckedToday = habitData.lastChecked === today;

  const handleCleanToday = () => {
    if (isCheckedToday) return;
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const wasYesterday = habitData.lastChecked === yesterday.toDateString();
    const newStreak = wasYesterday ? habitData.streak + 1 : 1;
    setHabitData({ lastChecked: today, streak: newStreak });
  };

  const resetStreak = () => {
    if (confirm(t('habit.reset_confirm'))) {
      setHabitData({ lastChecked: '', streak: 0 });
    }
  };

  return (
    <div style={{
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      borderRadius: '16px', padding: '25px 20px', marginBottom: '20px',
      boxShadow: '0 6px 20px rgba(0,0,0,0.08)', textAlign: 'center', color: 'white',
    }}>
      <h4 style={{ color: 'white', marginBottom: '10px', fontSize: '1.1rem' }}>
        <i className="fas fa-heart" style={{ marginRight: '8px' }}></i>
        {t('habit.title')}
      </h4>
      <p style={{ fontSize: '0.9rem', opacity: 0.9, marginBottom: '20px' }}>{t('habit.desc')}</p>
      <button onClick={handleCleanToday} disabled={isCheckedToday} style={{
        background: isCheckedToday ? '#22c55e' : 'white',
        color: isCheckedToday ? 'white' : '#667eea',
        border: 'none', borderRadius: '25px', padding: '18px 25px', fontSize: '1rem',
        fontWeight: 600, fontFamily: 'Poppins, sans-serif',
        cursor: isCheckedToday ? 'default' : 'pointer',
        width: '100%', transition: 'all 0.3s ease', boxShadow: '0 4px 15px rgba(0,0,0,0.2)',
      }}>
        {isCheckedToday ? t('habit.done') : t('habit.clean')}
      </button>
      <div style={{ fontSize: '2.5rem', fontWeight: 700, marginTop: '20px' }}>{habitData.streak}</div>
      <div style={{ fontSize: '0.9rem', opacity: 0.9, marginBottom: '15px' }}>{t('habit.days_clean')}</div>
      <button onClick={resetStreak} style={{
        background: 'transparent', border: '1px solid rgba(255,255,255,0.5)',
        color: 'white', padding: '8px 16px', borderRadius: '20px', fontSize: '0.85rem',
        cursor: 'pointer', fontFamily: 'Poppins, sans-serif', transition: 'all 0.3s ease',
      }}>{t('habit.reset')}</button>
    </div>
  );
}
