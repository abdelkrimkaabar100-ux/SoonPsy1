import { useState, useRef, useEffect } from 'react';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { useLanguage } from '../../i18n/LanguageContext';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

interface AIChatProps {
  triggerMessage?: string;
  onTriggerConsumed?: () => void;
}

// Read ALL user data from localStorage for comprehensive AI context
function getAIContextFromStorage() {
  const read = <T,>(key: string, fallback: T): T => {
    try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; } catch { return fallback; }
  };

  const userName = read<string>('soon-user-name', '');
  const sleepLog = read<{value:number;date:string}[]>('soon-sleep', []);
  const exerciseLog = read<{value:number;date:string}[]>('soon-exercise', []);
  const restLog = read<{value:number;date:string}[]>('soon-rest', []);
  const gratitudeEntries = read<{id:string;content:string;date:string}[]>('soon-gratitude', []);
  const dreams = read<{id:string;content:string;sleepQuality:string;recallLevel:string;date:string;formattedDate:string}[]>('soon-dreams', []);
  const journalEntries = read<{id:string;text:string;mood:string;date:string}[]>('soon-journal', []);
  const petData = read<{name:string;type:string;age:string;breed:string}>('soon-pet', { name: '', type: '', age: '', breed: '' });
  const petSleepLog = read<{value:number;date:string}[]>('soon-pet-sleep', []);
  const petExerciseLog = read<{value:number;date:string}[]>('soon-pet-exercise', []);
  const petFoodLog = read<{food:string;date:string}[]>('soon-pet-food-log', []);
  const petActivityLog = read<{activity:string;minutes:number;date:string}[]>('soon-pet-activity-log', []);
  const habitData = read<{lastChecked:string;streak:number}>('soon-habit', { lastChecked: '', streak: 0 });
  const foods = read<{food:string;date:string}[]>('soon-food-log', []);
  const reflections = read<string[]>('soon-reflections', []);
  const moodHistory = read<{mood:string;date:string}[]>('soon-mood-history', []);
  const smileChallenge = read<{date:string;count:number;note:string}[]>('soon-smile-challenge', []);
  const honestyEntries = read<{id:string;person:string;feelings:string;date:string}[]>('soon-honesty', []);
  const streakData = read<{lastVisit:string;totalDays:number;currentStreak:number}>('soon-streak', { lastVisit: '', totalDays: 0, currentStreak: 0 });

  const selectedMood = moodHistory.length > 0 ? moodHistory[0].mood : '';
  const today = new Date().toDateString();
  const getTodayValue = (log: {value:number;date:string}[]) =>
    log.filter(e => new Date(e.date).toDateString() === today).reduce((s, e) => s + e.value, 0);

  const oneWeekAgo = new Date(); oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
  const weekGratitude = gratitudeEntries.filter(e => new Date(e.date) >= oneWeekAgo);
  const weekMoods = moodHistory.filter(e => new Date(e.date) >= oneWeekAgo);
  const weekSleep = sleepLog.filter(e => new Date(e.date) >= oneWeekAgo);
  const weekExercise = exerciseLog.filter(e => new Date(e.date) >= oneWeekAgo);
  const todayFoods = foods.filter(f => new Date(f.date).toDateString() === today).map(f => f.food);
  const todayPetFood = petFoodLog.filter(f => new Date(f.date).toDateString() === today).map(f => f.food);
  const todayPetActivities = petActivityLog.filter(a => new Date(a.date).toDateString() === today);
  const todaySmiles = smileChallenge.find(s => new Date(s.date).toDateString() === today);

  // Weekly patterns
  const weekAvgSleep = weekSleep.length > 0 ? (weekSleep.reduce((s, e) => s + e.value, 0) / 7).toFixed(1) : '0';
  const weekTotalExercise = weekExercise.reduce((s, e) => s + e.value, 0);
  const moodPattern = weekMoods.map(m => m.mood).join(', ');

  return {
    userName,
    mood: selectedMood,
    sleepHours: getTodayValue(sleepLog),
    exerciseMinutes: getTodayValue(exerciseLog),
    restMinutes: getTodayValue(restLog),
    gratitudeEntries: weekGratitude.map(e => e.content),
    weeklyGratitudeCount: weekGratitude.length,
    recentDreams: dreams.slice(0, 3).map(d => ({ content: d.content, quality: d.sleepQuality, recall: d.recallLevel, date: d.formattedDate })),
    recentJournal: journalEntries.slice(0, 3).map(j => ({ text: j.text, mood: j.mood, date: new Date(j.date).toLocaleDateString() })),
    pet: petData.name ? {
      ...petData,
      sleepToday: getTodayValue(petSleepLog),
      exerciseToday: getTodayValue(petExerciseLog),
      foodToday: todayPetFood,
      activitiesToday: todayPetActivities,
    } : null,
    habitStreak: habitData.streak,
    habitCheckedToday: habitData.lastChecked === today,
    foodsToday: todayFoods,
    allFoodsThisWeek: foods.filter(f => new Date(f.date) >= oneWeekAgo).map(f => f.food),
    reflections: reflections.slice(0, 3),
    smilesToday: todaySmiles?.count || 0,
    honestyEntries: honestyEntries.slice(0, 2).map(h => ({ person: h.person, feelings: h.feelings.slice(0, 100) })),
    appStreak: streakData.currentStreak,
    totalDaysUsed: streakData.totalDays,
    weeklyPatterns: {
      avgSleep: weekAvgSleep,
      totalExercise: weekTotalExercise,
      moodPattern,
      gratitudeCount: weekGratitude.length,
    },
  };
}

export default function AIChat({ triggerMessage, onTriggerConsumed }: AIChatProps) {
  const { t, lang } = useLanguage();
  const [messages, setMessages] = useLocalStorage<Message[]>('soon-chat-messages', []);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [hasGreeted, setHasGreeted] = useLocalStorage<string>('soon-greeted-date', '');
  const responseRef = useRef<HTMLDivElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (responseRef.current) responseRef.current.scrollTop = responseRef.current.scrollHeight;
  }, [messages, isLoading]);

  useEffect(() => {
    const today = new Date().toDateString();
    if (hasGreeted !== today && messages.length === 0) {
      setHasGreeted(today);
      setMessages([{ role: 'assistant', content: getGreeting() }]);
    }
  }, []);

  useEffect(() => {
    if (triggerMessage && triggerMessage.trim()) {
      sendMessageText(triggerMessage);
      onTriggerConsumed?.();
      // Scroll to SoonPsy chat
      setTimeout(() => {
        chatContainerRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 300);
    }
  }, [triggerMessage]);

  const getGreeting = () => {
    const ctx = getAIContextFromStorage();
    const name = ctx.userName ? ` ${ctx.userName}` : '';
    const hour = new Date().getHours();
    const greetings: Record<string, Record<string, string>> = {
      en: {
        morning: `Good morning${name}! ☀️ I'm SoonPsy, your caring mental wellness companion — think of me as a supportive big brother. How did you sleep? Start by logging your mood, and I'll give you personalized insights based on ALL your data. I'm always here for you! 💚`,
        afternoon: `Good afternoon${name}! 🌤️ I'm SoonPsy, your mental wellness companion. How's your day going? Log your mood and I'll help you reflect. Remember, you can also care for your pet's mental health here! 💚`,
        evening: `Good evening${name}! 🌙 I'm SoonPsy, your mental wellness companion. How was your day? Take a moment to log your mood and gratitude. I can see all your data and give you personalized advice. 💚`,
      },
      ar: {
        morning: `صباح الخير${name}! ☀️ أنا سونسي، رفيقك النفسي — فكّر فيني كأخ كبير يحبك. كيف كان نومك؟ سجّل مزاجك وسأقدم لك نصائح مخصصة بناءً على جميع بياناتك. أنا دائماً هنا من أجلك! 💚`,
        afternoon: `مرحباً${name}! 🌤️ أنا سونسي، رفيقك النفسي. كيف يسير يومك؟ سجّل مزاجك وسأساعدك. لا تنسَ أنه يمكنك أيضاً العناية بصحة حيوانك الأليف النفسية هنا! 💚`,
        evening: `مساء الخير${name}! 🌙 أنا سونسي، رفيقك النفسي. كيف كان يومك؟ سجّل مزاجك وامتنانك. أنا أرى جميع بياناتك وسأقدم لك نصائح مخصصة. 💚`,
      },
      es: {
        morning: `¡Buenos días${name}! ☀️ Soy SoonPsy, tu compañero de bienestar — piensa en mí como un hermano mayor. Registra tu ánimo y te daré consejos personalizados. 💚`,
        afternoon: `¡Buenas tardes${name}! 🌤️ Soy SoonPsy. ¿Cómo va tu día? También puedes cuidar la salud mental de tu mascota aquí. 💚`,
        evening: `¡Buenas noches${name}! 🌙 Soy SoonPsy. Registra tu ánimo y gratitud. Puedo ver todos tus datos. 💚`,
      },
      fr: {
        morning: `Bonjour${name}! ☀️ Je suis SoonPsy, votre compagnon bienveillant. Enregistrez votre humeur et je vous donnerai des conseils personnalisés. 💚`,
        afternoon: `Bon après-midi${name}! 🌤️ Je suis SoonPsy. Vous pouvez aussi prendre soin de la santé mentale de votre animal ici! 💚`,
        evening: `Bonsoir${name}! 🌙 Je suis SoonPsy. Prenez un moment pour noter votre humeur. Je vois toutes vos données. 💚`,
      },
    };
    const langGreetings = greetings[lang] || greetings.en;
    if (hour < 12) return langGreetings.morning;
    if (hour < 18) return langGreetings.afternoon;
    return langGreetings.evening;
  };

  const langInstruction = lang === 'ar' ? 'CRITICAL: You MUST respond ENTIRELY in Arabic (العربية). Every single word must be in Arabic.'
    : lang === 'es' ? 'CRITICAL: You MUST respond ENTIRELY in Spanish (Español). Every single word must be in Spanish.'
    : lang === 'fr' ? 'CRITICAL: You MUST respond ENTIRELY in French (Français). Every single word must be in French.'
    : 'CRITICAL: You MUST respond ENTIRELY in English. Every single word must be in English. Do NOT use Arabic or any other language.';

  const getSystemPrompt = () => {
    const ctx = getAIContextFromStorage();

    const nameSection = ctx.userName ? `- User Name: ${ctx.userName}` : '- User Name: Not provided';
    const gratitudeSection = ctx.gratitudeEntries.length > 0
      ? `- Recent Gratitude (this week): ${ctx.gratitudeEntries.join(' | ')}`
      : '- Gratitude: None this week';
    const dreamsSection = ctx.recentDreams.length > 0
      ? `- Recent Dreams:\n${ctx.recentDreams.map(d => `  • [${d.date}] Quality: ${d.quality || 'N/A'}, Recall: ${d.recall || 'N/A'} — ${d.content.slice(0, 200)}`).join('\n')}`
      : '- Dreams: None recorded recently';
    const journalSection = ctx.recentJournal.length > 0
      ? `- Recent Journal:\n${ctx.recentJournal.map(j => `  • [${j.date}] Mood: ${j.mood || 'N/A'} — ${j.text.slice(0, 200)}`).join('\n')}`
      : '- Journal: No entries recently';
    const petSection = ctx.pet
      ? `- Pet: ${ctx.pet.name} (${ctx.pet.type}, Age: ${ctx.pet.age}, Breed: ${ctx.pet.breed})
  Sleep Today: ${ctx.pet.sleepToday}h | Exercise: ${ctx.pet.exerciseToday}min
  Food: ${ctx.pet.foodToday?.join(', ') || 'none logged'}
  Activities: ${ctx.pet.activitiesToday?.map((a: any) => `${a.activity} ${a.minutes}min`).join(', ') || 'none'}`
      : '- Pet: No pet registered';
    const foodSection = ctx.foodsToday.length > 0
      ? `- Food Today: ${ctx.foodsToday.join(', ')}`
      : '- Food Today: None logged';
    const weekFoodSection = ctx.allFoodsThisWeek.length > 0
      ? `- Food This Week: ${ctx.allFoodsThisWeek.slice(0, 20).join(', ')}`
      : '';
    const reflectionSection = ctx.reflections.length > 0
      ? `- Psychological Reflections:\n${ctx.reflections.map(r => `  • ${r.slice(0, 150)}`).join('\n')}`
      : '';
    const smileSection = `- Smiles Today: ${ctx.smilesToday}`;
    const honestySection = ctx.honestyEntries.length > 0
      ? `- Recent Honesty Entries:\n${ctx.honestyEntries.map(h => `  • To ${h.person}: ${h.feelings}`).join('\n')}`
      : '';
    const weeklySection = `- WEEKLY PATTERNS:
  Avg Sleep: ${ctx.weeklyPatterns.avgSleep}h/night
  Total Exercise: ${ctx.weeklyPatterns.totalExercise}min
  Mood Pattern: ${ctx.weeklyPatterns.moodPattern || 'no data'}
  Gratitude Count: ${ctx.weeklyPatterns.gratitudeCount}`;

    return `You are SoonPsy (سونسي), a PROACTIVE AI companion for mental health and well-being. You are like a caring, empathetic BIG BROTHER/SISTER — warm, supportive, understanding, and always looking out for the user. You STRICTLY focus on mental health support ONLY.

${langInstruction}

YOUR PERSONALITY:
- You are like a wise, loving older sibling who genuinely cares
- You use the user's name when available to create personal connection
- You are empathetic and never judgmental
- You celebrate every small win enthusiastically
- You gently flag concerns without diagnosing
- You speak naturally and warmly, not clinically
- You ALWAYS recommend professional help when needed

STRICT RULES:
1. ONLY answer questions related to psychology, mental health, well-being, and pet-human bond
2. REFUSE unrelated questions politely: "I'm specialized in mental wellness. Let me help you with that instead! 💚"
3. NEVER diagnose medical or psychological conditions
4. ALWAYS reference the user's actual data in responses
5. Be proactive — ask follow-up questions based on patterns you notice

═══════════════════════════════════════
COMPLETE USER DATA (automatically synced):
═══════════════════════════════════════
${nameSection}
- Current Mood: ${ctx.mood || 'Not set'}
- Sleep Today: ${ctx.sleepHours || 0} hours
- Exercise Today: ${ctx.exerciseMinutes || 0} minutes
- Rest/Breaks Today: ${ctx.restMinutes || 0} minutes
- App Usage Streak: ${ctx.appStreak || 0} days (Total: ${ctx.totalDaysUsed || 0} days)
- Clean Living Streak: ${ctx.habitStreak || 0} days ${ctx.habitCheckedToday ? '(checked ✅)' : ''}
${smileSection}
${foodSection}
${weekFoodSection}
${gratitudeSection}
${dreamsSection}
${journalSection}
${petSection}
${reflectionSection}
${honestySection}
${weeklySection}

═══════════════════════════════════════
ANALYSIS FRAMEWORK (MANDATORY for every response):
═══════════════════════════════════════

CORRELATION ANALYSIS — Always look for connections:
• Sleep ↔ Mood ↔ Energy ↔ Focus
• Food Quality ↔ Energy ↔ Mental Clarity
• Exercise ↔ Mood ↔ Sleep Quality
• Pet Wellbeing ↔ Owner's Emotional State
• Gratitude Practice ↔ Resilience ↔ Mood
• Dreams ↔ Subconscious Patterns ↔ Stress
• Journal Content ↔ Emotional Processing
• Honesty Entries ↔ Emotional Release ↔ Relationships
• Smile Challenge ↔ Social Connection ↔ Mood

RESPONSE FORMAT (STRICT):
1. 💡 Data-Based Observation — cite specific numbers from user data
2. 🧠 Behavioral Interpretation — explain the psychological connection
3. ✅ 2-3 Practical Steps — specific, actionable, personalized
4. ❓ Follow-up Question — to deepen understanding

MANDATORY FOOTER: Every response MUST end with this disclaimer IN THE SAME LANGUAGE as the rest of your response:
- English: "⚕️ This is guidance support only. For professional help, please consult a qualified mental health specialist."
- Arabic: "⚕️ هذا دعم توجيهي فقط. للمساعدة المهنية، يرجى استشارة أخصائي صحة نفسية مؤهل."
- Spanish: "⚕️ Esto es solo apoyo orientativo. Para ayuda profesional, consulte a un especialista en salud mental."
- French: "⚕️ Ceci est un soutien d'orientation uniquement. Pour une aide professionnelle, veuillez consulter un spécialiste en santé mentale."

Keep responses 200-400 words, warm, personalized, and data-driven.`;
  };

  const sendMessageText = async (text: string) => {
    if (!text.trim() || isLoading) return;
    const userMessage = text.trim();
    const newMessages: Message[] = [...messages, { role: 'user', content: userMessage }];
    setMessages(newMessages);
    setIsLoading(true);
    try {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
      const response = await fetch(`${supabaseUrl}/functions/v1/groq-chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'apikey': supabaseKey },
        body: JSON.stringify({ messages: newMessages.map(m => ({ role: m.role, content: m.content })), systemPrompt: getSystemPrompt() }),
      });
      if (!response.ok) throw new Error('API error');
      const data = await response.json();
      setMessages([...newMessages, { role: 'assistant', content: data.content || "I'm here to support you. Please try again." }]);
    } catch {
      const fallbackMsg = lang === 'ar' ? "عذراً، حدث خطأ في الاتصال. يرجى المحاولة مرة أخرى. 💚" : "Sorry, a connection error occurred. Please try again. 💚";
      setMessages([...newMessages, { role: 'assistant', content: fallbackMsg }]);
    } finally { setIsLoading(false); }
  };

  const sendMessage = async () => {
    if (!input.trim() || isLoading) return;
    const text = input.trim(); setInput('');
    await sendMessageText(text);
  };

  const clearChat = () => { setMessages([]); setHasGreeted(''); };

  const ctx = getAIContextFromStorage();
  const dataItems = [
    { label: t('data.mood'), value: ctx.mood || t('data.not_specified') },
    { label: t('data.sleep'), value: `${ctx.sleepHours || 0}h` },
    { label: t('data.exercise'), value: `${ctx.exerciseMinutes || 0}m` },
    { label: t('data.rest'), value: `${ctx.restMinutes || 0}m` },
    { label: t('data.gratitude'), value: `${ctx.weeklyGratitudeCount || 0}` },
    { label: t('data.dreams'), value: `${ctx.recentDreams?.length || 0}` },
    { label: t('data.journal'), value: `${ctx.recentJournal?.length || 0}` },
    { label: t('data.clean'), value: `${ctx.habitStreak || 0} ${t('data.days')}` },
    ...(ctx.pet ? [{ label: '🐾', value: ctx.pet.name }] : []),
    { label: '🍽️', value: `${ctx.foodsToday?.length || 0}` },
  ];

  return (
    <div id="soonpsy-chat" ref={chatContainerRef} style={{ background: 'white', borderRadius: '16px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)', marginBottom: '20px', overflow: 'hidden' }}>
      <div style={{ background: 'linear-gradient(to right, #2DCE89, #1a9f6e)', color: 'white', padding: '15px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <div style={{ width: 40, height: 40, background: 'white', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#2DCE89', fontSize: '1.2rem' }}>
            <i className="fas fa-robot"></i>
          </div>
          <h3 style={{ margin: 0, fontSize: '1rem', fontWeight: 600 }}>{t('ai.title')}</h3>
        </div>
        {messages.length > 0 && (
          <button onClick={clearChat} style={{ background: 'rgba(255,255,255,0.2)', border: 'none', color: 'white', borderRadius: '50%', width: 30, height: 30, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.8rem' }}>
            <i className="fas fa-trash"></i>
          </button>
        )}
      </div>

      <div ref={responseRef} style={{ padding: '20px', minHeight: '100px', lineHeight: 1.6, borderBottom: '1px solid #eee', maxHeight: '300px', overflowY: 'auto' }}>
        <div style={{ background: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: '10px', padding: '10px 14px', marginBottom: '12px', fontSize: '0.8rem', color: '#166534' }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: '8px', marginBottom: '8px' }}>
            <span style={{ fontSize: '1rem', flexShrink: 0 }}>🔒</span>
            <span><strong>{t('ai.data_notice')}</strong> {t('ai.data_notice_desc')}</span>
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginTop: '6px' }}>
            {dataItems.map(item => (
              <span key={item.label} style={{ background: '#dcfce7', padding: '2px 8px', borderRadius: '12px', fontSize: '0.7rem', color: '#15803d', fontWeight: 500 }}>
                {item.label}: <strong>{item.value}</strong>
              </span>
            ))}
          </div>
        </div>

        {messages.length === 0 && !isLoading && <p style={{ color: '#8898aa', fontStyle: 'italic' }}>{t('ai.empty')}</p>}
        {messages.map((msg, idx) => (
          <div key={idx} style={{ background: msg.role === 'user' ? '#e8f5e9' : '#f8f9fa', borderRadius: '12px', padding: '12px 15px', margin: '10px 0', borderLeft: `4px solid ${msg.role === 'user' ? '#4caf50' : '#2DCE89'}`, fontSize: '0.9rem', whiteSpace: 'pre-wrap' }}>
            {msg.content}
          </div>
        ))}
        {isLoading && (
          <div style={{ display: 'flex', padding: '10px 0', gap: '6px' }}>
            {[0, 200, 400].map((delay, i) => (
              <div key={i} style={{ width: 8, height: 8, background: '#8898aa', borderRadius: '50%', animation: `typing 1.4s infinite ${delay}ms` }}></div>
            ))}
          </div>
        )}
      </div>

      <div style={{ display: 'flex', padding: '15px', background: '#f7fafc', gap: '10px' }}>
        <input type="text" value={input} onChange={e => setInput(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
          placeholder={t('ai.placeholder')}
          style={{ flexGrow: 1, padding: '12px 15px', border: '1px solid #ddd', borderRadius: '25px', fontFamily: 'Poppins, sans-serif', fontSize: '1rem', outline: 'none', transition: 'all 0.3s ease' }}
          onFocus={e => e.target.style.borderColor = '#2DCE89'}
          onBlur={e => e.target.style.borderColor = '#ddd'}
        />
        <button onClick={sendMessage} disabled={isLoading || !input.trim()}
          style={{ background: '#2DCE89', color: 'white', borderRadius: '50%', width: 45, height: 45, display: 'flex', alignItems: 'center', justifyContent: 'center', border: 'none', cursor: 'pointer', transition: 'all 0.3s ease', flexShrink: 0 }}>
          <i className="fas fa-paper-plane"></i>
        </button>
      </div>
    </div>
  );
}
