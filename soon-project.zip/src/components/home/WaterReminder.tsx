import { useState, useEffect, useCallback } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';

type AgeGroup = 'child' | 'teen' | 'adult' | 'elder';

interface WaterLog {
  time: string;
  amount: number; // ml
}

interface WaterDay {
  date: string;
  logs: WaterLog[];
  goal: number;
}

const ageData: Record<AgeGroup, { labelAr: string; labelEn: string; mlPerDay: number; icon: string }> = {
  child: { labelAr: 'طفل (4-8 سنوات)', labelEn: 'Child (4-8 years)', mlPerDay: 1200, icon: '👶' },
  teen: { labelAr: 'مراهق (9-18 سنة)', labelEn: 'Teen (9-18 years)', mlPerDay: 2000, icon: '🧑' },
  adult: { labelAr: 'بالغ (19-60 سنة)', labelEn: 'Adult (19-60 years)', mlPerDay: 2500, icon: '🧔' },
  elder: { labelAr: 'كبير السن (60+)', labelEn: 'Elder (60+)', mlPerDay: 2000, icon: '👴' },
};

const cupSizes = [150, 250, 330, 500];

export default function WaterReminder() {
  const { lang } = useLanguage();
  const isAr = lang === 'ar';
  const [ageGroup, setAgeGroup] = useLocalStorage<AgeGroup>('soon-water-age', 'adult');
  const [waterDays, setWaterDays] = useLocalStorage<WaterDay[]>('soon-water-days', []);
  const [reminderInterval, setReminderInterval] = useLocalStorage<number>('soon-water-reminder-hrs', 2);
  const [reminderEnabled, setReminderEnabled] = useLocalStorage<boolean>('soon-water-reminder-on', false);
  const [showHistory, setShowHistory] = useState(false);

  const today = new Date().toDateString();
  const goal = ageData[ageGroup].mlPerDay;
  const todayEntry = waterDays.find(d => d.date === today);
  const totalToday = todayEntry?.logs.reduce((s, l) => s + l.amount, 0) || 0;
  const percentage = Math.min(100, Math.round((totalToday / goal) * 100));

  const drinkWater = (ml: number) => {
    const log: WaterLog = { time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), amount: ml };
    if (todayEntry) {
      setWaterDays(waterDays.map(d => d.date === today ? { ...d, logs: [...d.logs, log] } : d));
    } else {
      setWaterDays([...waterDays, { date: today, logs: [log], goal }]);
    }
  };

  // Water reminder notification
  useEffect(() => {
    if (!reminderEnabled || !('Notification' in window) || Notification.permission !== 'granted') return;
    const ms = reminderInterval * 60 * 60 * 1000;
    const interval = setInterval(() => {
      new Notification(isAr ? '💧 وقت شرب الماء!' : '💧 Time to drink water!', {
        body: isAr ? `هدفك اليوم: ${goal}مل — شربت حتى الآن: ${totalToday}مل` : `Goal: ${goal}ml — So far: ${totalToday}ml`,
        icon: '/icon.png',
      });
    }, ms);
    return () => clearInterval(interval);
  }, [reminderEnabled, reminderInterval, goal, totalToday, isAr]);

  const enableReminder = useCallback(async () => {
    if ('Notification' in window && Notification.permission === 'default') {
      await Notification.requestPermission();
    }
    setReminderEnabled(!reminderEnabled);
  }, [reminderEnabled, setReminderEnabled]);

  const sorted = [...waterDays].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  // Streak
  let streak = 0;
  for (const d of sorted) {
    const t = d.logs.reduce((s, l) => s + l.amount, 0);
    if (t >= d.goal * 0.8) streak++; else break;
  }

  return (
    <div style={{ background: 'linear-gradient(135deg, #eff6ff, #dbeafe)', borderRadius: '18px', padding: '18px', marginBottom: '20px', boxShadow: '0 4px 15px rgba(59,130,246,0.1)', border: '1px solid #bfdbfe' }}>
      <h4 style={{ color: '#1d4ed8', textAlign: 'center', marginBottom: '12px', fontSize: '1.05rem' }}>
        💧 {isAr ? 'تذكير شرب الماء' : 'Water Reminder'}
      </h4>

      {/* Age Group Selector */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '6px', marginBottom: '14px' }}>
        {(Object.keys(ageData) as AgeGroup[]).map(ag => (
          <button key={ag} onClick={() => setAgeGroup(ag)} style={{
            background: ageGroup === ag ? '#1d4ed8' : 'white',
            color: ageGroup === ag ? 'white' : '#1d4ed8',
            border: `2px solid ${ageGroup === ag ? '#1d4ed8' : '#bfdbfe'}`,
            borderRadius: '12px', padding: '8px 6px', fontWeight: 600, cursor: 'pointer',
            fontSize: '0.75rem', fontFamily: 'Poppins', transition: 'all 0.2s',
          }}>
            {ageData[ag].icon} {isAr ? ageData[ag].labelAr : ageData[ag].labelEn}
          </button>
        ))}
      </div>

      {/* Goal & Progress */}
      <div style={{ textAlign: 'center', marginBottom: '14px' }}>
        <p style={{ color: '#6b7280', fontSize: '0.8rem', margin: '0 0 8px' }}>
          {isAr ? `الموصى به: ${goal} مل/يوم` : `Recommended: ${goal} ml/day`}
        </p>
        {/* Progress bar */}
        <div style={{ background: '#e0e7ff', borderRadius: '20px', height: '24px', overflow: 'hidden', position: 'relative', marginBottom: '6px' }}>
          <div style={{
            background: percentage >= 100 ? 'linear-gradient(90deg, #16a34a, #22c55e)' : 'linear-gradient(90deg, #3b82f6, #60a5fa)',
            height: '100%', width: `${percentage}%`, borderRadius: '20px', transition: 'width 0.5s ease',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <span style={{ color: 'white', fontWeight: 700, fontSize: '0.75rem' }}>
              {percentage >= 10 ? `${percentage}%` : ''}
            </span>
          </div>
        </div>
        <p style={{ color: '#1d4ed8', fontWeight: 700, fontSize: '0.9rem', margin: 0 }}>
          {totalToday} / {goal} {isAr ? 'مل' : 'ml'}
        </p>
      </div>

      {/* Cup buttons */}
      <div style={{ display: 'flex', gap: '8px', justifyContent: 'center', marginBottom: '14px', flexWrap: 'wrap' }}>
        {cupSizes.map(ml => (
          <button key={ml} onClick={() => drinkWater(ml)} style={{
            background: 'white', color: '#1d4ed8', border: '2px solid #93c5fd',
            borderRadius: '14px', padding: '10px 14px', fontWeight: 700, cursor: 'pointer',
            fontSize: '0.82rem', fontFamily: 'Poppins', transition: 'all 0.2s',
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '2px',
          }}>
            <span style={{ fontSize: '1.2rem' }}>🥤</span>
            {ml}{isAr ? 'مل' : 'ml'}
          </button>
        ))}
      </div>

      {/* Today's log */}
      {todayEntry && todayEntry.logs.length > 0 && (
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px', marginBottom: '10px', justifyContent: 'center' }}>
          {todayEntry.logs.map((l, i) => (
            <span key={i} style={{ background: '#dbeafe', color: '#1d4ed8', padding: '2px 8px', borderRadius: '12px', fontSize: '0.7rem', fontWeight: 500 }}>
              💧 {l.amount}{isAr ? 'مل' : 'ml'} - {l.time}
            </span>
          ))}
        </div>
      )}

      {percentage >= 100 && (
        <div style={{ textAlign: 'center', background: '#dcfce7', borderRadius: '12px', padding: '10px', marginBottom: '10px', color: '#166534', fontWeight: 700, fontSize: '0.9rem' }}>
          🎉 {isAr ? 'أحسنت! أكملت هدفك اليوم!' : 'Great! You reached your goal today!'}
        </div>
      )}

      {streak > 1 && (
        <div style={{ textAlign: 'center', color: '#1d4ed8', fontWeight: 700, fontSize: '0.85rem', marginBottom: '10px' }}>
          🔥 {streak} {isAr ? 'يوم متتالي!' : 'day streak!'}
        </div>
      )}

      {/* Reminder toggle */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'white', borderRadius: '12px', padding: '10px 14px', marginBottom: '10px' }}>
        <div>
          <span style={{ fontSize: '0.82rem', fontWeight: 600, color: '#1d4ed8' }}>
            🔔 {isAr ? 'تذكير كل' : 'Remind every'}
          </span>
          <div style={{ display: 'flex', gap: '6px', marginTop: '4px' }}>
            {[1, 2, 3].map(h => (
              <button key={h} onClick={() => setReminderInterval(h)} style={{
                background: reminderInterval === h ? '#1d4ed8' : '#eff6ff',
                color: reminderInterval === h ? 'white' : '#1d4ed8',
                border: 'none', borderRadius: '8px', padding: '3px 10px', fontWeight: 600,
                fontSize: '0.75rem', cursor: 'pointer',
              }}>
                {h}{isAr ? ' ساعة' : 'h'}
              </button>
            ))}
          </div>
        </div>
        <button onClick={enableReminder} style={{
          background: reminderEnabled ? '#1d4ed8' : '#e0e7ff',
          color: reminderEnabled ? 'white' : '#1d4ed8',
          border: 'none', borderRadius: '20px', padding: '8px 16px', fontWeight: 700,
          cursor: 'pointer', fontSize: '0.8rem', transition: 'all 0.2s',
        }}>
          {reminderEnabled ? (isAr ? 'مُفعّل ✅' : 'ON ✅') : (isAr ? 'تفعيل' : 'Enable')}
        </button>
      </div>

      {/* History */}
      {waterDays.length > 0 && (
        <button onClick={() => setShowHistory(!showHistory)} style={{
          background: 'none', border: '1px solid #3b82f6', color: '#3b82f6', borderRadius: '20px',
          padding: '8px 16px', fontWeight: 600, cursor: 'pointer', width: '100%', fontSize: '0.8rem',
        }}>
          <i className={`fas fa-${showHistory ? 'chevron-up' : 'history'}`} style={{ marginRight: '6px' }}></i>
          {showHistory ? (isAr ? 'إخفاء' : 'Hide') : (isAr ? 'سجل الماء' : 'Water History')}
        </button>
      )}
      {showHistory && (
        <div style={{ marginTop: '10px', maxHeight: '200px', overflowY: 'auto' }}>
          {sorted.slice(0, 14).map((d, i) => {
            const t = d.logs.reduce((s, l) => s + l.amount, 0);
            const pct = Math.min(100, Math.round((t / d.goal) * 100));
            return (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px', fontSize: '0.78rem' }}>
                <span style={{ color: '#6b7280', width: '80px', flexShrink: 0 }}>{new Date(d.date).toLocaleDateString(isAr ? 'ar' : 'en')}</span>
                <div style={{ flex: 1, background: '#e0e7ff', borderRadius: '10px', height: '14px', overflow: 'hidden' }}>
                  <div style={{ background: pct >= 80 ? '#22c55e' : '#3b82f6', height: '100%', width: `${pct}%`, borderRadius: '10px' }}></div>
                </div>
                <span style={{ color: '#1d4ed8', fontWeight: 600, width: '50px', textAlign: 'right' }}>{t}{isAr ? 'مل' : 'ml'}</span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
