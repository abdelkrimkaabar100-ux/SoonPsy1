import { useState, useEffect } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';

interface ScrollIndicatorProps {
  showSoonPsyArrow?: boolean;
}

export default function ScrollIndicator({ showSoonPsyArrow }: ScrollIndicatorProps) {
  const { lang } = useLanguage();
  const [visible, setVisible] = useState(true);
  const [isNewUser] = useState(() => {
    try {
      const visited = localStorage.getItem('soon-visited');
      if (!visited) { localStorage.setItem('soon-visited', 'true'); return true; }
      return false;
    } catch { return false; }
  });

  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY || document.documentElement.scrollTop;
      setVisible(scrollY < 200);
    };
    window.addEventListener('scroll', handleScroll, true);
    const main = document.querySelector('.soon-main');
    if (main) main.addEventListener('scroll', () => {
      setVisible(main.scrollTop < 200);
    });
    return () => window.removeEventListener('scroll', handleScroll, true);
  }, []);

  const scrollToSoonPsy = () => {
    const el = document.getElementById('soonpsy-chat');
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <>
      {/* SoonPsy notification bell */}
      {showSoonPsyArrow && (
        <div onClick={scrollToSoonPsy} style={{
          textAlign: 'center', padding: '12px', cursor: 'pointer',
          background: 'linear-gradient(135deg, #fee2e2, #fecaca)', borderRadius: '16px',
          marginBottom: '12px', animation: 'pulseBeat 2s infinite',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }}>
            <i className="fas fa-bell" style={{ color: '#ef4444', fontSize: '1.2rem', animation: 'bellRing 1s infinite' }}></i>
            <span style={{ color: '#ef4444', fontSize: '0.9rem', fontWeight: 700 }}>
              {lang === 'ar' ? 'SoonPsy أرسل لك رسالة! اضغط هنا' : 'SoonPsy sent you a message! Tap here'}
            </span>
            <i className="fas fa-arrow-up" style={{ color: '#ef4444', fontSize: '1rem', animation: 'bounceArrow 1.5s infinite' }}></i>
          </div>
        </div>
      )}

      {/* Scroll down indicator */}
      {visible && (
        <div style={{
          textAlign: 'center', padding: '15px 0', animation: 'bounce 2s infinite',
        }}>
          <div style={{ color: '#2DCE89', fontSize: '0.8rem', fontWeight: 600, marginBottom: '5px' }}>
            {lang === 'ar' ? 'اكتشف المزيد من الميزات ↓' : lang === 'es' ? 'Descubre más funciones ↓' : lang === 'fr' ? 'Découvrez plus de fonctionnalités ↓' : 'Discover more features ↓'}
          </div>
          <div style={{ fontSize: '1.5rem', color: '#2DCE89' }}>
            <i className="fas fa-chevron-down" style={{ animation: 'bounceArrow 1.5s infinite' }}></i>
          </div>
          {isNewUser && (
            <div style={{ 
              background: 'linear-gradient(135deg, #2DCE89, #1a9f6e)', color: 'white', 
              borderRadius: '20px', padding: '10px 16px', margin: '10px auto', maxWidth: '280px',
              fontSize: '0.8rem', fontWeight: 600, animation: 'pulseBeat 2s infinite',
            }}>
              {lang === 'ar' ? '👋 مرحباً! مرر للأسفل لاكتشاف كل خصائص Soon' : '👋 Welcome! Scroll down to discover all Soon features'}
            </div>
          )}
        </div>
      )}
      <style>{`
        @keyframes bounceArrow {
          0%, 100% { transform: translateY(0); opacity: 1; }
          50% { transform: translateY(8px); opacity: 0.6; }
        }
        @keyframes bellRing {
          0%, 100% { transform: rotate(0deg); }
          25% { transform: rotate(15deg); }
          75% { transform: rotate(-15deg); }
        }
      `}</style>
    </>
  );
}
