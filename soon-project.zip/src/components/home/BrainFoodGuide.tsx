import { useState } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';

interface MealPlan { time: string; meal: string; forWhom: 'human' | 'pet' | 'both'; date: string; done: boolean; }

export default function BrainFoodGuide() {
  const { lang } = useLanguage();
  const isAr = lang === 'ar';
  const [mealPlans, setMealPlans] = useLocalStorage<MealPlan[]>('soon-meal-plans', []);
  const [showAll, setShowAll] = useState(false);

  const today = new Date().toDateString();
  const todayPlans = mealPlans.filter(m => new Date(m.date).toDateString() === today);

  const addMeal = (forWhom: 'human' | 'pet' | 'both') => {
    const time = prompt(isAr ? 'الوقت (مثل: 08:00)' : 'Time (e.g., 08:00)');
    const meal = prompt(isAr ? 'الوجبة' : 'Meal description');
    if (!time || !meal) return;
    setMealPlans([...mealPlans, { time, meal, forWhom, date: new Date().toISOString(), done: false }]);
  };

  const toggleDone = (idx: number) => {
    const todayIdxs = mealPlans.map((m, i) => ({ ...m, origIdx: i })).filter(m => new Date(m.date).toDateString() === today);
    if (todayIdxs[idx]) {
      setMealPlans(mealPlans.map((m, i) => i === todayIdxs[idx].origIdx ? { ...m, done: !m.done } : m));
    }
  };

  const brainFoods = isAr ? [
    { icon: '🐟', name: 'سمك دهني (سلمون، سردين)', benefit: 'أوميغا 3 — يبني أغشية خلايا الدماغ ويحسن الذاكرة' },
    { icon: '🫐', name: 'توت أزرق', benefit: 'مضادات أكسدة تحمي الدماغ من الشيخوخة والالتهاب' },
    { icon: '🥜', name: 'مكسرات (جوز، لوز)', benefit: 'فيتامين E وأوميغا 3 — يحمي من التدهور المعرفي' },
    { icon: '🥑', name: 'أفوكادو', benefit: 'دهون صحية تعزز تدفق الدم للدماغ' },
    { icon: '🥚', name: 'بيض', benefit: 'كولين — ضروري لإنتاج الناقلات العصبية' },
    { icon: '🥦', name: 'بروكلي', benefit: 'فيتامين K ومضادات التهاب للدماغ' },
    { icon: '🍫', name: 'شوكولاتة داكنة (70%+)', benefit: 'فلافونويد يحسن تدفق الدم والمزاج' },
    { icon: '🍵', name: 'شاي أخضر', benefit: 'L-theanine يعزز التركيز والهدوء معاً' },
    { icon: '🫒', name: 'زيت زيتون بكر', benefit: 'يحمي من الزهايمر ويقلل الالتهاب' },
    { icon: '🍠', name: 'بطاطا حلوة', benefit: 'بيتا كاروتين — مضاد أكسدة قوي للدماغ' },
    { icon: '🌿', name: 'كركم', benefit: 'كركومين يعبر حاجز الدم-الدماغ ويقلل الالتهاب' },
    { icon: '🍊', name: 'برتقال وحمضيات', benefit: 'فيتامين C يمنع التدهور العقلي' },
  ] : [
    { icon: '🐟', name: 'Fatty Fish (salmon, sardines)', benefit: 'Omega-3 — builds brain cell membranes, improves memory' },
    { icon: '🫐', name: 'Blueberries', benefit: 'Antioxidants protect brain from aging and inflammation' },
    { icon: '🥜', name: 'Nuts (walnuts, almonds)', benefit: 'Vitamin E and omega-3 — protects against cognitive decline' },
    { icon: '🥑', name: 'Avocado', benefit: 'Healthy fats enhance blood flow to the brain' },
    { icon: '🥚', name: 'Eggs', benefit: 'Choline — essential for neurotransmitter production' },
    { icon: '🥦', name: 'Broccoli', benefit: 'Vitamin K and anti-inflammatory compounds for brain' },
    { icon: '🍫', name: 'Dark Chocolate (70%+)', benefit: 'Flavonoids improve blood flow and mood' },
    { icon: '🍵', name: 'Green Tea', benefit: 'L-theanine boosts focus and calmness together' },
    { icon: '🫒', name: 'Extra Virgin Olive Oil', benefit: 'Protects from Alzheimer\'s, reduces inflammation' },
    { icon: '🍠', name: 'Sweet Potato', benefit: 'Beta-carotene — powerful brain antioxidant' },
    { icon: '🌿', name: 'Turmeric', benefit: 'Curcumin crosses blood-brain barrier, reduces inflammation' },
    { icon: '🍊', name: 'Oranges & Citrus', benefit: 'Vitamin C prevents mental decline' },
  ];

  const displayFoods = showAll ? brainFoods : brainFoods.slice(0, 6);

  return (
    <div>
      {/* ===== BRAIN FOOD GUIDE ===== */}
      <div style={{ background: 'linear-gradient(135deg, #fdf2f8, #fce7f3)', borderRadius: '18px', padding: '18px', marginBottom: '15px', boxShadow: '0 4px 15px rgba(236,72,153,0.1)', border: '1px solid #fbcfe8' }}>
        <h4 style={{ color: '#be185d', textAlign: 'center', marginBottom: '4px', fontSize: '1.05rem' }}>
          🧠 {isAr ? 'أطعمة لصحة الدماغ' : 'Brain-Healthy Foods'}
        </h4>
        <p style={{ color: '#9d174d', fontSize: '0.78rem', textAlign: 'center', marginBottom: '14px' }}>
          {isAr ? 'أطعمة يوصي بها أطباء الأعصاب لتحسين الذاكرة والتركيز والمزاج' : 'Neurologist-recommended foods for memory, focus & mood'}
        </p>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
          {displayFoods.map((f, i) => (
            <div key={i} style={{ background: 'rgba(255,255,255,0.7)', borderRadius: '14px', padding: '10px', borderLeft: '4px solid #ec4899' }}>
              <div style={{ fontSize: '1.3rem', marginBottom: '2px' }}>{f.icon}</div>
              <div style={{ fontSize: '0.78rem', fontWeight: 700, color: '#be185d', marginBottom: '2px' }}>{f.name}</div>
              <div style={{ fontSize: '0.68rem', color: '#6b7280', lineHeight: 1.4 }}>{f.benefit}</div>
            </div>
          ))}
        </div>

        {brainFoods.length > 6 && (
          <button onClick={() => setShowAll(!showAll)} style={{
            background: 'none', border: '1px solid #ec4899', color: '#ec4899', borderRadius: '20px',
            padding: '6px 16px', fontWeight: 600, cursor: 'pointer', width: '100%', fontSize: '0.78rem', marginTop: '10px',
          }}>
            {showAll ? (isAr ? 'عرض أقل ▲' : 'Show Less ▲') : (isAr ? 'عرض الكل ▼' : 'Show All ▼')}
          </button>
        )}
      </div>

      {/* ===== MEAL SCHEDULE ===== */}
      <div style={{ background: 'white', borderRadius: '18px', padding: '18px', marginBottom: '15px', boxShadow: '0 4px 15px rgba(0,0,0,0.06)' }}>
        <h4 style={{ color: '#32325d', textAlign: 'center', marginBottom: '12px', fontSize: '1rem' }}>
          📅 {isAr ? 'جدول وجبات اليوم (أنت + حيوانك)' : "Today's Meal Schedule (You + Pet)"}
        </h4>

        <div style={{ display: 'flex', gap: '6px', marginBottom: '12px' }}>
          <button onClick={() => addMeal('human')} style={{
            flex: 1, background: '#ec4899', color: 'white', border: 'none', borderRadius: '12px',
            padding: '10px', fontWeight: 600, cursor: 'pointer', fontSize: '0.78rem',
          }}>
            🧑 {isAr ? 'وجبتي' : 'My Meal'}
          </button>
          <button onClick={() => addMeal('pet')} style={{
            flex: 1, background: '#f59e0b', color: 'white', border: 'none', borderRadius: '12px',
            padding: '10px', fontWeight: 600, cursor: 'pointer', fontSize: '0.78rem',
          }}>
            🐾 {isAr ? 'وجبة حيواني' : 'Pet Meal'}
          </button>
          <button onClick={() => addMeal('both')} style={{
            flex: 1, background: '#6366f1', color: 'white', border: 'none', borderRadius: '12px',
            padding: '10px', fontWeight: 600, cursor: 'pointer', fontSize: '0.78rem',
          }}>
            👫 {isAr ? 'كلانا' : 'Both'}
          </button>
        </div>

        {todayPlans.length === 0 ? (
          <p style={{ textAlign: 'center', color: '#9ca3af', fontSize: '0.82rem' }}>
            {isAr ? 'لم تضف وجبات لليوم بعد' : 'No meals scheduled for today'}
          </p>
        ) : (
          <div>
            {todayPlans.sort((a, b) => a.time.localeCompare(b.time)).map((m, i) => (
              <div key={i} onClick={() => toggleDone(i)} style={{
                display: 'flex', alignItems: 'center', gap: '10px', padding: '10px 12px',
                background: m.done ? '#f0fdf4' : '#f9fafb', borderRadius: '12px', marginBottom: '6px',
                cursor: 'pointer', border: m.done ? '1px solid #bbf7d0' : '1px solid #e5e7eb',
                opacity: m.done ? 0.7 : 1, transition: 'all 0.2s',
              }}>
                <span style={{ fontSize: '1.1rem' }}>
                  {m.forWhom === 'human' ? '🧑' : m.forWhom === 'pet' ? '🐾' : '👫'}
                </span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: '0.82rem', fontWeight: 600, color: '#32325d', textDecoration: m.done ? 'line-through' : 'none' }}>
                    {m.meal}
                  </div>
                  <div style={{ fontSize: '0.7rem', color: '#9ca3af' }}>⏰ {m.time}</div>
                </div>
                <span style={{ fontSize: '1.1rem' }}>{m.done ? '✅' : '⬜'}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
