import { useState, useEffect } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import type { Page } from '../layout/AppContainer';

interface DailySuggestionProps {
  onNavigate: (page: Page) => void;
}

const suggestions: { page: Page; icon: string; en: string; ar: string; es: string; fr: string }[] = [
  { page: 'journal', icon: '📝', en: 'Write in your journal today', ar: 'اكتب في يومياتك اليوم', es: 'Escribe en tu diario hoy', fr: 'Écrivez dans votre journal' },
  { page: 'meditation', icon: '🧘', en: 'Try a meditation session', ar: 'جرّب جلسة تأمل', es: 'Prueba una sesión de meditación', fr: 'Essayez une méditation' },
  { page: 'gratitude-thanks', icon: '🙏', en: 'Express gratitude to someone', ar: 'عبّر عن امتنانك لشخص ما', es: 'Expresa gratitud a alguien', fr: 'Exprimez de la gratitude' },
  { page: 'smile-challenge', icon: '😊', en: 'Take the smile challenge', ar: 'قم بتحدي الابتسامة', es: 'Acepta el reto de la sonrisa', fr: 'Relevez le défi du sourire' },
  { page: 'walk', icon: '🚶', en: 'Go for a mindful walk', ar: 'اذهب لمشي واعٍ', es: 'Da un paseo consciente', fr: 'Faites une marche consciente' },
  { page: 'honesty', icon: '💭', en: 'Express your feelings honestly', ar: 'عبّر عن مشاعرك بصراحة', es: 'Expresa tus sentimientos', fr: 'Exprimez vos sentiments' },
  { page: 'love-page', icon: '💝', en: 'Send love to someone special', ar: 'أرسل حباً لشخص مميز', es: 'Envía amor a alguien especial', fr: 'Envoyez de l\'amour' },
  { page: 'dreams', icon: '🌙', en: 'Log your dreams', ar: 'سجّل أحلامك', es: 'Registra tus sueños', fr: 'Notez vos rêves' },
  { page: 'goals', icon: '🎯', en: 'Review your goals', ar: 'راجع أهدافك', es: 'Revisa tus metas', fr: 'Révisez vos objectifs' },
  { page: 'family', icon: '👨‍👩‍👧‍👦', en: 'Connect with family', ar: 'تواصل مع عائلتك', es: 'Conecta con tu familia', fr: 'Connectez-vous avec la famille' },
  { page: 'attention-games', icon: '🧠', en: 'Train your brain', ar: 'درّب عقلك', es: 'Entrena tu cerebro', fr: 'Entraînez votre cerveau' },
  { page: 'earth-care', icon: '🌍', en: 'Do something for the planet', ar: 'افعل شيئاً لكوكبنا', es: 'Haz algo por el planeta', fr: 'Agissez pour la planète' },
  { page: 'hobbies', icon: '🎨', en: 'Spend time on a hobby', ar: 'اقضِ وقتاً في هوايتك', es: 'Dedica tiempo a un hobby', fr: 'Consacrez du temps à un hobby' },
  { page: 'spirituality', icon: '🤲', en: 'Practice spirituality', ar: 'مارس الروحانية', es: 'Practica la espiritualidad', fr: 'Pratiquez la spiritualité' },
  { page: 'kind-words', icon: '✨', en: 'Write kind words', ar: 'اكتب كلمات طيبة', es: 'Escribe palabras amables', fr: 'Écrivez des mots gentils' },
  { page: 'decision-ai', icon: '🤔', en: 'Get help with a decision', ar: 'احصل على مساعدة في قرار', es: 'Obtén ayuda con una decisión', fr: 'Obtenez de l\'aide pour une décision' },
  { page: 'crying', icon: '😢', en: 'Release stress through crying', ar: 'حرر توترك من خلال البكاء', es: 'Libera estrés llorando', fr: 'Libérez le stress par les larmes' },
  { page: 'what-not-to-do', icon: '🚫', en: 'Check what you should avoid', ar: 'تحقق مما يجب تجنبه', es: 'Revisa qué evitar', fr: 'Vérifiez ce qu\'il faut éviter' },
  { page: 'future-self', icon: '🔮', en: 'Write to your future self', ar: 'اكتب لنفسك المستقبلية', es: 'Escribe a tu yo futuro', fr: 'Écrivez à votre moi futur' },
];

export default function DailySuggestion({ onNavigate }: DailySuggestionProps) {
  const { lang } = useLanguage();
  const [dismissed, setDismissed] = useState(false);

  const today = new Date();
  const dayOfYear = Math.floor((today.getTime() - new Date(today.getFullYear(), 0, 0).getTime()) / 86400000);
  const suggestion = suggestions[dayOfYear % suggestions.length];

  const todayKey = `soon-daily-suggestion-${today.toDateString()}`;
  useEffect(() => {
    const d = localStorage.getItem(todayKey);
    if (d === 'dismissed') setDismissed(true);
  }, [todayKey]);

  if (dismissed) return null;

  const dismiss = (e: React.MouseEvent) => {
    e.stopPropagation();
    setDismissed(true);
    localStorage.setItem(todayKey, 'dismissed');
  };

  const titleLabel = { en: "Today's suggestion", ar: 'اقتراح اليوم', es: 'Sugerencia de hoy', fr: 'Suggestion du jour' };
  const tryLabel = { en: 'Try it →', ar: '← جرّبها', es: 'Pruébalo →', fr: 'Essayez →' };

  return (
    <div onClick={() => onNavigate(suggestion.page)} style={{
      background: 'linear-gradient(135deg, #2DCE89, #1a9f6e)', borderRadius: '16px', padding: '15px 18px',
      marginBottom: '15px', cursor: 'pointer', color: 'white', position: 'relative',
      boxShadow: '0 6px 20px rgba(45,206,137,0.3)', display: 'flex', alignItems: 'center', gap: '12px',
    }}>
      <div style={{ fontSize: '2rem', flexShrink: 0 }}>{suggestion.icon}</div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: '0.7rem', opacity: 0.8, fontWeight: 600, textTransform: 'uppercase', marginBottom: '2px' }}>
          💡 {titleLabel[lang] || titleLabel.en}
        </div>
        <div style={{ fontSize: '0.9rem', fontWeight: 600 }}>{suggestion[lang] || suggestion.en}</div>
        <div style={{ fontSize: '0.75rem', opacity: 0.8, marginTop: '2px' }}>{tryLabel[lang] || tryLabel.en}</div>
      </div>
      <button onClick={dismiss} style={{ position: 'absolute', top: '8px', right: '8px', background: 'rgba(255,255,255,0.2)', border: 'none', color: 'white', borderRadius: '50%', width: 22, height: 22, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', fontSize: '0.7rem' }}>✕</button>
    </div>
  );
}
