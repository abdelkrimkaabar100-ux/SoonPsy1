import { useState } from 'react';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { useLanguage } from '../../i18n/LanguageContext';

interface AffirmationsData {
  aff1: boolean;
  aff2: boolean;
  aff3: boolean;
  custom: { text: string; done: boolean }[];
  lastReset: string;
}

export default function IdentityAffirmations() {
  const { t } = useLanguage();
  const [newAff, setNewAff] = useState('');
  const [data, setData] = useLocalStorage<AffirmationsData>('soon-affirmations', {
    aff1: false, aff2: false, aff3: false, custom: [], lastReset: '',
  });

  const today = new Date().toDateString();
  const currentData: AffirmationsData = data.lastReset !== today
    ? { ...data, aff1: false, aff2: false, aff3: false, custom: (data.custom || []).map(c => ({ ...c, done: false })), lastReset: today }
    : { ...data, custom: data.custom || [] };

  const toggle = (key: 'aff1' | 'aff2' | 'aff3') => {
    setData({ ...currentData, [key]: !currentData[key] });
  };

  const toggleCustom = (index: number) => {
    const updated = [...currentData.custom];
    updated[index] = { ...updated[index], done: !updated[index].done };
    setData({ ...currentData, custom: updated });
  };

  const addCustom = () => {
    if (!newAff.trim()) return;
    setData({ ...currentData, custom: [...currentData.custom, { text: newAff.trim(), done: false }] });
    setNewAff('');
  };

  const removeCustom = (index: number) => {
    const updated = currentData.custom.filter((_, i) => i !== index);
    setData({ ...currentData, custom: updated });
  };

  const allComplete = currentData.aff1 && currentData.aff2 && currentData.aff3 && currentData.custom.every(c => c.done);

  const affirmations: { key: 'aff1' | 'aff2' | 'aff3'; textKey: string }[] = [
    { key: 'aff1', textKey: 'identity.aff1' },
    { key: 'aff2', textKey: 'identity.aff2' },
    { key: 'aff3', textKey: 'identity.aff3' },
  ];

  return (
    <div style={{
      background: 'white', borderRadius: '16px', padding: '25px 20px', marginBottom: '20px',
      boxShadow: '0 6px 20px rgba(0,0,0,0.08)',
    }}>
      <h4 style={{ color: '#1a9f6e', marginBottom: '10px', fontSize: '1.1rem' }}>
        <i className="fas fa-brain" style={{ marginRight: '8px' }}></i>
        {t('identity.title')}
      </h4>
      <p style={{ fontSize: '0.85rem', color: '#8898aa', marginBottom: '15px' }}>{t('identity.desc')}</p>

      {affirmations.map(aff => (
        <div key={aff.key} onClick={() => toggle(aff.key)} style={{
          display: 'flex', alignItems: 'flex-start', padding: '15px', marginBottom: '12px',
          background: currentData[aff.key] ? '#e8f5e9' : '#f7fafc',
          borderRadius: '12px', cursor: 'pointer', transition: 'all 0.3s ease',
          borderLeft: currentData[aff.key] ? '4px solid #2DCE89' : '4px solid transparent',
        }}>
          <div style={{
            width: 24, height: 24, border: `2px solid ${currentData[aff.key] ? '#2DCE89' : '#ddd'}`,
            borderRadius: '6px', marginRight: '15px',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            flexShrink: 0, marginTop: '2px',
            background: currentData[aff.key] ? '#2DCE89' : 'white', color: 'white', transition: 'all 0.3s ease',
          }}>
            {currentData[aff.key] && <i className="fas fa-check" style={{ fontSize: '0.8rem' }}></i>}
          </div>
          <div style={{
            fontSize: '0.95rem', lineHeight: 1.5, color: '#32325d',
            textDecoration: currentData[aff.key] ? 'line-through' : 'none', transition: 'all 0.3s ease',
          }}>
            {t(aff.textKey)}
          </div>
        </div>
      ))}

      {/* Custom affirmations */}
      {currentData.custom.map((c, i) => (
        <div key={`custom-${i}`} onClick={() => toggleCustom(i)} style={{
          display: 'flex', alignItems: 'flex-start', padding: '15px', marginBottom: '12px',
          background: c.done ? '#e8f5e9' : '#f7fafc',
          borderRadius: '12px', cursor: 'pointer', transition: 'all 0.3s ease',
          borderLeft: c.done ? '4px solid #2DCE89' : '4px solid transparent',
        }}>
          <div style={{
            width: 24, height: 24, border: `2px solid ${c.done ? '#2DCE89' : '#ddd'}`,
            borderRadius: '6px', marginRight: '15px',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            flexShrink: 0, marginTop: '2px',
            background: c.done ? '#2DCE89' : 'white', color: 'white', transition: 'all 0.3s ease',
          }}>
            {c.done && <i className="fas fa-check" style={{ fontSize: '0.8rem' }}></i>}
          </div>
          <div style={{ flex: 1, fontSize: '0.95rem', lineHeight: 1.5, color: '#32325d', textDecoration: c.done ? 'line-through' : 'none' }}>
            {c.text}
          </div>
          <button onClick={(e) => { e.stopPropagation(); removeCustom(i); }} style={{
            background: 'none', border: 'none', color: '#e74c3c', cursor: 'pointer', fontSize: '0.85rem', padding: '0 4px',
          }}>✕</button>
        </div>
      ))}

      {/* Add custom affirmation */}
      <div style={{ display: 'flex', gap: '8px', marginTop: '12px' }}>
        <input
          type="text"
          value={newAff}
          onChange={e => setNewAff(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && addCustom()}
          placeholder={t('identity.add_placeholder')}
          style={{
            flex: 1, padding: '10px 15px', border: '1px solid #e0e0e0', borderRadius: '12px',
            fontFamily: 'Poppins, sans-serif', fontSize: '0.9rem', outline: 'none',
          }}
        />
        <button onClick={addCustom} style={{
          background: '#2DCE89', color: 'white', border: 'none', borderRadius: '50%',
          width: 40, height: 40, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
          cursor: 'pointer', fontSize: '1.1rem',
        }}>+</button>
      </div>

      {allComplete && (
        <div style={{
          textAlign: 'center', padding: '15px',
          background: 'linear-gradient(135deg, #d1efe1, #e8f5e9)',
          borderRadius: '12px', marginTop: '15px', color: '#1a9f6e', fontWeight: 500,
        }}>
          <i className="fas fa-check-circle" style={{ marginRight: '8px' }}></i>
          {t('identity.complete')}
        </div>
      )}
    </div>
  );
}
