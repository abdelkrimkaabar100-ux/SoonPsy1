import { useState } from 'react';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { useLanguage } from '../../i18n/LanguageContext';

interface FoodEntry { food: string; date: string; }

export default function FoodTracker() {
  const { t, lang } = useLanguage();
  const [foods, setFoods] = useLocalStorage<FoodEntry[]>('soon-food-log', []);
  const [input, setInput] = useState('');
  const [showHistory, setShowHistory] = useState(false);

  const logFood = () => {
    if (!input.trim()) return;
    setFoods([...foods, { food: input.trim(), date: new Date().toISOString() }]);
    setInput('');
  };

  const today = new Date().toDateString();
  const todayFoods = foods.filter(f => new Date(f.date).toDateString() === today);

  const removeFood = (index: number) => {
    const todayIndices = foods.map((f, i) => ({ ...f, origIdx: i })).filter(f => new Date(f.date).toDateString() === today);
    if (todayIndices[index]) {
      setFoods(foods.filter((_, i) => i !== todayIndices[index].origIdx));
    }
  };

  // Group history by date
  const grouped = foods.reduce<Record<string, FoodEntry[]>>((acc, f) => {
    const key = new Date(f.date).toLocaleDateString();
    if (!acc[key]) acc[key] = [];
    acc[key].push(f);
    return acc;
  }, {});
  const sortedDates = Object.keys(grouped).sort((a, b) => new Date(b).getTime() - new Date(a).getTime());

  return (
    <div style={{ background: 'white', borderRadius: '16px', padding: '15px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)', marginBottom: '20px' }}>
      <h4 style={{ color: '#1a9f6e', marginBottom: '15px', textAlign: 'center' }}>
        <i className="fas fa-apple-alt" style={{ marginRight: '8px' }}></i>
        {t('food.title')}
      </h4>
      <p style={{ color: '#8898aa', fontSize: '0.85rem', marginBottom: '12px', textAlign: 'center' }}>{t('food.desc')}</p>
      <div style={{ background: 'linear-gradient(135deg, #fff7ed, #ffedd5)', borderRadius: '12px', padding: '10px 14px', marginBottom: '12px', border: '1px solid #fed7aa' }}>
        <p style={{ color: '#c2410c', fontSize: '0.8rem', margin: 0, fontWeight: 600 }}>
          <i className="fas fa-moon" style={{ marginRight: '6px' }}></i>
          {lang === 'ar' ? '💡 تناول العشاء مبكراً (قبل 3 ساعات من النوم) لتجنب الكوابيس والاضطرابات الهضمية أثناء الليل' 
          : lang === 'fr' ? '💡 Dînez tôt (3h avant le coucher) pour éviter les cauchemars et les troubles digestifs nocturnes'
          : lang === 'es' ? '💡 Cena temprano (3h antes de dormir) para evitar pesadillas y trastornos digestivos nocturnos'
          : '💡 Eat dinner early (3h before bed) to avoid nightmares and nighttime digestive issues'}
        </p>
      </div>
      <div style={{ display: 'flex', gap: '8px', marginBottom: '12px' }}>
        <input type="text" value={input} onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && logFood()}
          placeholder={t('food.placeholder')}
          style={{ flexGrow: 1, padding: '10px 15px', border: '1px solid #ddd', borderRadius: '25px', fontFamily: 'Poppins, sans-serif', fontSize: '0.9rem', outline: 'none', boxSizing: 'border-box' }}
        />
        <button onClick={logFood} style={{ background: '#2DCE89', color: 'white', border: 'none', borderRadius: '50%', width: 40, height: 40, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', fontSize: '1rem' }}>
          <i className="fas fa-plus"></i>
        </button>
      </div>
      {todayFoods.length > 0 ? (
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
          {todayFoods.map((f, i) => (
            <span key={i} onClick={() => removeFood(i)} style={{ background: '#d1efe1', color: '#1a9f6e', padding: '4px 12px', borderRadius: '20px', fontSize: '0.85rem', fontWeight: 500, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '4px' }}>
              🍽️ {f.food}
              <span style={{ fontSize: '0.65rem', color: '#8898aa' }}>{new Date(f.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
              <i className="fas fa-times" style={{ fontSize: '0.7rem' }}></i>
            </span>
          ))}
        </div>
      ) : (
        <p style={{ color: '#8898aa', textAlign: 'center', fontSize: '0.85rem', margin: 0 }}>{t('food.empty')}</p>
      )}

      {foods.length > 0 && (
        <button onClick={() => setShowHistory(!showHistory)} style={{ background: 'none', border: '1px solid #2DCE89', color: '#2DCE89', borderRadius: '25px', padding: '8px 16px', fontWeight: 600, cursor: 'pointer', width: '100%', fontFamily: 'Poppins, sans-serif', marginTop: '10px', fontSize: '0.85rem' }}>
          <i className={`fas fa-${showHistory ? 'chevron-up' : 'history'}`} style={{ marginRight: '6px' }}></i>
          {showHistory ? t('mood.hide_history') : t('food.history')}
        </button>
      )}

      {showHistory && (
        <div style={{ marginTop: '12px', maxHeight: '250px', overflowY: 'auto' }}>
          {sortedDates.map(dateKey => (
            <div key={dateKey} style={{ marginBottom: '10px' }}>
              <div style={{ fontSize: '0.85rem', fontWeight: 600, color: '#1a9f6e', marginBottom: '6px', paddingBottom: '4px', borderBottom: '2px solid #d1efe1' }}>
                <i className="fas fa-calendar-alt" style={{ marginRight: '6px' }}></i>{dateKey}
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                {grouped[dateKey].map((f, i) => (
                  <span key={i} style={{ background: '#f0fdf4', padding: '4px 10px', borderRadius: '12px', fontSize: '0.8rem', border: '1px solid #bbf7d0' }}>
                    🍽️ {f.food} <span style={{ fontSize: '0.65rem', color: '#8898aa' }}>{new Date(f.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
