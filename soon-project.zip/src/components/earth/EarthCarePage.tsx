import { useState } from 'react';
import InlineAIChat from '../shared/InlineAIChat';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';

interface EarthCarePageProps {
  onBack: () => void;
}

interface CompletedAction {
  id: number;
  date: string;
}

type SharePeriod = 'today' | 'week' | 'month' | 'year';

export default function EarthCarePage({ onBack }: EarthCarePageProps) {
  const { t, lang } = useLanguage();
  const [completed, setCompleted] = useLocalStorage<CompletedAction[]>('soon-earth-actions', []);
  const [userName] = useLocalStorage<string>('soon-user-name', '');
  const [showAll, setShowAll] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [sharePeriod, setSharePeriod] = useState<SharePeriod>('today');
  const [shareSuccess, setShareSuccess] = useState(false);
  const [shareName, setShareName] = useState(userName);

  const actions = [
    { id: 1, icon: '🌳', titleKey: 'earth.plant_tree', benefitKey: 'earth.plant_tree_benefit', category: 'nature' },
    { id: 2, icon: '☀️', titleKey: 'earth.solar', benefitKey: 'earth.solar_benefit', category: 'energy' },
    { id: 3, icon: '🚶', titleKey: 'earth.walk_today', benefitKey: 'earth.walk_today_benefit', category: 'transport' },
    { id: 4, icon: '💧', titleKey: 'earth.save_water', benefitKey: 'earth.save_water_benefit', category: 'water' },
    { id: 5, icon: '♻️', titleKey: 'earth.recycle', benefitKey: 'earth.recycle_benefit', category: 'waste' },
    { id: 6, icon: '🐾', titleKey: 'earth.feed_animal', benefitKey: 'earth.feed_animal_benefit', category: 'compassion' },
    { id: 7, icon: '🌱', titleKey: 'earth.grow_food', benefitKey: 'earth.grow_food_benefit', category: 'nature' },
    { id: 8, icon: '🧹', titleKey: 'earth.clean_area', benefitKey: 'earth.clean_area_benefit', category: 'community' },
    { id: 9, icon: '🕊️', titleKey: 'earth.kindness', benefitKey: 'earth.kindness_benefit', category: 'compassion' },
    { id: 10, icon: '🌍', titleKey: 'earth.educate', benefitKey: 'earth.educate_benefit', category: 'awareness' },
    { id: 11, icon: '🛍️', titleKey: 'earth.reduce_plastic', benefitKey: 'earth.reduce_plastic_benefit', category: 'waste' },
    { id: 12, icon: '🤲', titleKey: 'earth.volunteer', benefitKey: 'earth.volunteer_benefit', category: 'compassion' },
  ];

  const today = new Date().toISOString().slice(0, 10);
  const todayCompleted = completed.filter(c => c.date === today).map(c => c.id);
  const totalCompleted = completed.length;

  const toggleAction = (id: number) => {
    if (todayCompleted.includes(id)) {
      setCompleted(prev => prev.filter(c => !(c.id === id && c.date === today)));
    } else {
      setCompleted(prev => [...prev, { id, date: today }]);
    }
  };

  const displayActions = showAll ? actions : actions.slice(0, 6);

  const getFilteredActions = (period: SharePeriod) => {
    const now = new Date();
    let startDate: string;
    
    switch (period) {
      case 'today':
        startDate = today;
        break;
      case 'week': {
        const d = new Date(now);
        d.setDate(d.getDate() - 7);
        startDate = d.toISOString().slice(0, 10);
        break;
      }
      case 'month': {
        const d = new Date(now);
        d.setMonth(d.getMonth() - 1);
        startDate = d.toISOString().slice(0, 10);
        break;
      }
      case 'year': {
        const d = new Date(now);
        d.setFullYear(d.getFullYear() - 1);
        startDate = d.toISOString().slice(0, 10);
        break;
      }
    }

    return completed.filter(c => c.date >= startDate);
  };

  const formatDate = (dateStr: string) => {
    const d = new Date(dateStr);
    return d.toLocaleDateString(lang === 'ar' ? 'ar-SA' : lang === 'es' ? 'es-ES' : lang === 'fr' ? 'fr-FR' : 'en-US', {
      year: 'numeric', month: 'short', day: 'numeric'
    });
  };

  const buildShareText = () => {
    const filtered = getFilteredActions(sharePeriod);
    if (filtered.length === 0) return '';

    const name = shareName.trim() || userName || t('earth.share_anonymous');
    const periodLabel = t(`earth.period_${sharePeriod}`);

    const grouped: Record<number, string[]> = {};
    filtered.forEach(c => {
      if (!grouped[c.id]) grouped[c.id] = [];
      grouped[c.id].push(c.date);
    });

    let lines = `🌍 ${name} ${t('earth.share_intro')} (${periodLabel}):\n\n`;
    
    Object.entries(grouped).forEach(([idStr, dates]) => {
      const id = parseInt(idStr);
      const action = actions.find(a => a.id === id);
      if (action) {
        const latestDate = dates.sort().reverse()[0];
        lines += `${action.icon} ${t(action.titleKey)} — ${formatDate(latestDate)}${dates.length > 1 ? ` (×${dates.length})` : ''}\n`;
      }
    });

    lines += `\n💚 ${t('earth.share_cta').replace('{name}', name)}\n`;
    lines += `\n${t('earth.share_from')}`;

    return lines;
  };

  const handleShare = async () => {
    const text = buildShareText();
    if (!text) return;

    try {
      await navigator.clipboard.writeText(text);
      setShareSuccess(true);
      setTimeout(() => setShareSuccess(false), 2000);
    } catch {
      // fallback: select from a temp textarea
      const ta = document.createElement('textarea');
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
      setShareSuccess(true);
      setTimeout(() => setShareSuccess(false), 2000);
    }
  };

  const filteredForPreview = getFilteredActions(sharePeriod);

  const periodTabs: { key: SharePeriod; labelKey: string }[] = [
    { key: 'today', labelKey: 'earth.period_today' },
    { key: 'week', labelKey: 'earth.period_week' },
    { key: 'month', labelKey: 'earth.period_month' },
    { key: 'year', labelKey: 'earth.period_year' },
  ];

  return (
    <div>
      {/* Header */}
      <div style={{ textAlign: 'center', margin: '20px 0' }}>
        <button onClick={onBack} style={{
          position: 'absolute', left: '25px', background: 'none', border: 'none',
          fontSize: '1.2rem', color: '#2DCE89', cursor: 'pointer',
        }}>
          <i className="fas fa-arrow-left"></i>
        </button>
        <h2 style={{ fontSize: '1.6rem', fontWeight: 700, color: '#32325d', margin: '0 0 5px' }}>
          🌍 {t('earth.title')}
        </h2>
        <p style={{ color: '#8898aa', fontSize: '0.9rem', margin: 0 }}>{t('earth.subtitle')}</p>
      </div>

      {/* Stats */}
      <div style={{ display: 'flex', gap: '12px', marginBottom: '20px' }}>
        <div style={{
          flex: 1, background: 'linear-gradient(135deg, #2DCE89, #1a9f6e)', borderRadius: '16px',
          padding: '15px', color: 'white', textAlign: 'center',
        }}>
          <div style={{ fontSize: '1.8rem', fontWeight: 700 }}>{todayCompleted.length}</div>
          <div style={{ fontSize: '0.8rem', opacity: 0.9 }}>{t('earth.today')}</div>
        </div>
        <div style={{
          flex: 1, background: 'linear-gradient(135deg, #11cdef, #0da5c0)', borderRadius: '16px',
          padding: '15px', color: 'white', textAlign: 'center',
        }}>
          <div style={{ fontSize: '1.8rem', fontWeight: 700 }}>{totalCompleted}</div>
          <div style={{ fontSize: '0.8rem', opacity: 0.9 }}>{t('earth.total')}</div>
        </div>
      </div>

      {/* Inspiration Quote */}
      <div style={{
        background: 'linear-gradient(135deg, #f8f9fe, #e8f5e9)', borderRadius: '16px',
        padding: '18px', marginBottom: '20px', textAlign: 'center',
        border: '1px solid #c8e6c9',
      }}>
        <p style={{ margin: 0, fontSize: '0.95rem', color: '#2e7d32', fontStyle: 'italic', lineHeight: 1.6 }}>
          {t('earth.quote')}
        </p>
      </div>

      {/* Actions */}
      <h3 style={{ fontSize: '1.1rem', color: '#32325d', marginBottom: '15px' }}>
        {t('earth.actions_title')}
      </h3>

      {displayActions.map(action => {
        const done = todayCompleted.includes(action.id);
        return (
          <div key={action.id} onClick={() => toggleAction(action.id)} style={{
            display: 'flex', alignItems: 'flex-start', gap: '14px',
            padding: '14px', marginBottom: '12px',
            background: done ? 'linear-gradient(135deg, #e8f5e9, #c8e6c9)' : 'white',
            borderRadius: '16px', boxShadow: '0 4px 15px rgba(0,0,0,0.06)',
            cursor: 'pointer', borderLeft: `4px solid ${done ? '#2DCE89' : '#e0e0e0'}`,
            transition: 'all 0.3s ease', position: 'relative',
          }}>
            <div style={{
              width: 50, height: 50, borderRadius: '14px',
              background: done ? '#2DCE89' : '#f0f4ff',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: '1.6rem', flexShrink: 0,
            }}>
              {done ? '✅' : action.icon}
            </div>
            <div style={{ flex: 1 }}>
              <h5 style={{
                margin: '0 0 4px', fontSize: '1rem', color: '#32325d',
                textDecoration: done ? 'line-through' : 'none',
              }}>
                {t(action.titleKey)}
              </h5>
              <p style={{ margin: 0, fontSize: '0.82rem', color: '#66bb6a', lineHeight: 1.5 }}>
                💚 {t(action.benefitKey)}
              </p>
            </div>
          </div>
        );
      })}

      {actions.length > 6 && (
        <button onClick={() => setShowAll(!showAll)} style={{
          width: '100%', padding: '12px', background: 'none', border: '2px dashed #c8e6c9',
          borderRadius: '12px', color: '#2DCE89', fontWeight: 600, cursor: 'pointer',
          fontSize: '0.9rem', fontFamily: 'Poppins, sans-serif', marginBottom: '20px',
        }}>
          {showAll ? t('earth.show_less') : t('earth.show_more')}
        </button>
      )}

      {/* Share Button */}
      {completed.length > 0 && (
        <button onClick={() => setShowShareModal(true)} style={{
          width: '100%', padding: '14px', background: 'linear-gradient(135deg, #2DCE89, #1a9f6e)',
          border: 'none', borderRadius: '14px', color: 'white', fontWeight: 600,
          fontSize: '1rem', cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
          marginBottom: '20px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
        }}>
          <i className="fas fa-share-alt"></i> {t('earth.share')}
        </button>
      )}

      {/* Share Modal */}
      {showShareModal && (
        <div style={{
          position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
          background: 'rgba(0,0,0,0.5)', zIndex: 1000,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          padding: '20px',
        }} onClick={() => setShowShareModal(false)}>
          <div onClick={e => e.stopPropagation()} style={{
            background: 'white', borderRadius: '20px', padding: '24px',
            maxWidth: '400px', width: '100%', maxHeight: '80vh', overflowY: 'auto',
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <h3 style={{ margin: 0, fontSize: '1.2rem', color: '#32325d' }}>
                📤 {t('earth.share_title')}
              </h3>
              <button onClick={() => setShowShareModal(false)} style={{
                background: 'none', border: 'none', fontSize: '1.2rem', cursor: 'pointer', color: '#8898aa',
              }}>✕</button>
            </div>

            {/* Name Input */}
            <div style={{ marginBottom: '16px' }}>
              <label style={{ fontSize: '0.85rem', color: '#8898aa', marginBottom: '6px', display: 'block' }}>
                {t('earth.share_name_label')}
              </label>
              <input
                type="text"
                value={shareName}
                onChange={e => setShareName(e.target.value)}
                placeholder={t('earth.share_name_placeholder')}
                style={{
                  width: '100%', padding: '10px 14px', borderRadius: '12px',
                  border: '1px solid #c8e6c9', background: '#f8f9fe',
                  fontSize: '0.9rem', fontFamily: 'Poppins, sans-serif',
                  outline: 'none', color: '#32325d', boxSizing: 'border-box',
                }}
              />
            </div>

            {/* Period Tabs */}
            <div style={{ display: 'flex', gap: '6px', marginBottom: '16px', flexWrap: 'wrap' }}>
              {periodTabs.map(tab => (
                <button key={tab.key} onClick={() => setSharePeriod(tab.key)} style={{
                  flex: 1, padding: '8px 4px', borderRadius: '10px', border: 'none',
                  background: sharePeriod === tab.key ? 'linear-gradient(135deg, #2DCE89, #1a9f6e)' : '#f0f4ff',
                  color: sharePeriod === tab.key ? 'white' : '#32325d',
                  fontWeight: 600, fontSize: '0.8rem', cursor: 'pointer',
                  fontFamily: 'Poppins, sans-serif', transition: 'all 0.3s ease',
                  minWidth: '70px',
                }}>
                  {t(tab.labelKey)}
                </button>
              ))}
            </div>

            {/* Preview */}
            <div style={{
              background: 'linear-gradient(135deg, #f8f9fe, #e8f5e9)',
              borderRadius: '14px', padding: '16px', marginBottom: '16px',
              border: '1px solid #c8e6c9', fontSize: '0.85rem', lineHeight: 1.7,
              color: '#32325d', whiteSpace: 'pre-wrap', maxHeight: '300px', overflowY: 'auto',
            }}>
              {filteredForPreview.length > 0 ? buildShareText() : (
                <p style={{ textAlign: 'center', color: '#8898aa', margin: 0 }}>
                  {t('earth.share_empty')}
                </p>
              )}
            </div>

            {/* Share Button */}
            {filteredForPreview.length > 0 && (
              <button onClick={handleShare} style={{
                width: '100%', padding: '14px',
                background: shareSuccess ? 'linear-gradient(135deg, #11cdef, #0da5c0)' : 'linear-gradient(135deg, #2DCE89, #1a9f6e)',
                border: 'none', borderRadius: '14px', color: 'white', fontWeight: 600,
                fontSize: '1rem', cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
                transition: 'all 0.3s ease',
              }}>
                <i className={`fas fa-${shareSuccess ? 'check' : 'share-alt'}`}></i>
                {shareSuccess ? t('earth.share_copied') : t('earth.share_now')}
              </button>
            )}
          </div>
        </div>
      )}

      {/* Compassion Section */}
      <div style={{
        background: 'linear-gradient(135deg, #8965e0, #2DCE89)', borderRadius: '16px',
        padding: '20px', color: 'white', textAlign: 'center', marginBottom: '20px',
      }}>
        <h3 style={{ margin: '0 0 10px', fontSize: '1.2rem' }}>🕊️ {t('earth.compassion_title')}</h3>
        <p style={{ margin: 0, fontSize: '0.9rem', opacity: 0.95, lineHeight: 1.6 }}>
          {t('earth.compassion_desc')}
        </p>
      </div>
      <InlineAIChat context="earth" lang={lang} />
    </div>
  );
}
