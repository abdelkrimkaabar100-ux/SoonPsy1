import { useState } from 'react';
import InlineAIChat from '../shared/InlineAIChat';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { supabase } from '@/integrations/supabase/client';

interface Experience {
  id: string;
  title: string;
  description: string;
  level: 'simple' | 'medium' | 'high';
  budget: 'free' | 'paid';
  category: string;
  icon: string;
}

interface CompletedExperience {
  id: string;
  date: string;
  note: string;
}

const allExperiences: Experience[] = [
  // Simple + Free
  { id: 'beach', title: 'exp.beach', description: 'exp.beach_desc', level: 'simple', budget: 'free', category: 'nature', icon: '🏖️' },
  { id: 'plant', title: 'exp.plant', description: 'exp.plant_desc', level: 'simple', budget: 'free', category: 'nature', icon: '🌱' },
  { id: 'sunrise', title: 'exp.sunrise', description: 'exp.sunrise_desc', level: 'simple', budget: 'free', category: 'nature', icon: '🌅' },
  { id: 'barefoot', title: 'exp.barefoot', description: 'exp.barefoot_desc', level: 'simple', budget: 'free', category: 'nature', icon: '🦶' },
  { id: 'stargazing', title: 'exp.stargazing', description: 'exp.stargazing_desc', level: 'simple', budget: 'free', category: 'nature', icon: '⭐' },
  { id: 'cook_new', title: 'exp.cook_new', description: 'exp.cook_new_desc', level: 'simple', budget: 'free', category: 'food', icon: '👨‍🍳' },
  { id: 'volunteer', title: 'exp.volunteer', description: 'exp.volunteer_desc', level: 'simple', budget: 'free', category: 'social', icon: '🤝' },
  { id: 'letter', title: 'exp.letter', description: 'exp.letter_desc', level: 'simple', budget: 'free', category: 'social', icon: '✉️' },
  // Simple + Paid
  { id: 'sushi', title: 'exp.sushi', description: 'exp.sushi_desc', level: 'simple', budget: 'paid', category: 'food', icon: '🍣' },
  { id: 'pottery', title: 'exp.pottery', description: 'exp.pottery_desc', level: 'simple', budget: 'paid', category: 'art', icon: '🏺' },
  { id: 'cinema', title: 'exp.cinema', description: 'exp.cinema_desc', level: 'simple', budget: 'paid', category: 'fun', icon: '🎬' },
  { id: 'massage', title: 'exp.massage', description: 'exp.massage_desc', level: 'simple', budget: 'paid', category: 'wellness', icon: '💆' },
  // Medium + Free
  { id: 'hike', title: 'exp.hike', description: 'exp.hike_desc', level: 'medium', budget: 'free', category: 'nature', icon: '🥾' },
  { id: 'camping', title: 'exp.camping', description: 'exp.camping_desc', level: 'medium', budget: 'free', category: 'nature', icon: '⛺' },
  { id: 'teach', title: 'exp.teach', description: 'exp.teach_desc', level: 'medium', budget: 'free', category: 'social', icon: '📚' },
  // Medium + Paid
  { id: 'cooking_class', title: 'exp.cooking_class', description: 'exp.cooking_class_desc', level: 'medium', budget: 'paid', category: 'food', icon: '👩‍🍳' },
  { id: 'local_trip', title: 'exp.local_trip', description: 'exp.local_trip_desc', level: 'medium', budget: 'paid', category: 'travel', icon: '🚗' },
  { id: 'art_class', title: 'exp.art_class', description: 'exp.art_class_desc', level: 'medium', budget: 'paid', category: 'art', icon: '🎨' },
  { id: 'diving', title: 'exp.diving', description: 'exp.diving_desc', level: 'medium', budget: 'paid', category: 'adventure', icon: '🤿' },
  // High + Paid
  { id: 'india', title: 'exp.india', description: 'exp.india_desc', level: 'high', budget: 'paid', category: 'travel', icon: '🕌' },
  { id: 'africa', title: 'exp.africa', description: 'exp.africa_desc', level: 'high', budget: 'paid', category: 'travel', icon: '🦁' },
  { id: 'morocco', title: 'exp.morocco', description: 'exp.morocco_desc', level: 'high', budget: 'paid', category: 'travel', icon: '🕌' },
  { id: 'france', title: 'exp.france', description: 'exp.france_desc', level: 'high', budget: 'paid', category: 'travel', icon: '🗼' },
  { id: 'japan', title: 'exp.japan', description: 'exp.japan_desc', level: 'high', budget: 'paid', category: 'travel', icon: '⛩️' },
  { id: 'iceland', title: 'exp.iceland', description: 'exp.iceland_desc', level: 'high', budget: 'paid', category: 'travel', icon: '🌋' },
  { id: 'safari', title: 'exp.safari', description: 'exp.safari_desc', level: 'high', budget: 'paid', category: 'adventure', icon: '🐘' },
  { id: 'skydiving', title: 'exp.skydiving', description: 'exp.skydiving_desc', level: 'high', budget: 'paid', category: 'adventure', icon: '🪂' },
];

interface ExperiencesPageProps {
  onBack: () => void;
}

export default function ExperiencesPage({ onBack }: ExperiencesPageProps) {
  const { t, lang } = useLanguage();
  const [level, setLevel] = useState<'simple' | 'medium' | 'high' | ''>('');
  const [budget, setBudget] = useState<'free' | 'paid' | ''>('');
  const [completed, setCompleted] = useLocalStorage<CompletedExperience[]>('soon-experiences', []);
  const [noteInput, setNoteInput] = useState('');
  const [completing, setCompleting] = useState<string | null>(null);
  const [aiSuggestions, setAiSuggestions] = useState('');
  const [loadingAI, setLoadingAI] = useState(false);
  const [showAI, setShowAI] = useState(false);
  const isRTL = lang === 'ar';

  const filtered = allExperiences.filter(e =>
    (level ? e.level === level : true) && (budget ? e.budget === budget : true)
  );

  const completeExperience = (id: string) => {
    if (!noteInput.trim()) return;
    setCompleted(prev => [...prev, { id, date: new Date().toISOString(), note: noteInput.trim() }]);
    setNoteInput('');
    setCompleting(null);
  };

  const isCompleted = (id: string) => completed.some(c => c.id === id);

  const getAISuggestions = async () => {
    setLoadingAI(true);
    setShowAI(true);
    const completedList = completed.map(c => {
      const exp = allExperiences.find(e => e.id === c.id);
      return exp ? t(exp.title) : c.id;
    }).join(', ');
    const prompt = lang === 'ar'
      ? `بناءً على التجارب التي أكملها المستخدم: ${completedList || 'لا توجد'}، وتفضيلاته: مستوى ${level || 'غير محدد'}، ميزانية ${budget || 'غير محددة'}. اقترح 5 تجارب جديدة مفيدة للصحة النفسية مع شرح لماذا كل تجربة مفيدة نفسياً. رد بالعربية.`
      : `Based on completed experiences: ${completedList || 'none'}, preferences: level ${level || 'any'}, budget ${budget || 'any'}. Suggest 5 new experiences beneficial for mental health with explanation of psychological benefits.`;
    try {
      const { data, error } = await supabase.functions.invoke('groq-chat', {
        body: { messages: [{ role: 'user', content: prompt }], systemPrompt: 'You are a travel and experience advisor focused on mental health benefits.' },
      });
      if (error) throw error;
      setAiSuggestions(data.content);
    } catch { setAiSuggestions(lang === 'ar' ? 'حدث خطأ. حاول مرة أخرى.' : 'Error. Please try again.'); }
    setLoadingAI(false);
  };

  const levels = [
    { id: 'simple' as const, icon: '🌿', key: 'exp.simple' },
    { id: 'medium' as const, icon: '🌊', key: 'exp.medium' },
    { id: 'high' as const, icon: '🚀', key: 'exp.high' },
  ];

  const budgets = [
    { id: 'free' as const, icon: '🆓', key: 'exp.free' },
    { id: 'paid' as const, icon: '💰', key: 'exp.paid' },
  ];

  return (
    <div style={{ paddingTop: '20px', direction: isRTL ? 'rtl' : 'ltr' }}>
      <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#2DCE89', fontSize: '1rem', cursor: 'pointer', marginBottom: '15px', fontFamily: 'Poppins, sans-serif' }}>
        <i className={`fas fa-arrow-${isRTL ? 'right' : 'left'}`}></i> {t('nav.home')}
      </button>

      <div style={{ textAlign: 'center', marginBottom: '20px' }}>
        <h2 style={{ color: '#32325d', fontSize: '1.5rem', margin: '0 0 5px' }}>🌟 {t('exp.title')}</h2>
        <p style={{ color: '#8898aa', fontSize: '0.85rem', margin: 0 }}>{t('exp.subtitle')}</p>
      </div>

      {/* Stats */}
      <div style={{ background: 'linear-gradient(135deg, #f093fb, #f5576c)', borderRadius: '16px', padding: '15px', marginBottom: '20px', color: 'white', textAlign: 'center' }}>
        <div style={{ fontSize: '2rem', fontWeight: 700 }}>{completed.length}</div>
        <div style={{ fontSize: '0.85rem', opacity: 0.9 }}>{t('exp.completed_count')}</div>
      </div>

      {/* Level Selection */}
      <div style={{ background: 'white', borderRadius: '16px', padding: '15px', marginBottom: '15px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
        <h4 style={{ color: '#32325d', marginBottom: '10px', fontSize: '0.95rem' }}>📊 {t('exp.choose_level')}</h4>
        <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
          {levels.map(l => (
            <button key={l.id} onClick={() => setLevel(level === l.id ? '' : l.id)} style={{
              flex: 1, minWidth: '80px', padding: '10px', borderRadius: '12px', border: 'none', cursor: 'pointer',
              background: level === l.id ? 'linear-gradient(135deg, #f093fb, #f5576c)' : '#f8f9fe',
              color: level === l.id ? 'white' : '#32325d', fontWeight: 600, fontSize: '0.8rem', fontFamily: 'Poppins, sans-serif',
            }}>
              {l.icon} {t(l.key)}
            </button>
          ))}
        </div>
      </div>

      {/* Budget Selection */}
      <div style={{ background: 'white', borderRadius: '16px', padding: '15px', marginBottom: '20px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
        <h4 style={{ color: '#32325d', marginBottom: '10px', fontSize: '0.95rem' }}>💵 {t('exp.choose_budget')}</h4>
        <div style={{ display: 'flex', gap: '8px' }}>
          {budgets.map(b => (
            <button key={b.id} onClick={() => setBudget(budget === b.id ? '' : b.id)} style={{
              flex: 1, padding: '10px', borderRadius: '12px', border: 'none', cursor: 'pointer',
              background: budget === b.id ? 'linear-gradient(135deg, #2DCE89, #1a9f6e)' : '#f8f9fe',
              color: budget === b.id ? 'white' : '#32325d', fontWeight: 600, fontSize: '0.85rem', fontFamily: 'Poppins, sans-serif',
            }}>
              {b.icon} {t(b.key)}
            </button>
          ))}
        </div>
      </div>

      {/* AI Suggestions */}
      <button onClick={getAISuggestions} disabled={loadingAI} style={{
        width: '100%', padding: '12px', borderRadius: '12px', border: 'none', cursor: loadingAI ? 'default' : 'pointer',
        background: 'linear-gradient(135deg, #8965e0, #5e72e4)', color: 'white', fontWeight: 600,
        fontFamily: 'Poppins, sans-serif', marginBottom: '15px', opacity: loadingAI ? 0.7 : 1,
      }}>
        🤖 {t('exp.ai_suggest')}
      </button>

      {showAI && (
        <div style={{ background: 'white', borderRadius: '16px', padding: '15px', marginBottom: '20px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
          <h4 style={{ color: '#5e72e4', marginBottom: '10px' }}>🤖 {t('exp.ai_title')}</h4>
          {loadingAI ? (
            <p style={{ textAlign: 'center', color: '#8898aa' }}>{t('exp.ai_loading')}</p>
          ) : (
            <div style={{ whiteSpace: 'pre-wrap', lineHeight: 1.7, color: '#32325d', fontSize: '0.85rem' }}>{aiSuggestions}</div>
          )}
        </div>
      )}

      {/* Experience Cards */}
      <h4 style={{ color: '#32325d', marginBottom: '12px' }}>✨ {t('exp.suggestions')} ({filtered.length})</h4>
      {filtered.map(exp => {
        const done = isCompleted(exp.id);
        return (
          <div key={exp.id} style={{
            background: done ? 'linear-gradient(135deg, #e8fdf5, #d4f5e9)' : 'white',
            borderRadius: '16px', padding: '15px', marginBottom: '12px',
            boxShadow: '0 4px 15px rgba(0,0,0,0.06)',
            border: done ? '2px solid #2DCE89' : '1px solid #f0f0f0',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '8px' }}>
              <span style={{ fontSize: '2rem' }}>{exp.icon}</span>
              <div style={{ flex: 1 }}>
                <h5 style={{ margin: 0, color: '#32325d', fontSize: '1rem' }}>{t(exp.title)}</h5>
                <p style={{ margin: '4px 0 0', color: '#8898aa', fontSize: '0.8rem' }}>{t(exp.description)}</p>
              </div>
              {done && <span style={{ fontSize: '1.5rem' }}>✅</span>}
            </div>

            <div style={{ display: 'flex', gap: '6px', marginBottom: '8px' }}>
              <span style={{ background: '#f0f4ff', borderRadius: '20px', padding: '3px 10px', fontSize: '0.7rem', color: '#5e72e4' }}>
                {t(`exp.${exp.level}`)}
              </span>
              <span style={{ background: exp.budget === 'free' ? '#e8fdf5' : '#fff3e0', borderRadius: '20px', padding: '3px 10px', fontSize: '0.7rem', color: exp.budget === 'free' ? '#2DCE89' : '#ff9800' }}>
                {t(`exp.${exp.budget}`)}
              </span>
            </div>

            {!done && completing !== exp.id && (
              <button onClick={() => setCompleting(exp.id)} style={{
                background: 'linear-gradient(135deg, #f093fb, #f5576c)', color: 'white', border: 'none',
                borderRadius: '20px', padding: '8px 16px', fontSize: '0.8rem', fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
              }}>
                🎯 {t('exp.try_it')}
              </button>
            )}

            {completing === exp.id && (
              <div style={{ display: 'flex', gap: '8px', marginTop: '8px' }}>
                <input type="text" value={noteInput} onChange={e => setNoteInput(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && completeExperience(exp.id)}
                  placeholder={t('exp.note_placeholder')}
                  style={{ flex: 1, padding: '8px 14px', border: '1px solid #e0e0e0', borderRadius: '20px', fontFamily: 'Poppins, sans-serif', fontSize: '0.8rem', outline: 'none' }}
                />
                <button onClick={() => completeExperience(exp.id)} style={{
                  background: '#2DCE89', color: 'white', border: 'none', borderRadius: '50%',
                  width: 36, height: 36, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>✓</button>
              </div>
            )}
          </div>
        );
      })}

      {filtered.length === 0 && (
        <div style={{ textAlign: 'center', padding: '30px', color: '#8898aa' }}>
          <span style={{ fontSize: '3rem' }}>🔍</span>
          <p>{t('exp.no_results')}</p>
        </div>
      )}
      <InlineAIChat context="experiences" lang={lang} />
    </div>
  );
}
