import { useState, useEffect, useRef } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';

interface PrimordialWitnessPageProps { onBack: () => void; }

export default function PrimordialWitnessPage({ onBack }: PrimordialWitnessPageProps) {
  const { lang } = useLanguage();
  const isAr = lang === 'ar';
  const [phase, setPhase] = useState<'intro' | 'stillness' | 'question' | 'write'>('intro');
  const [breathScale, setBreathScale] = useState(1);
  const [elapsed, setElapsed] = useState(0);
  const [writing, setWriting] = useState('');
  const [silenceDetected, setSilenceDetected] = useState(false);
  const [entries, setEntries] = useLocalStorage<{ text: string; date: string }[]>('soon-witness-entries', []);
  const lastTypeRef = useRef(Date.now());
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const labels = {
    en: {
      title: 'The Primordial Witness',
      intro: 'This is not an exercise. There is nothing to do here. Just stay.',
      begin: 'Enter Stillness',
      question: 'What is here when nothing is happening?',
      writeHint: 'Free writing... or simply close without writing.',
      save: 'Save & Close',
      close: 'Close Without Writing',
      silenceMsg: 'The silence is noticed. It is welcome here.',
      back: 'Back',
      past: 'Past Witnessing Sessions',
    },
    ar: {
      title: 'الشاهد الأصيل',
      intro: 'هذا ليس تمريناً. لا يوجد شيء لتفعله هنا. فقط ابقَ.',
      begin: 'ادخل السكون',
      question: 'ما الموجود هنا عندما لا يحدث شيء؟',
      writeHint: 'كتابة حرة... أو ببساطة أغلق بدون كتابة.',
      save: 'حفظ وإغلاق',
      close: 'إغلاق بدون كتابة',
      silenceMsg: 'الصمت ملاحَظ. هو مرحّب به هنا.',
      back: 'رجوع',
      past: 'جلسات شهادة سابقة',
    },
    es: { title: 'El Testigo Primordial', intro: 'Esto no es un ejercicio. No hay nada que hacer. Solo quédate.', begin: 'Entrar en Quietud', question: '¿Qué hay aquí cuando no pasa nada?', writeHint: 'Escritura libre...', save: 'Guardar', close: 'Cerrar', silenceMsg: 'El silencio es notado.', back: 'Volver', past: 'Sesiones anteriores' },
    fr: { title: 'Le Témoin Primordial', intro: 'Ce n\'est pas un exercice. Il n\'y a rien à faire. Restez.', begin: 'Entrer dans le Calme', question: 'Qu\'est-ce qui est ici quand rien ne se passe?', writeHint: 'Écriture libre...', save: 'Sauvegarder', close: 'Fermer', silenceMsg: 'Le silence est remarqué.', back: 'Retour', past: 'Sessions passées' },
  };
  const l = (labels as any)[lang] || labels.en;

  // Breathing animation
  useEffect(() => {
    if (phase !== 'stillness' && phase !== 'question') return;
    const breathInterval = setInterval(() => {
      setBreathScale(prev => prev === 1 ? 1.15 : 1);
    }, 4000);
    return () => clearInterval(breathInterval);
  }, [phase]);

  // Timer for stillness phase
  useEffect(() => {
    if (phase !== 'stillness') return;
    timerRef.current = setInterval(() => {
      setElapsed(prev => {
        const next = prev + 1;
        // After 2-3 minutes (150s), transition to question
        if (next >= 150) {
          setPhase('question');
        }
        return next;
      });
    }, 1000);
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [phase]);

  // Silence detection during writing
  useEffect(() => {
    if (phase !== 'write') return;
    const check = setInterval(() => {
      if (Date.now() - lastTypeRef.current > 60000) {
        setSilenceDetected(true);
      }
    }, 10000);
    return () => clearInterval(check);
  }, [phase]);

  const handleType = (val: string) => {
    setWriting(val);
    lastTypeRef.current = Date.now();
    setSilenceDetected(false);
  };

  const saveEntry = () => {
    if (writing.trim()) {
      setEntries(prev => [{ text: writing.trim(), date: new Date().toISOString() }, ...prev]);
    }
    resetAll();
  };

  const resetAll = () => {
    setPhase('intro');
    setElapsed(0);
    setWriting('');
    setSilenceDetected(false);
  };

  // Intro screen
  if (phase === 'intro') return (
    <div style={{ paddingTop: '10px', direction: isAr ? 'rtl' : 'ltr' }}>
      <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#1e3a5f', fontSize: '1rem', cursor: 'pointer', marginBottom: '12px', fontFamily: 'Poppins, sans-serif' }}>
        <i className={`fas fa-arrow-${isAr ? 'right' : 'left'}`}></i> {l.back}
      </button>

      <div style={{ minHeight: '60vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center' }}>
        <div style={{ width: 120, height: 120, borderRadius: '50%', background: 'radial-gradient(circle, #1e3a5f, #0a1628)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '30px', boxShadow: '0 0 60px rgba(30,58,95,0.3)' }}>
          <div style={{ width: 40, height: 40, borderRadius: '50%', background: 'radial-gradient(circle, #64748b, #334155)', opacity: 0.7 }} />
        </div>

        <h2 style={{ fontSize: '1.4rem', color: '#1e293b', marginBottom: '15px', fontWeight: 300, letterSpacing: '2px' }}>{l.title}</h2>
        <p style={{ fontSize: '1rem', color: '#64748b', maxWidth: '280px', lineHeight: 1.8, marginBottom: '40px' }}>{l.intro}</p>

        <button onClick={() => setPhase('stillness')} style={{
          background: 'none', border: '1px solid #94a3b8', borderRadius: '30px',
          padding: '14px 40px', color: '#475569', fontSize: '0.9rem', cursor: 'pointer',
          fontFamily: 'Poppins, sans-serif', letterSpacing: '1px', fontWeight: 300,
        }}>
          {l.begin}
        </button>
      </div>

      {entries.length > 0 && (
        <div style={{ marginTop: '30px' }}>
          <h4 style={{ color: '#64748b', fontSize: '0.85rem', fontWeight: 400, marginBottom: '10px' }}>{l.past}</h4>
          {entries.slice(0, 5).map((e, i) => (
            <div key={i} style={{ background: '#f8fafc', borderRadius: '12px', padding: '12px', marginBottom: '8px', borderLeft: '3px solid #94a3b8' }}>
              <p style={{ margin: 0, fontSize: '0.82rem', color: '#475569', lineHeight: 1.6 }}>{e.text.substring(0, 200)}{e.text.length > 200 ? '...' : ''}</p>
              <p style={{ margin: '4px 0 0', fontSize: '0.7rem', color: '#94a3b8' }}>{new Date(e.date).toLocaleDateString()}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  // Stillness & Question phases
  if (phase === 'stillness' || phase === 'question') return (
    <div style={{ minHeight: '80vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center', background: 'linear-gradient(180deg, #0a1628, #1e293b)', borderRadius: '20px', margin: '-20px', padding: '40px 20px' }}>
      {/* Breathing circle */}
      <div style={{
        width: 160, height: 160, borderRadius: '50%',
        background: 'radial-gradient(circle, rgba(100,116,139,0.3), rgba(10,22,40,0.8))',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        transform: `scale(${breathScale})`, transition: 'transform 4s ease-in-out',
        boxShadow: '0 0 80px rgba(100,116,139,0.15)',
      }}>
        <div style={{
          width: 60, height: 60, borderRadius: '50%',
          background: 'radial-gradient(circle, #475569, #1e293b)',
          transform: `scale(${breathScale})`, transition: 'transform 4s ease-in-out',
        }} />
      </div>

      {/* Question appears after stillness */}
      {phase === 'question' && (
        <div style={{ marginTop: '40px', animation: 'fade-in 3s ease-out' }}>
          <p style={{ color: '#94a3b8', fontSize: '1rem', fontWeight: 300, letterSpacing: '1px', lineHeight: 1.8 }}>
            {l.question}
          </p>
          <button onClick={() => setPhase('write')} style={{
            background: 'none', border: '1px solid rgba(148,163,184,0.3)', borderRadius: '20px',
            padding: '10px 30px', color: '#64748b', fontSize: '0.8rem', cursor: 'pointer',
            marginTop: '20px', fontFamily: 'Poppins, sans-serif',
          }}>
            ✍️
          </button>
          <br />
          <button onClick={resetAll} style={{
            background: 'none', border: 'none', color: '#475569', fontSize: '0.75rem',
            cursor: 'pointer', marginTop: '15px', fontFamily: 'Poppins, sans-serif',
          }}>
            {l.close}
          </button>
        </div>
      )}
    </div>
  );

  // Writing phase
  return (
    <div style={{ paddingTop: '20px', direction: isAr ? 'rtl' : 'ltr' }}>
      <div style={{ minHeight: '50vh', display: 'flex', flexDirection: 'column' }}>
        {silenceDetected && (
          <p style={{ textAlign: 'center', color: '#94a3b8', fontSize: '0.8rem', fontStyle: 'italic', marginBottom: '15px', animation: 'fade-in 2s ease-out' }}>
            {l.silenceMsg}
          </p>
        )}

        <textarea value={writing} onChange={e => handleType(e.target.value)} rows={12}
          placeholder={l.writeHint}
          autoFocus
          style={{
            width: '100%', border: 'none', outline: 'none', background: 'transparent',
            fontFamily: 'Georgia, serif', fontSize: '1rem', lineHeight: 2, color: '#334155',
            resize: 'none', boxSizing: 'border-box', direction: isAr ? 'rtl' : 'ltr',
          }} />

        <div style={{ display: 'flex', gap: '10px', marginTop: '20px' }}>
          <button onClick={saveEntry} style={{
            flex: 1, padding: '12px', border: 'none', borderRadius: '12px',
            background: '#1e293b', color: '#94a3b8', cursor: 'pointer',
            fontSize: '0.85rem', fontFamily: 'Poppins, sans-serif',
          }}>
            {l.save}
          </button>
          <button onClick={resetAll} style={{
            padding: '12px 20px', border: '1px solid #e2e8f0', borderRadius: '12px',
            background: 'none', color: '#94a3b8', cursor: 'pointer',
            fontSize: '0.85rem', fontFamily: 'Poppins, sans-serif',
          }}>
            {l.close}
          </button>
        </div>
      </div>
    </div>
  );
}
