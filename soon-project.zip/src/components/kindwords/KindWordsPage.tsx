import { useState } from 'react';
import InlineAIChat from '../shared/InlineAIChat';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';

interface KindWord {
  id: string;
  to: string;
  message: string;
  type: 'self' | 'others';
  date: string;
}

interface KindWordsPageProps {
  onBack: () => void;
}

export default function KindWordsPage({ onBack }: KindWordsPageProps) {
  const { t, lang } = useLanguage();
  const isRTL = lang === 'ar';
  const [words, setWords] = useLocalStorage<KindWord[]>('soon-kind-words', []);
  const [type, setType] = useState<'self' | 'others'>('self');
  const [to, setTo] = useState('');
  const [message, setMessage] = useState('');

  const save = () => {
    if (!message.trim()) return;
    setWords(prev => [{ id: Date.now().toString(), to: type === 'self' ? t('kind.myself') : to.trim(), message: message.trim(), type, date: new Date().toISOString() }, ...prev]);
    setTo(''); setMessage('');
  };

  const suggestions = [t('kind.sug1'), t('kind.sug2'), t('kind.sug3'), t('kind.sug4'), t('kind.sug5')];

  return (
    <div style={{ paddingTop: '20px', direction: isRTL ? 'rtl' : 'ltr' }}>
      <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#f5365c', fontSize: '1rem', cursor: 'pointer', marginBottom: '15px' }}>
        <i className={`fas fa-arrow-${isRTL ? 'right' : 'left'}`}></i> {t('nav.home')}
      </button>

      <div style={{ background: 'linear-gradient(135deg, #f5365c, #f56036)', borderRadius: '20px', padding: '25px', color: 'white', textAlign: 'center', marginBottom: '20px' }}>
        <div style={{ fontSize: '2.5rem', marginBottom: '10px' }}>💝🌸</div>
        <h2 style={{ fontSize: '1.3rem', fontWeight: 700, margin: '0 0 8px' }}>{t('kind.title')}</h2>
        <p style={{ fontSize: '0.85rem', opacity: 0.9, margin: 0 }}>{t('kind.subtitle')}</p>
      </div>

      <div style={{ background: 'white', borderRadius: '16px', padding: '20px', marginBottom: '15px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)' }}>
        <div style={{ display: 'flex', gap: '10px', marginBottom: '15px' }}>
          <button onClick={() => setType('self')} style={{ flex: 1, padding: '12px', borderRadius: '12px', border: 'none', cursor: 'pointer', background: type === 'self' ? 'linear-gradient(135deg, #f5365c, #f56036)' : '#f7f8fa', color: type === 'self' ? 'white' : '#32325d', fontWeight: 600 }}>
            🪞 {t('kind.to_self')}
          </button>
          <button onClick={() => setType('others')} style={{ flex: 1, padding: '12px', borderRadius: '12px', border: 'none', cursor: 'pointer', background: type === 'others' ? 'linear-gradient(135deg, #f5365c, #f56036)' : '#f7f8fa', color: type === 'others' ? 'white' : '#32325d', fontWeight: 600 }}>
            🤝 {t('kind.to_others')}
          </button>
        </div>
        {type === 'others' && (
          <input value={to} onChange={e => setTo(e.target.value)} placeholder={t('kind.to_placeholder')}
            style={{ width: '100%', padding: '12px', border: '2px solid #fff0f0', borderRadius: '12px', marginBottom: '10px', boxSizing: 'border-box' }} />
        )}
        <textarea value={message} onChange={e => setMessage(e.target.value)} placeholder={t('kind.message_placeholder')}
          style={{ width: '100%', padding: '15px', border: '2px solid #fff0f0', borderRadius: '12px', minHeight: '100px', resize: 'vertical', boxSizing: 'border-box', fontSize: '0.95rem' }} />
        <button onClick={save} style={{ width: '100%', background: 'linear-gradient(135deg, #f5365c, #f56036)', color: 'white', border: 'none', borderRadius: '12px', padding: '14px', fontWeight: 600, cursor: 'pointer', marginTop: '15px' }}>
          💝 {t('kind.send')}
        </button>
      </div>

      <div style={{ background: '#fff5f5', borderRadius: '14px', padding: '15px', marginBottom: '20px' }}>
        <h4 style={{ color: '#f5365c', marginBottom: '10px', fontSize: '0.9rem' }}>💡 {t('kind.suggestions')}</h4>
        {suggestions.map((s, i) => (
          <div key={i} onClick={() => setMessage(s)} style={{ background: 'white', borderRadius: '10px', padding: '10px', marginBottom: '6px', cursor: 'pointer', fontSize: '0.85rem', color: '#32325d' }}>
            {s}
          </div>
        ))}
      </div>

      <h4 style={{ color: '#32325d', marginBottom: '10px' }}>📖 {t('kind.history')}</h4>
      {words.length === 0 && <p style={{ textAlign: 'center', color: '#8898aa' }}>{t('kind.empty')}</p>}
      {words.slice(0, 15).map(w => (
        <div key={w.id} style={{ background: 'white', borderRadius: '12px', padding: '15px', marginBottom: '10px', borderLeft: `4px solid ${w.type === 'self' ? '#f5365c' : '#2DCE89'}` }}>
          <div style={{ fontSize: '0.75rem', color: '#8898aa', marginBottom: '5px' }}>{w.type === 'self' ? '🪞' : '🤝'} {t('kind.to_label')}: {w.to}</div>
          <p style={{ color: '#32325d', margin: 0, lineHeight: 1.6 }}>{w.message}</p>
          <span style={{ fontSize: '0.7rem', color: '#aaa' }}>{new Date(w.date).toLocaleDateString()}</span>
        </div>
      ))}
      <InlineAIChat context="kind-words" lang={lang} />
    </div>
  );
}
