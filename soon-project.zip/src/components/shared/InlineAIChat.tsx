import { useState, useEffect, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface InlineAIChatProps {
  context: string;
  lang: string;
  initialPrompt?: string;
}

function formatAIResponse(text: string): string {
  // Remove markdown ### headers and ** bold markers
  return text
    .replace(/#{1,6}\s*/g, '')
    .replace(/\*\*(.*?)\*\*/g, '$1')
    .replace(/\*(.*?)\*/g, '$1')
    .trim();
}

export default function InlineAIChat({ context, lang, initialPrompt }: InlineAIChatProps) {
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);
  const [prompt, setPrompt] = useState('');
  const isAr = lang === 'ar';
  const lastPromptRef = useRef('');
  const responseRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (initialPrompt && initialPrompt !== lastPromptRef.current) {
      lastPromptRef.current = initialPrompt;
      askAI(initialPrompt);
    }
  }, [initialPrompt]);

  useEffect(() => {
    if (response && responseRef.current) {
      responseRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }, [response]);

  const askAI = async (customPrompt?: string) => {
    const finalPrompt = customPrompt || prompt;
    if (!finalPrompt.trim() || loading) return;
    setLoading(true);
    setResponse('');
    setPrompt('');
    try {
      const { data, error } = await supabase.functions.invoke('ai-assistant', {
        body: { prompt: finalPrompt, context },
      });
      if (error) throw error;
      setResponse(formatAIResponse(data.content || (isAr ? 'لم أستطع الإجابة' : 'Could not get a response')));
    } catch (err: any) {
      console.error(err);
      setResponse(isAr ? '❌ حدث خطأ، حاول مرة أخرى' : '❌ An error occurred, try again');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <div style={{ display: 'flex', gap: '8px', marginTop: '10px' }}>
        <input
          value={prompt}
          onChange={e => setPrompt(e.target.value)}
          placeholder={isAr ? 'اسأل الذكاء الاصطناعي...' : 'Ask AI...'}
          onKeyDown={e => e.key === 'Enter' && askAI()}
          style={{
            flex: 1, padding: '10px 14px', borderRadius: '10px',
            border: '2px solid rgba(34,197,94,0.5)', background: 'rgba(34,197,94,0.25)',
            color: '#000', fontSize: '0.8rem', fontFamily: 'Poppins, sans-serif',
            outline: 'none', direction: isAr ? 'rtl' : 'ltr',
          }}
        />
        <button
          onClick={() => askAI()}
          disabled={loading}
          style={{
            background: 'rgba(34,197,94,0.4)', border: 'none', color: '#000',
            borderRadius: '10px', padding: '10px 16px', cursor: 'pointer',
            fontWeight: 600, fontSize: '0.85rem', fontFamily: 'Poppins, sans-serif',
          }}
        >
          {loading ? '⏳' : '🚀'}
        </button>
      </div>

      {loading && (
        <div style={{
          marginTop: '12px', padding: '14px', borderRadius: '12px',
          background: 'linear-gradient(135deg, rgba(220,53,69,0.3), rgba(255,100,100,0.2))',
          border: '1px solid rgba(220,53,69,0.4)',
          textAlign: 'center', direction: isAr ? 'rtl' : 'ltr',
          animation: 'pulse 1.5s ease-in-out infinite',
        }}>
          <div style={{ fontSize: '1.2rem', marginBottom: '6px' }}>🤖</div>
          <div style={{ fontSize: '0.8rem', color: 'white', fontWeight: 600 }}>
            {isAr ? '🔔 SoonPsy AI سيرد عليك الآن...' : '🔔 SoonPsy AI is preparing your response...'}
          </div>
          <div style={{ fontSize: '0.7rem', color: 'rgba(255,255,255,0.7)', marginTop: '4px' }}>
            {isAr ? 'جاري التحليل النفسي ⏳' : 'Analyzing... ⏳'}
          </div>
        </div>
      )}

      {response && (
        <div ref={responseRef} style={{
          marginTop: '12px', borderRadius: '16px', overflow: 'hidden',
          border: '2px solid rgba(220,53,69,0.5)',
          background: 'linear-gradient(135deg, rgba(180,30,45,0.95), rgba(120,20,30,0.95))',
          boxShadow: '0 8px 25px rgba(220,53,69,0.3)',
          direction: isAr ? 'rtl' : 'ltr',
        }}>
          <div style={{
            padding: '10px 14px',
            background: 'linear-gradient(90deg, rgba(220,53,69,0.9), rgba(180,30,45,0.9))',
            display: 'flex', alignItems: 'center', gap: '8px',
            borderBottom: '1px solid rgba(255,255,255,0.15)',
          }}>
            <span style={{ fontSize: '1.1rem' }}>🤖</span>
            <span style={{ color: 'white', fontWeight: 700, fontSize: '0.8rem' }}>SoonPsy AI</span>
            <span style={{ color: 'rgba(255,255,255,0.6)', fontSize: '0.65rem', marginInlineStart: 'auto' }}>
              {isAr ? 'مساعدك النفسي' : 'Your Psych Assistant'}
            </span>
          </div>
          <div style={{
            padding: '16px',
            fontSize: '0.82rem', lineHeight: 1.8, whiteSpace: 'pre-wrap', color: 'white',
          }}>
            {response}
          </div>
        </div>
      )}
    </div>
  );
}
