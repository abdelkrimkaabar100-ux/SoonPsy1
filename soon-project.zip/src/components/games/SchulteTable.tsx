import { useState, useCallback } from 'react';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { useLanguage } from '../../i18n/LanguageContext';

interface SchulteStats {
  totalPlayed: number;
  bestTime: number;
  bestSize: number;
}

export default function SchulteTable({ onBack }: { onBack: () => void }) {
  const { t } = useLanguage();
  const [stats, setStats] = useLocalStorage<SchulteStats>('soon-schulte-game', {
    totalPlayed: 0, bestTime: 0, bestSize: 0,
  });

  const [phase, setPhase] = useState<'ready' | 'playing' | 'result'>('ready');
  const [gridSize, setGridSize] = useState(3);
  const [grid, setGrid] = useState<number[]>([]);
  const [nextNumber, setNextNumber] = useState(1);
  const [startTime, setStartTime] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const [lastClicked, setLastClicked] = useState<number | null>(null);
  const [wrongClick, setWrongClick] = useState<number | null>(null);
  const [shareMsg, setShareMsg] = useState('');

  const handleShare = async () => {
    const text = t('games.schulte_share_text')
      .replace('{size}', `${gridSize}×${gridSize}`)
      .replace('{time}', elapsed.toFixed(1));
    if (navigator.share) {
      try { await navigator.share({ text, title: 'Soon - Schulte Table' }); return; } catch {}
    }
    try {
      await navigator.clipboard.writeText(text);
      setShareMsg(t('games.copied'));
      setTimeout(() => setShareMsg(''), 3000);
    } catch { setShareMsg(text); }
  };

  const generateGrid = useCallback((size: number) => {
    const total = size * size;
    const nums = Array.from({ length: total }, (_, i) => i + 1);
    for (let i = nums.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [nums[i], nums[j]] = [nums[j], nums[i]];
    }
    return nums;
  }, []);

  const startGame = (size?: number) => {
    const s = size || gridSize;
    setGridSize(s);
    setGrid(generateGrid(s));
    setNextNumber(1);
    setLastClicked(null);
    setWrongClick(null);
    setStartTime(Date.now());
    setPhase('playing');
  };

  const handleClick = (num: number, index: number) => {
    if (phase !== 'playing') return;
    if (num === nextNumber) {
      setLastClicked(index);
      setWrongClick(null);
      const total = gridSize * gridSize;
      if (num === total) {
        const time = (Date.now() - startTime) / 1000;
        setElapsed(time);
        setPhase('result');
        setStats(prev => ({
          totalPlayed: prev.totalPlayed + 1,
          bestTime: prev.bestTime === 0 || time < prev.bestTime ? time : prev.bestTime,
          bestSize: gridSize > prev.bestSize ? gridSize : prev.bestSize,
        }));
      } else {
        setNextNumber(n => n + 1);
      }
    } else {
      setWrongClick(index);
      setTimeout(() => setWrongClick(null), 400);
    }
  };

  const getCellBg = (num: number, index: number) => {
    if (wrongClick === index) return '#ffcdd2';
    if (num < nextNumber) return '#c8e6c9';
    if (lastClicked === index) return '#bbdefb';
    return 'white';
  };

  return (
    <div style={{ padding: '10px 0' }}>
      <button onClick={onBack} style={{
        background: 'none', border: 'none', color: '#01579b', fontSize: '1rem',
        cursor: 'pointer', marginBottom: '15px', fontFamily: 'Poppins, sans-serif',
      }}>← {t('games.back')}</button>

      <div style={{
        background: 'linear-gradient(135deg, #e0f7fa, #b2ebf2)',
        borderRadius: '20px', padding: '20px', marginBottom: '15px', textAlign: 'center',
      }}>
        <h3 style={{ color: '#00695c', margin: '0 0 5px' }}>🔢 {t('games.schulte_title')}</h3>
        <p style={{ color: '#00897b', fontSize: '0.8rem', margin: 0 }}>{t('games.schulte_desc')}</p>
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-around', marginBottom: '15px' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '1.3rem', fontWeight: 700, color: '#00695c' }}>{stats.totalPlayed}</div>
          <div style={{ fontSize: '0.75rem', color: '#9e9e9e' }}>{t('games.played')}</div>
        </div>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '1.3rem', fontWeight: 700, color: '#1565c0' }}>
            {stats.bestTime ? `${stats.bestTime.toFixed(1)}s` : '-'}
          </div>
          <div style={{ fontSize: '0.75rem', color: '#9e9e9e' }}>{t('games.best_time')}</div>
        </div>
      </div>

      {phase === 'ready' && (
        <div>
          <div style={{
            background: '#fff3e0', borderRadius: '12px', padding: '15px', marginBottom: '15px',
            fontSize: '0.85rem', color: '#e65100', lineHeight: 1.6,
          }}>
            💡 {t('games.schulte_instruction')}
          </div>
          <div style={{ display: 'flex', gap: '8px', marginBottom: '15px' }}>
            {[3, 4, 5].map(s => (
              <button key={s} onClick={() => setGridSize(s)} style={{
                flex: 1, background: gridSize === s ? '#00897b' : '#e0f2f1',
                color: gridSize === s ? 'white' : '#00695c',
                border: 'none', borderRadius: '12px', padding: '10px',
                fontWeight: 700, cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
                transition: 'all 0.2s',
              }}>{s}×{s}</button>
            ))}
          </div>
          <button onClick={() => startGame()} style={{
            width: '100%', background: '#00897b', color: 'white', border: 'none',
            borderRadius: '25px', padding: '15px', fontSize: '1.1rem', fontWeight: 600,
            cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
          }}>▶️ {t('games.start')}</button>
        </div>
      )}

      {phase === 'playing' && (
        <div>
          <div style={{ textAlign: 'center', marginBottom: '10px', fontSize: '1rem', fontWeight: 700, color: '#00695c' }}>
            {t('games.schulte_find')}: <span style={{ fontSize: '1.4rem', color: '#c62828' }}>{nextNumber}</span>
          </div>
          <div style={{
            display: 'grid', gridTemplateColumns: `repeat(${gridSize}, 1fr)`,
            gap: '4px', borderRadius: '12px', padding: '4px',
          }}>
            {grid.map((num, i) => (
              <div key={i} onClick={() => handleClick(num, i)} style={{
                aspectRatio: '1', display: 'flex', alignItems: 'center', justifyContent: 'center',
                background: getCellBg(num, i), borderRadius: '8px',
                fontSize: gridSize <= 3 ? '1.4rem' : gridSize <= 4 ? '1.1rem' : '0.9rem',
                fontWeight: 700, color: num < nextNumber ? '#a5d6a7' : '#37474f',
                cursor: num >= nextNumber ? 'pointer' : 'default',
                border: '1px solid #e0e0e0', transition: 'all 0.15s',
                boxShadow: '0 1px 4px rgba(0,0,0,0.06)',
              }}>
                {num}
              </div>
            ))}
          </div>
        </div>
      )}

      {phase === 'result' && (
        <div style={{
          background: '#e0f7fa', borderRadius: '16px', padding: '25px', textAlign: 'center',
        }}>
          <div style={{ fontSize: '2.5rem', marginBottom: '8px' }}>🎉</div>
          <h4 style={{ color: '#00695c', margin: '0 0 10px' }}>{t('games.correct')}</h4>
          <p style={{ fontSize: '1.2rem', fontWeight: 700, color: '#00897b', margin: '0 0 5px' }}>
            ⏱️ {elapsed.toFixed(1)}s
          </p>
          <p style={{ fontSize: '0.85rem', color: '#757575', margin: '0 0 15px' }}>
            {gridSize}×{gridSize} ({gridSize * gridSize} {t('games.schulte_numbers')})
          </p>
          <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
            {gridSize < 5 && (
              <button onClick={() => startGame(gridSize + 1)} style={{
                flex: 1, background: '#4caf50', color: 'white', border: 'none',
                borderRadius: '25px', padding: '12px', fontWeight: 600, cursor: 'pointer',
                fontFamily: 'Poppins, sans-serif',
              }}>⬆️ {gridSize + 1}×{gridSize + 1}</button>
            )}
            <button onClick={() => startGame()} style={{
              flex: 1, background: '#00897b', color: 'white', border: 'none',
              borderRadius: '25px', padding: '12px', fontWeight: 600, cursor: 'pointer',
              fontFamily: 'Poppins, sans-serif',
            }}>🔄 {t('games.retry')}</button>
            <button onClick={handleShare} style={{
              flex: 1, background: '#1976d2', color: 'white', border: 'none',
              borderRadius: '25px', padding: '12px', fontWeight: 600, cursor: 'pointer',
              fontFamily: 'Poppins, sans-serif',
            }}>📤 {t('games.share')}</button>
          </div>
          {shareMsg && <p style={{ marginTop: '10px', fontSize: '0.85rem', color: '#1976d2', fontWeight: 600 }}>{shareMsg}</p>}
        </div>
      )}
    </div>
  );
}
