import { useState, useCallback } from 'react';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { useLanguage } from '../../i18n/LanguageContext';

interface GameStats {
  totalPlayed: number;
  bestTime: number;
  bestLevel: number;
  history: { date: string; level: number; time: number }[];
}

const GRID_SIZE = 5;

export default function MemoryGridGame({ onBack }: { onBack: () => void }) {
  const { t } = useLanguage();
  const [stats, setStats] = useLocalStorage<GameStats>('soon-grid-game', {
    totalPlayed: 0, bestTime: 0, bestLevel: 0, history: [],
  });

  const [phase, setPhase] = useState<'ready' | 'showing' | 'playing' | 'result'>('ready');
  const [level, setLevel] = useState(1);
  const [redCells, setRedCells] = useState<number[]>([]);
  const [clicked, setClicked] = useState<number[]>([]);
  const [startTime, setStartTime] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const [correct, setCorrect] = useState(false);
  const [shareMsg, setShareMsg] = useState('');

  const cellCount = Math.min(3 + level, 10);
  const showDuration = Math.max(2000 - level * 100, 800);

  const generateCells = useCallback(() => {
    const cells: number[] = [];
    while (cells.length < cellCount) {
      const r = Math.floor(Math.random() * (GRID_SIZE * GRID_SIZE));
      if (!cells.includes(r)) cells.push(r);
    }
    return cells;
  }, [cellCount]);

  const startGame = () => {
    const cells = generateCells();
    setRedCells(cells);
    setClicked([]);
    setShareMsg('');
    setPhase('showing');
    setTimeout(() => {
      setPhase('playing');
      setStartTime(Date.now());
    }, showDuration);
  };

  const handleCellClick = (index: number) => {
    if (phase !== 'playing' || clicked.includes(index)) return;
    const newClicked = [...clicked, index];
    setClicked(newClicked);

    if (newClicked.length === redCells.length) {
      const time = (Date.now() - startTime) / 1000;
      setElapsed(time);
      const isCorrect = redCells.every(c => newClicked.includes(c));
      setCorrect(isCorrect);
      setPhase('result');

      setStats(prev => ({
        totalPlayed: prev.totalPlayed + 1,
        bestTime: isCorrect && (prev.bestTime === 0 || time < prev.bestTime) ? time : prev.bestTime,
        bestLevel: isCorrect && level > prev.bestLevel ? level : prev.bestLevel,
        history: [...prev.history.slice(-29), { date: new Date().toISOString(), level, time: isCorrect ? time : -1 }],
      }));
    }
  };

  const nextLevel = () => {
    setLevel(l => l + 1);
    startGame();
  };

  const handleShare = async () => {
    const text = t('games.share_text')
      .replace('{level}', String(level))
      .replace('{time}', elapsed.toFixed(1));

    if (navigator.share) {
      try {
        await navigator.share({ text, title: 'Soon - Memory Grid' });
        return;
      } catch {}
    }

    try {
      await navigator.clipboard.writeText(text);
      setShareMsg(t('games.copied'));
      setTimeout(() => setShareMsg(''), 3000);
    } catch {
      setShareMsg(text);
    }
  };

  const getCellColor = (index: number) => {
    if (phase === 'showing' && redCells.includes(index)) return '#ef5350';
    if (phase === 'result' && redCells.includes(index)) return clicked.includes(index) ? '#66bb6a' : '#ef5350';
    if ((phase === 'playing' || phase === 'result') && clicked.includes(index) && !redCells.includes(index)) return '#ffcc80';
    if (clicked.includes(index) && redCells.includes(index)) return '#66bb6a';
    return '#fafafa';
  };

  return (
    <div style={{ padding: '10px 0' }}>
      <button onClick={onBack} style={{
        background: 'none', border: 'none', color: '#01579b', fontSize: '1rem',
        cursor: 'pointer', marginBottom: '15px', fontFamily: 'Poppins, sans-serif',
      }}>← {t('games.back')}</button>

      <div style={{
        background: 'linear-gradient(135deg, #ffebee, #ffcdd2)',
        borderRadius: '20px', padding: '20px', marginBottom: '15px', textAlign: 'center',
      }}>
        <h3 style={{ color: '#c62828', margin: '0 0 5px' }}>🟥 {t('games.grid_title')}</h3>
        <p style={{ color: '#d32f2f', fontSize: '0.85rem', margin: 0 }}>
          {t('games.level')}: {level} | {t('games.cells')}: {cellCount}
        </p>
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-around', marginBottom: '15px' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '1.3rem', fontWeight: 700, color: '#c62828' }}>{stats.totalPlayed}</div>
          <div style={{ fontSize: '0.75rem', color: '#9e9e9e' }}>{t('games.played')}</div>
        </div>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '1.3rem', fontWeight: 700, color: '#2e7d32' }}>{stats.bestLevel}</div>
          <div style={{ fontSize: '0.75rem', color: '#9e9e9e' }}>{t('games.best_level')}</div>
        </div>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '1.3rem', fontWeight: 700, color: '#1565c0' }}>
            {stats.bestTime ? `${stats.bestTime.toFixed(1)}s` : '-'}
          </div>
          <div style={{ fontSize: '0.75rem', color: '#9e9e9e' }}>{t('games.best_time')}</div>
        </div>
      </div>

      {phase === 'ready' && (
        <button onClick={startGame} style={{
          width: '100%', background: '#f44336', color: 'white', border: 'none',
          borderRadius: '25px', padding: '15px', fontSize: '1.1rem', fontWeight: 600,
          cursor: 'pointer', fontFamily: 'Poppins, sans-serif', marginBottom: '15px',
        }}>▶️ {t('games.start')}</button>
      )}

      {phase === 'showing' && (
        <div style={{ textAlign: 'center', color: '#f44336', fontWeight: 600, marginBottom: '10px', fontSize: '0.9rem' }}>
          👀 {t('games.memorize')}
        </div>
      )}

      {(phase === 'showing' || phase === 'playing' || phase === 'result') && (
        <div style={{
          display: 'grid', gridTemplateColumns: `repeat(${GRID_SIZE}, 1fr)`,
          gap: '4px', background: '#e0e0e0', borderRadius: '12px', padding: '8px',
          marginBottom: '15px',
        }}>
          {Array.from({ length: GRID_SIZE * GRID_SIZE }).map((_, i) => (
            <div key={i} onClick={() => handleCellClick(i)} style={{
              aspectRatio: '1', background: getCellColor(i), borderRadius: '6px',
              cursor: phase === 'playing' ? 'pointer' : 'default',
              transition: 'background 0.2s', border: '1px solid #eee',
            }} />
          ))}
        </div>
      )}

      {phase === 'result' && (
        <div style={{
          background: correct ? '#e8f5e9' : '#fce4ec', borderRadius: '16px',
          padding: '20px', textAlign: 'center', marginBottom: '15px',
        }}>
          <div style={{ fontSize: '2rem', marginBottom: '8px' }}>{correct ? '🎉' : '😅'}</div>
          <h4 style={{ color: correct ? '#2e7d32' : '#c62828', margin: '0 0 8px' }}>
            {correct ? t('games.correct') : t('games.wrong')}
          </h4>
          <p style={{ fontSize: '0.9rem', color: '#616161', margin: '0 0 12px' }}>
            ⏱️ {elapsed.toFixed(1)}s
          </p>
          <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
            {correct && (
              <>
                <button onClick={nextLevel} style={{
                  flex: 1, background: '#4caf50', color: 'white', border: 'none',
                  borderRadius: '25px', padding: '12px', fontWeight: 600, cursor: 'pointer',
                  fontFamily: 'Poppins, sans-serif',
                }}>⬆️ {t('games.next_level')}</button>
                <button onClick={handleShare} style={{
                  flex: 1, background: '#1976d2', color: 'white', border: 'none',
                  borderRadius: '25px', padding: '12px', fontWeight: 600, cursor: 'pointer',
                  fontFamily: 'Poppins, sans-serif',
                }}>📤 {t('games.share')}</button>
              </>
            )}
            <button onClick={() => { setLevel(1); setPhase('ready'); }} style={{
              flex: 1, background: '#f44336', color: 'white', border: 'none',
              borderRadius: '25px', padding: '12px', fontWeight: 600, cursor: 'pointer',
              fontFamily: 'Poppins, sans-serif',
            }}>🔄 {t('games.retry')}</button>
          </div>
          {shareMsg && (
            <p style={{ marginTop: '10px', fontSize: '0.85rem', color: '#1976d2', fontWeight: 600 }}>
              {shareMsg}
            </p>
          )}
        </div>
      )}
    </div>
  );
}
