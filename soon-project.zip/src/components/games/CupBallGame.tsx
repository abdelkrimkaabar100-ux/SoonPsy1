import { useState, useEffect, useRef } from 'react';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { useLanguage } from '../../i18n/LanguageContext';

interface CupStats {
  totalPlayed: number;
  wins: number;
  history: { date: string; won: boolean; shuffles: number; time: number }[];
}

export default function CupBallGame({ onBack }: { onBack: () => void }) {
  const { t } = useLanguage();
  const [stats, setStats] = useLocalStorage<CupStats>('soon-cup-game', {
    totalPlayed: 0, wins: 0, history: [],
  });

  const [phase, setPhase] = useState<'ready' | 'reveal' | 'shuffling' | 'guess' | 'result'>('ready');
  const [ballPos, setBallPos] = useState(1);
  const [positions, setPositions] = useState([0, 1, 2]);
  const [level, setLevel] = useState(1);
  const [selectedCup, setSelectedCup] = useState<number | null>(null);
  const [won, setWon] = useState(false);
  const [startTime, setStartTime] = useState(0);
  const animRef = useRef<NodeJS.Timeout[]>([]);

  const shuffleCount = Math.min(3 + level * 2, 15);

  const startGame = () => {
    animRef.current.forEach(clearTimeout);
    animRef.current = [];

    const ball = Math.floor(Math.random() * 3);
    setBallPos(ball);
    setPositions([0, 1, 2]);
    setSelectedCup(null);
    setPhase('reveal');

    const revealTimeout = setTimeout(() => {
      setPhase('shuffling');
      let currentPositions = [0, 1, 2];

      for (let i = 0; i < shuffleCount; i++) {
        const timeout = setTimeout(() => {
          const a = Math.floor(Math.random() * 3);
          let b = Math.floor(Math.random() * 3);
          while (b === a) b = Math.floor(Math.random() * 3);

          currentPositions = [...currentPositions];
          const temp = currentPositions[a];
          currentPositions[a] = currentPositions[b];
          currentPositions[b] = temp;
          setPositions([...currentPositions]);

          if (i === shuffleCount - 1) {
            setTimeout(() => {
              setPhase('guess');
              setStartTime(Date.now());
            }, 400);
          }
        }, 600 + i * 500);
        animRef.current.push(timeout);
      }
    }, 1500);
    animRef.current.push(revealTimeout);
  };

  const handleGuess = (cupIndex: number) => {
    if (phase !== 'guess') return;
    setSelectedCup(cupIndex);
    const actualPos = positions.indexOf(ballPos);
    const isWon = cupIndex === actualPos;
    setWon(isWon);
    setPhase('result');

    const time = (Date.now() - startTime) / 1000;
    setStats(prev => ({
      totalPlayed: prev.totalPlayed + 1,
      wins: prev.wins + (isWon ? 1 : 0),
      history: [...prev.history.slice(-29), {
        date: new Date().toISOString(), won: isWon, shuffles: shuffleCount, time,
      }],
    }));
  };

  useEffect(() => {
    return () => animRef.current.forEach(clearTimeout);
  }, []);

  const getCupStyle = (displayIndex: number) => {
    const actualCupIndex = positions.indexOf(displayIndex);
    const isRevealed = phase === 'reveal' && displayIndex === ballPos;
    const isResult = phase === 'result';
    const hasBall = displayIndex === ballPos;

    return {
      width: '80px', height: '80px', display: 'flex', flexDirection: 'column' as const,
      alignItems: 'center', justifyContent: 'center', cursor: phase === 'guess' ? 'pointer' : 'default',
      transition: 'all 0.4s ease',
      transform: selectedCup === positions.indexOf(displayIndex) && isResult
        ? 'translateY(-15px)' : 'none',
    };
  };

  const renderCup = (displayIndex: number) => {
    const isRevealed = phase === 'reveal' && displayIndex === ballPos;
    const isResult = phase === 'result';
    const hasBall = displayIndex === ballPos;
    const cupVisualIndex = positions.indexOf(displayIndex);

    return (
      <div key={displayIndex} onClick={() => handleGuess(cupVisualIndex)}
        style={getCupStyle(displayIndex)}>
        <div style={{
          fontSize: '3.5rem', transition: 'transform 0.3s',
          transform: (isRevealed || (isResult && (selectedCup === cupVisualIndex || hasBall)))
            ? 'translateY(-15px)' : 'none',
        }}>🏆</div>
        {(isRevealed || (isResult && hasBall)) && (
          <div style={{
            fontSize: '1.5rem', marginTop: '-10px', animation: 'fade-in 0.3s ease',
          }}>⚽</div>
        )}
        {isResult && selectedCup === cupVisualIndex && !hasBall && (
          <div style={{ fontSize: '1.2rem', marginTop: '-10px', color: '#f44336' }}>❌</div>
        )}
      </div>
    );
  };

  const orderedCups = positions.map((_, i) => {
    const cupId = positions[i];
    return cupId;
  });

  return (
    <div style={{ padding: '10px 0' }}>
      <button onClick={onBack} style={{
        background: 'none', border: 'none', color: '#01579b', fontSize: '1rem',
        cursor: 'pointer', marginBottom: '15px', fontFamily: 'Poppins, sans-serif',
      }}>← {t('games.back')}</button>

      <div style={{
        background: 'linear-gradient(135deg, #fff3e0, #ffe0b2)',
        borderRadius: '20px', padding: '20px', marginBottom: '15px', textAlign: 'center',
      }}>
        <h3 style={{ color: '#e65100', margin: '0 0 5px' }}>🏆 {t('games.cups_title')}</h3>
        <p style={{ color: '#ef6c00', fontSize: '0.85rem', margin: 0 }}>
          {t('games.level')}: {level} | {t('games.shuffles')}: {shuffleCount}
        </p>
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-around', marginBottom: '15px' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '1.3rem', fontWeight: 700, color: '#e65100' }}>{stats.totalPlayed}</div>
          <div style={{ fontSize: '0.75rem', color: '#9e9e9e' }}>{t('games.played')}</div>
        </div>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '1.3rem', fontWeight: 700, color: '#2e7d32' }}>{stats.wins}</div>
          <div style={{ fontSize: '0.75rem', color: '#9e9e9e' }}>{t('games.wins')}</div>
        </div>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '1.3rem', fontWeight: 700, color: '#1565c0' }}>
            {stats.totalPlayed > 0 ? `${Math.round(stats.wins / stats.totalPlayed * 100)}%` : '-'}
          </div>
          <div style={{ fontSize: '0.75rem', color: '#9e9e9e' }}>{t('games.accuracy')}</div>
        </div>
      </div>

      {phase === 'ready' && (
        <button onClick={startGame} style={{
          width: '100%', background: '#ff9800', color: 'white', border: 'none',
          borderRadius: '25px', padding: '15px', fontSize: '1.1rem', fontWeight: 600,
          cursor: 'pointer', fontFamily: 'Poppins, sans-serif', marginBottom: '15px',
        }}>▶️ {t('games.start')}</button>
      )}

      {phase === 'reveal' && (
        <div style={{ textAlign: 'center', color: '#e65100', fontWeight: 600, marginBottom: '10px' }}>
          👀 {t('games.watch_ball')}
        </div>
      )}
      {phase === 'shuffling' && (
        <div style={{ textAlign: 'center', color: '#f57c00', fontWeight: 600, marginBottom: '10px' }}>
          🔄 {t('games.shuffling')}
        </div>
      )}
      {phase === 'guess' && (
        <div style={{ textAlign: 'center', color: '#2e7d32', fontWeight: 600, marginBottom: '10px' }}>
          👆 {t('games.pick_cup')}
        </div>
      )}

      {phase !== 'ready' && (
        <div style={{
          display: 'flex', justifyContent: 'space-around', alignItems: 'flex-end',
          background: '#efebe9', borderRadius: '16px', padding: '25px 15px', marginBottom: '15px',
          minHeight: '120px',
        }}>
          {[0, 1, 2].map(i => renderCup(positions[i]))}
        </div>
      )}

      {phase === 'result' && (
        <div style={{
          background: won ? '#e8f5e9' : '#fce4ec', borderRadius: '16px',
          padding: '20px', textAlign: 'center', marginBottom: '15px',
        }}>
          <div style={{ fontSize: '2rem', marginBottom: '8px' }}>{won ? '🎉' : '😅'}</div>
          <h4 style={{ color: won ? '#2e7d32' : '#c62828', margin: '0 0 12px' }}>
            {won ? t('games.correct') : t('games.wrong')}
          </h4>
          <div style={{ display: 'flex', gap: '10px' }}>
            {won && (
              <button onClick={() => { setLevel(l => l + 1); startGame(); }} style={{
                flex: 1, background: '#4caf50', color: 'white', border: 'none',
                borderRadius: '25px', padding: '12px', fontWeight: 600, cursor: 'pointer',
                fontFamily: 'Poppins, sans-serif',
              }}>⬆️ {t('games.next_level')}</button>
            )}
            <button onClick={() => { setLevel(1); setPhase('ready'); }} style={{
              flex: 1, background: '#ff9800', color: 'white', border: 'none',
              borderRadius: '25px', padding: '12px', fontWeight: 600, cursor: 'pointer',
              fontFamily: 'Poppins, sans-serif',
            }}>🔄 {t('games.retry')}</button>
          </div>
        </div>
      )}
    </div>
  );
}
