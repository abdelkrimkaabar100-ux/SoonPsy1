import { useState } from 'react';
import InlineAIChat from '../shared/InlineAIChat';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import MemoryGridGame from './MemoryGridGame';
import StroopGame from './StroopGame';
import SequenceMemoryGame from './SequenceMemoryGame';
import SchulteTable from './SchulteTable';

type GameView = 'menu' | 'grid' | 'stroop' | 'sequence' | 'schulte';

interface AttentionGamesPageProps { onBack?: () => void; }

export default function AttentionGamesPage({ onBack }: AttentionGamesPageProps) {
  const { t, lang } = useLanguage();
  const [activeGame, setActiveGame] = useState<GameView>('menu');
  const [leaderboard] = useLocalStorage<{ name: string; game: string; score: number; date: string }[]>('soon-game-leaderboard', []);
  const [showLeaderboard, setShowLeaderboard] = useState(false);
  const isAr = lang === 'ar';

  const backToMenu = () => setActiveGame('menu');

  if (activeGame === 'grid') return <MemoryGridGame onBack={backToMenu} />;
  if (activeGame === 'stroop') return <StroopGame onBack={backToMenu} />;
  if (activeGame === 'sequence') return <SequenceMemoryGame onBack={backToMenu} />;
  if (activeGame === 'schulte') return <SchulteTable onBack={backToMenu} />;

  const games = [
    { id: 'grid' as GameView, icon: '🟥', color: '#f44336', title: t('games.grid_title'), desc: t('games.grid_desc') },
    { id: 'stroop' as GameView, icon: '🎨', color: '#3f51b5', title: t('games.stroop_title'), desc: t('games.stroop_desc') },
    { id: 'sequence' as GameView, icon: '🔔', color: '#c2185b', title: t('games.seq_title'), desc: t('games.seq_desc') },
    { id: 'schulte' as GameView, icon: '🔢', color: '#00897b', title: t('games.schulte_title'), desc: t('games.schulte_desc') },
  ];

  const lbLabels: Record<string, Record<string, string>> = {
    en: { title: '🏆 Leaderboard', today: 'Today\'s Best', back: 'Back', no_scores: 'No scores yet. Play a game!' },
    ar: { title: '🏆 قائمة المتصدرين', today: 'أفضل اليوم', back: 'رجوع', no_scores: 'لا نتائج بعد. العب لعبة!' },
    es: { title: '🏆 Tabla de líderes', today: 'Mejor de hoy', back: 'Volver', no_scores: '¡Sin puntuaciones aún!' },
    fr: { title: '🏆 Classement', today: 'Meilleur aujourd\'hui', back: 'Retour', no_scores: 'Pas encore de scores!' },
  };
  const lb = lbLabels[lang] || lbLabels.en;

  // Build leaderboard from individual game stats
  const buildTodayScores = () => {
    const today = new Date().toDateString();
    const scores: { name: string; game: string; score: number }[] = [];
    
    // Read from individual game stats
    try {
      const userName = JSON.parse(localStorage.getItem('soon-user-name') || '""') || 'You';
      
      const gridStats = JSON.parse(localStorage.getItem('soon-grid-game') || '{}');
      if (gridStats.history) {
        gridStats.history.filter((h: any) => new Date(h.date).toDateString() === today && h.time > 0)
          .forEach((h: any) => scores.push({ name: userName, game: '🟥 Grid', score: Math.round((1 / h.time) * h.level * 100) }));
      }

      const stroopStats = JSON.parse(localStorage.getItem('soon-stroop-game') || '{}');
      if (stroopStats.bestScore > 0) {
        scores.push({ name: userName, game: '🎨 Stroop', score: stroopStats.bestScore });
      }

      const seqStats = JSON.parse(localStorage.getItem('soon-sequence-game') || '{}');
      if (seqStats.bestLevel > 0) {
        scores.push({ name: userName, game: '🔔 Sequence', score: seqStats.bestLevel * 10 });
      }

      const schulteStats = JSON.parse(localStorage.getItem('soon-schulte-game') || '{}');
      if (schulteStats.history) {
        schulteStats.history.filter((h: any) => new Date(h.date).toDateString() === today)
          .forEach((h: any) => scores.push({ name: userName, game: '🔢 Schulte', score: Math.round((1 / h.time) * 1000) }));
      }
    } catch {}

    // Also include explicit leaderboard entries
    const fromLb = leaderboard.filter(s => new Date(s.date).toDateString() === today);
    scores.push(...fromLb);

    return scores.sort((a, b) => b.score - a.score);
  };

  const todayScores = buildTodayScores();

  return (
    <div style={{ padding: '10px 0', direction: isAr ? 'rtl' : 'ltr' }}>
      {onBack && (
        <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#01579b', cursor: 'pointer', fontSize: '1rem', fontFamily: 'Poppins, sans-serif', marginBottom: '10px' }}>
          <i className={`fas fa-arrow-${isAr ? 'right' : 'left'}`}></i> {isAr ? 'رجوع' : 'Back'}
        </button>
      )}
      <div style={{
        background: 'linear-gradient(135deg, #e1f5fe, #b3e5fc)',
        borderRadius: '20px', padding: '25px', marginBottom: '20px', textAlign: 'center',
      }}>
        <div style={{ fontSize: '3rem', marginBottom: '10px' }}>🧠</div>
        <h2 style={{ color: '#01579b', margin: '0 0 8px', fontSize: '1.4rem' }}>{t('games.title')}</h2>
        <p style={{ color: '#0277bd', fontSize: '0.9rem', margin: 0 }}>{t('games.subtitle')}</p>
      </div>

      <button onClick={() => setShowLeaderboard(!showLeaderboard)} style={{
        width: '100%', background: showLeaderboard ? '#f1f5f9' : 'linear-gradient(135deg, #f59e0b, #d97706)',
        color: showLeaderboard ? '#475569' : 'white', border: 'none', borderRadius: '12px', padding: '12px',
        fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif', marginBottom: '15px', fontSize: '0.9rem',
      }}>
        {showLeaderboard ? `✕ ${lb.back}` : lb.title}
      </button>

      {showLeaderboard && (
        <div style={{ background: 'white', borderRadius: '16px', padding: '15px', boxShadow: '0 4px 15px rgba(0,0,0,0.08)', marginBottom: '15px' }}>
          <h4 style={{ color: '#f59e0b', margin: '0 0 10px' }}>📊 {lb.today}</h4>
          {todayScores.length === 0 && <p style={{ textAlign: 'center', color: '#8898aa', fontSize: '0.85rem' }}>{lb.no_scores}</p>}
          {todayScores.slice(0, 10).map((s, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '8px 0', borderBottom: '1px solid #f1f5f9' }}>
              <span style={{ fontWeight: 700, color: i < 3 ? '#f59e0b' : '#8898aa', fontSize: '1rem', width: '24px' }}>
                {i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `${i + 1}`}
              </span>
              <span style={{ flex: 1, fontSize: '0.85rem', color: '#32325d' }}>{s.name || 'Anonymous'}</span>
              <span style={{ fontSize: '0.8rem', color: '#8898aa' }}>{s.game}</span>
              <span style={{ fontWeight: 700, color: '#2DCE89' }}>{s.score}</span>
            </div>
          ))}
        </div>
      )}

      {games.map(game => (
        <div key={game.id} onClick={() => setActiveGame(game.id)} style={{
          background: 'white', borderRadius: '16px', padding: '20px',
          boxShadow: '0 4px 15px rgba(0,0,0,0.08)', marginBottom: '12px',
          cursor: 'pointer', borderLeft: `5px solid ${game.color}`, transition: 'transform 0.2s',
        }}
        onMouseEnter={e => e.currentTarget.style.transform = 'translateY(-3px)'}
        onMouseLeave={e => e.currentTarget.style.transform = 'translateY(0)'}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
            <div style={{ fontSize: '2.2rem' }}>{game.icon}</div>
            <div>
              <h3 style={{ margin: '0 0 4px', color: game.color, fontSize: '1.05rem' }}>{game.title}</h3>
              <p style={{ margin: 0, fontSize: '0.82rem', color: '#757575' }}>{game.desc}</p>
            </div>
          </div>
        </div>
      ))}
      <InlineAIChat context="games" lang={lang} />
    </div>
  );
}
