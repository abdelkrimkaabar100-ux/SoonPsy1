import { useState, useEffect, useCallback } from 'react';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { useLanguage } from '../../i18n/LanguageContext';

interface SeqStats {
  totalPlayed: number;
  bestLevel: number;
}

const TILE_COLORS = ['#e53935', '#1e88e5', '#43a047', '#fb8c00'];
const FLASH_DURATION = 500;
const GAP_DURATION = 200;

export default function SequenceMemoryGame({ onBack }: { onBack: () => void }) {
  const { t } = useLanguage();
  const [stats, setStats] = useLocalStorage<SeqStats>('soon-sequence-game', {
    totalPlayed: 0, bestLevel: 0,
  });

  const [phase, setPhase] = useState<'ready' | 'showing' | 'input' | 'result'>('ready');
  const [sequence, setSequence] = useState<number[]>([]);
  const [playerInput, setPlayerInput] = useState<number[]>([]);
  const [activeFlash, setActiveFlash] = useState<number | null>(null);
  const [level, setLevel] = useState(1);
  const [correct, setCorrect] = useState(false);
  const [shareMsg, setShareMsg] = useState('');

  const handleShare = async () => {
    const text = t('games.seq_share_text').replace('{level}', String(level - 1));
    if (navigator.share) {
      try { await navigator.share({ text, title: 'Soon - Sequence Memory' }); return; } catch {}
    }
    try {
      await navigator.clipboard.writeText(text);
      setShareMsg(t('games.copied'));
      setTimeout(() => setShareMsg(''), 3000);
    } catch { setShareMsg(text); }
  };

  const playSequence = useCallback((seq: number[]) => {
    setPhase('showing');
    let i = 0;
    const play = () => {
      if (i >= seq.length) {
        setActiveFlash(null);
        setPhase('input');
        return;
      }
      setActiveFlash(seq[i]);
      setTimeout(() => {
        setActiveFlash(null);
        i++;
        setTimeout(play, GAP_DURATION);
      }, FLASH_DURATION);
    };
    setTimeout(play, 500);
  }, []);

  const startGame = () => {
    const first = [Math.floor(Math.random() * 4)];
    setSequence(first);
    setPlayerInput([]);
    setLevel(1);
    playSequence(first);
  };

  const handleTileClick = (index: number) => {
    if (phase !== 'input') return;
    setActiveFlash(index);
    setTimeout(() => setActiveFlash(null), 150);

    const newInput = [...playerInput, index];
    setPlayerInput(newInput);

    // Check if wrong
    if (newInput[newInput.length - 1] !== sequence[newInput.length - 1]) {
      setCorrect(false);
      setPhase('result');
      setStats(prev => ({
        totalPlayed: prev.totalPlayed + 1,
        bestLevel: Math.max(prev.bestLevel, level - 1),
      }));
      return;
    }

    // Check if complete
    if (newInput.length === sequence.length) {
      const nextLevel = level + 1;
      setLevel(nextLevel);
      const next = [...sequence, Math.floor(Math.random() * 4)];
      setSequence(next);
      setPlayerInput([]);
      setTimeout(() => playSequence(next), 800);
    }
  };

  return (
    <div style={{ padding: '10px 0' }}>
      <button onClick={onBack} style={{
        background: 'none', border: 'none', color: '#01579b', fontSize: '1rem',
        cursor: 'pointer', marginBottom: '15px', fontFamily: 'Poppins, sans-serif',
      }}>← {t('games.back')}</button>

      <div style={{
        background: 'linear-gradient(135deg, #fce4ec, #f8bbd0)',
        borderRadius: '20px', padding: '20px', marginBottom: '15px', textAlign: 'center',
      }}>
        <h3 style={{ color: '#880e4f', margin: '0 0 5px' }}>🔔 {t('games.seq_title')}</h3>
        <p style={{ color: '#ad1457', fontSize: '0.85rem', margin: 0 }}>
          {t('games.level')}: {level}
        </p>
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-around', marginBottom: '15px' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '1.3rem', fontWeight: 700, color: '#880e4f' }}>{stats.totalPlayed}</div>
          <div style={{ fontSize: '0.75rem', color: '#9e9e9e' }}>{t('games.played')}</div>
        </div>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '1.3rem', fontWeight: 700, color: '#2e7d32' }}>{stats.bestLevel}</div>
          <div style={{ fontSize: '0.75rem', color: '#9e9e9e' }}>{t('games.best_level')}</div>
        </div>
      </div>

      {phase === 'ready' && (
        <div>
          <div style={{
            background: '#fff3e0', borderRadius: '12px', padding: '15px', marginBottom: '15px',
            fontSize: '0.85rem', color: '#e65100', lineHeight: 1.6,
          }}>
            💡 {t('games.seq_instruction')}
          </div>
          <button onClick={startGame} style={{
            width: '100%', background: '#c2185b', color: 'white', border: 'none',
            borderRadius: '25px', padding: '15px', fontSize: '1.1rem', fontWeight: 600,
            cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
          }}>▶️ {t('games.start')}</button>
        </div>
      )}

      {(phase === 'showing' || phase === 'input') && (
        <div>
          <div style={{ textAlign: 'center', marginBottom: '10px', fontSize: '0.9rem', fontWeight: 600, color: phase === 'showing' ? '#c62828' : '#2e7d32' }}>
            {phase === 'showing' ? `👀 ${t('games.seq_watch')}` : `👆 ${t('games.seq_repeat')}`}
          </div>
          <div style={{
            display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)',
            gap: '10px', maxWidth: '260px', margin: '0 auto',
          }}>
            {TILE_COLORS.map((color, i) => (
              <div key={i} onClick={() => handleTileClick(i)} style={{
                aspectRatio: '1', borderRadius: '16px',
                background: color,
                opacity: activeFlash === i ? 1 : 0.45,
                transform: activeFlash === i ? 'scale(1.05)' : 'scale(1)',
                transition: 'all 0.15s ease',
                cursor: phase === 'input' ? 'pointer' : 'default',
                boxShadow: activeFlash === i ? `0 0 25px ${color}` : '0 2px 8px rgba(0,0,0,0.15)',
              }} />
            ))}
          </div>
        </div>
      )}

      {phase === 'result' && (
        <div style={{
          background: '#fce4ec', borderRadius: '16px', padding: '25px', textAlign: 'center',
        }}>
          <div style={{ fontSize: '2.5rem', marginBottom: '8px' }}>😅</div>
          <h4 style={{ color: '#880e4f', margin: '0 0 8px' }}>{t('games.wrong')}</h4>
          <p style={{ fontSize: '1.5rem', fontWeight: 700, color: '#c2185b', margin: '0 0 15px' }}>
            {t('games.level')}: {level - 1}
          </p>
          <div style={{ display: 'flex', gap: '10px' }}>
            <button onClick={startGame} style={{
              flex: 1, background: '#c2185b', color: 'white', border: 'none',
              borderRadius: '25px', padding: '12px', fontWeight: 600, cursor: 'pointer',
              fontFamily: 'Poppins, sans-serif',
            }}>🔄 {t('games.retry')}</button>
            <button onClick={handleShare} style={{
              flex: 1, background: '#1976d2', color: 'white', border: 'none',
              borderRadius: '25px', padding: '12px', fontWeight: 600, cursor: 'pointer',
              fontFamily: 'Poppins, sans-serif',
            }}>📤 {t('games.share')}</button>
          </div>
          {shareMsg && <p style={{ marginTop: '10px', fontSize: '0.85rem', color: '#1976d2', fontWeight: 600 }}>{shareMsg}</p>}
        </div>
      )}
    </div>
  );
}
