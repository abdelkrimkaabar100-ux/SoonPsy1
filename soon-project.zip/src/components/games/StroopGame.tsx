import { useState, useEffect, useCallback } from 'react';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { useLanguage } from '../../i18n/LanguageContext';

interface StroopStats {
  totalPlayed: number;
  bestScore: number;
  bestStreak: number;
}

const COLORS = [
  { name: 'red', hex: '#e53935' },
  { name: 'blue', hex: '#1e88e5' },
  { name: 'green', hex: '#43a047' },
  { name: 'yellow', hex: '#fdd835' },
  { name: 'purple', hex: '#8e24aa' },
  { name: 'orange', hex: '#fb8c00' },
];

const COLOR_NAMES: Record<string, Record<string, string>> = {
  red: { en: 'RED', ar: 'أحمر', es: 'ROJO', fr: 'ROUGE' },
  blue: { en: 'BLUE', ar: 'أزرق', es: 'AZUL', fr: 'BLEU' },
  green: { en: 'GREEN', ar: 'أخضر', es: 'VERDE', fr: 'VERT' },
  yellow: { en: 'YELLOW', ar: 'أصفر', es: 'AMARILLO', fr: 'JAUNE' },
  purple: { en: 'PURPLE', ar: 'بنفسجي', es: 'MORADO', fr: 'VIOLET' },
  orange: { en: 'ORANGE', ar: 'برتقالي', es: 'NARANJA', fr: 'ORANGE' },
};

const ROUND_TIME = 30;

export default function StroopGame({ onBack }: { onBack: () => void }) {
  const { t, lang } = useLanguage();
  const [stats, setStats] = useLocalStorage<StroopStats>('soon-stroop-game', {
    totalPlayed: 0, bestScore: 0, bestStreak: 0,
  });

  const [phase, setPhase] = useState<'ready' | 'playing' | 'result'>('ready');
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [maxStreak, setMaxStreak] = useState(0);
  const [timeLeft, setTimeLeft] = useState(ROUND_TIME);
  const [wordColor, setWordColor] = useState(COLORS[0]);
  const [displayedColorName, setDisplayedColorName] = useState(COLORS[1]);
  const [options, setOptions] = useState<typeof COLORS>([]);
  const [feedback, setFeedback] = useState<'correct' | 'wrong' | null>(null);
  const [shareMsg, setShareMsg] = useState('');

  const handleShare = async () => {
    const text = t('games.stroop_share_text')
      .replace('{score}', String(score))
      .replace('{streak}', String(maxStreak));
    if (navigator.share) {
      try { await navigator.share({ text, title: 'Soon - Stroop Test' }); return; } catch {}
    }
    try {
      await navigator.clipboard.writeText(text);
      setShareMsg(t('games.copied'));
      setTimeout(() => setShareMsg(''), 3000);
    } catch { setShareMsg(text); }
  };

  const generateRound = useCallback(() => {
    const actualColor = COLORS[Math.floor(Math.random() * COLORS.length)];
    let textColor = COLORS[Math.floor(Math.random() * COLORS.length)];
    while (textColor.name === actualColor.name) {
      textColor = COLORS[Math.floor(Math.random() * COLORS.length)];
    }
    setWordColor(actualColor);
    setDisplayedColorName(textColor);

    const optionSet = new Set<string>([actualColor.name]);
    while (optionSet.size < 3) {
      optionSet.add(COLORS[Math.floor(Math.random() * COLORS.length)].name);
    }
    const shuffled = Array.from(optionSet)
      .map(name => COLORS.find(c => c.name === name)!)
      .sort(() => Math.random() - 0.5);
    setOptions(shuffled);
    setFeedback(null);
  }, []);

  useEffect(() => {
    if (phase !== 'playing') return;
    if (timeLeft <= 0) {
      setPhase('result');
      setStats(prev => ({
        totalPlayed: prev.totalPlayed + 1,
        bestScore: Math.max(prev.bestScore, score),
        bestStreak: Math.max(prev.bestStreak, maxStreak),
      }));
      return;
    }
    const timer = setTimeout(() => setTimeLeft(t => t - 1), 1000);
    return () => clearTimeout(timer);
  }, [phase, timeLeft]);

  const startGame = () => {
    setScore(0);
    setStreak(0);
    setMaxStreak(0);
    setTimeLeft(ROUND_TIME);
    setPhase('playing');
    generateRound();
  };

  const handleAnswer = (colorName: string) => {
    if (phase !== 'playing') return;
    if (colorName === wordColor.name) {
      const newStreak = streak + 1;
      setScore(s => s + 1);
      setStreak(newStreak);
      setMaxStreak(m => Math.max(m, newStreak));
      setFeedback('correct');
    } else {
      setStreak(0);
      setFeedback('wrong');
    }
    setTimeout(() => generateRound(), 300);
  };

  return (
    <div style={{ padding: '10px 0' }}>
      <button onClick={onBack} style={{
        background: 'none', border: 'none', color: '#01579b', fontSize: '1rem',
        cursor: 'pointer', marginBottom: '15px', fontFamily: 'Poppins, sans-serif',
      }}>← {t('games.back')}</button>

      <div style={{
        background: 'linear-gradient(135deg, #e8eaf6, #c5cae9)',
        borderRadius: '20px', padding: '20px', marginBottom: '15px', textAlign: 'center',
      }}>
        <h3 style={{ color: '#283593', margin: '0 0 5px' }}>🎨 {t('games.stroop_title')}</h3>
        <p style={{ color: '#3949ab', fontSize: '0.8rem', margin: 0 }}>{t('games.stroop_desc')}</p>
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-around', marginBottom: '15px' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '1.3rem', fontWeight: 700, color: '#283593' }}>{stats.totalPlayed}</div>
          <div style={{ fontSize: '0.75rem', color: '#9e9e9e' }}>{t('games.played')}</div>
        </div>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '1.3rem', fontWeight: 700, color: '#2e7d32' }}>{stats.bestScore}</div>
          <div style={{ fontSize: '0.75rem', color: '#9e9e9e' }}>{t('games.stroop_best')}</div>
        </div>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '1.3rem', fontWeight: 700, color: '#e65100' }}>{stats.bestStreak}</div>
          <div style={{ fontSize: '0.75rem', color: '#9e9e9e' }}>{t('games.stroop_streak')}</div>
        </div>
      </div>

      {phase === 'ready' && (
        <div>
          <div style={{
            background: '#fff3e0', borderRadius: '12px', padding: '15px', marginBottom: '15px',
            fontSize: '0.85rem', color: '#e65100', lineHeight: 1.6,
          }}>
            💡 {t('games.stroop_instruction')}
          </div>
          <button onClick={startGame} style={{
            width: '100%', background: '#3f51b5', color: 'white', border: 'none',
            borderRadius: '25px', padding: '15px', fontSize: '1.1rem', fontWeight: 600,
            cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
          }}>▶️ {t('games.start')}</button>
        </div>
      )}

      {phase === 'playing' && (
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '15px', padding: '0 10px' }}>
            <span style={{ fontWeight: 700, color: '#283593' }}>🏆 {score}</span>
            <span style={{ fontWeight: 700, color: '#e65100' }}>🔥 {streak}</span>
            <span style={{ fontWeight: 700, color: timeLeft <= 5 ? '#c62828' : '#616161' }}>⏱️ {timeLeft}s</span>
          </div>

          <div style={{
            background: feedback === 'correct' ? '#e8f5e9' : feedback === 'wrong' ? '#ffebee' : 'white',
            borderRadius: '20px', padding: '40px 20px', textAlign: 'center',
            marginBottom: '15px', boxShadow: '0 4px 15px rgba(0,0,0,0.08)',
            transition: 'background 0.2s',
          }}>
            <div style={{
              fontSize: '2.5rem', fontWeight: 900,
              color: wordColor.hex,
              fontFamily: 'Arial, sans-serif',
              letterSpacing: '3px',
            }}>
              {COLOR_NAMES[displayedColorName.name][lang] || COLOR_NAMES[displayedColorName.name].en}
            </div>
            <p style={{ fontSize: '0.8rem', color: '#9e9e9e', marginTop: '10px' }}>
              {t('games.stroop_question')}
            </p>
          </div>

          <div style={{ display: 'flex', gap: '10px' }}>
            {options.map(color => (
              <button key={color.name} onClick={() => handleAnswer(color.name)} style={{
                flex: 1, background: color.hex, color: 'white', border: 'none',
                borderRadius: '16px', padding: '18px 10px', fontSize: '0.9rem', fontWeight: 700,
                cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
                boxShadow: '0 3px 10px rgba(0,0,0,0.15)',
              }}>
                {COLOR_NAMES[color.name][lang] || COLOR_NAMES[color.name].en}
              </button>
            ))}
          </div>
        </div>
      )}

      {phase === 'result' && (
        <div style={{
          background: '#e8eaf6', borderRadius: '16px', padding: '25px', textAlign: 'center',
        }}>
          <div style={{ fontSize: '2.5rem', marginBottom: '8px' }}>🧠</div>
          <h4 style={{ color: '#283593', margin: '0 0 10px' }}>{t('games.stroop_result')}</h4>
          <div style={{ display: 'flex', justifyContent: 'space-around', marginBottom: '15px' }}>
            <div>
              <div style={{ fontSize: '2rem', fontWeight: 700, color: '#283593' }}>{score}</div>
              <div style={{ fontSize: '0.8rem', color: '#757575' }}>{t('games.stroop_score')}</div>
            </div>
            <div>
              <div style={{ fontSize: '2rem', fontWeight: 700, color: '#e65100' }}>{maxStreak}</div>
              <div style={{ fontSize: '0.8rem', color: '#757575' }}>{t('games.stroop_streak')}</div>
            </div>
          </div>
          <div style={{ display: 'flex', gap: '10px' }}>
            <button onClick={startGame} style={{
              flex: 1, background: '#3f51b5', color: 'white', border: 'none',
              borderRadius: '25px', padding: '12px', fontWeight: 600, cursor: 'pointer',
              fontFamily: 'Poppins, sans-serif',
            }}>🔄 {t('games.retry')}</button>
            <button onClick={handleShare} style={{
              flex: 1, background: '#1976d2', color: 'white', border: 'none',
              borderRadius: '25px', padding: '12px', fontWeight: 600, cursor: 'pointer',
              fontFamily: 'Poppins, sans-serif',
            }}>📤 {t('games.share')}</button>
          </div>
          {shareMsg && <p style={{ marginTop: '10px', fontSize: '0.85rem', color: '#1976d2', fontWeight: 600 }}>{shareMsg}</p>}
        </div>
      )}
    </div>
  );
}
