import { useState } from 'react';
import InlineAIChat from '../shared/InlineAIChat';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';

interface AngerEntry {
  id: string;
  trigger: string;
  intensity: number;
  response: string;
  date: string;
}

interface AngerPageProps {
  onBack: () => void;
}

export default function AngerPage({ onBack }: AngerPageProps) {
  const { t, lang } = useLanguage();
  const isRTL = lang === 'ar';
  const [entries, setEntries] = useLocalStorage<AngerEntry[]>('soon-anger', []);
  const [activeSection, setActiveSection] = useState<'home' | 'calm' | 'log' | 'history'>('home');
  const [calmStep, setCalmStep] = useState(0);
  const [trigger, setTrigger] = useState('');
  const [intensity, setIntensity] = useState(5);
  const [response, setResponse] = useState('');

  const calmSteps = [
    { icon: '🛑', text: t('anger.stop') },
    { icon: '🧘', text: t('anger.breathe_deep') },
    { icon: '🔢', text: t('anger.count_10') },
    { icon: '💭', text: t('anger.this_will_pass') },
    { icon: '❤️', text: t('anger.wont_stay_angry') },
    { icon: '✅', text: t('anger.choose_peace') },
  ];

  const nextStep = () => {
    if (calmStep < calmSteps.length - 1) setCalmStep(prev => prev + 1);
    else setCalmStep(0);
  };

  const saveAnger = () => {
    if (!trigger.trim()) return;
    setEntries(prev => [{ id: Date.now().toString(), trigger: trigger.trim(), intensity, response: response.trim(), date: new Date().toISOString() }, ...prev]);
    setTrigger(''); setIntensity(5); setResponse('');
  };

  return (
    <div style={{ paddingTop: '20px', direction: isRTL ? 'rtl' : 'ltr' }}>
      <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#fb6340', fontSize: '1rem', cursor: 'pointer', marginBottom: '15px' }}>
        <i className={`fas fa-arrow-${isRTL ? 'right' : 'left'}`}></i> {t('nav.home')}
      </button>

      <div style={{ background: 'linear-gradient(135deg, #fb6340, #fbb140)', borderRadius: '20px', padding: '25px', color: 'white', textAlign: 'center', marginBottom: '20px' }}>
        <div style={{ fontSize: '2.5rem', marginBottom: '10px' }}>🕊️</div>
        <h2 style={{ fontSize: '1.3rem', fontWeight: 700, margin: '0 0 8px' }}>{t('anger.title')}</h2>
        <p style={{ fontSize: '0.85rem', opacity: 0.9, margin: 0, fontStyle: 'italic' }}>"{t('anger.motto')}"</p>
      </div>

      {activeSection === 'home' && (
        <div style={{ display: 'grid', gap: '12px' }}>
          <div onClick={() => setActiveSection('calm')} style={{ background: 'white', borderRadius: '16px', padding: '20px', cursor: 'pointer', boxShadow: '0 4px 15px rgba(0,0,0,0.05)', display: 'flex', alignItems: 'center', gap: '15px' }}>
            <div style={{ fontSize: '2rem', width: '50px', textAlign: 'center' }}>🛑</div>
            <div>
              <div style={{ fontWeight: 600, color: '#32325d' }}>{t('anger.calm_now')}</div>
              <div style={{ color: '#8898aa', fontSize: '0.75rem' }}>{t('anger.calm_desc')}</div>
            </div>
          </div>
          <div onClick={() => setActiveSection('log')} style={{ background: 'white', borderRadius: '16px', padding: '20px', cursor: 'pointer', boxShadow: '0 4px 15px rgba(0,0,0,0.05)', display: 'flex', alignItems: 'center', gap: '15px' }}>
            <div style={{ fontSize: '2rem', width: '50px', textAlign: 'center' }}>📝</div>
            <div>
              <div style={{ fontWeight: 600, color: '#32325d' }}>{t('anger.log_anger')}</div>
              <div style={{ color: '#8898aa', fontSize: '0.75rem' }}>{t('anger.log_desc')}</div>
            </div>
          </div>
          <div onClick={() => setActiveSection('history')} style={{ background: 'white', borderRadius: '16px', padding: '20px', cursor: 'pointer', boxShadow: '0 4px 15px rgba(0,0,0,0.05)', display: 'flex', alignItems: 'center', gap: '15px' }}>
            <div style={{ fontSize: '2rem', width: '50px', textAlign: 'center' }}>📋</div>
            <div>
              <div style={{ fontWeight: 600, color: '#32325d' }}>{t('anger.my_history')}</div>
              <div style={{ color: '#8898aa', fontSize: '0.75rem' }}>{entries.length} {t('anger.entries')}</div>
            </div>
          </div>
        </div>
      )}

      {activeSection === 'calm' && (
        <div style={{ textAlign: 'center' }}>
          <button onClick={() => setActiveSection('home')} style={{ background: 'none', border: 'none', color: '#fb6340', cursor: 'pointer', marginBottom: '15px' }}>← {t('anx.back')}</button>
          <div style={{
            background: 'linear-gradient(135deg, #fb6340, #fbb140)', borderRadius: '20px', padding: '40px 25px',
            color: 'white', marginBottom: '20px'
          }}>
            <div style={{ fontSize: '4rem', marginBottom: '20px' }}>{calmSteps[calmStep].icon}</div>
            <p style={{ fontSize: '1.3rem', fontWeight: 700, lineHeight: 1.6, margin: '0 0 10px' }}>{calmSteps[calmStep].text}</p>
            <div style={{ fontSize: '0.8rem', opacity: 0.8 }}>{calmStep + 1} / {calmSteps.length}</div>
          </div>
          <button onClick={nextStep} style={{ background: 'linear-gradient(135deg, #fb6340, #fbb140)', color: 'white', border: 'none', borderRadius: '25px', padding: '14px 40px', fontWeight: 600, cursor: 'pointer', fontSize: '1rem' }}>
            {calmStep < calmSteps.length - 1 ? t('anger.next') : t('anger.restart')}
          </button>
        </div>
      )}

      {activeSection === 'log' && (
        <div>
          <button onClick={() => setActiveSection('home')} style={{ background: 'none', border: 'none', color: '#fb6340', cursor: 'pointer', marginBottom: '15px' }}>← {t('anx.back')}</button>
          <div style={{ background: 'white', borderRadius: '16px', padding: '20px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)' }}>
            <h4 style={{ color: '#fb6340', marginBottom: '15px' }}>📝 {t('anger.what_happened')}</h4>
            <textarea value={trigger} onChange={e => setTrigger(e.target.value)} placeholder={t('anger.trigger_placeholder')}
              style={{ width: '100%', padding: '12px', border: '2px solid #fff5f0', borderRadius: '12px', minHeight: '80px', resize: 'vertical', boxSizing: 'border-box', marginBottom: '10px' }} />
            <div style={{ marginBottom: '10px' }}>
              <label style={{ color: '#32325d', fontSize: '0.85rem', fontWeight: 600 }}>{t('anger.intensity')}: {intensity}/10</label>
              <input type="range" min="1" max="10" value={intensity} onChange={e => setIntensity(parseInt(e.target.value))}
                style={{ width: '100%' }} />
            </div>
            <textarea value={response} onChange={e => setResponse(e.target.value)} placeholder={t('anger.response_placeholder')}
              style={{ width: '100%', padding: '12px', border: '2px solid #fff5f0', borderRadius: '12px', minHeight: '60px', resize: 'vertical', boxSizing: 'border-box', marginBottom: '15px' }} />
            <button onClick={saveAnger} style={{ width: '100%', background: 'linear-gradient(135deg, #fb6340, #fbb140)', color: 'white', border: 'none', borderRadius: '12px', padding: '14px', fontWeight: 600, cursor: 'pointer' }}>
              {t('anger.save')}
            </button>
          </div>
        </div>
      )}

      {activeSection === 'history' && (
        <div>
          <button onClick={() => setActiveSection('home')} style={{ background: 'none', border: 'none', color: '#fb6340', cursor: 'pointer', marginBottom: '15px' }}>← {t('anx.back')}</button>
          {entries.length === 0 && <p style={{ textAlign: 'center', color: '#8898aa' }}>{t('anger.empty')}</p>}
          {entries.map(e => (
            <div key={e.id} style={{ background: 'white', borderRadius: '12px', padding: '15px', marginBottom: '10px', borderLeft: '4px solid #fb6340' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px' }}>
                <span style={{ fontSize: '0.8rem', fontWeight: 600, color: '#fb6340' }}>{t('anger.intensity')}: {e.intensity}/10</span>
                <span style={{ fontSize: '0.7rem', color: '#aaa' }}>{new Date(e.date).toLocaleDateString()}</span>
              </div>
              <p style={{ color: '#32325d', margin: '5px 0', fontSize: '0.85rem' }}>{e.trigger}</p>
              {e.response && <p style={{ color: '#2DCE89', margin: 0, fontSize: '0.8rem' }}>💚 {e.response}</p>}
            </div>
          ))}
        </div>
      )}
      <InlineAIChat context="anger" lang={lang} />
    </div>
  );
}
