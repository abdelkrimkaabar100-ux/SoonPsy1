import { useState } from 'react';
import InlineAIChat from '../shared/InlineAIChat';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';

interface Hobby {
  id: string;
  name: string;
  icon: string;
  category: string;
  date: string;
  note: string;
}

interface HobbiesPageProps {
  onBack: () => void;
}

const defaultHobbies = [
  { name: 'hobbies.basketball', icon: '🏀', cat: 'sports' },
  { name: 'hobbies.football', icon: '⚽', cat: 'sports' },
  { name: 'hobbies.swimming', icon: '🏊', cat: 'sports' },
  { name: 'hobbies.running', icon: '🏃', cat: 'sports' },
  { name: 'hobbies.cycling', icon: '🚴', cat: 'sports' },
  { name: 'hobbies.tennis', icon: '🎾', cat: 'sports' },
  { name: 'hobbies.drawing', icon: '🎨', cat: 'art' },
  { name: 'hobbies.photography', icon: '📷', cat: 'art' },
  { name: 'hobbies.writing', icon: '✍️', cat: 'art' },
  { name: 'hobbies.music', icon: '🎵', cat: 'art' },
  { name: 'hobbies.reading', icon: '📖', cat: 'mind' },
  { name: 'hobbies.cooking', icon: '👨‍🍳', cat: 'life' },
  { name: 'hobbies.gardening', icon: '🌱', cat: 'life' },
  { name: 'hobbies.gaming', icon: '🎮', cat: 'fun' },
  { name: 'hobbies.hiking', icon: '🥾', cat: 'sports' },
  { name: 'hobbies.yoga', icon: '🧘', cat: 'mind' },
  { name: 'hobbies.dancing', icon: '💃', cat: 'art' },
  { name: 'hobbies.crafts', icon: '🧶', cat: 'art' },
];

export default function HobbiesPage({ onBack }: HobbiesPageProps) {
  const { t, lang } = useLanguage();
  const isRTL = lang === 'ar';
  const [myHobbies, setMyHobbies] = useLocalStorage<Hobby[]>('soon-hobbies', []);
  const [customHobby, setCustomHobby] = useState('');
  const [note, setNote] = useState('');
  const [selectedHobby, setSelectedHobby] = useState('');

  const addHobby = (name: string, icon: string, category: string) => {
    setMyHobbies(prev => [{
      id: Date.now().toString(), name, icon, category, date: new Date().toISOString(), note: note.trim(),
    }, ...prev]);
    setNote('');
    setSelectedHobby('');
  };

  const addCustom = () => {
    if (!customHobby.trim()) return;
    addHobby(customHobby.trim(), '⭐', 'custom');
    setCustomHobby('');
  };

  const todayCount = myHobbies.filter(h => new Date(h.date).toDateString() === new Date().toDateString()).length;

  return (
    <div style={{ paddingTop: '20px', direction: isRTL ? 'rtl' : 'ltr' }}>
      <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#2DCE89', fontSize: '1rem', cursor: 'pointer', marginBottom: '15px', fontFamily: 'Poppins, sans-serif' }}>
        <i className={`fas fa-arrow-${isRTL ? 'right' : 'left'}`}></i> {t('nav.home')}
      </button>

      <div style={{ textAlign: 'center', marginBottom: '20px' }}>
        <h2 style={{ color: '#32325d', fontSize: '1.5rem', margin: '0 0 5px' }}>🎯 {t('hobbies.title')}</h2>
        <p style={{ color: '#8898aa', fontSize: '0.85rem', margin: 0 }}>{t('hobbies.subtitle')}</p>
      </div>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginBottom: '20px' }}>
        <div style={{ background: 'linear-gradient(135deg, #2DCE89, #1a9f6e)', borderRadius: '12px', padding: '15px', color: 'white', textAlign: 'center' }}>
          <div style={{ fontSize: '1.8rem', fontWeight: 700 }}>{todayCount}</div>
          <div style={{ fontSize: '0.75rem', opacity: 0.9 }}>{t('hobbies.today')}</div>
        </div>
        <div style={{ background: 'linear-gradient(135deg, #5e72e4, #825ee4)', borderRadius: '12px', padding: '15px', color: 'white', textAlign: 'center' }}>
          <div style={{ fontSize: '1.8rem', fontWeight: 700 }}>{myHobbies.length}</div>
          <div style={{ fontSize: '0.75rem', opacity: 0.9 }}>{t('hobbies.total')}</div>
        </div>
      </div>

      {/* Select hobby */}
      <div style={{ background: 'white', borderRadius: '16px', padding: '15px', marginBottom: '15px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
        <h4 style={{ color: '#32325d', marginBottom: '10px', fontSize: '0.95rem' }}>{t('hobbies.log_today')}</h4>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginBottom: '10px' }}>
          {defaultHobbies.map(h => (
            <button key={h.name} onClick={() => setSelectedHobby(h.name === selectedHobby ? '' : h.name)} style={{
              padding: '8px 12px', borderRadius: '20px', border: 'none', cursor: 'pointer',
              background: selectedHobby === h.name ? '#2DCE89' : '#f0f4ff',
              color: selectedHobby === h.name ? 'white' : '#32325d',
              fontSize: '0.75rem', fontWeight: 600, fontFamily: 'Poppins, sans-serif',
            }}>
              {h.icon} {t(h.name)}
            </button>
          ))}
        </div>

        {selectedHobby && (
          <div style={{ marginTop: '10px' }}>
            <input type="text" value={note} onChange={e => setNote(e.target.value)} placeholder={t('hobbies.note_placeholder')}
              style={{ width: '100%', padding: '8px 14px', border: '1px solid #e0e0e0', borderRadius: '10px', marginBottom: '8px', fontFamily: 'Poppins, sans-serif', fontSize: '0.8rem', boxSizing: 'border-box' }} />
            <button onClick={() => {
              const hobby = defaultHobbies.find(h => h.name === selectedHobby);
              if (hobby) addHobby(t(hobby.name), hobby.icon, hobby.cat);
            }} style={{
              width: '100%', background: '#2DCE89', color: 'white', border: 'none', borderRadius: '20px',
              padding: '10px', fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
            }}>
              ✓ {t('hobbies.log_it')}
            </button>
          </div>
        )}

        {/* Custom hobby */}
        <div style={{ marginTop: '12px', display: 'flex', gap: '8px' }}>
          <input type="text" value={customHobby} onChange={e => setCustomHobby(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && addCustom()}
            placeholder={t('hobbies.custom_placeholder')}
            style={{ flex: 1, padding: '8px 14px', border: '1px solid #e0e0e0', borderRadius: '20px', fontFamily: 'Poppins, sans-serif', fontSize: '0.8rem' }} />
          <button onClick={addCustom} style={{ background: '#5e72e4', color: 'white', border: 'none', borderRadius: '50%', width: 36, height: 36, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>+</button>
        </div>
      </div>

      {/* History */}
      <h4 style={{ color: '#32325d', marginBottom: '10px' }}>📋 {t('hobbies.history')}</h4>
      {myHobbies.length === 0 && <p style={{ textAlign: 'center', color: '#8898aa' }}>{t('hobbies.empty')}</p>}
      {myHobbies.slice(0, 30).map(h => (
        <div key={h.id} style={{ background: 'white', borderRadius: '10px', padding: '10px 14px', marginBottom: '8px', boxShadow: '0 2px 6px rgba(0,0,0,0.04)', display: 'flex', alignItems: 'center', gap: '10px' }}>
          <span style={{ fontSize: '1.5rem' }}>{h.icon}</span>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: '0.85rem', fontWeight: 600, color: '#32325d' }}>{h.name}</div>
            {h.note && <div style={{ fontSize: '0.75rem', color: '#8898aa' }}>{h.note}</div>}
          </div>
          <div style={{ fontSize: '0.7rem', color: '#aaa' }}>{new Date(h.date).toLocaleDateString()}</div>
        </div>
      ))}

      {/* Info */}
      <div style={{ background: 'linear-gradient(135deg, #d1efe1, #e8f5e8)', borderRadius: '16px', padding: '15px', marginTop: '15px', borderLeft: '4px solid #2DCE89' }}>
        <h4 style={{ color: '#1a9f6e', marginBottom: '8px' }}>💡 {t('hobbies.benefit_title')}</h4>
        <p style={{ color: '#32325d', fontSize: '0.85rem', lineHeight: 1.6, margin: 0 }}>{t('hobbies.benefit_desc')}</p>
      </div>
      <InlineAIChat context="hobbies" lang={lang} />
    </div>
  );
}
