import { useState } from 'react';
import InlineAIChat from '../shared/InlineAIChat';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { useLanguage } from '../../i18n/LanguageContext';

interface PositiveEntry {
  id: string;
  content: string;
  date: string;
}

export default function PositiveSelfPage({ onShareWithAI }: { onShareWithAI: (text: string) => void }) {
  const { t, lang } = useLanguage();
  const [entries, setEntries] = useLocalStorage<PositiveEntry[]>('soon-positive-self', []);
  const [input, setInput] = useState('');

  const prompts = [
    t('positive.prompt1'),
    t('positive.prompt2'),
    t('positive.prompt3'),
    t('positive.prompt4'),
    t('positive.prompt5'),
  ];

  const save = () => {
    if (!input.trim()) return;
    setEntries([...entries, { id: Date.now().toString(), content: input.trim(), date: new Date().toISOString() }]);
    setInput('');
  };

  const todayEntries = entries.filter(e => new Date(e.date).toDateString() === new Date().toDateString());

  return (
    <div style={{ padding: '10px 0' }}>
      <div style={{
        background: 'linear-gradient(135deg, #ffecd2, #fcb69f)',
        borderRadius: '20px', padding: '25px', marginBottom: '20px',
        textAlign: 'center',
      }}>
        <div style={{ fontSize: '3rem', marginBottom: '10px' }}>🌟</div>
        <h2 style={{ color: '#5d4037', margin: '0 0 8px', fontSize: '1.4rem' }}>{t('positive.title')}</h2>
        <p style={{ color: '#6d4c41', fontSize: '0.9rem', margin: 0 }}>{t('positive.subtitle')}</p>
      </div>

      <div style={{
        background: 'white', borderRadius: '16px', padding: '20px',
        boxShadow: '0 4px 15px rgba(0,0,0,0.08)', marginBottom: '15px',
      }}>
        <h4 style={{ color: '#5d4037', marginBottom: '12px', fontSize: '1rem' }}>
          💡 {t('positive.prompts_title')}
        </h4>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginBottom: '15px' }}>
          {prompts.map((p, i) => (
            <button key={i} onClick={() => setInput(prev => prev ? prev + '\n' + p : p)} style={{
              background: '#fff3e0', border: '1px solid #ffcc80', borderRadius: '20px',
              padding: '8px 14px', fontSize: '0.8rem', cursor: 'pointer', color: '#e65100',
              fontFamily: 'Poppins, sans-serif',
            }}>{p}</button>
          ))}
        </div>

        <textarea
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder={t('positive.placeholder')}
          style={{
            width: '100%', padding: '14px', border: '2px solid #ffe0b2', borderRadius: '14px',
            fontFamily: 'Poppins, sans-serif', fontSize: '0.95rem', resize: 'vertical',
            minHeight: '120px', outline: 'none', boxSizing: 'border-box',
            transition: 'border-color 0.3s',
          }}
          onFocus={e => e.target.style.borderColor = '#ff9800'}
          onBlur={e => e.target.style.borderColor = '#ffe0b2'}
        />

        <div style={{ display: 'flex', gap: '10px', marginTop: '12px' }}>
          <button onClick={save} style={{
            flex: 1, background: '#ff9800', color: 'white', border: 'none', borderRadius: '25px',
            padding: '12px', fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
          }}>💛 {t('positive.save')}</button>
          <button onClick={() => onShareWithAI(`Positive things I wrote about myself: ${input}`)} style={{
            flex: 1, background: '#4caf50', color: 'white', border: 'none', borderRadius: '25px',
            padding: '12px', fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
          }}>🤖 {t('positive.share_ai')}</button>
        </div>
      </div>

      {todayEntries.length > 0 && (
        <div style={{
          background: 'white', borderRadius: '16px', padding: '20px',
          boxShadow: '0 4px 15px rgba(0,0,0,0.08)', marginBottom: '15px',
        }}>
          <h4 style={{ color: '#e65100', marginBottom: '12px' }}>🌈 {t('positive.today')}</h4>
          {todayEntries.map(e => (
            <div key={e.id} style={{
              background: '#fff8e1', borderRadius: '12px', padding: '12px',
              marginBottom: '8px', borderLeft: '4px solid #ff9800',
              fontSize: '0.9rem', color: '#5d4037', lineHeight: 1.6, whiteSpace: 'pre-wrap',
            }}>{e.content}</div>
          ))}
        </div>
      )}

      <div style={{
        background: 'white', borderRadius: '16px', padding: '20px',
        boxShadow: '0 4px 15px rgba(0,0,0,0.08)',
      }}>
        <div style={{ textAlign: 'center', color: '#e65100' }}>
          <div style={{ fontSize: '2rem', fontWeight: 700 }}>{entries.length}</div>
          <div style={{ fontSize: '0.85rem', color: '#8d6e63' }}>{t('positive.total')}</div>
        </div>
      </div>
      <InlineAIChat context="positive-self" lang={lang} />
    </div>
  );
}
