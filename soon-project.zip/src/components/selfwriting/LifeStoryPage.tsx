import { useState } from 'react';
import InlineAIChat from '../shared/InlineAIChat';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { useLanguage } from '../../i18n/LanguageContext';

interface StoryChapter {
  id: string;
  title: string;
  content: string;
  date: string;
}

export default function LifeStoryPage({ onShareWithAI }: { onShareWithAI: (text: string) => void }) {
  const { t, lang } = useLanguage();
  const [chapters, setChapters] = useLocalStorage<StoryChapter[]>('soon-life-story', []);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [viewChapter, setViewChapter] = useState<string | null>(null);

  const chapterPrompts = [
    t('story.ch1'), t('story.ch2'), t('story.ch3'),
    t('story.ch4'), t('story.ch5'), t('story.ch6'),
  ];

  const save = () => {
    if (!title.trim() || !content.trim()) return;
    setChapters([...chapters, {
      id: Date.now().toString(), title: title.trim(),
      content: content.trim(), date: new Date().toISOString(),
    }]);
    setTitle(''); setContent('');
  };

  return (
    <div style={{ padding: '10px 0' }}>
      <div style={{
        background: 'linear-gradient(135deg, #e8eaf6, #c5cae9)',
        borderRadius: '20px', padding: '25px', marginBottom: '20px', textAlign: 'center',
      }}>
        <div style={{ fontSize: '3rem', marginBottom: '10px' }}>📖</div>
        <h2 style={{ color: '#283593', margin: '0 0 8px', fontSize: '1.4rem' }}>{t('story.title')}</h2>
        <p style={{ color: '#3949ab', fontSize: '0.9rem', margin: 0 }}>{t('story.subtitle')}</p>
      </div>

      <div style={{
        background: 'white', borderRadius: '16px', padding: '20px',
        boxShadow: '0 4px 15px rgba(0,0,0,0.08)', marginBottom: '15px',
      }}>
        <h4 style={{ color: '#283593', marginBottom: '10px' }}>✍️ {t('story.write_chapter')}</h4>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginBottom: '12px' }}>
          {chapterPrompts.map((p, i) => (
            <button key={i} onClick={() => setTitle(p)} style={{
              background: '#e8eaf6', border: '1px solid #9fa8da', borderRadius: '20px',
              padding: '6px 12px', fontSize: '0.75rem', cursor: 'pointer', color: '#283593',
              fontFamily: 'Poppins, sans-serif',
            }}>{p}</button>
          ))}
        </div>

        <input
          value={title}
          onChange={e => setTitle(e.target.value)}
          placeholder={t('story.title_placeholder')}
          style={{
            width: '100%', padding: '12px', border: '2px solid #c5cae9', borderRadius: '12px',
            fontFamily: 'Poppins, sans-serif', fontSize: '1rem', fontWeight: 600,
            outline: 'none', boxSizing: 'border-box', marginBottom: '10px',
          }}
        />
        <textarea
          value={content}
          onChange={e => setContent(e.target.value)}
          placeholder={t('story.content_placeholder')}
          style={{
            width: '100%', padding: '14px', border: '2px solid #c5cae9', borderRadius: '14px',
            fontFamily: 'Poppins, sans-serif', fontSize: '0.95rem', resize: 'vertical',
            minHeight: '150px', outline: 'none', boxSizing: 'border-box',
          }}
        />
        <div style={{ display: 'flex', gap: '10px', marginTop: '12px' }}>
          <button onClick={save} style={{
            flex: 1, background: '#3f51b5', color: 'white', border: 'none', borderRadius: '25px',
            padding: '12px', fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
          }}>📝 {t('story.save')}</button>
          <button onClick={() => onShareWithAI(`My life story chapter "${title}": ${content}`)} style={{
            flex: 1, background: '#4caf50', color: 'white', border: 'none', borderRadius: '25px',
            padding: '12px', fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
          }}>🤖 {t('story.share_ai')}</button>
        </div>
      </div>

      {chapters.length > 0 && (
        <div style={{
          background: 'white', borderRadius: '16px', padding: '20px',
          boxShadow: '0 4px 15px rgba(0,0,0,0.08)',
        }}>
          <h4 style={{ color: '#283593', marginBottom: '15px' }}>📚 {t('story.my_chapters')} ({chapters.length})</h4>
          {[...chapters].reverse().map(ch => (
            <div key={ch.id} onClick={() => setViewChapter(viewChapter === ch.id ? null : ch.id)} style={{
              background: viewChapter === ch.id ? '#e8eaf6' : '#f5f5f5',
              borderRadius: '12px', padding: '14px', marginBottom: '10px', cursor: 'pointer',
              borderLeft: '4px solid #3f51b5', transition: 'all 0.3s',
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <strong style={{ color: '#283593', fontSize: '0.95rem' }}>{ch.title}</strong>
                <span style={{ fontSize: '0.75rem', color: '#9e9e9e' }}>
                  {new Date(ch.date).toLocaleDateString()}
                </span>
              </div>
              {viewChapter === ch.id && (
                <div style={{
                  marginTop: '10px', fontSize: '0.9rem', color: '#424242',
                  lineHeight: 1.7, whiteSpace: 'pre-wrap',
                }}>{ch.content}</div>
              )}
            </div>
          ))}
        </div>
      )}
      <InlineAIChat context="life-story" lang={lang} />
    </div>
  );
}
