import { useState } from 'react';
import InlineAIChat from '../shared/InlineAIChat';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';

interface AnxietyEntry {
  id: string;
  technique: string;
  feeling_before: string;
  feeling_after: string;
  date: string;
}

interface AnxietyPageProps {
  onBack: () => void;
}

export default function AnxietyPage({ onBack }: AnxietyPageProps) {
  const { t, lang } = useLanguage();
  const isRTL = lang === 'ar';
  const [entries, setEntries] = useLocalStorage<AnxietyEntry[]>('soon-anxiety', []);
  const [activeSection, setActiveSection] = useState<'home' | 'breathe' | 'worst' | 'gratitude' | 'history'>('home');
  const [breathPhase, setBreathPhase] = useState<'idle' | 'inhale' | 'hold' | 'exhale'>('idle');
  const [breathCount, setBreathCount] = useState(0);
  const [worstCase, setWorstCase] = useState('');
  const [worstAcceptance, setWorstAcceptance] = useState('');
  const [feelingBefore, setFeelingBefore] = useState('');
  const [feelingAfter, setFeelingAfter] = useState('');

  const startBreathing = () => {
    let count = 0;
    const cycle = () => {
      if (count >= 4) { setBreathPhase('idle'); setBreathCount(prev => prev + 1); return; }
      setBreathPhase('inhale');
      setTimeout(() => {
        setBreathPhase('hold');
        setTimeout(() => {
          setBreathPhase('exhale');
          setTimeout(() => { count++; cycle(); }, 4000);
        }, 4000);
      }, 4000);
    };
    cycle();
  };

  const saveWorstCase = () => {
    if (!worstCase.trim()) return;
    setEntries(prev => [{
      id: Date.now().toString(), technique: 'worst-case',
      feeling_before: feelingBefore, feeling_after: feelingAfter || worstAcceptance,
      date: new Date().toISOString()
    }, ...prev]);
    setWorstCase(''); setWorstAcceptance(''); setFeelingBefore(''); setFeelingAfter('');
  };

  const techniques = [
    { id: 'breathe', icon: '🌬️', label: t('anx.breathe'), desc: t('anx.breathe_desc') },
    { id: 'worst', icon: '🎯', label: t('anx.worst_case'), desc: t('anx.worst_desc') },
    { id: 'gratitude', icon: '🙏', label: t('anx.still_alive'), desc: t('anx.still_alive_desc') },
  ];

  const phaseLabels: Record<string, string> = {
    idle: t('anx.start'), inhale: t('anx.inhale'), hold: t('anx.hold'), exhale: t('anx.exhale')
  };

  const phaseColors: Record<string, string> = {
    idle: '#8898aa', inhale: '#2DCE89', hold: '#5e72e4', exhale: '#fb6340'
  };

  return (
    <div style={{ paddingTop: '20px', direction: isRTL ? 'rtl' : 'ltr' }}>
      <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#5e72e4', fontSize: '1rem', cursor: 'pointer', marginBottom: '15px' }}>
        <i className={`fas fa-arrow-${isRTL ? 'right' : 'left'}`}></i> {t('nav.home')}
      </button>

      <div style={{ background: 'linear-gradient(135deg, #5e72e4, #825ee4)', borderRadius: '20px', padding: '25px', color: 'white', textAlign: 'center', marginBottom: '20px' }}>
        <div style={{ fontSize: '2.5rem', marginBottom: '10px' }}>🧘</div>
        <h2 style={{ fontSize: '1.3rem', fontWeight: 700, margin: '0 0 8px' }}>{t('anx.title')}</h2>
        <p style={{ fontSize: '0.85rem', opacity: 0.9, margin: '0 0 5px' }}>{t('anx.subtitle')}</p>
        <p style={{ fontSize: '0.75rem', opacity: 0.8, margin: 0, fontStyle: 'italic' }}>"{t('anx.motto')}"</p>
      </div>

      {activeSection === 'home' && (
        <div>
          <div style={{ background: '#fff3cd', borderRadius: '14px', padding: '15px', marginBottom: '20px', borderLeft: '4px solid #ffc107' }}>
            <p style={{ color: '#856404', fontSize: '0.85rem', fontWeight: 600, margin: 0 }}>⚡ {t('anx.first_rule')}</p>
          </div>

          <div style={{ display: 'grid', gap: '12px' }}>
            {techniques.map(tech => (
              <div key={tech.id} onClick={() => setActiveSection(tech.id as any)} style={{
                background: 'white', borderRadius: '16px', padding: '20px', cursor: 'pointer',
                boxShadow: '0 4px 15px rgba(0,0,0,0.05)', display: 'flex', alignItems: 'center', gap: '15px'
              }}>
                <div style={{ fontSize: '2rem', width: '50px', textAlign: 'center' }}>{tech.icon}</div>
                <div>
                  <div style={{ fontWeight: 600, color: '#32325d', fontSize: '0.95rem' }}>{tech.label}</div>
                  <div style={{ color: '#8898aa', fontSize: '0.75rem' }}>{tech.desc}</div>
                </div>
              </div>
            ))}
          </div>

          <div style={{ background: 'white', borderRadius: '16px', padding: '20px', marginTop: '15px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)' }}>
            <h4 style={{ color: '#5e72e4', marginBottom: '10px' }}>💡 {t('anx.tips_title')}</h4>
            <ul style={{ color: '#32325d', fontSize: '0.85rem', lineHeight: 2, paddingLeft: '20px', paddingRight: '20px', margin: 0 }}>
              <li>{t('anx.tip1')}</li>
              <li>{t('anx.tip2')}</li>
              <li>{t('anx.tip3')}</li>
              <li>{t('anx.tip4')}</li>
              <li>{t('anx.tip5')}</li>
            </ul>
          </div>

          <button onClick={() => setActiveSection('history')} style={{ width: '100%', background: '#f7f8fa', border: 'none', borderRadius: '12px', padding: '12px', marginTop: '15px', cursor: 'pointer', color: '#5e72e4', fontWeight: 600 }}>
            📋 {t('anx.my_history')} ({entries.length})
          </button>
        </div>
      )}

      {activeSection === 'breathe' && (
        <div style={{ textAlign: 'center' }}>
          <button onClick={() => setActiveSection('home')} style={{ background: 'none', border: 'none', color: '#5e72e4', cursor: 'pointer', marginBottom: '15px' }}>← {t('anx.back')}</button>
          <div style={{
            width: '200px', height: '200px', borderRadius: '50%', margin: '20px auto',
            background: `radial-gradient(circle, ${phaseColors[breathPhase]}22, ${phaseColors[breathPhase]}44)`,
            border: `4px solid ${phaseColors[breathPhase]}`, display: 'flex', alignItems: 'center', justifyContent: 'center',
            transition: 'all 1s ease', transform: breathPhase === 'inhale' ? 'scale(1.2)' : breathPhase === 'exhale' ? 'scale(0.8)' : 'scale(1)'
          }}>
            <div>
              <div style={{ fontSize: '2rem' }}>🌬️</div>
              <div style={{ fontSize: '1.1rem', fontWeight: 700, color: phaseColors[breathPhase] }}>{phaseLabels[breathPhase]}</div>
            </div>
          </div>
          {breathPhase === 'idle' && (
            <button onClick={startBreathing} style={{ background: 'linear-gradient(135deg, #5e72e4, #825ee4)', color: 'white', border: 'none', borderRadius: '25px', padding: '14px 30px', fontWeight: 600, cursor: 'pointer', fontSize: '1rem' }}>
              {t('anx.start_breathing')}
            </button>
          )}
          <div style={{ marginTop: '15px', color: '#8898aa', fontSize: '0.85rem' }}>
            {t('anx.cycles_done')}: {breathCount}
          </div>
        </div>
      )}

      {activeSection === 'worst' && (
        <div>
          <button onClick={() => setActiveSection('home')} style={{ background: 'none', border: 'none', color: '#5e72e4', cursor: 'pointer', marginBottom: '15px' }}>← {t('anx.back')}</button>
          <div style={{ background: 'white', borderRadius: '16px', padding: '20px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)' }}>
            <h4 style={{ color: '#5e72e4', marginBottom: '10px' }}>🎯 {t('anx.worst_case')}</h4>
            <p style={{ color: '#8898aa', fontSize: '0.85rem', marginBottom: '15px' }}>{t('anx.worst_explain')}</p>
            <input value={feelingBefore} onChange={e => setFeelingBefore(e.target.value)} placeholder={t('anx.feeling_before')}
              style={{ width: '100%', padding: '12px', border: '2px solid #f0f4ff', borderRadius: '12px', marginBottom: '10px', boxSizing: 'border-box' }} />
            <textarea value={worstCase} onChange={e => setWorstCase(e.target.value)} placeholder={t('anx.worst_placeholder')}
              style={{ width: '100%', padding: '12px', border: '2px solid #f0f4ff', borderRadius: '12px', minHeight: '80px', resize: 'vertical', boxSizing: 'border-box', marginBottom: '10px' }} />
            <textarea value={worstAcceptance} onChange={e => setWorstAcceptance(e.target.value)} placeholder={t('anx.accept_placeholder')}
              style={{ width: '100%', padding: '12px', border: '2px solid #f0f4ff', borderRadius: '12px', minHeight: '60px', resize: 'vertical', boxSizing: 'border-box', marginBottom: '10px' }} />
            <div style={{ background: '#d4edda', borderRadius: '12px', padding: '15px', marginBottom: '15px' }}>
              <p style={{ color: '#155724', fontSize: '0.9rem', fontWeight: 600, margin: 0 }}>✅ {t('anx.still_here')}</p>
            </div>
            <input value={feelingAfter} onChange={e => setFeelingAfter(e.target.value)} placeholder={t('anx.feeling_after')}
              style={{ width: '100%', padding: '12px', border: '2px solid #f0f4ff', borderRadius: '12px', marginBottom: '15px', boxSizing: 'border-box' }} />
            <button onClick={saveWorstCase} style={{ width: '100%', background: 'linear-gradient(135deg, #5e72e4, #825ee4)', color: 'white', border: 'none', borderRadius: '12px', padding: '14px', fontWeight: 600, cursor: 'pointer' }}>
              {t('anx.save')}
            </button>
          </div>
        </div>
      )}

      {activeSection === 'gratitude' && (
        <div>
          <button onClick={() => setActiveSection('home')} style={{ background: 'none', border: 'none', color: '#5e72e4', cursor: 'pointer', marginBottom: '15px' }}>← {t('anx.back')}</button>
          <div style={{ background: 'white', borderRadius: '16px', padding: '25px', textAlign: 'center', boxShadow: '0 4px 15px rgba(0,0,0,0.05)' }}>
            <div style={{ fontSize: '3rem', marginBottom: '15px' }}>🙏❤️</div>
            <h3 style={{ color: '#2DCE89', marginBottom: '15px' }}>{t('anx.alive_title')}</h3>
            <div style={{ display: 'grid', gap: '12px', textAlign: isRTL ? 'right' : 'left' }}>
              {[t('anx.yes1'), t('anx.yes2'), t('anx.yes3'), t('anx.yes4'), t('anx.yes5')].map((item, i) => (
                <div key={i} style={{ background: '#f0fff4', borderRadius: '12px', padding: '12px 15px', borderLeft: '3px solid #2DCE89' }}>
                  <span style={{ color: '#32325d', fontSize: '0.9rem' }}>✅ {item}</span>
                </div>
              ))}
            </div>
            <div style={{ background: 'linear-gradient(135deg, #2DCE89, #1a9f6e)', borderRadius: '14px', padding: '20px', marginTop: '20px', color: 'white' }}>
              <p style={{ fontSize: '1rem', fontWeight: 600, margin: 0 }}>{t('anx.enough')}</p>
            </div>
          </div>
        </div>
      )}

      {activeSection === 'history' && (
        <div>
          <button onClick={() => setActiveSection('home')} style={{ background: 'none', border: 'none', color: '#5e72e4', cursor: 'pointer', marginBottom: '15px' }}>← {t('anx.back')}</button>
          {entries.length === 0 && <p style={{ textAlign: 'center', color: '#8898aa' }}>{t('anx.no_entries')}</p>}
          {entries.map(e => (
            <div key={e.id} style={{ background: 'white', borderRadius: '12px', padding: '15px', marginBottom: '10px', borderLeft: '4px solid #5e72e4' }}>
              <div style={{ fontWeight: 600, color: '#5e72e4', marginBottom: '5px' }}>{e.technique}</div>
              {e.feeling_before && <div style={{ fontSize: '0.8rem', color: '#8898aa' }}>{t('anx.before')}: {e.feeling_before}</div>}
              {e.feeling_after && <div style={{ fontSize: '0.8rem', color: '#2DCE89' }}>{t('anx.after')}: {e.feeling_after}</div>}
              <div style={{ fontSize: '0.7rem', color: '#aaa' }}>{new Date(e.date).toLocaleDateString()}</div>
            </div>
          ))}
        </div>
      )}
      <InlineAIChat context="anxiety" lang={lang} />
    </div>
  );
}
