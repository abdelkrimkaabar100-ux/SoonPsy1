import { useState } from 'react';
import InlineAIChat from '../shared/InlineAIChat';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { supabase } from '@/integrations/supabase/client';

interface Transaction {
  id: string;
  type: 'income' | 'expense' | 'saving' | 'investment' | 'necessary' | 'unnecessary';
  amount: number;
  description: string;
  date: string;
}

interface WishItem {
  id: string;
  name: string;
  estimatedCost: number;
  priority: 'high' | 'medium' | 'low';
  aiAdvice?: string;
}

interface FinancePageProps {
  onBack: () => void;
}

export default function FinancePage({ onBack }: FinancePageProps) {
  const { t, lang } = useLanguage();
  const isRTL = lang === 'ar';
  const [transactions, setTransactions] = useLocalStorage<Transaction[]>('soon-finance', []);
  const [wishlist, setWishlist] = useLocalStorage<WishItem[]>('soon-wishlist', []);
  const [activeTab, setActiveTab] = useState<'overview' | 'add' | 'history' | 'wishlist'>('overview');
  const [type, setType] = useState<Transaction['type']>('income');
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [wishName, setWishName] = useState('');
  const [wishCost, setWishCost] = useState('');
  const [wishPriority, setWishPriority] = useState<'high' | 'medium' | 'low'>('medium');
  const [loadingAI, setLoadingAI] = useState<string | null>(null);

  const labels = {
    ar: {
      necessary: '🍞 شراء ضروري', unnecessary: '🛍️ شراء غير ضروري',
      necessaryDesc: 'مثل: أكل (أنت جائع فعلاً)، دواء، فواتير أساسية',
      unnecessaryDesc: 'مثل: كماليات، أشياء يمكن تأجيلها',
      warning: '⚠️ تحذير: مشترياتك غير الضرورية تتجاوز ادخارك! هذا قد يضر بصحتك النفسية على المدى الطويل',
      warningHigh: '🚨 تنبيه خطير: أنت تخسر أموالك! المصاريف تتجاوز الدخل. هذا سيزيد التوتر والقلق',
      wishTitle: '🎯 أشياء أريدها', wishAdd: 'أضف ما تريده', wishAsk: 'اسأل الذكاء الاصطناعي',
      wishPlaceholder: 'ماذا تريد؟', wishCostPh: 'التكلفة التقديرية',
    },
    en: {
      necessary: '🍞 Necessary Purchase', unnecessary: '🛍️ Unnecessary Purchase',
      necessaryDesc: 'E.g: Food (you\'re actually hungry), medicine, essential bills',
      unnecessaryDesc: 'E.g: Luxuries, things that can wait',
      warning: '⚠️ Warning: Your unnecessary spending exceeds your savings! This may harm your mental health long-term',
      warningHigh: '🚨 Critical Alert: You\'re losing money! Expenses exceed income. This will increase stress and anxiety',
      wishTitle: '🎯 Things I Want', wishAdd: 'Add a Wish', wishAsk: 'Ask AI',
      wishPlaceholder: 'What do you want?', wishCostPh: 'Estimated cost',
    },
    es: {
      necessary: '🍞 Compra Necesaria', unnecessary: '🛍️ Compra Innecesaria',
      necessaryDesc: 'Ej: Comida, medicinas, facturas esenciales',
      unnecessaryDesc: 'Ej: Lujos, cosas que pueden esperar',
      warning: '⚠️ Advertencia: Tus gastos innecesarios superan tus ahorros',
      warningHigh: '🚨 Alerta: ¡Estás perdiendo dinero! Esto aumentará el estrés',
      wishTitle: '🎯 Cosas que Quiero', wishAdd: 'Agregar', wishAsk: 'Preguntar IA',
      wishPlaceholder: '¿Qué quieres?', wishCostPh: 'Costo estimado',
    },
    fr: {
      necessary: '🍞 Achat Nécessaire', unnecessary: '🛍️ Achat Non Nécessaire',
      necessaryDesc: 'Ex: Nourriture, médicaments, factures essentielles',
      unnecessaryDesc: 'Ex: Luxe, choses qui peuvent attendre',
      warning: '⚠️ Attention: Vos dépenses inutiles dépassent vos économies',
      warningHigh: '🚨 Alerte: Vous perdez de l\'argent! Cela augmentera le stress',
      wishTitle: '🎯 Choses que je Veux', wishAdd: 'Ajouter', wishAsk: 'Demander à l\'IA',
      wishPlaceholder: 'Que voulez-vous?', wishCostPh: 'Coût estimé',
    },
  };
  const l = labels[lang] || labels.en;

  const addTransaction = () => {
    if (!amount || !description.trim()) return;
    setTransactions(prev => [{
      id: Date.now().toString(), type, amount: parseFloat(amount),
      description: description.trim(), date: new Date().toISOString()
    }, ...prev]);
    setAmount(''); setDescription('');
  };

  const totalIncome = transactions.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0);
  const totalExpense = transactions.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
  const totalSaving = transactions.filter(t => t.type === 'saving').reduce((s, t) => s + t.amount, 0);
  const totalInvestment = transactions.filter(t => t.type === 'investment').reduce((s, t) => s + t.amount, 0);
  const totalNecessary = transactions.filter(t => t.type === 'necessary').reduce((s, t) => s + t.amount, 0);
  const totalUnnecessary = transactions.filter(t => t.type === 'unnecessary').reduce((s, t) => s + t.amount, 0);
  const balance = totalIncome - totalExpense - totalSaving - totalInvestment - totalNecessary - totalUnnecessary;

  const showWarning = totalUnnecessary > totalSaving && totalUnnecessary > 0;
  const showCriticalWarning = (totalExpense + totalUnnecessary + totalNecessary) > totalIncome && totalIncome > 0;

  const typeConfig: Record<Transaction['type'], { icon: string; color: string; label: string }> = {
    income: { icon: '💰', color: '#2DCE89', label: t('fin.income') },
    expense: { icon: '🛒', color: '#f5365c', label: t('fin.expense') },
    saving: { icon: '🏦', color: '#5e72e4', label: t('fin.saving') },
    investment: { icon: '📈', color: '#fb6340', label: t('fin.investment') },
    necessary: { icon: '🍞', color: '#11cdef', label: lang === 'ar' ? 'ضروري' : 'Necessary' },
    unnecessary: { icon: '🛍️', color: '#f5365c', label: lang === 'ar' ? 'غير ضروري' : 'Unnecessary' },
  };

  const addWishItem = () => {
    if (!wishName.trim()) return;
    setWishlist(prev => [...prev, {
      id: Date.now().toString(), name: wishName.trim(),
      estimatedCost: parseFloat(wishCost) || 0, priority: wishPriority,
    }]);
    setWishName(''); setWishCost('');
  };

  const getAIAdvice = async (item: WishItem) => {
    setLoadingAI(item.id);
    try {
      const context = `Balance: ${balance}, Income: ${totalIncome}, Savings: ${totalSaving}, Expenses: ${totalExpense + totalNecessary + totalUnnecessary}`;
      const prompt = lang === 'ar'
        ? `المستخدم يريد شراء "${item.name}" بتكلفة تقديرية ${item.estimatedCost}. بياناته المالية: ${context}. أعطِ رأيك بجملتين فقط هل يناسبه الشراء الآن أم لا حسب وضعه المالي.`
        : `User wants to buy "${item.name}" estimated cost ${item.estimatedCost}. Financial data: ${context}. Give a 2-sentence opinion on whether they should buy it now based on their finances.`;

      const { data } = await supabase.functions.invoke('groq-chat', {
        body: {
          messages: [{ role: 'user', content: prompt }],
          systemPrompt: lang === 'ar'
            ? 'أنت مستشار مالي نفسي. أجب بجملتين فقط مع رأيك بناءً على البيانات المالية للمستخدم.'
            : 'You are a financial wellness advisor. Reply in exactly 2 sentences based on user financial data.',
        }
      });
      const advice = data?.content || data?.choices?.[0]?.message?.content || '';
      setWishlist(prev => prev.map(w => w.id === item.id ? { ...w, aiAdvice: advice } : w));
    } catch { /* ignore */ }
    setLoadingAI(null);
  };

  const removeWish = (id: string) => setWishlist(prev => prev.filter(w => w.id !== id));

  return (
    <div style={{ paddingTop: '20px', direction: isRTL ? 'rtl' : 'ltr' }}>
      <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#2DCE89', fontSize: '1rem', cursor: 'pointer', marginBottom: '15px' }}>
        <i className={`fas fa-arrow-${isRTL ? 'right' : 'left'}`}></i> {t('nav.home')}
      </button>

      <div style={{ background: 'linear-gradient(135deg, #2DCE89, #1a9f6e)', borderRadius: '20px', padding: '25px', color: 'white', textAlign: 'center', marginBottom: '20px' }}>
        <div style={{ fontSize: '2.5rem', marginBottom: '10px' }}>💎</div>
        <h2 style={{ fontSize: '1.3rem', fontWeight: 700, margin: '0 0 8px' }}>{t('fin.title')}</h2>
        <p style={{ fontSize: '0.85rem', opacity: 0.9, margin: 0 }}>{t('fin.subtitle')}</p>
      </div>

      {/* Warnings */}
      {showCriticalWarning && (
        <div style={{ background: '#fff5f5', border: '2px solid #f5365c', borderRadius: '14px', padding: '15px', marginBottom: '15px', textAlign: 'center' }}>
          <p style={{ color: '#f5365c', fontWeight: 700, margin: 0, fontSize: '0.85rem' }}>{l.warningHigh}</p>
        </div>
      )}
      {showWarning && !showCriticalWarning && (
        <div style={{ background: '#fffaf0', border: '2px solid #fb6340', borderRadius: '14px', padding: '15px', marginBottom: '15px', textAlign: 'center' }}>
          <p style={{ color: '#fb6340', fontWeight: 600, margin: 0, fontSize: '0.85rem' }}>{l.warning}</p>
        </div>
      )}

      <div style={{ display: 'flex', gap: '5px', marginBottom: '20px', flexWrap: 'wrap' }}>
        {(['overview', 'add', 'history', 'wishlist'] as const).map(tab => (
          <button key={tab} onClick={() => setActiveTab(tab)} style={{
            flex: 1, minWidth: '70px', padding: '10px 4px', borderRadius: '12px', border: 'none', cursor: 'pointer',
            background: activeTab === tab ? 'linear-gradient(135deg, #2DCE89, #1a9f6e)' : '#fff',
            color: activeTab === tab ? 'white' : '#32325d', fontWeight: 600, fontSize: '0.7rem',
            boxShadow: activeTab === tab ? '0 4px 15px rgba(45,206,137,0.3)' : '0 2px 8px rgba(0,0,0,0.05)'
          }}>
            {tab === 'overview' && '📊'} {tab === 'add' && '➕'} {tab === 'history' && '📋'} {tab === 'wishlist' && '🎯'}
            <br/>{tab === 'wishlist' ? (lang === 'ar' ? 'أريد' : 'Wishlist') : t(`fin.tab_${tab}`)}
          </button>
        ))}
      </div>

      {activeTab === 'overview' && (
        <div>
          <div style={{ background: 'white', borderRadius: '16px', padding: '20px', marginBottom: '15px', textAlign: 'center', boxShadow: '0 4px 15px rgba(0,0,0,0.05)' }}>
            <div style={{ fontSize: '0.85rem', color: '#8898aa' }}>{t('fin.balance')}</div>
            <div style={{ fontSize: '2rem', fontWeight: 700, color: balance >= 0 ? '#2DCE89' : '#f5365c' }}>{balance.toFixed(2)}</div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
            {(Object.keys(typeConfig) as Transaction['type'][]).map(key => {
              const total = key === 'income' ? totalIncome : key === 'expense' ? totalExpense : key === 'saving' ? totalSaving : key === 'investment' ? totalInvestment : key === 'necessary' ? totalNecessary : totalUnnecessary;
              return (
                <div key={key} style={{ background: 'white', borderRadius: '14px', padding: '12px', textAlign: 'center', boxShadow: '0 2px 10px rgba(0,0,0,0.05)', borderTop: `3px solid ${typeConfig[key].color}` }}>
                  <div style={{ fontSize: '1.3rem' }}>{typeConfig[key].icon}</div>
                  <div style={{ fontSize: '0.7rem', color: '#8898aa', marginTop: '4px' }}>{typeConfig[key].label}</div>
                  <div style={{ fontSize: '1rem', fontWeight: 700, color: typeConfig[key].color }}>{total.toFixed(0)}</div>
                </div>
              );
            })}
          </div>
          <div style={{ background: 'linear-gradient(135deg, #5e72e4, #825ee4)', borderRadius: '16px', padding: '20px', marginTop: '15px', color: 'white', textAlign: 'center' }}>
            <div style={{ fontSize: '1.3rem', marginBottom: '8px' }}>🧘</div>
            <p style={{ fontSize: '0.85rem', margin: 0, lineHeight: 1.6 }}>{t('fin.mental_tip')}</p>
          </div>
        </div>
      )}

      {activeTab === 'add' && (
        <div style={{ background: 'white', borderRadius: '16px', padding: '20px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)' }}>
          <h4 style={{ color: '#32325d', marginBottom: '15px' }}>➕ {t('fin.add_transaction')}</h4>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '15px' }}>
            {(Object.keys(typeConfig) as Transaction['type'][]).map(key => (
              <button key={key} onClick={() => setType(key)} style={{
                padding: '10px', borderRadius: '12px', border: 'none', cursor: 'pointer',
                background: type === key ? typeConfig[key].color : '#f7f8fa',
                color: type === key ? 'white' : '#32325d', fontWeight: 600, fontSize: '0.75rem'
              }}>
                {typeConfig[key].icon} {typeConfig[key].label}
              </button>
            ))}
          </div>
          {/* Hints for necessary/unnecessary */}
          {type === 'necessary' && (
            <div style={{ background: '#e6f7ff', borderRadius: '10px', padding: '10px', marginBottom: '10px', fontSize: '0.75rem', color: '#11cdef' }}>
              ℹ️ {l.necessaryDesc}
            </div>
          )}
          {type === 'unnecessary' && (
            <div style={{ background: '#fff5f5', borderRadius: '10px', padding: '10px', marginBottom: '10px', fontSize: '0.75rem', color: '#f5365c' }}>
              ⚠️ {l.unnecessaryDesc}
            </div>
          )}
          <input type="number" value={amount} onChange={e => setAmount(e.target.value)} placeholder={t('fin.amount_placeholder')}
            style={{ width: '100%', padding: '12px', border: '2px solid #f0f4ff', borderRadius: '12px', marginBottom: '10px', fontSize: '1rem', boxSizing: 'border-box' }} />
          <input type="text" value={description} onChange={e => setDescription(e.target.value)} placeholder={t('fin.desc_placeholder')}
            style={{ width: '100%', padding: '12px', border: '2px solid #f0f4ff', borderRadius: '12px', marginBottom: '15px', fontSize: '0.9rem', boxSizing: 'border-box' }} />
          <button onClick={addTransaction} style={{ width: '100%', background: 'linear-gradient(135deg, #2DCE89, #1a9f6e)', color: 'white', border: 'none', borderRadius: '12px', padding: '14px', fontWeight: 600, cursor: 'pointer', fontSize: '1rem' }}>
            {t('fin.save')}
          </button>
        </div>
      )}

      {activeTab === 'history' && (
        <div>
          {transactions.length === 0 && <p style={{ textAlign: 'center', color: '#8898aa' }}>{t('fin.empty')}</p>}
          {transactions.slice(0, 20).map(tx => (
            <div key={tx.id} style={{ background: 'white', borderRadius: '12px', padding: '12px 15px', marginBottom: '8px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderLeft: isRTL ? 'none' : `4px solid ${typeConfig[tx.type]?.color || '#ccc'}`, borderRight: isRTL ? `4px solid ${typeConfig[tx.type]?.color || '#ccc'}` : 'none' }}>
              <div>
                <span style={{ fontSize: '1rem' }}>{typeConfig[tx.type]?.icon}</span>
                <span style={{ fontWeight: 600, color: '#32325d', marginLeft: '8px', marginRight: '8px', fontSize: '0.85rem' }}>{tx.description}</span>
                <div style={{ fontSize: '0.7rem', color: '#aaa' }}>{new Date(tx.date).toLocaleDateString()}</div>
              </div>
              <span style={{ fontWeight: 700, color: typeConfig[tx.type]?.color || '#999', fontSize: '1rem' }}>
                {tx.type === 'income' ? '+' : '-'}{tx.amount}
              </span>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'wishlist' && (
        <div>
          <div style={{ background: 'white', borderRadius: '16px', padding: '20px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)', marginBottom: '15px' }}>
            <h4 style={{ color: '#32325d', marginBottom: '12px' }}>{l.wishTitle}</h4>
            <input type="text" value={wishName} onChange={e => setWishName(e.target.value)} placeholder={l.wishPlaceholder}
              style={{ width: '100%', padding: '10px', border: '2px solid #f0f4ff', borderRadius: '10px', marginBottom: '8px', fontSize: '0.9rem', boxSizing: 'border-box' }} />
            <input type="number" value={wishCost} onChange={e => setWishCost(e.target.value)} placeholder={l.wishCostPh}
              style={{ width: '100%', padding: '10px', border: '2px solid #f0f4ff', borderRadius: '10px', marginBottom: '8px', fontSize: '0.9rem', boxSizing: 'border-box' }} />
            <div style={{ display: 'flex', gap: '6px', marginBottom: '12px' }}>
              {(['high', 'medium', 'low'] as const).map(p => (
                <button key={p} onClick={() => setWishPriority(p)} style={{
                  flex: 1, padding: '8px', borderRadius: '10px', border: 'none', cursor: 'pointer', fontSize: '0.75rem', fontWeight: 600,
                  background: wishPriority === p ? (p === 'high' ? '#f5365c' : p === 'medium' ? '#fb6340' : '#2DCE89') : '#f7f8fa',
                  color: wishPriority === p ? 'white' : '#32325d',
                }}>
                  {p === 'high' ? '🔴' : p === 'medium' ? '🟡' : '🟢'} {p}
                </button>
              ))}
            </div>
            <button onClick={addWishItem} style={{ width: '100%', background: 'linear-gradient(135deg, #8965e0, #6a3fbb)', color: 'white', border: 'none', borderRadius: '10px', padding: '12px', fontWeight: 600, cursor: 'pointer' }}>
              {l.wishAdd}
            </button>
          </div>

          {wishlist.map(item => (
            <div key={item.id} style={{ background: 'white', borderRadius: '14px', padding: '15px', marginBottom: '10px', boxShadow: '0 2px 10px rgba(0,0,0,0.05)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                <div>
                  <span style={{ fontWeight: 700, color: '#32325d' }}>{item.name}</span>
                  {item.estimatedCost > 0 && <span style={{ color: '#8898aa', fontSize: '0.8rem', marginLeft: '8px', marginRight: '8px' }}>{item.estimatedCost}</span>}
                </div>
                <button onClick={() => removeWish(item.id)} style={{ background: 'none', border: 'none', color: '#f5365c', cursor: 'pointer' }}>
                  <i className="fas fa-times"></i>
                </button>
              </div>
              <button onClick={() => getAIAdvice(item)} disabled={loadingAI === item.id} style={{
                background: 'linear-gradient(135deg, #5e72e4, #825ee4)', color: 'white', border: 'none',
                borderRadius: '8px', padding: '8px 14px', cursor: 'pointer', fontSize: '0.8rem', fontWeight: 600, opacity: loadingAI === item.id ? 0.6 : 1,
              }}>
                {loadingAI === item.id ? '...' : `🤖 ${l.wishAsk}`}
              </button>
              {item.aiAdvice && (
                <div style={{ background: '#f0f4ff', borderRadius: '10px', padding: '10px', marginTop: '8px', fontSize: '0.8rem', color: '#5e72e4', lineHeight: 1.5 }}>
                  🤖 {item.aiAdvice}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
      <InlineAIChat context="finance" lang={lang} />
    </div>
  );
}
