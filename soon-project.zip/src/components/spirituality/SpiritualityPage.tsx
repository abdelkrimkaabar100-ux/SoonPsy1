import { useState } from 'react';
import InlineAIChat from '../shared/InlineAIChat';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';

interface SpiritualityPageProps {
  onBack: () => void;
}

interface PracticeEntry {
  practice: string;
  date: string;
  done: boolean;
}

const religions = [
  { id: 'islam', icon: '☪️', label: { en: 'Islam', ar: 'الإسلام', es: 'Islam', fr: 'Islam' } },
  { id: 'christianity', icon: '✝️', label: { en: 'Christianity', ar: 'المسيحية', es: 'Cristianismo', fr: 'Christianisme' } },
  { id: 'judaism', icon: '✡️', label: { en: 'Judaism', ar: 'اليهودية', es: 'Judaísmo', fr: 'Judaïsme' } },
  { id: 'hinduism', icon: '🕉️', label: { en: 'Hinduism', ar: 'الهندوسية', es: 'Hinduismo', fr: 'Hindouisme' } },
  { id: 'buddhism', icon: '☸️', label: { en: 'Buddhism', ar: 'البوذية', es: 'Budismo', fr: 'Bouddhisme' } },
  { id: 'other', icon: '🙏', label: { en: 'Other', ar: 'أخرى', es: 'Otra', fr: 'Autre' } },
];

const practicesByReligion: Record<string, { key: string; icon: string }[]> = {
  islam: [
    { key: 'spirit.prayer', icon: '🕌' },
    { key: 'spirit.quran', icon: '📖' },
    { key: 'spirit.dhikr', icon: '📿' },
    { key: 'spirit.charity', icon: '💝' },
    { key: 'spirit.fasting', icon: '🌙' },
    { key: 'spirit.dua', icon: '🤲' },
  ],
  christianity: [
    { key: 'spirit.church', icon: '⛪' },
    { key: 'spirit.bible', icon: '📖' },
    { key: 'spirit.pray_christian', icon: '🙏' },
    { key: 'spirit.charity', icon: '💝' },
    { key: 'spirit.fellowship', icon: '🤝' },
    { key: 'spirit.gratitude_prayer', icon: '💛' },
  ],
  judaism: [
    { key: 'spirit.synagogue', icon: '🕍' },
    { key: 'spirit.torah', icon: '📜' },
    { key: 'spirit.shabbat', icon: '🕯️' },
    { key: 'spirit.charity', icon: '💝' },
    { key: 'spirit.pray_jewish', icon: '🙏' },
    { key: 'spirit.tikkun', icon: '🌍' },
  ],
  hinduism: [
    { key: 'spirit.temple', icon: '🛕' },
    { key: 'spirit.meditation_hindu', icon: '🧘' },
    { key: 'spirit.yoga', icon: '🧘‍♀️' },
    { key: 'spirit.charity', icon: '💝' },
    { key: 'spirit.mantra', icon: '🕉️' },
    { key: 'spirit.puja', icon: '🪔' },
  ],
  buddhism: [
    { key: 'spirit.meditation_buddhist', icon: '🧘' },
    { key: 'spirit.dharma', icon: '📖' },
    { key: 'spirit.mindfulness', icon: '🌸' },
    { key: 'spirit.charity', icon: '💝' },
    { key: 'spirit.compassion', icon: '💗' },
    { key: 'spirit.sangha', icon: '🤝' },
  ],
  other: [
    { key: 'spirit.meditation_general', icon: '🧘' },
    { key: 'spirit.reading', icon: '📖' },
    { key: 'spirit.gratitude_prayer', icon: '💛' },
    { key: 'spirit.charity', icon: '💝' },
    { key: 'spirit.reflection', icon: '🌅' },
    { key: 'spirit.kindness', icon: '💗' },
  ],
};

export default function SpiritualityPage({ onBack }: SpiritualityPageProps) {
  const { t, lang } = useLanguage();
  const [selectedReligion, setSelectedReligion] = useLocalStorage<string>('soon-religion', '');
  const [customReligion, setCustomReligion] = useLocalStorage<string>('soon-custom-religion', '');
  const [practices, setPractices] = useLocalStorage<PracticeEntry[]>('soon-spirit-practices', []);
  const [customPractice, setCustomPractice] = useState('');

  const today = new Date().toDateString();
  const todayPractices = practices.filter(p => new Date(p.date).toDateString() === today);
  const totalDays = new Set(practices.map(p => new Date(p.date).toDateString())).size;

  const togglePractice = (practice: string) => {
    const exists = todayPractices.find(p => p.practice === practice);
    if (exists) {
      setPractices(prev => prev.filter(p => !(p.practice === practice && new Date(p.date).toDateString() === today)));
    } else {
      setPractices(prev => [...prev, { practice, date: new Date().toISOString(), done: true }]);
    }
  };

  const addCustomPractice = () => {
    if (!customPractice.trim()) return;
    setPractices(prev => [...prev, { practice: customPractice.trim(), date: new Date().toISOString(), done: true }]);
    setCustomPractice('');
  };

  const currentPractices = practicesByReligion[selectedReligion] || practicesByReligion.other;
  const religionInfo = religions.find(r => r.id === selectedReligion);

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px', margin: '20px 0' }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', fontSize: '1.5rem', cursor: 'pointer', color: '#8965e0' }}>
          <i className="fas fa-arrow-left"></i>
        </button>
        <h2 style={{ fontSize: '1.5rem', fontWeight: 700, color: '#32325d', margin: 0 }}>
          🙏 {t('spirit.title')}
        </h2>
      </div>

      {/* Coexistence banner */}
      <div style={{
        background: 'linear-gradient(135deg, #667eea, #764ba2)', borderRadius: '16px', padding: '20px',
        marginBottom: '20px', textAlign: 'center', color: 'white',
      }}>
        <div style={{ fontSize: '2rem', marginBottom: '8px' }}>☪️ ✝️ ✡️ 🕉️ ☸️ 🙏</div>
        <h3 style={{ margin: '0 0 8px', fontSize: '1.1rem' }}>{t('spirit.coexist')}</h3>
        <p style={{ margin: 0, fontSize: '0.85rem', opacity: 0.9 }}>{t('spirit.coexist_desc')}</p>
      </div>

      {/* Religion Selection */}
      {!selectedReligion ? (
        <div style={{ background: 'white', borderRadius: '16px', padding: '20px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)', marginBottom: '20px' }}>
          <h4 style={{ textAlign: 'center', color: '#32325d', marginBottom: '15px' }}>{t('spirit.choose')}</h4>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '10px' }}>
            {religions.map(r => (
              <div key={r.id} onClick={() => setSelectedReligion(r.id)} style={{
                padding: '15px 8px', borderRadius: '16px', textAlign: 'center', cursor: 'pointer',
                background: '#f8f9fe', border: '2px solid #e8daff', transition: 'all 0.3s ease',
              }}
              onMouseEnter={e => { e.currentTarget.style.transform = 'scale(1.05)'; e.currentTarget.style.borderColor = '#8965e0'; }}
              onMouseLeave={e => { e.currentTarget.style.transform = 'scale(1)'; e.currentTarget.style.borderColor = '#e8daff'; }}
              >
                <div style={{ fontSize: '2rem', marginBottom: '6px' }}>{r.icon}</div>
                <div style={{ fontSize: '0.8rem', fontWeight: 600, color: '#32325d' }}>
                  {r.label[lang as keyof typeof r.label] || r.label.en}
                </div>
              </div>
            ))}
          </div>

          {/* Custom religion input */}
          <div style={{ marginTop: '15px' }}>
            <div style={{ display: 'flex', gap: '8px' }}>
              <input type="text" value={customReligion} onChange={e => setCustomReligion(e.target.value)}
                placeholder={t('spirit.custom_religion')}
                style={{ flex: 1, padding: '10px 15px', border: '1px solid #e8daff', borderRadius: '25px', fontFamily: 'Poppins, sans-serif', fontSize: '0.85rem', outline: 'none' }}
              />
              <button onClick={() => { if (customReligion.trim()) setSelectedReligion('other'); }} style={{
                background: '#8965e0', color: 'white', border: 'none', borderRadius: '25px', padding: '10px 16px',
                fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif', fontSize: '0.8rem',
              }}>✓</button>
            </div>
          </div>
        </div>
      ) : (
        <>
          {/* Selected religion header */}
          <div style={{
            background: 'white', borderRadius: '16px', padding: '15px', marginBottom: '15px',
            boxShadow: '0 6px 20px rgba(0,0,0,0.08)', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <span style={{ fontSize: '2rem' }}>{religionInfo?.icon || '🙏'}</span>
              <div>
                <div style={{ fontWeight: 700, color: '#32325d' }}>
                  {customReligion || (religionInfo?.label[lang as keyof typeof religionInfo.label] || religionInfo?.label.en)}
                </div>
                <div style={{ fontSize: '0.8rem', color: '#8898aa' }}>
                  {totalDays} {t('spirit.days_tracked')}
                </div>
              </div>
            </div>
            <button onClick={() => setSelectedReligion('')} style={{
              background: '#f0f4ff', border: 'none', borderRadius: '12px', padding: '6px 12px',
              color: '#8965e0', fontWeight: 600, cursor: 'pointer', fontSize: '0.75rem',
            }}>{t('spirit.change')}</button>
          </div>

          {/* Stats */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '20px' }}>
            <div style={{ background: 'white', borderRadius: '16px', padding: '15px', textAlign: 'center', boxShadow: '0 4px 15px rgba(0,0,0,0.06)', border: '2px solid #e8daff' }}>
              <div style={{ fontSize: '2rem', fontWeight: 700, color: '#8965e0' }}>{todayPractices.length}</div>
              <div style={{ fontSize: '0.8rem', color: '#8898aa' }}>{t('spirit.today')}</div>
            </div>
            <div style={{ background: 'white', borderRadius: '16px', padding: '15px', textAlign: 'center', boxShadow: '0 4px 15px rgba(0,0,0,0.06)', border: '2px solid #e8daff' }}>
              <div style={{ fontSize: '2rem', fontWeight: 700, color: '#8965e0' }}>{practices.length}</div>
              <div style={{ fontSize: '0.8rem', color: '#8898aa' }}>{t('spirit.total')}</div>
            </div>
          </div>

          {/* Practices */}
          <div style={{ background: 'white', borderRadius: '16px', padding: '15px', marginBottom: '20px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)', border: '2px solid #e8daff' }}>
            <h4 style={{ color: '#8965e0', marginBottom: '15px', textAlign: 'center' }}>🙏 {t('spirit.daily_practices')}</h4>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '10px', marginBottom: '15px' }}>
              {currentPractices.map(p => {
                const done = todayPractices.some(tp => tp.practice === t(p.key));
                return (
                  <div key={p.key} onClick={() => togglePractice(t(p.key))} style={{
                    padding: '12px 6px', borderRadius: '14px', textAlign: 'center', cursor: 'pointer',
                    background: done ? 'linear-gradient(135deg, #e8f5e9, #c8e6c9)' : '#f8f9fe',
                    border: `2px solid ${done ? '#2DCE89' : '#e8daff'}`, transition: 'all 0.3s ease',
                  }}>
                    <div style={{ fontSize: '1.5rem', marginBottom: '4px' }}>{done ? '✅' : p.icon}</div>
                    <div style={{ fontSize: '0.72rem', fontWeight: 600, color: done ? '#2DCE89' : '#8965e0', lineHeight: 1.3 }}>
                      {t(p.key)}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Custom practice */}
            <div style={{ display: 'flex', gap: '8px' }}>
              <input type="text" value={customPractice} onChange={e => setCustomPractice(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && addCustomPractice()}
                placeholder={t('spirit.custom_practice')}
                style={{ flex: 1, padding: '10px 15px', border: '1px solid #e8daff', borderRadius: '25px', fontFamily: 'Poppins, sans-serif', fontSize: '0.85rem', outline: 'none' }}
              />
              <button onClick={addCustomPractice} style={{
                background: '#8965e0', color: 'white', border: 'none', borderRadius: '50%',
                width: 38, height: 38, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
                cursor: 'pointer', fontSize: '1rem',
              }}>+</button>
            </div>
          </div>

          {/* Mental health benefit */}
          <div style={{
            background: 'linear-gradient(135deg, #f8f9fe, #e8daff)', borderRadius: '16px', padding: '20px',
            marginBottom: '20px', textAlign: 'center',
          }}>
            <h4 style={{ color: '#8965e0', marginBottom: '8px' }}>💜 {t('spirit.benefit_title')}</h4>
            <p style={{ color: '#32325d', fontSize: '0.9rem', lineHeight: 1.6, margin: 0 }}>{t('spirit.benefit_desc')}</p>
          </div>
        </>
      )}
      <InlineAIChat context="spirituality" lang={lang} />
    </div>
  );
}
