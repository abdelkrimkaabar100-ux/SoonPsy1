import { useState } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import InlineAIChat from '../shared/InlineAIChat';

interface ForgivenessEntry {
  id: string;
  pain: string;
  letter: string;
  released: boolean;
  date: string;
}

export default function ForgivenessPage({ onBack }: { onBack: () => void }) {
  const { lang } = useLanguage();
  const isAr = lang === 'ar';
  const [entries, setEntries] = useLocalStorage<ForgivenessEntry[]>('soon-forgiveness', []);
  const [pain, setPain] = useState('');
  const [letter, setLetter] = useState('');
  const [showAnimation, setShowAnimation] = useState(false);

  const l = {
    en: { title: '🕊️ Forgiveness & Letting Go', subtitle: 'Write what hurts you and let it go', back: 'Home', pain_label: 'What still hurts you from the past?', letter_label: 'Write a letter of forgiveness to that person, event, or yourself...', release: '🕊️ Forgive & Let Go', released: 'Released', entries_title: 'My Forgiveness Journey', empty: 'Nothing here yet. When you\'re ready, let go of what weighs you down.', benefit: 'Why Forgiveness Heals', benefit_desc: 'Forgiveness is not about condoning what happened. It\'s about freeing YOURSELF from the weight of resentment. Studies show forgiveness reduces anxiety by 35%, lowers blood pressure, and improves sleep quality. You deserve peace.', releasing_msg: 'Letting go... You are free now 🕊️' },
    ar: { title: '🕊️ المسامحة والتحرر', subtitle: 'اكتب ما يؤلمك واسمح له بالرحيل', back: 'الرئيسية', pain_label: 'ما الذي لا يزال يؤلمك من الماضي؟', letter_label: 'اكتب رسالة مسامحة لذلك الشخص، الحدث، أو لنفسك...', release: '🕊️ سامح واسمح بالرحيل', released: 'تم التحرر', entries_title: 'رحلة مسامحتي', empty: 'لا شيء هنا بعد. عندما تكون مستعداً، اسمح لما يثقلك بالرحيل.', benefit: 'لماذا المسامحة تشفي', benefit_desc: 'المسامحة ليست عن تبرير ما حدث. إنها عن تحرير نفسك من ثقل الاستياء. الدراسات تظهر أن المسامحة تقلل القلق 35%، تخفض ضغط الدم، وتحسن جودة النوم. أنت تستحق السلام.', releasing_msg: 'جارٍ التحرر... أنت حر الآن 🕊️' },
    es: { title: '🕊️ Perdón y Soltar', subtitle: 'Escribe lo que te duele y déjalo ir', back: 'Inicio', pain_label: '¿Qué te sigue doliendo?', letter_label: 'Escribe una carta de perdón...', release: '🕊️ Perdonar y Soltar', released: 'Liberado', entries_title: 'Mi camino de perdón', empty: 'Nada aquí aún.', benefit: '¿Por qué el perdón sana?', benefit_desc: 'El perdón reduce la ansiedad un 35%.', releasing_msg: 'Soltando... Eres libre ahora 🕊️' },
    fr: { title: '🕊️ Pardon et Lâcher-Prise', subtitle: 'Écrivez ce qui vous fait mal et laissez partir', back: 'Accueil', pain_label: 'Qu\'est-ce qui vous fait encore mal?', letter_label: 'Écrivez une lettre de pardon...', release: '🕊️ Pardonner', released: 'Libéré', entries_title: 'Mon parcours de pardon', empty: 'Rien ici encore.', benefit: 'Pourquoi le pardon guérit', benefit_desc: 'Le pardon réduit l\'anxiété de 35%.', releasing_msg: 'Lâcher-prise... Vous êtes libre 🕊️' },
  };
  const t = l[lang as keyof typeof l] || l.en;

  const save = () => {
    if (!pain.trim()) return;
    setShowAnimation(true);
    setTimeout(() => {
      setEntries(prev => [{ id: Date.now().toString(), pain: pain.trim(), letter: letter.trim(), released: true, date: new Date().toISOString() }, ...prev]);
      setPain(''); setLetter('');
      setShowAnimation(false);
    }, 3000);
  };

  const inputStyle = { width: '100%', padding: '12px', border: '2px solid #e0e7ff', borderRadius: '12px', fontSize: '0.9rem', boxSizing: 'border-box' as const, fontFamily: 'Poppins, sans-serif', direction: isAr ? 'rtl' as const : 'ltr' as const };

  return (
    <div style={{ paddingTop: '20px', direction: isAr ? 'rtl' : 'ltr' }}>
      <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#7c3aed', fontSize: '1rem', cursor: 'pointer', marginBottom: '15px' }}>
        <i className={`fas fa-arrow-${isAr ? 'right' : 'left'}`}></i> {t.back}
      </button>

      <div style={{ background: 'linear-gradient(135deg, #7c3aed, #6d28d9)', borderRadius: '20px', padding: '25px', color: 'white', textAlign: 'center', marginBottom: '20px' }}>
        <div style={{ fontSize: '2.5rem', marginBottom: '10px' }}>🕊️💜</div>
        <h2 style={{ fontSize: '1.3rem', fontWeight: 700, margin: '0 0 8px' }}>{t.title}</h2>
        <p style={{ fontSize: '0.85rem', opacity: 0.9, margin: 0 }}>{t.subtitle}</p>
      </div>

      {showAnimation && (
        <div style={{ background: 'linear-gradient(135deg, #ede9fe, #ddd6fe)', borderRadius: '16px', padding: '30px', textAlign: 'center', marginBottom: '15px', animation: 'pulseBeat 1.5s infinite' }}>
          <div style={{ fontSize: '3rem', marginBottom: '10px', animation: 'float 2s infinite' }}>🕊️</div>
          <p style={{ color: '#6d28d9', fontWeight: 700, fontSize: '1rem' }}>{t.releasing_msg}</p>
        </div>
      )}

      {!showAnimation && (
        <div style={{ background: 'white', borderRadius: '16px', padding: '20px', marginBottom: '15px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)' }}>
          <label style={{ display: 'block', color: '#6d28d9', fontWeight: 600, marginBottom: '8px', fontSize: '0.9rem' }}>{t.pain_label}</label>
          <textarea value={pain} onChange={e => setPain(e.target.value)} placeholder="..." style={{ ...inputStyle, marginBottom: '15px', minHeight: '80px', resize: 'vertical' }} />
          
          <label style={{ display: 'block', color: '#6d28d9', fontWeight: 600, marginBottom: '8px', fontSize: '0.9rem' }}>{t.letter_label}</label>
          <textarea value={letter} onChange={e => setLetter(e.target.value)} placeholder="..." style={{ ...inputStyle, marginBottom: '15px', minHeight: '120px', resize: 'vertical' }} />
          
          <button onClick={save} disabled={!pain.trim()} style={{ width: '100%', background: pain.trim() ? 'linear-gradient(135deg, #7c3aed, #6d28d9)' : '#ccc', color: 'white', border: 'none', borderRadius: '12px', padding: '14px', fontWeight: 600, cursor: pain.trim() ? 'pointer' : 'not-allowed' }}>{t.release}</button>
        </div>
      )}

      <h4 style={{ color: '#32325d', marginBottom: '10px' }}>📜 {t.entries_title}</h4>
      {entries.length === 0 && <p style={{ textAlign: 'center', color: '#8898aa', fontSize: '0.85rem' }}>{t.empty}</p>}
      {entries.map(e => (
        <div key={e.id} style={{ background: 'white', borderRadius: '12px', padding: '15px', marginBottom: '10px', borderLeft: '4px solid #a78bfa', opacity: 0.85 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px' }}>
            <span style={{ fontSize: '0.75rem', color: '#8898aa' }}>{new Date(e.date).toLocaleDateString()}</span>
            <span style={{ fontSize: '0.75rem', background: '#ede9fe', color: '#7c3aed', padding: '2px 8px', borderRadius: '10px' }}>🕊️ {t.released}</span>
          </div>
          <p style={{ color: '#32325d', margin: '5px 0', fontWeight: 500, fontSize: '0.9rem' }}>{e.pain}</p>
          {e.letter && <p style={{ color: '#8898aa', margin: 0, fontSize: '0.8rem', fontStyle: 'italic' }}>{e.letter.slice(0, 100)}...</p>}
        </div>
      ))}

      <div style={{ background: 'linear-gradient(135deg, #ede9fe, #ddd6fe)', borderRadius: '16px', padding: '15px', marginTop: '15px', borderLeft: '4px solid #7c3aed' }}>
        <h4 style={{ color: '#6d28d9', marginBottom: '8px' }}>💜 {t.benefit}</h4>
        <p style={{ color: '#32325d', fontSize: '0.85rem', lineHeight: 1.6, margin: 0 }}>{t.benefit_desc}</p>
      </div>

      <style>{`@keyframes float { 0%,100% { transform: translateY(0); } 50% { transform: translateY(-20px); } }`}</style>
      <InlineAIChat context="forgiveness" lang={lang} />
    </div>
  );
}
