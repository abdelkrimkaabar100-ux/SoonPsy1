import { useState } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import InlineAIChat from '../shared/InlineAIChat';

interface Goal {
  id: string;
  title: string;
  description: string;
  category: string;
  deadline: string;
  progress: number;
  completed: boolean;
  date: string;
}

interface GoalsPageProps {
  onBack: () => void;
}

export default function GoalsPage({ onBack }: GoalsPageProps) {
  const { t, lang } = useLanguage();
  const isRTL = lang === 'ar';
  const [goals, setGoals] = useLocalStorage<Goal[]>('soon-goals', []);
  const [showAdd, setShowAdd] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('personal');
  const [deadline, setDeadline] = useState('');
  const [aiPrompt, setAiPrompt] = useState('');

  const categories = [
    { id: 'personal', icon: '🌟', key: 'goals.cat_personal' },
    { id: 'career', icon: '💼', key: 'goals.cat_career' },
    { id: 'health', icon: '💪', key: 'goals.cat_health' },
    { id: 'education', icon: '📚', key: 'goals.cat_education' },
    { id: 'travel', icon: '✈️', key: 'goals.cat_travel' },
    { id: 'financial', icon: '💰', key: 'goals.cat_financial' },
    { id: 'creative', icon: '🎨', key: 'goals.cat_creative' },
    { id: 'social', icon: '🤝', key: 'goals.cat_social' },
  ];

  const addGoal = () => {
    if (!title.trim()) return;
    setGoals(prev => [{
      id: Date.now().toString(), title: title.trim(), description: description.trim(),
      category, deadline, progress: 0, completed: false, date: new Date().toISOString(),
    }, ...prev]);
    setTitle(''); setDescription(''); setDeadline(''); setShowAdd(false);
  };

  const updateProgress = (id: string, progress: number) => {
    setGoals(prev => prev.map(g => g.id === id ? { ...g, progress, completed: progress >= 100 } : g));
  };

  const deleteGoal = (id: string) => setGoals(prev => prev.filter(g => g.id !== id));

  const activeGoals = goals.filter(g => !g.completed);
  const completedGoals = goals.filter(g => g.completed);

  return (
    <div style={{ paddingTop: '20px', direction: isRTL ? 'rtl' : 'ltr' }}>
      <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#2DCE89', fontSize: '1rem', cursor: 'pointer', marginBottom: '15px', fontFamily: 'Poppins, sans-serif' }}>
        <i className={`fas fa-arrow-${isRTL ? 'right' : 'left'}`}></i> {t('nav.home')}
      </button>

      <div style={{ textAlign: 'center', marginBottom: '20px' }}>
        <h2 style={{ color: '#32325d', fontSize: '1.5rem', margin: '0 0 5px' }}>🌈 {t('goals.title')}</h2>
        <p style={{ color: '#8898aa', fontSize: '0.85rem', margin: 0 }}>{t('goals.subtitle')}</p>
      </div>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginBottom: '20px' }}>
        <div style={{ background: 'linear-gradient(135deg, #f093fb, #f5576c)', borderRadius: '12px', padding: '15px', color: 'white', textAlign: 'center' }}>
          <div style={{ fontSize: '1.8rem', fontWeight: 700 }}>{activeGoals.length}</div>
          <div style={{ fontSize: '0.75rem', opacity: 0.9 }}>{t('goals.active')}</div>
        </div>
        <div style={{ background: 'linear-gradient(135deg, #2DCE89, #1a9f6e)', borderRadius: '12px', padding: '15px', color: 'white', textAlign: 'center' }}>
          <div style={{ fontSize: '1.8rem', fontWeight: 700 }}>{completedGoals.length}</div>
          <div style={{ fontSize: '0.75rem', opacity: 0.9 }}>{t('goals.achieved')}</div>
        </div>
      </div>

      {/* Add button */}
      {!showAdd && (
        <button onClick={() => setShowAdd(true)} style={{
          width: '100%', padding: '12px', borderRadius: '12px', border: '2px dashed #f5576c',
          background: 'transparent', color: '#f5576c', fontWeight: 600, cursor: 'pointer',
          fontFamily: 'Poppins, sans-serif', marginBottom: '15px',
        }}>
          + {t('goals.add')}
        </button>
      )}

      {showAdd && (
        <div style={{ background: 'white', borderRadius: '16px', padding: '15px', marginBottom: '15px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
          <input type="text" value={title} onChange={e => setTitle(e.target.value)} placeholder={t('goals.title_placeholder')}
            style={{ width: '100%', padding: '10px 14px', border: '1px solid #e0e0e0', borderRadius: '10px', marginBottom: '10px', fontFamily: 'Poppins, sans-serif', fontSize: '0.85rem', boxSizing: 'border-box' }} />
          <textarea value={description} onChange={e => setDescription(e.target.value)} placeholder={t('goals.desc_placeholder')}
            style={{ width: '100%', padding: '10px 14px', border: '1px solid #e0e0e0', borderRadius: '10px', marginBottom: '10px', fontFamily: 'Poppins, sans-serif', fontSize: '0.85rem', minHeight: '60px', resize: 'vertical', boxSizing: 'border-box' }} />
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginBottom: '10px' }}>
            {categories.map(c => (
              <button key={c.id} onClick={() => setCategory(c.id)} style={{
                padding: '6px 10px', borderRadius: '15px', border: 'none', cursor: 'pointer',
                background: category === c.id ? '#f5576c' : '#f0f4ff', color: category === c.id ? 'white' : '#32325d',
                fontSize: '0.7rem', fontWeight: 600, fontFamily: 'Poppins, sans-serif',
              }}>
                {c.icon} {t(c.key)}
              </button>
            ))}
          </div>
          <input type="date" value={deadline} onChange={e => setDeadline(e.target.value)}
            style={{ width: '100%', padding: '10px 14px', border: '1px solid #e0e0e0', borderRadius: '10px', marginBottom: '10px', fontFamily: 'Poppins, sans-serif', fontSize: '0.85rem', boxSizing: 'border-box' }} />
          <div style={{ display: 'flex', gap: '8px' }}>
            <button onClick={addGoal} style={{ flex: 1, background: '#f5576c', color: 'white', border: 'none', borderRadius: '20px', padding: '10px', fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif' }}>
              {t('goals.save')}
            </button>
            <button onClick={() => setShowAdd(false)} style={{ flex: 1, background: '#f0f0f0', color: '#666', border: 'none', borderRadius: '20px', padding: '10px', cursor: 'pointer', fontFamily: 'Poppins, sans-serif' }}>
              {t('family.cancel')}
            </button>
          </div>
        </div>
      )}

      {/* Active Goals */}
      {activeGoals.length > 0 && <h4 style={{ color: '#32325d', marginBottom: '10px' }}>🎯 {t('goals.active')}</h4>}
      {activeGoals.map(g => {
        const cat = categories.find(c => c.id === g.category);
        return (
          <div key={g.id} style={{ background: 'white', borderRadius: '12px', padding: '15px', marginBottom: '10px', boxShadow: '0 4px 15px rgba(0,0,0,0.06)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
              <h5 style={{ margin: 0, color: '#32325d', fontSize: '0.95rem' }}>{cat?.icon} {g.title}</h5>
              <button onClick={() => deleteGoal(g.id)} style={{ background: 'none', border: 'none', color: '#f5576c', cursor: 'pointer' }}>
                <i className="fas fa-trash" style={{ fontSize: '0.8rem' }}></i>
              </button>
            </div>
            {g.description && <p style={{ margin: '0 0 8px', fontSize: '0.8rem', color: '#8898aa' }}>{g.description}</p>}
            <div style={{ background: '#f0f0f0', borderRadius: '10px', height: '8px', marginBottom: '8px' }}>
              <div style={{ background: 'linear-gradient(to right, #f5576c, #f093fb)', borderRadius: '10px', height: '100%', width: `${g.progress}%`, transition: 'width 0.3s' }}></div>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: '0.75rem', color: '#8898aa' }}>{g.progress}%</span>
              <div style={{ display: 'flex', gap: '4px' }}>
                {[25, 50, 75, 100].map(p => (
                  <button key={p} onClick={() => updateProgress(g.id, p)} style={{
                    padding: '4px 8px', borderRadius: '10px', border: 'none', cursor: 'pointer',
                    background: g.progress >= p ? '#f5576c' : '#f0f4ff', color: g.progress >= p ? 'white' : '#666',
                    fontSize: '0.65rem', fontWeight: 600,
                  }}>{p}%</button>
                ))}
              </div>
            </div>
            {g.deadline && <div style={{ fontSize: '0.7rem', color: '#8898aa', marginTop: '5px' }}>📅 {g.deadline}</div>}
          </div>
        );
      })}

      {/* Completed */}
      {completedGoals.length > 0 && (
        <>
          <h4 style={{ color: '#2DCE89', marginTop: '20px', marginBottom: '10px' }}>✅ {t('goals.achieved')}</h4>
          {completedGoals.map(g => (
            <div key={g.id} style={{ background: 'linear-gradient(135deg, #e8fdf5, #d4f5e9)', borderRadius: '12px', padding: '12px 15px', marginBottom: '8px', border: '1px solid #2DCE89' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontWeight: 600, color: '#1a9f6e' }}>🏆 {g.title}</span>
                <span style={{ fontSize: '0.7rem', color: '#8898aa' }}>{new Date(g.date).toLocaleDateString()}</span>
              </div>
            </div>
          ))}
        </>
      )}

      {/* AI Goals & Dreams Assistant - Inline */}
      <div style={{ background: 'linear-gradient(135deg, #8965e0, #6a3fbb)', borderRadius: '16px', padding: '20px', marginTop: '20px', color: 'white' }}>
        <h4 style={{ color: 'white', marginBottom: '10px', display: 'flex', alignItems: 'center', gap: '8px' }}>
          🤖 {isRTL ? 'مساعد تحقيق الأهداف والأحلام' : 'Goals & Dreams AI Assistant'}
        </h4>
        <p style={{ fontSize: '0.8rem', opacity: 0.9, marginBottom: '12px' }}>
          {isRTL ? 'الذكاء الاصطناعي سيساعدك هنا مباشرة في تحقيق أهدافك' : 'AI will help you right here to achieve your goals'}
        </p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          <button onClick={() => setAiPrompt(isRTL
            ? `أريد أن أحول أحلامي إلى أهداف حقيقية. ساعدني في وضع خطة عملية لتحقيقها خطوة بخطوة مع نصائح نفسية للحفاظ على الحافز.`
            : `I want to turn my dreams into real goals. Help me create a practical step-by-step plan with psychological tips to stay motivated.`
          )} style={{ background: 'rgba(255,255,255,0.2)', border: 'none', color: 'white', borderRadius: '10px', padding: '10px', cursor: 'pointer', fontWeight: 600, fontSize: '0.8rem', fontFamily: 'Poppins, sans-serif' }}>
            🎯 {isRTL ? 'حوّل أحلامي لأهداف' : 'Turn dreams into goals'}
          </button>
          <button onClick={() => setAiPrompt(isRTL
            ? `أشعر أن أحلامي بعيدة المنال. ساعدني كأخ أكبر في التغلب على الخوف والشك الذاتي وكيف أبدأ بخطوات صغيرة نحو تحقيق ما أريد.`
            : `My dreams feel out of reach. Help me as a big brother to overcome fear and self-doubt, and start with small steps toward achieving what I want.`
          )} style={{ background: 'rgba(255,255,255,0.2)', border: 'none', color: 'white', borderRadius: '10px', padding: '10px', cursor: 'pointer', fontWeight: 600, fontSize: '0.8rem', fontFamily: 'Poppins, sans-serif' }}>
            💪 {isRTL ? 'تغلب على الخوف والشك' : 'Overcome fear & self-doubt'}
          </button>
          {activeGoals.length > 0 && (
            <button onClick={() => {
              const goalsSummary = activeGoals.map(g => `- ${g.title} (${g.progress}%)`).join('\n');
              setAiPrompt(isRTL
                ? `هذه أهدافي النشطة:\n${goalsSummary}\n\nساعدني في وضع خطة واقعية لتحقيقها وحافظ على حافزي.`
                : `These are my active goals:\n${goalsSummary}\n\nHelp me create a realistic plan and keep me motivated.`
              );
            }} style={{ background: 'rgba(255,255,255,0.2)', border: 'none', color: 'white', borderRadius: '10px', padding: '10px', cursor: 'pointer', fontWeight: 600, fontSize: '0.8rem', fontFamily: 'Poppins, sans-serif' }}>
              📊 {isRTL ? 'حلل أهدافي وساعدني' : 'Analyze my goals & help me'}
            </button>
          )}
        </div>
        <InlineAIChat context="goals" lang={lang} initialPrompt={aiPrompt} />
      </div>

      {/* Inspiration */}
      <div style={{ background: 'linear-gradient(135deg, #ffecd2, #fcb69f)', borderRadius: '16px', padding: '15px', marginTop: '15px', textAlign: 'center' }}>
        <p style={{ color: '#8b4513', fontSize: '0.9rem', fontWeight: 600, fontStyle: 'italic', margin: 0, lineHeight: 1.6 }}>
          {t('goals.quote')}
        </p>
      </div>
    </div>
  );
}
