import { useState } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import InlineAIChat from '../shared/InlineAIChat';

interface Recipe {
  id: string;
  name: string;
  utensil: string;
  ingredients: string;
  steps: string;
  memory: string;
  date: string;
}

export default function TraditionalCookingPage({ onBack }: { onBack: () => void }) {
  const { lang } = useLanguage();
  const isAr = lang === 'ar';
  const [recipes, setRecipes] = useLocalStorage<Recipe[]>('soon-traditional-cooking', []);
  const [name, setName] = useState('');
  const [utensil, setUtensil] = useState('');
  const [ingredients, setIngredients] = useState('');
  const [steps, setSteps] = useState('');
  const [memory, setMemory] = useState('');

  const l = {
    en: { title: '🍲 Traditional Cooking', subtitle: 'Cook with soul using traditional utensils', back: 'Home', name: 'Recipe name', utensil: 'Traditional utensil used (clay pot, cast iron...)', ingredients: 'Ingredients', steps: 'Steps', memory: 'Memory or feeling linked to this dish', save: '🍲 Save Recipe', empty: 'No recipes yet. Start cooking with love!', benefit: 'Why Traditional Cooking?', benefit_desc: 'Cooking with traditional utensils connects us to our roots, slows us down mindfully, and food cooked in clay/iron pots is often healthier. The process itself is therapeutic.' },
    ar: { title: '🍲 الطبخ التقليدي', subtitle: 'اطبخ بروح باستخدام أواني تقليدية', back: 'الرئيسية', name: 'اسم الوصفة', utensil: 'الإناء التقليدي (طاجين، قدر فخاري...)', ingredients: 'المكونات', steps: 'الخطوات', memory: 'ذكرى أو شعور مرتبط بهذا الطبق', save: '🍲 حفظ الوصفة', empty: 'لا توجد وصفات بعد. ابدأ الطبخ بحب!', benefit: 'لماذا الطبخ التقليدي؟', benefit_desc: 'الطبخ بالأواني التقليدية يربطنا بجذورنا، يبطئنا بوعي، والطعام المطبوخ في الأواني الفخارية والحديدية غالباً أكثر صحة. العملية نفسها علاجية.' },
    es: { title: '🍲 Cocina Tradicional', subtitle: 'Cocina con alma usando utensilios tradicionales', back: 'Inicio', name: 'Nombre', utensil: 'Utensilio tradicional', ingredients: 'Ingredientes', steps: 'Pasos', memory: 'Recuerdo vinculado', save: '🍲 Guardar', empty: '¡Sin recetas aún!', benefit: '¿Por qué cocina tradicional?', benefit_desc: 'Nos conecta con nuestras raíces y es terapéutico.' },
    fr: { title: '🍲 Cuisine Traditionnelle', subtitle: 'Cuisinez avec âme', back: 'Accueil', name: 'Nom', utensil: 'Ustensile traditionnel', ingredients: 'Ingrédients', steps: 'Étapes', memory: 'Souvenir lié', save: '🍲 Sauvegarder', empty: 'Pas de recettes encore!', benefit: 'Pourquoi la cuisine traditionnelle?', benefit_desc: 'Elle nous connecte à nos racines et est thérapeutique.' },
  };
  const t = l[lang as keyof typeof l] || l.en;

  const utensils = [
    { icon: '🏺', name: isAr ? 'طاجين' : 'Tagine' },
    { icon: '🫕', name: isAr ? 'قدر فخاري' : 'Clay Pot' },
    { icon: '🍳', name: isAr ? 'مقلاة حديدية' : 'Cast Iron Pan' },
    { icon: '🥘', name: isAr ? 'كسكس' : 'Couscousier' },
    { icon: '🪨', name: isAr ? 'حجر الطحن' : 'Stone Mortar' },
    { icon: '🔥', name: isAr ? 'تنور' : 'Tandoor/Oven' },
  ];

  const save = () => {
    if (!name.trim()) return;
    setRecipes(prev => [{ id: Date.now().toString(), name: name.trim(), utensil: utensil.trim(), ingredients: ingredients.trim(), steps: steps.trim(), memory: memory.trim(), date: new Date().toISOString() }, ...prev]);
    setName(''); setUtensil(''); setIngredients(''); setSteps(''); setMemory('');
  };

  const inputStyle = { width: '100%', padding: '12px', border: '2px solid #fed7aa', borderRadius: '12px', fontSize: '0.9rem', boxSizing: 'border-box' as const, fontFamily: 'Poppins, sans-serif', direction: isAr ? 'rtl' as const : 'ltr' as const };

  return (
    <div style={{ paddingTop: '20px', direction: isAr ? 'rtl' : 'ltr' }}>
      <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#ea580c', fontSize: '1rem', cursor: 'pointer', marginBottom: '15px' }}>
        <i className={`fas fa-arrow-${isAr ? 'right' : 'left'}`}></i> {t.back}
      </button>

      <div style={{ background: 'linear-gradient(135deg, #ea580c, #c2410c)', borderRadius: '20px', padding: '25px', color: 'white', textAlign: 'center', marginBottom: '20px' }}>
        <div style={{ fontSize: '2.5rem', marginBottom: '10px' }}>🍲🔥</div>
        <h2 style={{ fontSize: '1.3rem', fontWeight: 700, margin: '0 0 8px' }}>{t.title}</h2>
        <p style={{ fontSize: '0.85rem', opacity: 0.9, margin: 0 }}>{t.subtitle}</p>
      </div>

      {/* Utensil selector */}
      <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', marginBottom: '15px' }}>
        {utensils.map(u => (
          <button key={u.name} onClick={() => setUtensil(u.name)} style={{
            padding: '8px 12px', borderRadius: '20px', border: 'none', cursor: 'pointer',
            background: utensil === u.name ? '#ea580c' : '#fff7ed',
            color: utensil === u.name ? 'white' : '#9a3412', fontSize: '0.75rem', fontWeight: 600,
          }}>{u.icon} {u.name}</button>
        ))}
      </div>

      {/* Add recipe */}
      <div style={{ background: 'white', borderRadius: '16px', padding: '20px', marginBottom: '15px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)' }}>
        <input value={name} onChange={e => setName(e.target.value)} placeholder={t.name} style={{ ...inputStyle, marginBottom: '10px' }} />
        <textarea value={ingredients} onChange={e => setIngredients(e.target.value)} placeholder={t.ingredients} style={{ ...inputStyle, marginBottom: '10px', minHeight: '60px', resize: 'vertical' }} />
        <textarea value={steps} onChange={e => setSteps(e.target.value)} placeholder={t.steps} style={{ ...inputStyle, marginBottom: '10px', minHeight: '80px', resize: 'vertical' }} />
        <input value={memory} onChange={e => setMemory(e.target.value)} placeholder={t.memory} style={{ ...inputStyle, marginBottom: '15px' }} />
        <button onClick={save} style={{ width: '100%', background: 'linear-gradient(135deg, #ea580c, #c2410c)', color: 'white', border: 'none', borderRadius: '12px', padding: '14px', fontWeight: 600, cursor: 'pointer' }}>{t.save}</button>
      </div>

      {/* Recipes list */}
      {recipes.length === 0 && <p style={{ textAlign: 'center', color: '#8898aa' }}>{t.empty}</p>}
      {recipes.map(r => (
        <div key={r.id} style={{ background: 'white', borderRadius: '12px', padding: '15px', marginBottom: '10px', borderLeft: '4px solid #ea580c' }}>
          <h4 style={{ margin: '0 0 5px', color: '#9a3412' }}>🍲 {r.name}</h4>
          {r.utensil && <span style={{ fontSize: '0.75rem', background: '#fff7ed', color: '#ea580c', padding: '2px 8px', borderRadius: '10px' }}>{r.utensil}</span>}
          {r.memory && <p style={{ color: '#8898aa', fontSize: '0.8rem', margin: '8px 0 0', fontStyle: 'italic' }}>💭 {r.memory}</p>}
        </div>
      ))}

      <div style={{ background: 'linear-gradient(135deg, #fff7ed, #fed7aa)', borderRadius: '16px', padding: '15px', marginTop: '15px', borderLeft: '4px solid #ea580c' }}>
        <h4 style={{ color: '#9a3412', marginBottom: '8px' }}>🏺 {t.benefit}</h4>
        <p style={{ color: '#32325d', fontSize: '0.85rem', lineHeight: 1.6, margin: 0 }}>{t.benefit_desc}</p>
      </div>
      <InlineAIChat context="traditional-cooking" lang={lang} />
    </div>
  );
}
