import { useState } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { supabase } from '@/integrations/supabase/client';
import InlineAIChat from '../shared/InlineAIChat';

interface SadKnowledgePageProps { onBack: () => void; }

export default function SadKnowledgePage({ onBack }: SadKnowledgePageProps) {
  const { lang } = useLanguage();
  const isAr = lang === 'ar';
  const [bodyLocation, setBodyLocation] = useState('');
  const [oldestMemory, setOldestMemory] = useState('');
  const [pattern, setPattern] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState('');
  const [decoderTool, setDecoderTool] = useState('');

  const labels = {
    en: {
      title: '🔑 Body Message Decoder', subtitle: 'Your body is speaking — let\'s translate it',
      bodyQ: 'Where do you feel it in your body? *', bodyHint: 'Chest tightness, stomach knot, throat lump, heavy shoulders, headache...',
      memoryQ: 'Any memory or moment it reminds you of? (optional)', memoryHint: 'Even a vague feeling or image is enough...',
      patternQ: 'A pattern you keep noticing? (optional)', patternHint: 'I always..., people always..., every time I...',
      decode: 'Translate My Body', back: 'Back',
      messageTitle: '🗣️ What your body is saying',
      needTitle: '💗 What your body needs from you right now',
      toolTitle: '🔧 A small thing you can do now',
    },
    ar: {
      title: '🔑 مترجم رسائل الجسم', subtitle: 'جسمك يتكلم — دعنا نترجم ما يقوله',
      bodyQ: 'أين تشعر بذلك في جسمك؟ *', bodyHint: 'ضيق في الصدر، عقدة في المعدة، غصة في الحلق، ثقل في الكتفين، صداع...',
      memoryQ: 'هل يذكّرك بذكرى أو لحظة؟ (اختياري)', memoryHint: 'حتى شعور غامض أو صورة يكفي...',
      patternQ: 'هل تلاحظ نمطاً يتكرر؟ (اختياري)', patternHint: 'دائماً أنا...، الناس دائماً...، كل مرة...',
      decode: 'ترجم لي ما يقوله جسمي', back: 'رجوع',
      messageTitle: '🗣️ ما يحاول جسمك قوله لك',
      needTitle: '💗 ما يحتاجه جسمك منك الآن',
      toolTitle: '🔧 خطوة صغيرة تستطيع فعلها الآن',
    },
    es: { title: '🔑 Decodificador de Mensajes del Cuerpo', subtitle: 'Tu cuerpo habla — traduzcámoslo', bodyQ: '¿Dónde lo sientes en tu cuerpo? *', bodyHint: 'Pecho, estómago, garganta...', memoryQ: '¿Un recuerdo asociado? (opcional)', memoryHint: 'Incluso una sensación vaga...', patternQ: '¿Un patrón que se repite? (opcional)', patternHint: 'Siempre yo...', decode: 'Traducir mi cuerpo', back: 'Volver', messageTitle: '🗣️ Lo que tu cuerpo dice', needTitle: '💗 Lo que necesita ahora', toolTitle: '🔧 Algo pequeño que puedes hacer' },
    fr: { title: '🔑 Décodeur des Messages du Corps', subtitle: 'Votre corps parle — traduisons-le', bodyQ: 'Où le ressentez-vous? *', bodyHint: 'Poitrine, estomac, gorge...', memoryQ: 'Un souvenir associé? (optionnel)', memoryHint: 'Même un sentiment vague...', patternQ: 'Un schéma récurrent? (optionnel)', patternHint: 'Je suis toujours...', decode: 'Traduire mon corps', back: 'Retour', messageTitle: '🗣️ Ce que votre corps dit', needTitle: '💗 Ce dont il a besoin', toolTitle: '🔧 Un petit geste à faire' },
  };
  const l = (labels as any)[lang] || labels.en;

  const decode = async () => {
    if (!bodyLocation.trim() || loading) return;
    setLoading(true); setResult(''); setDecoderTool('');
    try {
      const seed = Math.random().toString(36).slice(2, 8);
      const userContent = isAr
        ? `الإحساس الجسدي: ${bodyLocation}\nذكرى مرتبطة: ${oldestMemory || 'لا شيء'}\nنمط متكرر: ${pattern || 'لا شيء'}`
        : `Body sensation: ${bodyLocation}\nAssociated memory: ${oldestMemory || 'none'}\nRepeating pattern: ${pattern || 'none'}`;

      const systemPrompt = isAr
        ? `أنت معالج نفسي جسدي (somatic therapist). مهمتك أن تترجم الأحاسيس الجسدية إلى رسالة عاطفية واضحة كأن الجسم نفسه يتكلم بصوت المستخدم. لا تذكر أي شخصية أسطورية. لا تستخدم رموز ماركداون. كن دافئاً ومحدداً ومختصراً. معرّف التنويع: ${seed}
أجب بهذا التنسيق فقط:
[الرسالة]: ما يحاول الجسم قوله بصيغة المتكلم (3-5 جمل تبدأ بـ "أنا..." كأن الجسم يتحدث)
[الحاجة]: ما الذي يحتاجه الجسم من المستخدم الآن (جملتان)
[الأداة]: تمرين جسدي صغير محدد أو سؤال تأملي يمكن فعله خلال دقيقتين`
        : `You are a somatic therapist. Translate the body sensation into a clear emotional message as if the body itself is speaking in first person. Do NOT mention any mythological character. No markdown. Be warm, specific, and concise. Variation id: ${seed}
Reply in exactly this format:
[Message]: What the body is trying to say in first person (3-5 sentences starting with "I..." as the body speaking)
[Need]: What the body needs from the user right now (2 sentences)
[Tool]: One specific small somatic exercise or reflective question doable within 2 minutes`;

      const { data, error } = await supabase.functions.invoke('groq-chat', {
        body: {
          messages: [{ role: 'user', content: userContent }],
          systemPrompt,
        }
      });
      if (error) throw error;
      let content = (data?.content || '').replace(/#{1,6}\s*/g, '').replace(/\*\*(.*?)\*\*/g, '$1').replace(/\*(.*?)\*/g, '$1').trim();

      const parse = (tag: string) => {
        const regex = new RegExp(`\\[${tag}\\]:\\s*(.+?)(?=\\n?\\[|$)`, 's');
        return regex.exec(content)?.[1]?.trim() || '';
      };
      const message = parse(isAr ? 'الرسالة' : 'Message');
      const need = parse(isAr ? 'الحاجة' : 'Need');
      const tool = parse(isAr ? 'الأداة' : 'Tool');

      if (message || need || tool) {
        const main = [message && `${l.messageTitle}\n${message}`, need && `\n\n${l.needTitle}\n${need}`].filter(Boolean).join('');
        setResult(main || content);
        setDecoderTool(tool);
      } else {
        // Fallback: show raw content so the user always sees something.
        setResult(content || (isAr ? 'لم يصل رد. حاول مرة أخرى.' : 'No response. Please try again.'));
      }
    } catch {
      setResult(isAr ? '❌ حدث خطأ، حاول مرة أخرى' : '❌ An error occurred');
    } finally {
      setLoading(false);
    }
  };


  const fieldStyle = { width: '100%', padding: '12px 14px', border: '2px solid #e9d5ff', borderRadius: '12px', fontFamily: 'Poppins, sans-serif', fontSize: '0.9rem', boxSizing: 'border-box' as const, direction: isAr ? 'rtl' as const : 'ltr' as const, marginBottom: '6px' };

  return (
    <div style={{ paddingTop: '10px', direction: isAr ? 'rtl' : 'ltr' }}>
      <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#7c3aed', fontSize: '1rem', cursor: 'pointer', marginBottom: '12px', fontFamily: 'Poppins, sans-serif' }}>
        <i className={`fas fa-arrow-${isAr ? 'right' : 'left'}`}></i> {l.back}
      </button>

      <div style={{ textAlign: 'center', marginBottom: '20px', background: 'linear-gradient(135deg, #4c1d95, #7c3aed, #a855f7)', borderRadius: '20px', padding: '25px 15px', color: 'white' }}>
        <div style={{ fontSize: '2.5rem', marginBottom: '8px' }}>🔑</div>
        <h2 style={{ margin: '0 0 6px', fontSize: '1.3rem', fontWeight: 800 }}>{l.title}</h2>
        <p style={{ margin: 0, fontSize: '0.85rem', opacity: 0.9 }}>{l.subtitle}</p>
      </div>

      {/* Body Map Questions */}
      <div style={{ background: 'white', borderRadius: '16px', padding: '18px', marginBottom: '15px', boxShadow: '0 6px 25px rgba(0,0,0,0.08)' }}>
        <div style={{ marginBottom: '15px' }}>
          <label style={{ fontWeight: 700, fontSize: '0.9rem', color: '#4c1d95', display: 'block', marginBottom: '6px' }}>🫀 {l.bodyQ}</label>
          <input value={bodyLocation} onChange={e => setBodyLocation(e.target.value)} placeholder={l.bodyHint} style={fieldStyle} />
        </div>

        <div style={{ marginBottom: '15px' }}>
          <label style={{ fontWeight: 700, fontSize: '0.9rem', color: '#4c1d95', display: 'block', marginBottom: '6px' }}>🕰️ {l.memoryQ}</label>
          <textarea value={oldestMemory} onChange={e => setOldestMemory(e.target.value)} placeholder={l.memoryHint} rows={2} style={{ ...fieldStyle, resize: 'none' }} />
        </div>

        <div style={{ marginBottom: '15px' }}>
          <label style={{ fontWeight: 700, fontSize: '0.9rem', color: '#4c1d95', display: 'block', marginBottom: '6px' }}>🔄 {l.patternQ}</label>
          <textarea value={pattern} onChange={e => setPattern(e.target.value)} placeholder={l.patternHint} rows={2} style={{ ...fieldStyle, resize: 'none' }} />
        </div>

        <button onClick={decode} disabled={!bodyLocation.trim() || loading} style={{
          width: '100%', padding: '14px', border: 'none', borderRadius: '14px', cursor: 'pointer', fontWeight: 700,
          background: bodyLocation.trim() ? 'linear-gradient(135deg, #4c1d95, #7c3aed)' : '#d1d5db',
          color: 'white', fontSize: '0.95rem', fontFamily: 'Poppins, sans-serif',
        }}>
          {loading ? '⏳ ...' : `🔮 ${l.decode}`}
        </button>
      </div>

      {loading && (
        <div style={{ textAlign: 'center', padding: '30px', background: 'linear-gradient(135deg, #4c1d95, #6d28d9)', borderRadius: '16px', color: 'white', marginBottom: '15px' }}>
          <div style={{ fontSize: '3rem', animation: 'pulse 2s infinite' }}>🔑</div>
          <p>{isAr ? 'جاري فك الشفرة...' : 'Decoding your body\'s wisdom...'}</p>
        </div>
      )}

      {result && (
        <div style={{ background: 'linear-gradient(135deg, #1e1b4b, #312e81)', borderRadius: '20px', padding: '20px', color: 'white', marginBottom: '15px', border: '2px solid #7c3aed' }}>
          <div style={{ fontSize: '0.9rem', lineHeight: 1.8, whiteSpace: 'pre-wrap' }}>{result}</div>
        </div>
      )}

      {decoderTool && (
        <div style={{ background: 'linear-gradient(135deg, #fef3c7, #fde68a)', borderRadius: '16px', padding: '18px', marginBottom: '15px', border: '2px solid #f59e0b' }}>
          <h4 style={{ color: '#92400e', margin: '0 0 8px', fontSize: '0.9rem' }}>{l.toolTitle}</h4>
          <p style={{ margin: 0, fontSize: '0.88rem', color: '#78350f', lineHeight: 1.7 }}>{decoderTool}</p>
        </div>
      )}

      <InlineAIChat context="sad-knowledge-decoder somatic therapy mythology" lang={lang} />
    </div>
  );
}
