import { useState, useEffect, useRef } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { supabase } from '@/integrations/supabase/client';

interface GroupsPageProps { onBack: () => void; }

export default function GroupsPage({ onBack }: GroupsPageProps) {
  const { lang } = useLanguage();
  const [userName] = useLocalStorage<string>('soon-user-name', '');
  const [groups, setGroups] = useState<any[]>([]);
  const [activeGroup, setActiveGroup] = useState<any>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [msgInput, setMsgInput] = useState('');
  const [showCreate, setShowCreate] = useState(false);
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [isPrivate, setIsPrivate] = useState(false);
  const [joinCode, setJoinCode] = useState('');
  const [tab, setTab] = useState<'official' | 'community'>('official');
  const [challengeChecked, setChallengeChecked] = useLocalStorage<Record<string, string[]>>('soon-group-challenges', {});
  const [myGroups] = useLocalStorage<string[]>('soon-my-groups', []);
  const [, setMyGroupsRaw] = useLocalStorage<string[]>('soon-my-groups', []);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const isAr = lang === 'ar';

  const labels: Record<string, Record<string, string>> = {
    en: { title: '👥 Groups', subtitle: 'Join communities and connect', create: 'Create Group', join: 'Join by Code', name: 'Group name', desc: 'Description', code: 'Invite code', send: 'Send', back: 'Back', share: 'Share Link', copied: 'Link copied!', msg_placeholder: 'Type a message...', no_msgs: 'No messages yet. Start the conversation!', official: 'Official', community: 'Community', private: 'Private (link only)', private_note: 'Only people with the link can see this group', challenge: 'Daily Challenge', done_count: 'completed', my_groups: 'My Groups', stats: 'Stats', members: 'Members', active_today: 'Active Today', challenges_done: 'Challenges Done' },
    ar: { title: '👥 المجموعات', subtitle: 'انضم لمجتمعات وتواصل', create: 'إنشاء مجموعة', join: 'انضم بالكود', name: 'اسم المجموعة', desc: 'الوصف', code: 'كود الدعوة', send: 'إرسال', back: 'رجوع', share: 'مشاركة الرابط', copied: 'تم نسخ الرابط!', msg_placeholder: 'اكتب رسالة...', no_msgs: 'لا توجد رسائل بعد. ابدأ المحادثة!', official: 'رسمية', community: 'مجتمعية', private: 'خاصة (بالرابط فقط)', private_note: 'فقط من لديه الرابط يمكنه رؤية هذه المجموعة', challenge: 'تحدي اليوم', done_count: 'أكملوا', my_groups: 'مجموعاتي', stats: 'إحصائيات', members: 'الأعضاء', active_today: 'نشطون اليوم', challenges_done: 'تحديات منجزة' },
    es: { title: '👥 Grupos', subtitle: 'Únete a comunidades', create: 'Crear Grupo', join: 'Unirse por código', name: 'Nombre', desc: 'Descripción', code: 'Código', send: 'Enviar', back: 'Volver', share: 'Compartir enlace', copied: '¡Enlace copiado!', msg_placeholder: 'Escribe un mensaje...', no_msgs: '¡Sin mensajes aún!', official: 'Oficiales', community: 'Comunidad', private: 'Privado', private_note: 'Solo con enlace', challenge: 'Reto del día', done_count: 'completaron', my_groups: 'Mis Grupos', stats: 'Estadísticas', members: 'Miembros', active_today: 'Activos hoy', challenges_done: 'Retos completados' },
    fr: { title: '👥 Groupes', subtitle: 'Rejoignez des communautés', create: 'Créer un groupe', join: 'Rejoindre par code', name: 'Nom', desc: 'Description', code: 'Code', send: 'Envoyer', back: 'Retour', share: 'Partager le lien', copied: 'Lien copié!', msg_placeholder: 'Écrivez un message...', no_msgs: 'Pas de messages encore!', official: 'Officiels', community: 'Communauté', private: 'Privé', private_note: 'Lien uniquement', challenge: 'Défi du jour', done_count: 'ont complété', my_groups: 'Mes Groupes', stats: 'Statistiques', members: 'Membres', active_today: 'Actifs aujourd\'hui', challenges_done: 'Défis complétés' },
  };
  const l = labels[lang] || labels.en;

  const officialGroupNames: Record<string, Record<string, string>> = {
    'Book Club': { en: 'Book Club', ar: 'نادي الكتب', es: 'Club de Lectura', fr: 'Club de Lecture' },
    'Meditation': { en: 'Meditation', ar: 'التأمل', es: 'Meditación', fr: 'Méditation' },
    'Human Connection': { en: 'Human Connection', ar: 'التواصل الإنساني', es: 'Conexión Humana', fr: 'Connexion Humaine' },
    'Holiday Greetings': { en: 'Holiday Greetings', ar: 'تهنئة بالأعياد', es: 'Felicitaciones', fr: 'Vœux de Fêtes' },
  };
  const officialGroupDescs: Record<string, Record<string, string>> = {
    'Book Club': { en: 'Read and discuss books together', ar: 'اقرأ وناقش الكتب معاً', es: 'Lee y discute libros', fr: 'Lisez et discutez des livres' },
    'Meditation': { en: 'Practice mindfulness together', ar: 'مارس التأمل معاً', es: 'Practica mindfulness juntos', fr: 'Pratiquez la pleine conscience' },
    'Human Connection': { en: 'Share and connect authentically', ar: 'شارك وتواصل بصدق', es: 'Comparte y conecta', fr: 'Partagez et connectez-vous' },
    'Holiday Greetings': { en: 'Celebrate together', ar: 'احتفلوا معاً', es: 'Celebren juntos', fr: 'Célébrez ensemble' },
  };

  const getTranslatedName = (g: any) => officialGroupNames[g.name]?.[lang] || g.name;
  const getTranslatedDesc = (g: any) => officialGroupDescs[g.name]?.[lang] || g.description;

  const getDailyChallenge = (group: any) => {
    const day = new Date().getDay();
    const challenges: Record<string, { en: string; ar: string }[]> = {
      'Book Club': [
        { en: '📖 Read 1 page from "Atomic Habits" by James Clear today', ar: '📖 اقرأ صفحة واحدة من كتاب "العادات الذرية" لجيمس كلير اليوم' },
        { en: '📖 Read 1 page from "The Power of Now" by Eckhart Tolle', ar: '📖 اقرأ صفحة من "قوة الآن" لإيكهارت تول' },
        { en: '📖 Read 1 page from "Man\'s Search for Meaning" by Viktor Frankl', ar: '📖 اقرأ صفحة من "الإنسان يبحث عن معنى" لفيكتور فرانكل' },
        { en: '📖 Read 1 page from "Thinking, Fast and Slow" by Daniel Kahneman', ar: '📖 اقرأ صفحة من "التفكير السريع والبطيء" لدانيال كانمان' },
        { en: '📖 Read 1 page from "The 7 Habits of Highly Effective People"', ar: '📖 اقرأ صفحة من "العادات السبع للناس الأكثر فعالية"' },
        { en: '📖 Read 1 page from "Deep Work" by Cal Newport', ar: '📖 اقرأ صفحة من "العمل العميق" لكال نيوبورت' },
        { en: '📖 Share a quote that inspired you from your reading', ar: '📖 شارك اقتباساً ألهمك من قراءتك' },
      ],
      'Meditation': [
        { en: '🧘 Meditate for 5 minutes focusing on your breath', ar: '🧘 تأمل 5 دقائق مع التركيز على تنفسك' },
        { en: '🧘 Practice body scan meditation for 3 minutes', ar: '🧘 مارس تأمل مسح الجسم 3 دقائق' },
        { en: '🧘 Do a gratitude meditation: think of 3 things', ar: '🧘 تأمل الامتنان: فكر في 3 أشياء' },
        { en: '🧘 Try walking meditation for 5 minutes', ar: '🧘 جرب تأمل المشي 5 دقائق' },
        { en: '🧘 Practice loving-kindness meditation', ar: '🧘 مارس تأمل المحبة واللطف' },
        { en: '🧘 Sit silently for 3 minutes. Just observe.', ar: '🧘 اجلس بصمت 3 دقائق. فقط راقب.' },
        { en: '🧘 Deep breathing: 4-7-8 technique, 5 rounds', ar: '🧘 تنفس عميق: تقنية 4-7-8، 5 جولات' },
      ],
      'Human Connection': [
        { en: '💬 Send a kind message to someone you haven\'t talked to in a while', ar: '💬 أرسل رسالة لطيفة لشخص لم تتحدث معه منذ فترة' },
        { en: '💬 Compliment a stranger or colleague today', ar: '💬 أثنِ على شخص غريب أو زميل اليوم' },
        { en: '💬 Listen deeply to someone without interrupting', ar: '💬 استمع بعمق لشخص بدون مقاطعة' },
        { en: '💬 Share something vulnerable with someone you trust', ar: '💬 شارك شيئاً شخصياً مع شخص تثق به' },
        { en: '💬 Call a family member just to check on them', ar: '💬 اتصل بفرد من عائلتك فقط للاطمئنان' },
        { en: '💬 Write a thank you note to someone', ar: '💬 اكتب رسالة شكر لشخص ما' },
        { en: '💬 Ask someone "How are you really?" and truly listen', ar: '💬 اسأل شخصاً "كيف حالك حقاً؟" واستمع بجدية' },
      ],
    };

    const groupChallenges = challenges[group.name];
    if (!groupChallenges) {
      const generic = [
        { en: '🌟 Share something positive with the group today', ar: '🌟 شارك شيئاً إيجابياً مع المجموعة اليوم' },
        { en: '🌟 Encourage another member in the group', ar: '🌟 شجع عضواً آخر في المجموعة' },
        { en: '🌟 Share a tip or resource with the group', ar: '🌟 شارك نصيحة أو مصدراً مع المجموعة' },
        { en: '🌟 Set a small goal and share it with the group', ar: '🌟 ضع هدفاً صغيراً وشاركه مع المجموعة' },
        { en: '🌟 Reflect on your progress and share a win', ar: '🌟 تأمل تقدمك وشارك انتصاراً' },
        { en: '🌟 Ask a thoughtful question to the group', ar: '🌟 اسأل سؤالاً عميقاً للمجموعة' },
        { en: '🌟 Share what you learned this week', ar: '🌟 شارك ما تعلمته هذا الأسبوع' },
      ];
      return isAr ? generic[day].ar : generic[day].en;
    }
    return isAr ? groupChallenges[day].ar : groupChallenges[day].en;
  };

  const getChallengeKey = (groupId: string) => `${groupId}-${new Date().toDateString()}`;

  const toggleChallenge = async (groupId: string) => {
    const key = getChallengeKey(groupId);
    const uName = userName || 'Anonymous';
    setChallengeChecked(prev => {
      const current = prev[key] || [];
      if (current.includes(uName)) return { ...prev, [key]: current.filter(n => n !== uName) };
      return { ...prev, [key]: [...current, uName] };
    });
    // Also send a message to the group to notify others
    await supabase.from('group_messages').insert({
      group_id: groupId,
      sender_name: uName,
      content: isAr ? `✅ ${uName} أكمل تحدي اليوم!` : `✅ ${uName} completed today's challenge!`
    });
  };

  const getChallengeCount = (groupId: string) => {
    const key = getChallengeKey(groupId);
    return (challengeChecked[key] || []).length;
  };

  const isChallengeCheckedByMe = (groupId: string) => {
    const key = getChallengeKey(groupId);
    return (challengeChecked[key] || []).includes(userName || 'Anonymous');
  };

  // Fetch groups + auto-refresh every 30s
  const fetchGroups = async () => {
    const { data } = await supabase.from('groups').select('*').order('created_at');
    if (data) setGroups(data);
  };

  useEffect(() => {
    fetchGroups();
    const interval = setInterval(fetchGroups, 30000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (!activeGroup) return;
    const fetchMsgs = async () => {
      const { data } = await supabase.from('group_messages').select('*').eq('group_id', activeGroup.id).order('created_at');
      if (data) setMessages(data);
    };
    fetchMsgs();
    const channel = supabase.channel(`group-${activeGroup.id}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'group_messages', filter: `group_id=eq.${activeGroup.id}` },
        (payload) => setMessages(prev => [...prev, payload.new]))
      .subscribe();
    // Also refresh messages every 30s
    const interval = setInterval(fetchMsgs, 30000);
    return () => { supabase.removeChannel(channel); clearInterval(interval); };
  }, [activeGroup]);

  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  const sendMessage = async () => {
    if (!msgInput.trim() || !activeGroup) return;
    const content = msgInput.trim();
    setMsgInput('');
    await supabase.from('group_messages').insert({ group_id: activeGroup.id, sender_name: userName || 'Anonymous', content });
  };

  const createGroup = async () => {
    if (!newName.trim()) return;
    const groupType = isPrivate ? 'private' : 'custom';
    const { data } = await supabase.from('groups').insert({ name: newName.trim(), description: newDesc.trim(), group_type: groupType, created_by: userName || 'Anonymous', icon: '💬' }).select().single();
    if (data) {
      setGroups(prev => [...prev, data]);
      // Save to my groups
      setMyGroupsRaw(prev => [...prev, data.id]);
      setShowCreate(false); setNewName(''); setNewDesc(''); setIsPrivate(false);
      setActiveGroup(data);
    }
  };

  const joinByCode = async () => {
    if (!joinCode.trim()) return;
    const { data } = await supabase.from('groups').select('*').eq('invite_code', joinCode.trim()).single();
    if (data) { setActiveGroup(data); setJoinCode(''); setMyGroupsRaw(prev => prev.includes(data.id) ? prev : [...prev, data.id]); }
    else alert(isAr ? 'كود غير صحيح' : 'Invalid code');
  };

  const shareGroup = (group: any) => {
    const link = `${window.location.origin}/group/${group.invite_code}`;
    if (navigator.share) navigator.share({ url: link, title: getTranslatedName(group) });
    else { navigator.clipboard.writeText(link); alert(l.copied); }
  };

  const inputStyle = { width: '100%', padding: '10px 14px', border: '1px solid #e5e7eb', borderRadius: '12px', fontFamily: 'Poppins, sans-serif', fontSize: '0.85rem', outline: 'none', boxSizing: 'border-box' as const, direction: isAr ? 'rtl' as const : 'ltr' as const };

  const officialGroups = groups.filter(g => g.group_type === 'predefined');
  const communityGroups = groups.filter(g => g.group_type === 'custom');
  const privateGroups = groups.filter(g => g.group_type === 'private' && myGroups.includes(g.id));

  // Get daily unique senders as "active today" count
  const getActiveTodayCount = (groupId: string) => {
    const today = new Date().toDateString();
    const todayMsgs = messages.filter(m => m.group_id === groupId && new Date(m.created_at).toDateString() === today);
    return new Set(todayMsgs.map(m => m.sender_name)).size;
  };

  // Chat view
  if (activeGroup) return (
    <div style={{ paddingTop: '10px', direction: isAr ? 'rtl' : 'ltr' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '10px' }}>
        <button onClick={() => setActiveGroup(null)} style={{ background: 'none', border: 'none', color: '#6366f1', fontSize: '1.2rem', cursor: 'pointer' }}>
          <i className={`fas fa-arrow-${isAr ? 'right' : 'left'}`}></i>
        </button>
        <div style={{ flex: 1 }}>
          <h3 style={{ margin: 0, color: '#32325d', fontSize: '1.1rem' }}>{activeGroup.icon} {activeGroup.group_type === 'predefined' ? getTranslatedName(activeGroup) : activeGroup.name}</h3>
          <p style={{ margin: 0, color: '#8898aa', fontSize: '0.75rem' }}>{activeGroup.group_type === 'predefined' ? getTranslatedDesc(activeGroup) : activeGroup.description}</p>
        </div>
        <button onClick={() => shareGroup(activeGroup)} style={{ background: '#6366f1', color: 'white', border: 'none', borderRadius: '20px', padding: '6px 14px', fontSize: '0.75rem', cursor: 'pointer', fontWeight: 600 }}>
          📤 {l.share}
        </button>
      </div>

      {/* Stats bar */}
      <div style={{ display: 'flex', gap: '8px', marginBottom: '10px' }}>
        <div style={{ flex: 1, background: '#f0f4ff', borderRadius: '10px', padding: '8px', textAlign: 'center' }}>
          <div style={{ fontSize: '1.1rem', fontWeight: 700, color: '#6366f1' }}>{messages.length}</div>
          <div style={{ fontSize: '0.65rem', color: '#8898aa' }}>{l.members}</div>
        </div>
        <div style={{ flex: 1, background: '#f0fdf4', borderRadius: '10px', padding: '8px', textAlign: 'center' }}>
          <div style={{ fontSize: '1.1rem', fontWeight: 700, color: '#22c55e' }}>{getActiveTodayCount(activeGroup.id)}</div>
          <div style={{ fontSize: '0.65rem', color: '#8898aa' }}>{l.active_today}</div>
        </div>
        <div style={{ flex: 1, background: '#fefce8', borderRadius: '10px', padding: '8px', textAlign: 'center' }}>
          <div style={{ fontSize: '1.1rem', fontWeight: 700, color: '#f59e0b' }}>{getChallengeCount(activeGroup.id)}</div>
          <div style={{ fontSize: '0.65rem', color: '#8898aa' }}>{l.challenges_done}</div>
        </div>
      </div>

      {/* Daily Challenge */}
      <div style={{ background: 'linear-gradient(135deg, #fef3c7, #fde68a)', borderRadius: '12px', padding: '12px', marginBottom: '10px', border: '2px solid #f59e0b' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: '0.7rem', fontWeight: 700, color: '#92400e', marginBottom: '4px' }}>🎯 {l.challenge}</div>
            <div style={{ fontSize: '0.82rem', color: '#78350f', lineHeight: 1.4 }}>{getDailyChallenge(activeGroup)}</div>
          </div>
          <button onClick={() => toggleChallenge(activeGroup.id)} style={{
            width: 40, height: 40, borderRadius: '50%', border: 'none', cursor: 'pointer', flexShrink: 0,
            background: isChallengeCheckedByMe(activeGroup.id) ? '#2DCE89' : '#e5e7eb',
            color: 'white', fontSize: '1.2rem', display: 'flex', alignItems: 'center', justifyContent: 'center',
            marginLeft: '10px',
          }}>
            {isChallengeCheckedByMe(activeGroup.id) ? '✓' : ''}
          </button>
        </div>
        <div style={{ fontSize: '0.7rem', color: '#92400e', marginTop: '6px', textAlign: 'center' }}>
          ✅ {getChallengeCount(activeGroup.id)} {l.done_count}
        </div>
      </div>

      <div style={{ background: '#f8fafc', borderRadius: '16px', padding: '15px', minHeight: '300px', maxHeight: '400px', overflowY: 'auto', marginBottom: '10px' }}>
        {messages.length === 0 && <p style={{ textAlign: 'center', color: '#8898aa', fontSize: '0.85rem', padding: '40px 0' }}>{l.no_msgs}</p>}
        {messages.map((m: any) => {
          const isMe = m.sender_name === (userName || 'Anonymous');
          const isChallenge = m.content?.includes('✅') && m.content?.includes('completed') || m.content?.includes('أكمل');
          return (
            <div key={m.id} style={{ display: 'flex', justifyContent: isMe ? 'flex-end' : 'flex-start', marginBottom: '8px' }}>
              <div style={{
                background: isChallenge ? 'linear-gradient(135deg, #fef3c7, #fde68a)' : isMe ? 'linear-gradient(135deg, #6366f1, #8b5cf6)' : 'white',
                color: isChallenge ? '#92400e' : isMe ? 'white' : '#32325d', borderRadius: '16px', padding: '10px 14px',
                maxWidth: '75%', boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
              }}>
                {!isMe && <div style={{ fontSize: '0.7rem', fontWeight: 700, color: isChallenge ? '#78350f' : '#6366f1', marginBottom: '2px' }}>{m.sender_name}</div>}
                <div style={{ fontSize: '0.85rem', lineHeight: 1.5 }}>{m.content}</div>
                <div style={{ fontSize: '0.65rem', opacity: 0.6, marginTop: '4px', textAlign: 'right' }}>
                  {new Date(m.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      <div style={{ display: 'flex', gap: '8px' }}>
        <input value={msgInput} onChange={e => setMsgInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && sendMessage()}
          placeholder={l.msg_placeholder} style={{ ...inputStyle, flex: 1, marginBottom: 0 }} />
        <button onClick={sendMessage} style={{ background: '#6366f1', color: 'white', border: 'none', borderRadius: '12px', padding: '10px 18px', cursor: 'pointer', fontWeight: 600, fontFamily: 'Poppins, sans-serif', flexShrink: 0 }}>
          {l.send}
        </button>
      </div>
    </div>
  );

  // Groups list view
  return (
    <div style={{ paddingTop: '20px', direction: isAr ? 'rtl' : 'ltr' }}>
      <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#6366f1', fontSize: '1rem', cursor: 'pointer', marginBottom: '15px', fontFamily: 'Poppins, sans-serif' }}>
        <i className={`fas fa-arrow-${isAr ? 'right' : 'left'}`}></i> {l.back}
      </button>

      <div style={{ textAlign: 'center', marginBottom: '20px' }}>
        <h2 style={{ color: '#6366f1', fontSize: '1.5rem', margin: '0 0 5px' }}>{l.title}</h2>
        <p style={{ color: '#8898aa', fontSize: '0.85rem', margin: 0 }}>{l.subtitle}</p>
      </div>

      <div style={{ display: 'flex', gap: '8px', marginBottom: '15px' }}>
        <input value={joinCode} onChange={e => setJoinCode(e.target.value)} placeholder={l.code} style={{ ...inputStyle, flex: 1, marginBottom: 0 }} />
        <button onClick={joinByCode} style={{ background: '#6366f1', color: 'white', border: 'none', borderRadius: '12px', padding: '10px 16px', cursor: 'pointer', fontWeight: 600, fontFamily: 'Poppins, sans-serif', flexShrink: 0, fontSize: '0.8rem' }}>
          {l.join}
        </button>
      </div>

      <div style={{ display: 'flex', gap: '6px', marginBottom: '15px' }}>
        <button onClick={() => setTab('official')} style={{ flex: 1, padding: '10px', border: 'none', borderRadius: '12px', cursor: 'pointer', fontWeight: 600, fontSize: '0.85rem', background: tab === 'official' ? '#6366f1' : '#f1f5f9', color: tab === 'official' ? 'white' : '#64748b' }}>
          🏛️ {l.official}
        </button>
        <button onClick={() => setTab('community')} style={{ flex: 1, padding: '10px', border: 'none', borderRadius: '12px', cursor: 'pointer', fontWeight: 600, fontSize: '0.85rem', background: tab === 'community' ? '#6366f1' : '#f1f5f9', color: tab === 'community' ? 'white' : '#64748b' }}>
          🌍 {l.community}
        </button>
      </div>

      {/* My Private Groups */}
      {privateGroups.length > 0 && (
        <div style={{ marginBottom: '15px' }}>
          <h4 style={{ color: '#475569', fontSize: '0.85rem', marginBottom: '8px' }}>🔒 {l.my_groups}</h4>
          {privateGroups.map(g => (
            <div key={g.id} style={{ background: '#fefce8', borderRadius: '16px', padding: '15px', marginBottom: '10px', boxShadow: '0 4px 15px rgba(0,0,0,0.06)', display: 'flex', alignItems: 'center', gap: '12px', cursor: 'pointer', borderLeft: '4px solid #f59e0b' }}
              onClick={() => setActiveGroup(g)}>
              <div style={{ fontSize: '2rem', flexShrink: 0 }}>{g.icon}</div>
              <div style={{ flex: 1 }}>
                <h4 style={{ margin: '0 0 2px', color: '#32325d', fontSize: '0.95rem' }}>🔒 {g.name}</h4>
                <p style={{ margin: 0, color: '#8898aa', fontSize: '0.75rem' }}>{g.description}</p>
              </div>
              <button onClick={(e) => { e.stopPropagation(); shareGroup(g); }} style={{ background: 'none', border: 'none', color: '#f59e0b', cursor: 'pointer', fontSize: '1rem' }}>
                <i className="fas fa-share-alt"></i>
              </button>
            </div>
          ))}
        </div>
      )}

      {(tab === 'official' ? officialGroups : communityGroups).map(g => (
        <div key={g.id} style={{ background: 'white', borderRadius: '16px', padding: '15px', marginBottom: '10px', boxShadow: '0 4px 15px rgba(0,0,0,0.06)', display: 'flex', alignItems: 'center', gap: '12px', cursor: 'pointer', borderLeft: `4px solid ${g.group_type === 'predefined' ? '#6366f1' : '#2DCE89'}` }}
          onClick={() => setActiveGroup(g)}>
          <div style={{ fontSize: '2rem', flexShrink: 0 }}>{g.icon}</div>
          <div style={{ flex: 1 }}>
            <h4 style={{ margin: '0 0 2px', color: '#32325d', fontSize: '0.95rem' }}>{g.group_type === 'predefined' ? getTranslatedName(g) : g.name}</h4>
            <p style={{ margin: 0, color: '#8898aa', fontSize: '0.75rem' }}>{g.group_type === 'predefined' ? getTranslatedDesc(g) : g.description}</p>
          </div>
          <button onClick={(e) => { e.stopPropagation(); shareGroup(g); }} style={{ background: 'none', border: 'none', color: '#6366f1', cursor: 'pointer', fontSize: '1rem' }}>
            <i className="fas fa-share-alt"></i>
          </button>
        </div>
      ))}

      {tab === 'community' && communityGroups.length === 0 && (
        <p style={{ textAlign: 'center', color: '#8898aa', fontSize: '0.85rem', padding: '20px 0' }}>
          {isAr ? 'لا توجد مجموعات مجتمعية بعد. أنشئ واحدة!' : 'No community groups yet. Create one!'}
        </p>
      )}

      {showCreate ? (
        <div style={{ background: 'white', borderRadius: '16px', padding: '20px', marginTop: '15px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
          <input value={newName} onChange={e => setNewName(e.target.value)} placeholder={l.name} style={{ ...inputStyle, marginBottom: '10px' }} />
          <input value={newDesc} onChange={e => setNewDesc(e.target.value)} placeholder={l.desc} style={{ ...inputStyle, marginBottom: '10px' }} />
          <label style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '10px', cursor: 'pointer', fontSize: '0.85rem', color: '#475569' }}>
            <input type="checkbox" checked={isPrivate} onChange={e => setIsPrivate(e.target.checked)} style={{ width: 18, height: 18 }} />
            🔒 {l.private}
          </label>
          {isPrivate && <p style={{ color: '#8898aa', fontSize: '0.75rem', margin: '0 0 10px' }}>ℹ️ {l.private_note}</p>}
          <div style={{ display: 'flex', gap: '8px' }}>
            <button onClick={createGroup} style={{ flex: 1, background: '#6366f1', color: 'white', border: 'none', borderRadius: '25px', padding: '10px', fontWeight: 600, cursor: 'pointer' }}>
              ✅ {l.create}
            </button>
            <button onClick={() => setShowCreate(false)} style={{ background: '#f1f5f9', border: 'none', borderRadius: '25px', padding: '10px 20px', cursor: 'pointer' }}>✕</button>
          </div>
        </div>
      ) : (
        <button onClick={() => setShowCreate(true)} style={{
          width: '100%', background: 'linear-gradient(135deg, #6366f1, #8b5cf6)', color: 'white',
          border: 'none', borderRadius: '16px', padding: '15px', fontWeight: 600, cursor: 'pointer',
          fontFamily: 'Poppins, sans-serif', fontSize: '0.95rem', marginTop: '15px',
        }}>
          ➕ {l.create}
        </button>
      )}
    </div>
  );
}
