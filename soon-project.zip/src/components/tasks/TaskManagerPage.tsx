import { useState, useMemo } from 'react';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { useLanguage } from '../../i18n/LanguageContext';
import InlineAIChat from '../shared/InlineAIChat';

interface Task {
  id: string;
  title: string;
  description: string;
  quadrant: 'urgent-important' | 'not-urgent-important' | 'urgent-not-important' | 'not-urgent-not-important';
  dueDate: string;
  completed: boolean;
  createdAt: string;
}

interface TaskManagerPageProps {
  onBack: () => void;
}

export default function TaskManagerPage({ onBack }: TaskManagerPageProps) {
  const [showAIHelper, setShowAIHelper] = useState(false);
  const { lang } = useLanguage();
  const [tasks, setTasks] = useLocalStorage<Task[]>('soon-tasks', []);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [quadrant, setQuadrant] = useState<Task['quadrant']>('urgent-important');
  const [dueDate, setDueDate] = useState('');
  const [viewMode, setViewMode] = useState<'matrix' | 'list' | 'calendar'>('matrix');
  const [calendarMonth, setCalendarMonth] = useState(() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`; });
  const [aiPrompt, setAiPrompt] = useState('');

  const isAr = lang === 'ar';

  const quadrants = {
    'urgent-important': { label: isAr ? '🔴 عاجل ومهم' : '🔴 Urgent & Important', color: '#ef4444', bg: '#fef2f2', example: isAr ? 'مثال: موعد طبيب، مشروع ينتهي غداً' : 'Ex: Doctor appointment, project due tomorrow' },
    'not-urgent-important': { label: isAr ? '🟡 مهم وغير عاجل' : '🟡 Important, Not Urgent', color: '#f59e0b', bg: '#fffbeb', example: isAr ? 'مثال: تعلم مهارة، تمارين رياضية' : 'Ex: Learning a skill, exercise routine' },
    'urgent-not-important': { label: isAr ? '🟠 عاجل وغير مهم' : '🟠 Urgent, Not Important', color: '#f97316', bg: '#fff7ed', example: isAr ? 'مثال: رد على رسائل، اجتماع غير ضروري' : 'Ex: Answering emails, unnecessary meetings' },
    'not-urgent-not-important': { label: isAr ? '⚪ غير عاجل وغير مهم' : '⚪ Not Urgent, Not Important', color: '#6b7280', bg: '#f9fafb', example: isAr ? 'مثال: تصفح عشوائي، مشاهدة بلا هدف' : 'Ex: Random browsing, aimless watching' },
  };

  const addTask = () => {
    if (!title.trim()) return;
    setTasks([...tasks, { id: Date.now().toString(), title: title.trim(), description: description.trim(), quadrant, dueDate, completed: false, createdAt: new Date().toISOString() }]);
    setTitle(''); setDescription(''); setDueDate('');
  };

  const toggleTask = (id: string) => setTasks(tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  const deleteTask = (id: string) => setTasks(tasks.filter(t => t.id !== id));

  const stats = useMemo(() => ({
    total: tasks.length,
    completed: tasks.filter(t => t.completed).length,
    pending: tasks.filter(t => !t.completed).length,
  }), [tasks]);

  const calendarDays = useMemo(() => {
    const [y, m] = calendarMonth.split('-').map(Number);
    const firstDay = new Date(y, m - 1, 1).getDay();
    const daysInMonth = new Date(y, m, 0).getDate();
    const days: { day: number; tasks: Task[] }[] = [];
    for (let i = 0; i < firstDay; i++) days.push({ day: 0, tasks: [] });
    for (let d = 1; d <= daysInMonth; d++) {
      const dateStr = `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
      days.push({ day: d, tasks: tasks.filter(t => t.dueDate === dateStr) });
    }
    return days;
  }, [calendarMonth, tasks]);

  const buildTasksSummary = () => {
    const pendingTasks = tasks.filter(t => !t.completed);
    return pendingTasks.map(t => `- ${t.title} (${quadrants[t.quadrant].label})`).join('\n');
  };

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '20px', marginTop: '15px' }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', fontSize: '1.2rem', cursor: 'pointer', color: '#2DCE89' }}>
          <i className="fas fa-arrow-left"></i>
        </button>
        <h2 style={{ fontSize: '1.5rem', fontWeight: 700, color: '#32325d', margin: 0 }}>
          {isAr ? '📋 مدير المهام' : '📋 Task Manager'}
        </h2>
      </div>

      {/* Eisenhower Matrix Explanation */}
      <div style={{ background: 'linear-gradient(135deg, #f0f4ff, #e8f5e8)', borderRadius: '12px', padding: '12px', marginBottom: '15px', fontSize: '0.75rem', color: '#32325d' }}>
        <strong>{isAr ? '🧠 مصفوفة أيزنهاور للإنتاجية:' : '🧠 Eisenhower Matrix for Productivity:'}</strong>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '6px', marginTop: '8px' }}>
          {(Object.entries(quadrants) as [Task['quadrant'], typeof quadrants[Task['quadrant']]][]).map(([key, q]) => (
            <div key={key} style={{ background: q.bg, padding: '6px 8px', borderRadius: '8px', borderLeft: `3px solid ${q.color}` }}>
              <div style={{ fontWeight: 600, fontSize: '0.65rem' }}>{q.label}</div>
              <div style={{ fontSize: '0.6rem', color: '#6b7280', marginTop: '2px' }}>{q.example}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Stats */}
      <div style={{ display: 'flex', gap: '10px', marginBottom: '15px' }}>
        {[
          { label: isAr ? 'الكل' : 'Total', value: stats.total, color: '#2DCE89' },
          { label: isAr ? 'مُنجز' : 'Done', value: stats.completed, color: '#10b981' },
          { label: isAr ? 'قيد الانتظار' : 'Pending', value: stats.pending, color: '#f59e0b' },
        ].map(s => (
          <div key={s.label} style={{ flex: 1, textAlign: 'center', background: 'white', borderRadius: '10px', padding: '8px', boxShadow: '0 2px 8px rgba(0,0,0,0.06)' }}>
            <div style={{ fontSize: '1.2rem', fontWeight: 700, color: s.color }}>{s.value}</div>
            <div style={{ fontSize: '0.65rem', color: '#8898aa' }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Add Task */}
      <div style={{ background: 'white', borderRadius: '12px', padding: '15px', boxShadow: '0 4px 12px rgba(0,0,0,0.06)', marginBottom: '15px' }}>
        <h3 style={{ fontSize: '0.95rem', color: '#32325d', marginBottom: '10px' }}>{isAr ? 'إضافة مهمة' : 'Add Task'}</h3>
        <input value={title} onChange={e => setTitle(e.target.value)} placeholder={isAr ? 'عنوان المهمة...' : 'Task title...'}
          style={{ width: '100%', padding: '10px', border: '2px solid #e1e8ed', borderRadius: '10px', marginBottom: '8px', fontFamily: 'Poppins, sans-serif', fontSize: '0.85rem', outline: 'none', boxSizing: 'border-box' }} />
        <textarea value={description} onChange={e => setDescription(e.target.value)} placeholder={isAr ? 'وصف (اختياري)...' : 'Description (optional)...'}
          style={{ width: '100%', padding: '10px', border: '2px solid #e1e8ed', borderRadius: '10px', marginBottom: '8px', fontFamily: 'Poppins, sans-serif', fontSize: '0.85rem', minHeight: '50px', resize: 'vertical', outline: 'none', boxSizing: 'border-box' }} />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '10px' }}>
          <select value={quadrant} onChange={e => setQuadrant(e.target.value as Task['quadrant'])}
            style={{ padding: '8px', border: '2px solid #e1e8ed', borderRadius: '8px', fontSize: '0.8rem', fontFamily: 'Poppins, sans-serif' }}>
            {(Object.entries(quadrants) as [Task['quadrant'], typeof quadrants[Task['quadrant']]][]).map(([key, q]) => (
              <option key={key} value={key}>{q.label}</option>
            ))}
          </select>
          <input type="date" value={dueDate} onChange={e => setDueDate(e.target.value)}
            style={{ padding: '8px', border: '2px solid #e1e8ed', borderRadius: '8px', fontSize: '0.8rem' }} />
        </div>
        <button onClick={addTask} style={{ width: '100%', background: 'linear-gradient(to right, #2DCE89, #1a9f6e)', color: 'white', border: 'none', borderRadius: '10px', padding: '10px', fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif' }}>
          {isAr ? '➕ إضافة' : '➕ Add Task'}
        </button>
      </div>

      {/* View Toggle */}
      <div style={{ display: 'flex', gap: '6px', marginBottom: '15px' }}>
        {(['matrix', 'list', 'calendar'] as const).map(mode => (
          <button key={mode} onClick={() => setViewMode(mode)} style={{
            flex: 1, padding: '8px', border: 'none', borderRadius: '10px', cursor: 'pointer',
            background: viewMode === mode ? '#2DCE89' : '#f0f4ff', color: viewMode === mode ? 'white' : '#32325d',
            fontWeight: 600, fontSize: '0.75rem', fontFamily: 'Poppins, sans-serif'
          }}>
            {mode === 'matrix' ? (isAr ? '🔲 مصفوفة' : '🔲 Matrix') : mode === 'list' ? (isAr ? '📝 قائمة' : '📝 List') : (isAr ? '📅 تقويم' : '📅 Calendar')}
          </button>
        ))}
      </div>

      {/* Matrix View */}
      {viewMode === 'matrix' && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '15px' }}>
          {(Object.entries(quadrants) as [Task['quadrant'], typeof quadrants[Task['quadrant']]][]).map(([key, q]) => {
            const qTasks = tasks.filter(t => t.quadrant === key);
            return (
              <div key={key} style={{ background: q.bg, borderRadius: '12px', padding: '10px', borderTop: `3px solid ${q.color}`, minHeight: '100px' }}>
                <div style={{ fontSize: '0.7rem', fontWeight: 700, color: q.color, marginBottom: '6px' }}>{q.label}</div>
                {qTasks.length === 0 && <div style={{ fontSize: '0.6rem', color: '#aaa', fontStyle: 'italic' }}>{isAr ? 'لا مهام' : 'No tasks'}</div>}
                {qTasks.map(task => (
                  <div key={task.id} onClick={() => toggleTask(task.id)} style={{
                    background: 'white', borderRadius: '6px', padding: '6px 8px', marginBottom: '4px', cursor: 'pointer',
                    opacity: task.completed ? 0.5 : 1, textDecoration: task.completed ? 'line-through' : 'none',
                    fontSize: '0.65rem', color: '#32325d', boxShadow: '0 1px 3px rgba(0,0,0,0.05)'
                  }}>
                    {task.completed ? '✅' : '⬜'} {task.title}
                    {task.dueDate && <div style={{ fontSize: '0.55rem', color: '#8898aa' }}>📅 {task.dueDate}</div>}
                  </div>
                ))}
              </div>
            );
          })}
        </div>
      )}

      {/* List View */}
      {viewMode === 'list' && (
        <div>
          {tasks.length === 0 && <p style={{ color: '#8898aa', textAlign: 'center', fontSize: '0.85rem' }}>{isAr ? 'لا توجد مهام بعد' : 'No tasks yet'}</p>}
          {tasks.sort((a, b) => {
            const order: Record<string, number> = { 'urgent-important': 0, 'not-urgent-important': 1, 'urgent-not-important': 2, 'not-urgent-not-important': 3 };
            return (order[a.quadrant] || 0) - (order[b.quadrant] || 0);
          }).map(task => (
            <div key={task.id} style={{ background: 'white', borderRadius: '10px', padding: '12px', marginBottom: '8px', boxShadow: '0 2px 8px rgba(0,0,0,0.05)', borderLeft: `3px solid ${quadrants[task.quadrant].color}`, opacity: task.completed ? 0.6 : 1 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flex: 1 }}>
                  <button onClick={() => toggleTask(task.id)} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '1rem' }}>
                    {task.completed ? '✅' : '⬜'}
                  </button>
                  <div>
                    <div style={{ fontWeight: 600, fontSize: '0.85rem', color: '#32325d', textDecoration: task.completed ? 'line-through' : 'none' }}>{task.title}</div>
                    {task.description && <div style={{ fontSize: '0.7rem', color: '#8898aa' }}>{task.description}</div>}
                    <div style={{ fontSize: '0.6rem', color: quadrants[task.quadrant].color, marginTop: '3px' }}>{quadrants[task.quadrant].label} {task.dueDate && `· 📅 ${task.dueDate}`}</div>
                  </div>
                </div>
                <button onClick={() => deleteTask(task.id)} style={{ background: 'none', border: 'none', color: '#f87171', cursor: 'pointer', fontSize: '0.85rem' }}>
                  <i className="fas fa-trash"></i>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Calendar View */}
      {viewMode === 'calendar' && (
        <div style={{ background: 'white', borderRadius: '12px', padding: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.06)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
            <button onClick={() => {
              const [y, m] = calendarMonth.split('-').map(Number);
              const prev = m === 1 ? `${y - 1}-12` : `${y}-${String(m - 1).padStart(2, '0')}`;
              setCalendarMonth(prev);
            }} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '1rem' }}>◀</button>
            <span style={{ fontWeight: 600, color: '#32325d', fontSize: '0.9rem' }}>{calendarMonth}</span>
            <button onClick={() => {
              const [y, m] = calendarMonth.split('-').map(Number);
              const next = m === 12 ? `${y + 1}-01` : `${y}-${String(m + 1).padStart(2, '0')}`;
              setCalendarMonth(next);
            }} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '1rem' }}>▶</button>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: '2px' }}>
            {(isAr ? ['أحد', 'اثن', 'ثلا', 'أرب', 'خمي', 'جمع', 'سبت'] : ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']).map(d => (
              <div key={d} style={{ textAlign: 'center', fontSize: '0.55rem', color: '#8898aa', fontWeight: 600, padding: '4px 0' }}>{d}</div>
            ))}
            {calendarDays.map((day, i) => (
              <div key={i} style={{
                textAlign: 'center', padding: '4px 2px', fontSize: '0.6rem', minHeight: '30px',
                background: day.tasks.length > 0 ? '#f0fdf4' : 'transparent', borderRadius: '4px',
                border: day.day === new Date().getDate() && calendarMonth === `${new Date().getFullYear()}-${String(new Date().getMonth() + 1).padStart(2, '0')}` ? '1px solid #2DCE89' : 'none'
              }}>
                {day.day > 0 && (
                  <>
                    <div style={{ fontWeight: 600, color: '#32325d' }}>{day.day}</div>
                    {day.tasks.map(t => (
                      <div key={t.id} style={{ width: '5px', height: '5px', borderRadius: '50%', background: quadrants[t.quadrant].color, margin: '1px auto' }} />
                    ))}
                  </>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Inline AI Psychological Helper */}
      <div style={{ background: 'linear-gradient(135deg, #8965e0, #6a3fbb)', borderRadius: '12px', padding: '15px', marginTop: '15px', color: 'white' }}>
        <h4 style={{ color: 'white', marginBottom: '10px', fontSize: '0.9rem' }}>
          🤖 {isAr ? 'مساعد الذكاء الاصطناعي النفسي' : 'AI Psychological Assistant'}
        </h4>
        <p style={{ fontSize: '0.75rem', opacity: 0.9, marginBottom: '12px' }}>
          {isAr ? 'دع الذكاء الاصطناعي يساعدك في تنظيم مهامك وتقليل التوتر النفسي' : 'Let AI help you organize tasks and reduce psychological stress'}
        </p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          <button onClick={() => setAiPrompt(isAr
            ? `لدي هذه المهام المعلقة:\n${buildTasksSummary()}\n\nساعدني نفسياً في ترتيب أولوياتي وكيف أتعامل مع الضغط النفسي الناتج عنها.`
            : `I have these pending tasks:\n${buildTasksSummary()}\n\nHelp me psychologically prioritize and cope with the stress.`
          )} style={{ background: 'rgba(255,255,255,0.2)', border: 'none', color: 'white', borderRadius: '10px', padding: '10px', cursor: 'pointer', fontWeight: 600, fontSize: '0.8rem', fontFamily: 'Poppins, sans-serif' }}>
            📊 {isAr ? 'تحليل مهامي وتقليل التوتر' : 'Analyze my tasks & reduce stress'}
          </button>
          <button onClick={() => setAiPrompt(isAr
            ? `أشعر بالإرهاق من كثرة المهام. لدي ${tasks.filter(t => !t.completed).length} مهمة معلقة. ساعدني كأخ أكبر في وضع خطة يومية واقعية وكيف أحافظ على صحتي النفسية أثناء العمل.`
            : `I feel overwhelmed with tasks. I have ${tasks.filter(t => !t.completed).length} pending tasks. Help me create a realistic daily plan and maintain mental health.`
          )} style={{ background: 'rgba(255,255,255,0.2)', border: 'none', color: 'white', borderRadius: '10px', padding: '10px', cursor: 'pointer', fontWeight: 600, fontSize: '0.8rem', fontFamily: 'Poppins, sans-serif' }}>
            🧠 {isAr ? 'خطة يومية مع دعم نفسي' : 'Daily plan with psychological support'}
          </button>
          <button onClick={() => setAiPrompt(isAr
            ? `أنجزت ${tasks.filter(t => t.completed).length} من أصل ${tasks.length} مهمة. حفّزني وأخبرني كيف أحتفل بإنجازاتي الصغيرة.`
            : `I completed ${tasks.filter(t => t.completed).length} out of ${tasks.length} tasks. Motivate me and tell me how to celebrate small wins.`
          )} style={{ background: 'rgba(255,255,255,0.2)', border: 'none', color: 'white', borderRadius: '10px', padding: '10px', cursor: 'pointer', fontWeight: 600, fontSize: '0.8rem', fontFamily: 'Poppins, sans-serif' }}>
            🎉 {isAr ? 'احتفل بإنجازاتي' : 'Celebrate my achievements'}
          </button>
        </div>
        <InlineAIChat context="tasks" lang={lang} initialPrompt={aiPrompt} />
      </div>

      {/* Psychological Tip */}
      <div style={{ background: 'linear-gradient(135deg, #d1efe1, #e8f5e8)', borderRadius: '12px', padding: '15px', marginTop: '15px', borderLeft: '4px solid #2DCE89' }}>
        <h4 style={{ color: '#1a9f6e', marginBottom: '8px', fontSize: '0.85rem' }}>
          💡 {isAr ? 'لماذا تنظيم المهام يحسّن صحتك النفسية؟' : 'Why task management improves mental health?'}
        </h4>
        <ul style={{ listStyle: 'none', padding: 0, margin: 0, fontSize: '0.75rem', color: '#32325d' }}>
          {(isAr ? [
            'تقليل القلق من خلال وضوح ما يجب فعله',
            'الشعور بالإنجاز يعزز هرمون الدوبامين',
            'فصل العاجل عن المهم يمنع الإرهاق',
            'التخطيط المسبق يقلل التوتر والضغط النفسي',
          ] : [
            'Reduces anxiety by clarifying what needs to be done',
            'Feeling accomplished boosts dopamine',
            'Separating urgent from important prevents burnout',
            'Planning ahead reduces stress and pressure',
          ]).map((tip, i) => (
            <li key={i} style={{ padding: '4px 0 4px 16px', position: 'relative' }}>
              <span style={{ position: 'absolute', left: 0 }}>✨</span>{tip}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
