import { useState, useMemo } from 'react';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { useLanguage } from '../../i18n/LanguageContext';
import InlineAIChat from '../shared/InlineAIChat';

interface DreamEntry { id: string; content: string; sleepQuality: string; recallLevel: string; date: string; formattedDate: string; }

export default function DreamsPage() {
  const { t, lang } = useLanguage();
  const [dreams, setDreams] = useLocalStorage<DreamEntry[]>('soon-dreams', []);
  const [dreamText, setDreamText] = useState('');
  const [sleepQuality, setSleepQuality] = useState('');
  const [recallLevel, setRecallLevel] = useState('');
  const [aiPrompt, setAiPrompt] = useState('');

  const saveDream = () => {
    if (!dreamText.trim()) return;
    setDreams([{ id: Date.now().toString(), content: dreamText.trim(), sleepQuality, recallLevel, date: new Date().toISOString(), formattedDate: new Date().toLocaleDateString() }, ...dreams]);
    setDreamText(''); setSleepQuality(''); setRecallLevel('');
    alert(t('dreams.saved'));
  };

  const qualityColors: Record<string, string> = { excellent: '#2DCE89', good: '#11cdef', fair: '#fb6340', poor: '#f5365c' };
  const qualityValues: Record<string, number> = { excellent: 4, good: 3, fair: 2, poor: 1 };
  const recallValues: Record<string, number> = { clear: 4, vivid: 3, fuzzy: 2, fragments: 1 };

  const dreamsChart = useMemo(() => {
    const last14: { date: string; day: string; quality: number | null; recall: number | null; count: number }[] = [];
    for (let i = 13; i >= 0; i--) {
      const d = new Date(); d.setDate(d.getDate() - i);
      const dayStr = d.toISOString().split('T')[0];
      const dayDreams = dreams.filter(dr => dr.date.startsWith(dayStr));
      const avgQ = dayDreams.length > 0 ? dayDreams.reduce((s, dr) => s + (qualityValues[dr.sleepQuality] || 0), 0) / dayDreams.length : null;
      const avgR = dayDreams.length > 0 ? dayDreams.reduce((s, dr) => s + (recallValues[dr.recallLevel] || 0), 0) / dayDreams.length : null;
      last14.push({ date: dayStr, day: d.toLocaleDateString(lang, { weekday: 'short', day: 'numeric' }), quality: avgQ, recall: avgR, count: dayDreams.length });
    }
    return last14;
  }, [dreams, lang]);

  return (
    <div>
      <h2 style={{ fontSize: '1.8rem', fontWeight: 700, color: '#32325d', margin: '25px 0', textAlign: 'center', position: 'relative' }}>
        {t('dreams.title')}
        <div style={{ position: 'absolute', bottom: '-10px', left: '50%', transform: 'translateX(-50%)', width: '80px', height: '4px', background: '#2DCE89', borderRadius: '2px' }}></div>
      </h2>

      {/* Dreams Evolution Chart */}
      <div style={{ background: 'white', borderRadius: '12px', padding: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.06)', marginBottom: '15px', marginTop: '15px' }}>
        <h3 style={{ fontSize: '0.85rem', color: '#32325d', marginBottom: '8px' }}>📊 {lang === 'ar' ? 'تطور أحلامك' : 'Dreams Evolution'}</h3>
        <div style={{ display: 'flex', alignItems: 'flex-end', gap: '2px', height: '70px', padding: '0 2px' }}>
          {dreamsChart.map((day, i) => (
            <div key={i} style={{ flex: 1, textAlign: 'center', display: 'flex', flexDirection: 'column', justifyContent: 'flex-end', height: '100%' }}>
              {day.quality !== null ? (
                <div style={{
                  height: `${(day.quality / 4) * 55}px`, 
                  background: 'linear-gradient(180deg, #2DCE89, #1a9f6e)',
                  borderRadius: '3px 3px 0 0', transition: 'height 0.5s', minHeight: '6px',
                  position: 'relative'
                }}>
                  {day.recall !== null && (
                    <div style={{
                      position: 'absolute', top: '-4px', left: '50%', transform: 'translateX(-50%)',
                      width: '6px', height: '6px', borderRadius: '50%',
                      background: day.recall >= 3 ? '#8965e0' : '#fb6340',
                      border: '1.5px solid white'
                    }} />
                  )}
                </div>
              ) : (
                <div style={{ height: '6px', background: '#f0f0f0', borderRadius: '3px 3px 0 0' }} />
              )}
              {i % 2 === 0 && <div style={{ fontSize: '0.4rem', color: '#8898aa', marginTop: '2px', lineHeight: 1 }}>{day.day}</div>}
            </div>
          ))}
        </div>
        <div style={{ display: 'flex', gap: '8px', marginTop: '6px', justifyContent: 'center', fontSize: '0.55rem', color: '#8898aa' }}>
          <span><span style={{ display: 'inline-block', width: 7, height: 7, background: '#2DCE89', borderRadius: 2, marginRight: 3, verticalAlign: 'middle' }}></span>{lang === 'ar' ? 'جودة' : 'Quality'}</span>
          <span><span style={{ display: 'inline-block', width: 6, height: 6, background: '#8965e0', borderRadius: '50%', marginRight: 3, verticalAlign: 'middle' }}></span>{lang === 'ar' ? 'واضح' : 'Clear'}</span>
          <span><span style={{ display: 'inline-block', width: 6, height: 6, background: '#fb6340', borderRadius: '50%', marginRight: 3, verticalAlign: 'middle' }}></span>{lang === 'ar' ? 'ضبابي' : 'Fuzzy'}</span>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-around', marginTop: '6px', padding: '6px', background: '#f0f4ff', borderRadius: '8px' }}>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: '0.6rem', color: '#8898aa' }}>{lang === 'ar' ? 'الإجمالي' : 'Total'}</div>
            <div style={{ fontWeight: 700, color: '#2DCE89', fontSize: '0.85rem' }}>{dreams.length}</div>
          </div>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: '0.6rem', color: '#8898aa' }}>{lang === 'ar' ? 'هذا الأسبوع' : 'This Week'}</div>
            <div style={{ fontWeight: 700, color: '#2DCE89', fontSize: '0.85rem' }}>{dreamsChart.slice(-7).reduce((s, d) => s + d.count, 0)}</div>
          </div>
        </div>
      </div>

      <div style={{ background: 'white', borderRadius: '16px', padding: '20px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)', marginBottom: '20px' }}>
        <h3 style={{ fontSize: '1.1rem', color: '#32325d', marginBottom: '15px' }}>{t('dreams.record')}</h3>
        <div style={{ marginBottom: '20px' }}>
          <label style={{ display: 'block', marginBottom: '8px', fontWeight: 500, color: '#32325d' }}>{t('dreams.placeholder').split(' - ')[0]}</label>
          <textarea value={dreamText} onChange={e => setDreamText(e.target.value)} placeholder={t('dreams.placeholder')}
            style={{ width: '100%', minHeight: '120px', padding: '12px', border: '2px solid #e1e8ed', borderRadius: '12px', fontFamily: 'Poppins, sans-serif', fontSize: '0.95rem', resize: 'vertical', outline: 'none', boxSizing: 'border-box' }}
            onFocus={e => e.target.style.borderColor = '#2DCE89'}
            onBlur={e => e.target.style.borderColor = '#e1e8ed'}
          />
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '20px' }}>
          <div>
            <label style={{ display: 'block', marginBottom: '8px', fontWeight: 500, color: '#32325d' }}>{t('dreams.quality')}</label>
            <select value={sleepQuality} onChange={e => setSleepQuality(e.target.value)}
              style={{ width: '100%', padding: '10px', border: '2px solid #e1e8ed', borderRadius: '8px', background: 'white', fontSize: '0.9rem', fontFamily: 'Poppins, sans-serif', outline: 'none' }}>
              <option value="">{t('dreams.select_quality')}</option>
              <option value="excellent">😴 {t('mood.excellent')}</option>
              <option value="good">😊 {t('mood.good')}</option>
              <option value="fair">😐 {t('mood.neutral')}</option>
              <option value="poor">😔 {t('mood.bad')}</option>
            </select>
          </div>
          <div>
            <label style={{ display: 'block', marginBottom: '8px', fontWeight: 500, color: '#32325d' }}>{t('dreams.recall')}</label>
            <select value={recallLevel} onChange={e => setRecallLevel(e.target.value)}
              style={{ width: '100%', padding: '10px', border: '2px solid #e1e8ed', borderRadius: '8px', background: 'white', fontSize: '0.9rem', fontFamily: 'Poppins, sans-serif', outline: 'none' }}>
              <option value="">{t('dreams.select_recall')}</option>
              <option value="clear">💭 Very Clear</option>
              <option value="vivid">✨ Vivid</option>
              <option value="fuzzy">🌫️ Fuzzy</option>
              <option value="fragments">🧩 Fragments</option>
            </select>
          </div>
        </div>

        <div style={{ display: 'flex', gap: '10px' }}>
          <button onClick={saveDream} style={{ background: 'linear-gradient(to right, #2DCE89, #1a9f6e)', color: 'white', border: 'none', borderRadius: '25px', padding: '12px 20px', fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif', flex: 1 }}>{t('dreams.save')}</button>
          <button onClick={() => setAiPrompt(`Please analyze this dream: ${dreamText}\nSleep quality: ${sleepQuality}, Recall: ${recallLevel}`)}
            style={{ background: '#d1efe1', color: '#2DCE89', border: 'none', borderRadius: '25px', padding: '12px 20px', fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif', flex: 1 }}>{t('dreams.analyze')}</button>
        </div>
      </div>

      <h3 style={{ fontSize: '1.3rem', color: '#32325d', marginBottom: '15px' }}>{t('dreams.history')}</h3>
      {dreams.length === 0 && <p style={{ color: '#8898aa', textAlign: 'center' }}>{t('dreams.no_dreams')}</p>}
      {dreams.map(dream => (
        <div key={dream.id} style={{ background: 'white', borderRadius: '16px', padding: '15px', marginBottom: '15px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px', fontSize: '0.8rem', color: '#8898aa' }}>
            <span>{dream.formattedDate}</span>
            {dream.sleepQuality && <span style={{ padding: '4px 8px', borderRadius: '12px', background: `${qualityColors[dream.sleepQuality]}20`, color: qualityColors[dream.sleepQuality], fontWeight: 500, fontSize: '0.7rem' }}>{dream.sleepQuality}</span>}
          </div>
          <p style={{ lineHeight: 1.6, color: '#32325d', margin: '0 0 10px' }}>{dream.content}</p>
          <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <button onClick={() => setAiPrompt(`Analyze this dream: ${dream.content}`)}
              style={{ background: 'none', border: '1px solid #2DCE89', color: '#2DCE89', padding: '6px 12px', borderRadius: '15px', fontSize: '0.8rem', cursor: 'pointer', fontFamily: 'Poppins, sans-serif' }}>{t('dreams.analyze')}</button>
          </div>
        </div>
      ))}

      {/* Inline AI Dream Analyzer */}
      <div style={{ background: 'linear-gradient(135deg, #8965e0, #6a3fbb)', borderRadius: '16px', padding: '20px', marginTop: '20px', color: 'white' }}>
        <h4 style={{ color: 'white', marginBottom: '10px', display: 'flex', alignItems: 'center', gap: '8px' }}>
          🤖 {lang === 'ar' ? 'محلل الأحلام بالذكاء الاصطناعي' : 'AI Dream Analyzer'}
        </h4>
        <p style={{ fontSize: '0.8rem', opacity: 0.9, marginBottom: '12px' }}>
          {lang === 'ar' ? 'حلل أحلامك مباشرة هنا بدون مغادرة الصفحة' : 'Analyze your dreams right here without leaving the page'}
        </p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          <button onClick={() => {
            const recentDreams = dreams.slice(0, 5).map(d => d.content).join('\n---\n');
            setAiPrompt(lang === 'ar'
              ? `هذه أحلامي الأخيرة:\n${recentDreams}\n\nحلل أحلامي من منظور نفسي وأخبرني ماذا تعني.`
              : `These are my recent dreams:\n${recentDreams}\n\nAnalyze my dreams psychologically and tell me what they mean.`);
          }} style={{ background: 'rgba(255,255,255,0.2)', border: 'none', color: 'white', borderRadius: '10px', padding: '10px', cursor: 'pointer', fontWeight: 600, fontSize: '0.8rem', fontFamily: 'Poppins, sans-serif' }}>
            🔮 {lang === 'ar' ? 'تحليل أنماط أحلامي' : 'Analyze my dream patterns'}
          </button>
        </div>
        <InlineAIChat context="dreams" lang={lang} initialPrompt={aiPrompt} />
      </div>

      <div style={{ background: 'linear-gradient(135deg, #d1efe1, #e8f5e8)', borderRadius: '16px', padding: '20px', marginTop: '15px', borderLeft: '4px solid #2DCE89' }}>
        <h4 style={{ color: '#1a9f6e', marginBottom: '15px', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <i className="fas fa-lightbulb"></i> {t('dreams.tips')}
        </h4>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {['Write immediately upon waking while details are fresh', 'Focus on emotions and sensations in the dream', 'Note recurring characters, places, or themes', 'Look for patterns over time'].map((tip, i) => (
            <li key={i} style={{ padding: '8px 0 8px 20px', position: 'relative', color: '#32325d', lineHeight: 1.5 }}>
              <span style={{ position: 'absolute', left: 0 }}>✨</span>{tip}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
