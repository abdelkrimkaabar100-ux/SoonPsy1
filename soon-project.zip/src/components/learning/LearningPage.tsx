import { useState } from 'react';
import InlineAIChat from '../shared/InlineAIChat';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { supabase } from '@/integrations/supabase/client';

interface LearningActivity {
  id: string;
  type: string;
  name: string;
  note: string;
  learned?: string;
  whyWritten?: string;
  date: string;
}

interface LearningPageProps {
  onBack: () => void;
}

export default function LearningPage({ onBack }: LearningPageProps) {
  const { t, lang } = useLanguage();
  const isRTL = lang === 'ar';
  const [activities, setActivities] = useLocalStorage<LearningActivity[]>('soon-learning', []);
  const [activeSection, setActiveSection] = useState<'discovery' | 'play' | 'music' | 'stories'>('discovery');
  
  const [customActivity, setCustomActivity] = useState('');
  const [learned, setLearned] = useState('');
  const [note, setNote] = useState('');
  const [whyWritten, setWhyWritten] = useState('');
  
  const [aiSuggestions, setAiSuggestions] = useState('');
  const [isLoadingAI, setIsLoadingAI] = useState(false);
  const [showWriteStory, setShowWriteStory] = useState(false);

  const sections = [
    { id: 'discovery' as const, icon: '🔍', key: 'learn.discovery' },
    { id: 'play' as const, icon: '🎮', key: 'learn.play' },
    { id: 'music' as const, icon: '🎵', key: 'learn.music_learn' },
    { id: 'stories' as const, icon: '📖', key: 'learn.stories' },
  ];

  const formatAIResponse = (text: string) => {
    return text
      .replace(/#{1,6}\s*/g, '')
      .replace(/\*\*(.*?)\*\*/g, '$1')
      .replace(/\*(.*?)\*/g, '$1')
      .replace(/#\w+/g, '')
      .replace(/_/g, '')
      .trim();
  };

  const getAISuggestions = async () => {
    setIsLoadingAI(true);
    try {
      const isStories = activeSection === 'stories';
      const sectionPrompts: Record<string, string> = {
        discovery: lang === 'ar' 
          ? 'اقترح 5 أنشطة تعليمية ممتعة في مجال الاكتشاف والعلوم. اجعلها بسيطة وممتعة ومفيدة للصحة النفسية. لا تستخدم رموز ماركداون أو هاشتاغ.'
          : 'Suggest 5 fun educational activities in discovery and science. Make them simple, fun, and beneficial for mental health. Do NOT use markdown, hashtags, or special symbols.',
        play: lang === 'ar'
          ? 'اقترح 5 ألعاب تعليمية ممتعة تنمي المهارات. لا تستخدم رموز ماركداون أو هاشتاغ.'
          : 'Suggest 5 fun educational games. No markdown, hashtags, or symbols.',
        music: lang === 'ar'
          ? 'اقترح 5 أنشطة موسيقية تعليمية ممتعة. لا تستخدم ماركداون.'
          : 'Suggest 5 educational music activities. No markdown.',
        stories: lang === 'ar'
          ? 'اكتب قصة قصيرة ملهمة وجميلة للأطفال (4-10 سنوات) مع درس مفيد. استخدم لغة دافئة ومشجعة. أضف رموز الزهور والطبيعة 🌸🌼🌻🌈🦋🌺. لا تستخدم أبداً رموز ماركداون مثل # أو * أو _ أو هاشتاغ. اجعل القصة سحرية وملونة ومليئة بالحب.'
          : 'Write a short inspiring beautiful story for children (ages 4-10) with a useful lesson. Use warm, encouraging, child-friendly language. Add flower and nature emojis 🌸🌼🌻🌈🦋🌺. NEVER use markdown symbols like #, *, _, or hashtags. Make it magical, colorful, and full of love.',
      };

      const { data, error } = await supabase.functions.invoke('groq-chat', {
        body: {
          messages: [{ role: 'user', content: sectionPrompts[activeSection] }],
          systemPrompt: isStories
            ? (lang === 'ar' 
              ? 'أنت حكّاء سحري للأطفال. اكتب بلغة بسيطة جداً ودافئة. أضف رموز تعبيرية جميلة 🌸🌼🌻🌈🦋🌺. لا تستخدم أبداً رموز ماركداون مثل # أو * أو _ أو هاشتاغ. القصة يجب أن تكون ملونة وسحرية.'
              : 'You are a magical storyteller for children. Write in very simple, warm language. Add beautiful emojis 🌸🌼🌻🌈🦋🌺. NEVER use markdown (#, *, _, hashtags). Stories should be colorful and magical.')
            : (lang === 'ar' 
              ? 'أنت معلم متخصص في التعلم الممتع. قدم اقتراحات مختصرة ومفيدة بدون ماركداون.'
              : 'You are a teacher specialized in fun learning. Provide brief suggestions without markdown.')
        }
      });

      if (error) throw error;
      setAiSuggestions(formatAIResponse(data.content));
    } catch {
      setAiSuggestions(lang === 'ar' ? 'عذراً، حاول مرة أخرى.' : 'Sorry, please try again.');
    } finally {
      setIsLoadingAI(false);
    }
  };

  const logActivity = () => {
    if (!customActivity.trim()) return;
    setActivities(prev => [{
      id: Date.now().toString(),
      type: activeSection,
      name: customActivity.trim(),
      note: note.trim(),
      learned: learned.trim(),
      whyWritten: whyWritten.trim(),
      date: new Date().toISOString(),
    }, ...prev]);
    setCustomActivity(''); setLearned(''); setNote(''); setWhyWritten(''); setShowWriteStory(false);
  };

  const todayCount = activities.filter(a => new Date(a.date).toDateString() === new Date().toDateString()).length;

  const sectionPlaceholders: Record<string, Record<string, string>> = {
    discovery: { ar: 'مثل: تجربة علمية، قراءة كتاب عن الفضاء...', en: 'e.g., Science experiment, reading about space...', es: 'ej., Experimento científico...', fr: 'ex., Expérience scientifique...' },
    play: { ar: 'مثل: لعب في الحديقة، بناء بالمكعبات...', en: 'e.g., Playing in the park, building with blocks...', es: 'ej., Jugar en el parque...', fr: 'ex., Jouer au parc...' },
    music: { ar: 'مثل: حولت درساً لأغنية...', en: 'e.g., Turned a lesson into a song...', es: 'ej., Convertí una lección en canción...', fr: 'ex., J\'ai transformé une leçon en chanson...' },
    stories: { ar: 'اكتب قصتك الخاصة هنا... 🌸', en: 'Write your own story here... 🌸', es: 'Escribe tu historia aquí... 🌸', fr: 'Écrivez votre histoire ici... 🌸' }
  };

  const isStories = activeSection === 'stories';

  return (
    <div style={{ paddingTop: '20px', direction: isRTL ? 'rtl' : 'ltr' }}>
      <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#2DCE89', fontSize: '1rem', cursor: 'pointer', marginBottom: '15px', fontFamily: 'Poppins, sans-serif' }}>
        <i className={`fas fa-arrow-${isRTL ? 'right' : 'left'}`}></i> {t('nav.home')}
      </button>

      <div style={{ textAlign: 'center', marginBottom: '20px' }}>
        <h2 style={{ color: '#32325d', fontSize: '1.5rem', margin: '0 0 5px' }}>🧒 {t('learn.title')}</h2>
        <p style={{ color: '#8898aa', fontSize: '0.85rem', margin: 0 }}>{t('learn.subtitle')}</p>
      </div>

      {/* Stats */}
      <div style={{ background: 'linear-gradient(135deg, #667eea, #764ba2)', borderRadius: '12px', padding: '15px', color: 'white', textAlign: 'center', marginBottom: '20px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-around' }}>
          <div><div style={{ fontSize: '1.5rem', fontWeight: 700 }}>{todayCount}</div><div style={{ fontSize: '0.7rem', opacity: 0.9 }}>{t('learn.today')}</div></div>
          <div><div style={{ fontSize: '1.5rem', fontWeight: 700 }}>{activities.length}</div><div style={{ fontSize: '0.7rem', opacity: 0.9 }}>{t('learn.total')}</div></div>
        </div>
      </div>

      {/* Section tabs */}
      <div style={{ display: 'flex', gap: '8px', marginBottom: '15px' }}>
        {sections.map(s => (
          <button key={s.id} onClick={() => { setActiveSection(s.id); setAiSuggestions(''); setShowWriteStory(false); }} style={{
            flex: 1, padding: '10px 8px', borderRadius: '12px', border: 'none', cursor: 'pointer',
            background: activeSection === s.id ? 'linear-gradient(135deg, #667eea, #764ba2)' : '#f8f9fe',
            color: activeSection === s.id ? 'white' : '#32325d', fontWeight: 600, fontSize: '0.75rem', fontFamily: 'Poppins, sans-serif',
          }}>
            {s.icon} {t(s.key)}
          </button>
        ))}
      </div>

      {/* Stories: Write your own (optional) */}
      {isStories && (
        <div style={{ marginBottom: '15px' }}>
          {!showWriteStory ? (
            <button onClick={() => setShowWriteStory(true)} style={{
              width: '100%', padding: '14px', border: '2px dashed #c084fc', borderRadius: '16px',
              background: 'linear-gradient(135deg, #faf5ff, #f3e8ff)', color: '#7c3aed',
              cursor: 'pointer', fontSize: '0.9rem', fontWeight: 600, fontFamily: 'Poppins, sans-serif',
            }}>
              ✍️🌸 {isRTL ? 'اكتب قصتك الخاصة (اختياري)' : 'Write Your Own Story (Optional)'} 🌼
            </button>
          ) : (
            <div style={{ background: 'linear-gradient(135deg, #faf5ff, #fce7f3)', borderRadius: '16px', padding: '15px', border: '2px solid #e9d5ff' }}>
              <h4 style={{ color: '#7c3aed', marginBottom: '10px' }}>✍️🌸 {isRTL ? 'قصتي' : 'My Story'}</h4>
              <textarea value={customActivity} onChange={e => setCustomActivity(e.target.value)}
                placeholder={sectionPlaceholders.stories[lang] || sectionPlaceholders.stories.en}
                rows={4}
                style={{ width: '100%', padding: '12px', border: '2px solid #e9d5ff', borderRadius: '12px', fontFamily: 'Poppins, sans-serif', fontSize: '0.9rem', boxSizing: 'border-box', resize: 'none', direction: isRTL ? 'rtl' : 'ltr' }} />
              <input value={whyWritten} onChange={e => setWhyWritten(e.target.value)}
                placeholder={isRTL ? '🌻 لماذا كتبت هذه القصة؟' : '🌻 Why did you write this story?'}
                style={{ width: '100%', padding: '10px', border: '1px solid #e9d5ff', borderRadius: '12px', fontFamily: 'Poppins, sans-serif', fontSize: '0.85rem', boxSizing: 'border-box', marginTop: '8px', direction: isRTL ? 'rtl' : 'ltr' }} />
              <input value={learned} onChange={e => setLearned(e.target.value)}
                placeholder={isRTL ? '🌈 ما الذي تعلمته من هذه القصة؟' : '🌈 What did you learn from this story?'}
                style={{ width: '100%', padding: '10px', border: '1px solid #e9d5ff', borderRadius: '12px', fontFamily: 'Poppins, sans-serif', fontSize: '0.85rem', boxSizing: 'border-box', marginTop: '8px', direction: isRTL ? 'rtl' : 'ltr' }} />
              <div style={{ display: 'flex', gap: '8px', marginTop: '10px' }}>
                <button onClick={logActivity} disabled={!customActivity.trim()} style={{ flex: 1, padding: '10px', background: customActivity.trim() ? 'linear-gradient(135deg, #a855f7, #ec4899)' : '#d1d5db', color: 'white', border: 'none', borderRadius: '12px', fontWeight: 600, cursor: 'pointer' }}>
                  🌺 {isRTL ? 'حفظ' : 'Save'}
                </button>
                <button onClick={() => setShowWriteStory(false)} style={{ padding: '10px 16px', background: '#f3e8ff', border: 'none', borderRadius: '12px', cursor: 'pointer' }}>✕</button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Input (non-stories) */}
      {!isStories && (
        <div style={{ background: 'white', borderRadius: '16px', padding: '15px', marginBottom: '15px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
          <h4 style={{ color: '#667eea', marginBottom: '12px' }}>✏️ {t('learn.add_activity')}</h4>
          <input type="text" value={customActivity} onChange={e => setCustomActivity(e.target.value)} 
            placeholder={sectionPlaceholders[activeSection][lang] || sectionPlaceholders[activeSection].en}
            style={{ width: '100%', padding: '12px 14px', border: '2px solid #667eea', borderRadius: '12px', fontFamily: 'Poppins, sans-serif', fontSize: '0.9rem', boxSizing: 'border-box', marginBottom: '10px' }} />
          <input type="text" value={learned} onChange={e => setLearned(e.target.value)} placeholder={t('learn.what_learned')}
            style={{ width: '100%', padding: '10px 14px', border: '1px solid #e0e0e0', borderRadius: '12px', fontFamily: 'Poppins, sans-serif', fontSize: '0.85rem', boxSizing: 'border-box', marginBottom: '8px' }} />
          <input type="text" value={note} onChange={e => setNote(e.target.value)} placeholder={t('learn.note_optional')}
            style={{ width: '100%', padding: '8px 14px', border: '1px solid #e0e0e0', borderRadius: '12px', fontFamily: 'Poppins, sans-serif', fontSize: '0.8rem', boxSizing: 'border-box', marginBottom: '12px' }} />
          <button onClick={logActivity} disabled={!customActivity.trim()} style={{ width: '100%', padding: '12px', background: customActivity.trim() ? 'linear-gradient(135deg, #667eea, #764ba2)' : '#ccc', color: 'white', border: 'none', borderRadius: '12px', fontWeight: 600, cursor: customActivity.trim() ? 'pointer' : 'not-allowed' }}>
            {t('learn.save_activity')}
          </button>
        </div>
      )}

      {/* AI Suggestions */}
      <div style={{ background: isStories ? 'linear-gradient(135deg, #fdf2f8, #fce7f3)' : '#f0f4ff', borderRadius: '16px', padding: '15px', marginBottom: '15px', border: isStories ? '2px solid #f9a8d4' : '2px solid #667eea' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
          <h4 style={{ color: isStories ? '#ec4899' : '#667eea', margin: 0 }}>
            {isStories ? '🌸✨' : '🤖'} {isStories ? (isRTL ? 'قصة سحرية جديدة' : 'New Magical Story') : t('learn.ai_ideas')}
          </h4>
          <button onClick={getAISuggestions} disabled={isLoadingAI} style={{ background: isStories ? 'linear-gradient(135deg, #ec4899, #a855f7)' : 'linear-gradient(135deg, #667eea, #764ba2)', color: 'white', border: 'none', borderRadius: '20px', padding: '6px 12px', fontSize: '0.75rem', cursor: 'pointer' }}>
            {isLoadingAI ? '...' : isStories ? (isRTL ? '🌼 قصة جديدة' : '🌼 New Story') : t('learn.get_ideas')}
          </button>
        </div>
        
        {aiSuggestions ? (
          <div style={{
            background: isStories ? 'linear-gradient(135deg, #fff7ed, #fef3c7, #fdf2f8)' : 'white',
            borderRadius: '14px', padding: '16px', fontSize: '0.9rem', color: '#32325d',
            lineHeight: 1.8, whiteSpace: 'pre-wrap',
            border: isStories ? '1px solid #fde68a' : 'none',
          }}>
            {aiSuggestions}
          </div>
        ) : (
          <p style={{ color: '#8898aa', fontSize: '0.8rem', margin: 0, textAlign: 'center' }}>{t('learn.ai_empty')}</p>
        )}
      </div>

      {/* History */}
      <h4 style={{ color: '#32325d', marginBottom: '10px' }}>📋 {t('learn.history')}</h4>
      {activities.length === 0 && <p style={{ textAlign: 'center', color: '#8898aa' }}>{t('learn.empty')}</p>}
      {activities.slice(0, 20).map(a => (
        <div key={a.id} style={{ background: a.type === 'stories' ? 'linear-gradient(135deg, #faf5ff, #fce7f3)' : 'white', borderRadius: '10px', padding: '10px 14px', marginBottom: '8px', boxShadow: '0 2px 6px rgba(0,0,0,0.04)', display: 'flex', alignItems: 'flex-start', gap: '10px' }}>
          <span style={{ fontSize: '1.2rem' }}>{a.type === 'discovery' ? '🔍' : a.type === 'play' ? '🎮' : a.type === 'stories' ? '📖' : '🎵'}</span>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: '0.85rem', fontWeight: 600, color: '#32325d' }}>{a.name.substring(0, 100)}{a.name.length > 100 ? '...' : ''}</div>
            {a.whyWritten && <div style={{ fontSize: '0.78rem', color: '#a855f7' }}>🌻 {a.whyWritten}</div>}
            {a.learned && <div style={{ fontSize: '0.8rem', color: '#667eea' }}>💡 {a.learned}</div>}
            {a.note && <div style={{ fontSize: '0.75rem', color: '#8898aa' }}>{a.note}</div>}
          </div>
          <div style={{ fontSize: '0.7rem', color: '#aaa', flexShrink: 0 }}>{new Date(a.date).toLocaleDateString()}</div>
        </div>
      ))}

      <div style={{ background: 'linear-gradient(135deg, #e0e7ff, #d1d5f0)', borderRadius: '16px', padding: '15px', marginTop: '15px', borderLeft: '4px solid #667eea' }}>
        <h4 style={{ color: '#4338ca', marginBottom: '8px' }}>🧒 {t('learn.benefit_title')}</h4>
        <p style={{ color: '#32325d', fontSize: '0.85rem', lineHeight: 1.6, margin: 0 }}>{t('learn.benefit_desc')}</p>
      </div>
      <InlineAIChat context="learning" lang={lang} />
    </div>
  );
}
