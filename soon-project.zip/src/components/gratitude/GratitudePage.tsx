import { useState } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { supabase } from '@/integrations/supabase/client';

interface GratitudePageProps {
  onBack: () => void;
}

interface Victory {
  id: string;
  text: string;
  date: string;
}

type Tab = 'self' | 'others' | 'victories';

export default function GratitudePage({ onBack }: GratitudePageProps) {
  const { t, lang } = useLanguage();
  const isAr = lang === 'ar';
  const [activeTab, setActiveTab] = useState<Tab>('self');
  
  // Self thanks
  const [selfMessage, setSelfMessage] = useState('');
  const [selfHistory, setSelfHistory] = useLocalStorage<{ text: string; date: string }[]>('soon-self-thanks', []);
  
  // Thank others
  const [recipientName, setRecipientName] = useState('');
  const [thankMessage, setThankMessage] = useState('');
  const [senderName, setSenderName] = useLocalStorage<string>('soon-user-name', '');
  const [sharedLink, setSharedLink] = useState('');
  const [sending, setSending] = useState(false);
  const [copied, setCopied] = useState(false);
  
  // Daily victories
  const [victories, setVictories] = useLocalStorage<Victory[]>('soon-victories', []);
  const [victoryInput, setVictoryInput] = useState('');

  const today = new Date().toISOString().split('T')[0];
  const todayVictories = victories.filter(v => v.date === today);

  const saveSelfThanks = () => {
    if (!selfMessage.trim()) return;
    setSelfHistory(prev => [{ text: selfMessage.trim(), date: new Date().toISOString() }, ...prev]);
    setSelfMessage('');
  };

  const sendThankYou = async () => {
    if (!recipientName.trim() || !thankMessage.trim()) return;
    setSending(true);
    try {
      const { data, error } = await supabase.from('gratitude_messages').insert({
        sender_name: senderName || (isAr ? 'شخص يقدّرك' : 'Someone who appreciates you'),
        recipient_name: recipientName.trim(),
        message: thankMessage.trim(),
        is_self_thanks: false,
      }).select('id').single();
      
      if (error) throw error;
      const baseUrl = window.location.origin;
      const link = `${baseUrl}/thanks/${data.id}`;
      setSharedLink(link);
      setRecipientName('');
      setThankMessage('');
    } catch (e) {
      console.error(e);
    }
    setSending(false);
  };

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(sharedLink);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback
      const ta = document.createElement('textarea');
      ta.value = sharedLink;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const copyMessage = () => {
    const text = isAr
      ? `💚 رسالة شكر لك من ${senderName || 'شخص يقدّرك'}:\n\n"${thankMessage}"\n\n— عبر تطبيق Soon 🌿`
      : `💚 A thank you message for you from ${senderName || 'Someone who appreciates you'}:\n\n"${thankMessage}"\n\n— via Soon App 🌿`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const addVictory = () => {
    if (!victoryInput.trim()) return;
    setVictories(prev => [{ id: Date.now().toString(), text: victoryInput.trim(), date: today }, ...prev]);
    setVictoryInput('');
  };

  const removeVictory = (id: string) => {
    setVictories(prev => prev.filter(v => v.id !== id));
  };

  const tabs: { id: Tab; icon: string; label: string }[] = [
    { id: 'self', icon: 'fas fa-heart', label: isAr ? 'شكر نفسي' : lang === 'es' ? 'Agradecerme' : lang === 'fr' ? 'Me remercier' : 'Thank Myself' },
    { id: 'others', icon: 'fas fa-gift', label: isAr ? 'شكر الآخرين' : lang === 'es' ? 'Agradecer' : lang === 'fr' ? 'Remercier' : 'Thank Others' },
    { id: 'victories', icon: 'fas fa-trophy', label: isAr ? 'انتصاراتي' : lang === 'es' ? 'Mis victorias' : lang === 'fr' ? 'Mes victoires' : 'My Victories' },
  ];

  const sectionStyle: React.CSSProperties = {
    background: 'white', borderRadius: '20px', padding: '20px',
    boxShadow: '0 4px 15px rgba(0,0,0,0.08)', marginBottom: '20px',
  };

  const inputStyle: React.CSSProperties = {
    width: '100%', padding: '14px 16px', borderRadius: '14px',
    border: '2px solid #e5e7eb', fontSize: '0.95rem',
    fontFamily: 'Poppins, sans-serif', outline: 'none',
    transition: 'border-color 0.3s', boxSizing: 'border-box',
    direction: isAr ? 'rtl' : 'ltr',
  };

  const btnStyle: React.CSSProperties = {
    background: 'linear-gradient(135deg, #2DCE89, #1fa86d)',
    color: 'white', border: 'none', borderRadius: '14px',
    padding: '14px 24px', fontSize: '1rem', fontWeight: 600,
    cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
    width: '100%', transition: 'all 0.3s',
  };

  return (
    <div style={{ paddingTop: '20px', paddingBottom: '20px' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '20px' }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', fontSize: '1.3rem', cursor: 'pointer', color: '#2DCE89' }}>
          <i className={`fas fa-arrow-${isAr ? 'right' : 'left'}`}></i>
        </button>
        <div>
          <h2 style={{ margin: 0, fontSize: '1.4rem', color: '#32325d' }}>
            {isAr ? '💚 الامتنان والشكر' : lang === 'es' ? '💚 Gratitud' : lang === 'fr' ? '💚 Gratitude' : '💚 Gratitude & Thanks'}
          </h2>
          <p style={{ margin: 0, fontSize: '0.8rem', color: '#8898aa' }}>
            {isAr ? 'اشكر نفسك، اشكر من حولك، واحتفل بانتصاراتك' : lang === 'es' ? 'Agradécete, agradece a otros, celebra tus victorias' : lang === 'fr' ? 'Remercie-toi, remercie les autres, célèbre tes victoires' : 'Thank yourself, thank others, celebrate your victories'}
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: '8px', marginBottom: '20px', overflowX: 'auto' }}>
        {tabs.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)} style={{
            flex: 1, padding: '12px 8px', borderRadius: '14px', border: 'none',
            background: activeTab === tab.id ? 'linear-gradient(135deg, #2DCE89, #1fa86d)' : '#f3f4f6',
            color: activeTab === tab.id ? 'white' : '#6b7280',
            fontSize: '0.8rem', fontWeight: 600, cursor: 'pointer',
            fontFamily: 'Poppins, sans-serif', transition: 'all 0.3s',
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '4px',
            whiteSpace: 'nowrap',
          }}>
            <i className={tab.icon} style={{ fontSize: '1.1rem' }}></i>
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab: Thank Myself */}
      {activeTab === 'self' && (
        <div>
          <div style={sectionStyle}>
            <div style={{ textAlign: 'center', marginBottom: '20px' }}>
              <div style={{ fontSize: '3rem', marginBottom: '10px' }}>🪞</div>
              <h3 style={{ margin: '0 0 8px', color: '#32325d', fontSize: '1.1rem' }}>
                {isAr ? 'رسالة لنفسك' : 'A Message to Yourself'}
              </h3>
              <p style={{ margin: 0, fontSize: '0.85rem', color: '#8898aa' }}>
                {isAr ? 'أنت تستحق الشكر. اكتب ما تقدّره في نفسك اليوم' : 'You deserve gratitude. Write what you appreciate about yourself today'}
              </p>
            </div>
            <textarea
              value={selfMessage}
              onChange={e => setSelfMessage(e.target.value)}
              placeholder={isAr ? 'أشكر نفسي لأني...' : 'I thank myself for...'}
              rows={4}
              style={{ ...inputStyle, resize: 'none', marginBottom: '12px' }}
              onFocus={e => e.target.style.borderColor = '#2DCE89'}
              onBlur={e => e.target.style.borderColor = '#e5e7eb'}
            />
            <button onClick={saveSelfThanks} disabled={!selfMessage.trim()} style={{ ...btnStyle, opacity: selfMessage.trim() ? 1 : 0.5 }}>
              <i className="fas fa-heart" style={{ marginRight: '8px' }}></i>
              {isAr ? 'حفظ الشكر' : 'Save Thanks'}
            </button>
          </div>

          {/* Self thanks history */}
          {selfHistory.length > 0 && (
            <div style={sectionStyle}>
              <h4 style={{ margin: '0 0 15px', color: '#32325d', fontSize: '1rem' }}>
                <i className="fas fa-history" style={{ marginRight: '8px', color: '#2DCE89' }}></i>
                {isAr ? 'سجل شكري لنفسي' : 'My Self-Thanks Journal'}
              </h4>
              {selfHistory.slice(0, 10).map((item, i) => (
                <div key={i} style={{
                  padding: '14px', borderRadius: '12px', marginBottom: '10px',
                  background: 'linear-gradient(135deg, #f0fdf4, #ecfdf5)',
                  borderLeft: '4px solid #2DCE89',
                }}>
                  <p style={{ margin: 0, fontSize: '0.9rem', color: '#32325d', lineHeight: 1.6 }}>💚 {item.text}</p>
                  <span style={{ fontSize: '0.7rem', color: '#8898aa', marginTop: '6px', display: 'block' }}>
                    {new Date(item.date).toLocaleDateString(isAr ? 'ar-SA' : 'en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab: Thank Others */}
      {activeTab === 'others' && (
        <div>
          <div style={sectionStyle}>
            <div style={{ textAlign: 'center', marginBottom: '20px' }}>
              <div style={{ fontSize: '3rem', marginBottom: '10px' }}>🎁</div>
              <h3 style={{ margin: '0 0 8px', color: '#32325d', fontSize: '1.1rem' }}>
                {isAr ? 'أرسل شكراً لشخص مميز' : 'Send Thanks to Someone Special'}
              </h3>
              <p style={{ margin: 0, fontSize: '0.85rem', color: '#8898aa' }}>
                {isAr ? 'اكتب رسالة شكر وشاركها عبر رابط خاص' : 'Write a thank you message and share it via a private link'}
              </p>
            </div>

            <input
              type="text"
              value={recipientName}
              onChange={e => setRecipientName(e.target.value)}
              placeholder={isAr ? 'اسم الشخص...' : "Person's name..."}
              style={{ ...inputStyle, marginBottom: '12px' }}
              onFocus={e => e.target.style.borderColor = '#2DCE89'}
              onBlur={e => e.target.style.borderColor = '#e5e7eb'}
            />

            <textarea
              value={thankMessage}
              onChange={e => setThankMessage(e.target.value)}
              placeholder={isAr ? 'شكراً لك على...' : 'Thank you for...'}
              rows={4}
              style={{ ...inputStyle, resize: 'none', marginBottom: '12px' }}
              onFocus={e => e.target.style.borderColor = '#2DCE89'}
              onBlur={e => e.target.style.borderColor = '#e5e7eb'}
            />

            <div style={{ display: 'flex', gap: '10px', marginBottom: '12px' }}>
              <button onClick={sendThankYou} disabled={sending || !recipientName.trim() || !thankMessage.trim()} style={{ ...btnStyle, flex: 2, opacity: (!recipientName.trim() || !thankMessage.trim()) ? 0.5 : 1 }}>
                <i className="fas fa-paper-plane" style={{ marginRight: '8px' }}></i>
                {sending ? (isAr ? 'جاري الإرسال...' : 'Sending...') : (isAr ? 'إنشاء رابط الشكر' : 'Create Thank You Link')}
              </button>
              {thankMessage.trim() && recipientName.trim() && (
                <button onClick={copyMessage} style={{ ...btnStyle, flex: 1, background: 'linear-gradient(135deg, #8965e0, #6c4ab6)' }}>
                  <i className="fas fa-copy"></i>
                </button>
              )}
            </div>
          </div>

          {/* Shared link result */}
          {sharedLink && (
            <div style={{ ...sectionStyle, background: 'linear-gradient(135deg, #f0fdf4, #ecfdf5)', border: '2px solid #2DCE89' }}>
              <div style={{ textAlign: 'center', marginBottom: '15px' }}>
                <div style={{ fontSize: '2.5rem' }}>✅</div>
                <h4 style={{ margin: '10px 0 5px', color: '#2DCE89' }}>
                  {isAr ? 'تم إنشاء رابط الشكر!' : 'Thank You Link Created!'}
                </h4>
                <p style={{ margin: 0, fontSize: '0.8rem', color: '#8898aa' }}>
                  {isAr ? 'فقط من لديه الرابط يمكنه رؤية الرسالة' : 'Only people with the link can see the message'}
                </p>
              </div>
              <div style={{
                background: 'white', borderRadius: '12px', padding: '12px',
                fontSize: '0.75rem', color: '#6b7280', wordBreak: 'break-all',
                marginBottom: '12px', border: '1px solid #e5e7eb',
              }}>
                {sharedLink}
              </div>
              <div style={{ display: 'flex', gap: '10px' }}>
                <button onClick={copyLink} style={{ ...btnStyle, flex: 1 }}>
                  <i className={`fas fa-${copied ? 'check' : 'copy'}`} style={{ marginRight: '8px' }}></i>
                  {copied ? (isAr ? 'تم النسخ!' : 'Copied!') : (isAr ? 'نسخ الرابط' : 'Copy Link')}
                </button>
                {navigator.share && (
                  <button onClick={() => navigator.share({ title: 'Soon - Thank You', url: sharedLink })} style={{ ...btnStyle, flex: 1, background: 'linear-gradient(135deg, #8965e0, #6c4ab6)' }}>
                    <i className="fas fa-share-alt" style={{ marginRight: '8px' }}></i>
                    {isAr ? 'مشاركة' : 'Share'}
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Tab: Daily Victories */}
      {activeTab === 'victories' && (
        <div>
          <div style={sectionStyle}>
            <div style={{ textAlign: 'center', marginBottom: '20px' }}>
              <div style={{ fontSize: '3rem', marginBottom: '10px' }}>🏆</div>
              <h3 style={{ margin: '0 0 8px', color: '#32325d', fontSize: '1.1rem' }}>
                {isAr ? 'انتصاراتي اليومية' : lang === 'es' ? 'Mis victorias diarias' : lang === 'fr' ? 'Mes victoires du jour' : 'My Daily Victories'}
              </h3>
              <p style={{ margin: 0, fontSize: '0.85rem', color: '#8898aa' }}>
                {isAr ? 'حتى لو كانت صغيرة، كل انتصار يستحق الاحتفال 🎉' : 'Even small ones. Every victory deserves celebration 🎉'}
              </p>
            </div>

            <div style={{ display: 'flex', gap: '10px', marginBottom: '15px' }}>
              <input
                type="text"
                value={victoryInput}
                onChange={e => setVictoryInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && addVictory()}
                placeholder={isAr ? 'انتصار اليوم...' : "Today's victory..."}
                style={{ ...inputStyle, flex: 1 }}
                onFocus={e => e.target.style.borderColor = '#f59e0b'}
                onBlur={e => e.target.style.borderColor = '#e5e7eb'}
              />
              <button onClick={addVictory} disabled={!victoryInput.trim()} style={{
                background: victoryInput.trim() ? 'linear-gradient(135deg, #f59e0b, #d97706)' : '#e5e7eb',
                color: 'white', border: 'none', borderRadius: '14px',
                width: '52px', fontSize: '1.2rem', cursor: 'pointer', transition: 'all 0.3s',
              }}>
                <i className="fas fa-plus"></i>
              </button>
            </div>

            {/* Today's count */}
            <div style={{
              background: 'linear-gradient(135deg, #fffbeb, #fef3c7)',
              borderRadius: '14px', padding: '14px', textAlign: 'center',
              marginBottom: '15px', border: '1px solid #fde68a',
            }}>
              <span style={{ fontSize: '2rem' }}>⭐</span>
              <p style={{ margin: '5px 0 0', fontWeight: 700, color: '#92400e', fontSize: '1.1rem' }}>
                {todayVictories.length} {isAr ? 'انتصار اليوم' : 'victories today'}
              </p>
            </div>

            {/* Victories list */}
            {todayVictories.map(v => (
              <div key={v.id} style={{
                display: 'flex', alignItems: 'center', gap: '12px',
                padding: '14px', borderRadius: '12px', marginBottom: '10px',
                background: 'linear-gradient(135deg, #fffbeb, #fff)',
                borderLeft: '4px solid #f59e0b',
              }}>
                <span style={{ fontSize: '1.3rem' }}>🏅</span>
                <p style={{ margin: 0, flex: 1, fontSize: '0.9rem', color: '#32325d' }}>{v.text}</p>
                <button onClick={() => removeVictory(v.id)} style={{
                  background: 'none', border: 'none', color: '#d1d5db',
                  cursor: 'pointer', fontSize: '0.9rem',
                }}>
                  <i className="fas fa-times"></i>
                </button>
              </div>
            ))}

            {/* Previous victories */}
            {victories.filter(v => v.date !== today).length > 0 && (
              <div style={{ marginTop: '20px' }}>
                <h4 style={{ margin: '0 0 12px', color: '#8898aa', fontSize: '0.9rem' }}>
                  <i className="fas fa-history" style={{ marginRight: '8px' }}></i>
                  {isAr ? 'الانتصارات السابقة' : 'Previous Victories'}
                </h4>
                {victories.filter(v => v.date !== today).slice(0, 15).map(v => (
                  <div key={v.id} style={{
                    padding: '10px 14px', borderRadius: '10px', marginBottom: '8px',
                    background: '#f9fafb', borderLeft: '3px solid #d1d5db',
                  }}>
                    <p style={{ margin: 0, fontSize: '0.85rem', color: '#6b7280' }}>🏅 {v.text}</p>
                    <span style={{ fontSize: '0.7rem', color: '#9ca3af' }}>
                      {new Date(v.date).toLocaleDateString(isAr ? 'ar-SA' : 'en-US', { month: 'short', day: 'numeric' })}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
