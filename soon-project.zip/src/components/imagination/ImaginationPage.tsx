import { useState } from 'react';
import InlineAIChat from '../shared/InlineAIChat';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';

interface VisionEntry {
  id: string;
  text: string;
  category: string;
  date: string;
}

interface ImaginationPageProps {
  onBack: () => void;
}

export default function ImaginationPage({ onBack }: ImaginationPageProps) {
  const { t, lang } = useLanguage();
  const isRTL = lang === 'ar';
  const [visions, setVisions] = useLocalStorage<VisionEntry[]>('soon-imagination', []);
  const [text, setText] = useState('');
  const [category, setCategory] = useState('life');

  const categories = [
    { id: 'life', icon: '🌟', label: t('imag.life') },
    { id: 'career', icon: '💼', label: t('imag.career') },
    { id: 'love', icon: '❤️', label: t('imag.love') },
    { id: 'health', icon: '🧘', label: t('imag.health') },
    { id: 'travel', icon: '✈️', label: t('imag.travel') },
    { id: 'free', icon: '🎨', label: t('imag.free') },
  ];

  const save = () => {
    if (!text.trim()) return;
    setVisions(prev => [{ id: Date.now().toString(), text: text.trim(), category, date: new Date().toISOString() }, ...prev]);
    setText('');
  };

  return (
    <div style={{ paddingTop: '20px', direction: isRTL ? 'rtl' : 'ltr' }}>
      <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#8965e0', fontSize: '1rem', cursor: 'pointer', marginBottom: '15px' }}>
        <i className={`fas fa-arrow-${isRTL ? 'right' : 'left'}`}></i> {t('nav.home')}
      </button>

      <div style={{ background: 'linear-gradient(135deg, #8965e0, #bc65e0)', borderRadius: '20px', padding: '25px', color: 'white', textAlign: 'center', marginBottom: '20px' }}>
        <div style={{ fontSize: '2.5rem', marginBottom: '10px' }}>🌈✨</div>
        <h2 style={{ fontSize: '1.3rem', fontWeight: 700, margin: '0 0 8px' }}>{t('imag.title')}</h2>
        <p style={{ fontSize: '0.85rem', opacity: 0.9, margin: 0 }}>{t('imag.subtitle')}</p>
      </div>

      <div style={{ background: 'white', borderRadius: '16px', padding: '20px', marginBottom: '15px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)' }}>
        <h4 style={{ color: '#8965e0', marginBottom: '15px' }}>🌈 {t('imag.close_eyes')}</h4>
        <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', marginBottom: '15px' }}>
          {categories.map(c => (
            <button key={c.id} onClick={() => setCategory(c.id)} style={{
              padding: '8px 12px', borderRadius: '20px', border: 'none', cursor: 'pointer',
              background: category === c.id ? '#8965e0' : '#f7f8fa',
              color: category === c.id ? 'white' : '#32325d', fontSize: '0.75rem', fontWeight: 600
            }}>
              {c.icon} {c.label}
            </button>
          ))}
        </div>
        <textarea value={text} onChange={e => setText(e.target.value)} placeholder={t('imag.placeholder')}
          style={{ width: '100%', padding: '15px', border: '2px solid #f0f4ff', borderRadius: '12px', minHeight: '120px', resize: 'vertical', boxSizing: 'border-box', fontSize: '0.95rem' }} />
        <button onClick={save} style={{ width: '100%', background: 'linear-gradient(135deg, #8965e0, #bc65e0)', color: 'white', border: 'none', borderRadius: '12px', padding: '14px', fontWeight: 600, cursor: 'pointer', marginTop: '15px' }}>
          {t('imag.save')}
        </button>
      </div>

      <h4 style={{ color: '#32325d', marginBottom: '10px' }}>📖 {t('imag.my_visions')}</h4>
      {visions.length === 0 && <p style={{ textAlign: 'center', color: '#8898aa' }}>{t('imag.empty')}</p>}
      {visions.slice(0, 15).map(v => (
        <div key={v.id} style={{ background: 'white', borderRadius: '12px', padding: '15px', marginBottom: '10px', borderLeft: '4px solid #8965e0' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px' }}>
            <span style={{ fontSize: '0.75rem', background: '#f0e6ff', color: '#8965e0', padding: '2px 8px', borderRadius: '10px' }}>
              {categories.find(c => c.id === v.category)?.icon} {categories.find(c => c.id === v.category)?.label}
            </span>
            <span style={{ fontSize: '0.7rem', color: '#aaa' }}>{new Date(v.date).toLocaleDateString()}</span>
          </div>
          <p style={{ color: '#32325d', margin: 0, lineHeight: 1.6, fontSize: '0.9rem' }}>{v.text}</p>
        </div>
      ))}
      <InlineAIChat context="imagination" lang={lang} />
    </div>
  );
}
