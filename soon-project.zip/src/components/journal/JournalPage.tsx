import { useState } from 'react';
import InlineAIChat from '../shared/InlineAIChat';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { useLanguage } from '../../i18n/LanguageContext';

interface JournalEntry { id: string; text: string; mood: string; date: string; }
interface FamilyJournalEntry { id: string; role: string; name: string; wishes: string; lessons: string; guidance: string; date: string; }
interface JournalPageProps { onShareWithAI: (text: string) => void; }

export default function JournalPage({ onShareWithAI }: JournalPageProps) {
  const { t, lang } = useLanguage();
  const isRTL = lang === 'ar';
  const [entries, setEntries] = useLocalStorage<JournalEntry[]>('soon-journal', []);
  const [familyEntries, setFamilyEntries] = useLocalStorage<FamilyJournalEntry[]>('soon-family-journal', []);
  const [activeTab, setActiveTab] = useState<'personal' | 'family'>('personal');
  const [text, setText] = useState('');
  const [mood, setMood] = useState('');
  
  // Family journal state
  const [familyRole, setFamilyRole] = useState('');
  const [familyName, setFamilyName] = useState('');
  const [familyWishes, setFamilyWishes] = useState('');
  const [familyLessons, setFamilyLessons] = useState('');
  const [familyGuidance, setFamilyGuidance] = useState('');

  const familyRoles = [
    { id: 'father', icon: '👨', key: 'fj.father' },
    { id: 'mother', icon: '👩', key: 'fj.mother' },
    { id: 'son', icon: '👦', key: 'fj.son' },
    { id: 'daughter', icon: '👧', key: 'fj.daughter' },
    { id: 'grandfather', icon: '👴', key: 'fj.grandfather' },
    { id: 'grandmother', icon: '👵', key: 'fj.grandmother' },
    { id: 'sibling', icon: '👫', key: 'fj.sibling' },
  ];

  const saveEntry = () => {
    if (!text.trim()) return;
    setEntries([{ id: Date.now().toString(), text: text.trim(), mood: mood.trim(), date: new Date().toISOString() }, ...entries]);
    setText(''); setMood('');
    alert(t('journal.saved'));
  };

  const saveFamilyEntry = () => {
    if (!familyRole || !familyWishes.trim()) return;
    setFamilyEntries([{
      id: Date.now().toString(),
      role: familyRole,
      name: familyName.trim(),
      wishes: familyWishes.trim(),
      lessons: familyLessons.trim(),
      guidance: familyGuidance.trim(),
      date: new Date().toISOString()
    }, ...familyEntries]);
    setFamilyRole('');
    setFamilyName('');
    setFamilyWishes('');
    setFamilyLessons('');
    setFamilyGuidance('');
  };

  return (
    <div style={{ direction: isRTL ? 'rtl' : 'ltr' }}>
      <h2 style={{ fontSize: '1.8rem', fontWeight: 700, color: '#32325d', margin: '25px 0', textAlign: 'center', position: 'relative' }}>
        {t('journal.title')}
        <div style={{ position: 'absolute', bottom: '-10px', left: '50%', transform: 'translateX(-50%)', width: '80px', height: '4px', background: '#2DCE89', borderRadius: '2px' }}></div>
      </h2>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: '10px', marginBottom: '20px' }}>
        <button onClick={() => setActiveTab('personal')} style={{
          flex: 1, padding: '12px', borderRadius: '12px', border: 'none', cursor: 'pointer',
          background: activeTab === 'personal' ? 'linear-gradient(to right, #2DCE89, #1a9f6e)' : '#f8f9fe',
          color: activeTab === 'personal' ? 'white' : '#32325d', fontWeight: 600, fontFamily: 'Poppins, sans-serif'
        }}>
          📝 {t('journal.personal')}
        </button>
        <button onClick={() => setActiveTab('family')} style={{
          flex: 1, padding: '12px', borderRadius: '12px', border: 'none', cursor: 'pointer',
          background: activeTab === 'family' ? 'linear-gradient(135deg, #8b5cf6, #a855f7)' : '#f8f9fe',
          color: activeTab === 'family' ? 'white' : '#32325d', fontWeight: 600, fontFamily: 'Poppins, sans-serif'
        }}>
          👨‍👩‍👧‍👦 {t('fj.title')}
        </button>
      </div>

      {/* Personal Journal */}
      {activeTab === 'personal' && (
        <div>
          <div style={{ marginBottom: '30px', marginTop: '20px' }}>
            <h3 style={{ fontSize: '1.3rem', color: '#32325d', marginBottom: '15px' }}>{t('journal.daily')}</h3>
            <textarea value={text} onChange={e => setText(e.target.value)} placeholder={t('journal.placeholder')}
              style={{ width: '100%', height: '180px', border: '1px solid #ddd', borderRadius: '16px', padding: '15px', fontFamily: 'Poppins, sans-serif', fontSize: '1rem', resize: 'vertical', marginBottom: '15px', lineHeight: 1.6, outline: 'none', boxSizing: 'border-box' }}
              onFocus={e => { e.target.style.borderColor = '#2DCE89'; e.target.style.boxShadow = '0 0 0 3px rgba(45,206,137,0.2)'; }}
              onBlur={e => { e.target.style.borderColor = '#ddd'; e.target.style.boxShadow = 'none'; }}
            />
            <input value={mood} onChange={e => setMood(e.target.value)} placeholder={t('journal.mood_placeholder')}
              style={{ width: '100%', padding: '12px 15px', border: '1px solid #ddd', borderRadius: '25px', fontFamily: 'Poppins, sans-serif', fontSize: '1rem', outline: 'none', marginBottom: '15px', boxSizing: 'border-box' }}
            />
            <div style={{ display: 'flex', gap: '10px' }}>
              <button onClick={saveEntry} style={{ background: 'linear-gradient(to right, #2DCE89, #1a9f6e)', color: 'white', border: 'none', borderRadius: '25px', padding: '12px 24px', fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif', flex: 1 }}>{t('journal.save')}</button>
              <button onClick={() => onShareWithAI(`My journal entry: ${text}\nMood: ${mood}`)} style={{ background: '#d1efe1', color: '#2DCE89', border: 'none', borderRadius: '25px', padding: '12px 24px', fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif', flex: 1 }}>{t('journal.share')}</button>
            </div>
          </div>

          <h3 style={{ fontSize: '1.3rem', color: '#32325d', marginBottom: '15px' }}>{t('journal.previous')}</h3>
          {entries.length === 0 && <p style={{ color: '#8898aa', textAlign: 'center' }}>{t('journal.no_entries')}</p>}
          {entries.map(entry => (
            <div key={entry.id} style={{ background: 'white', borderRadius: '16px', padding: '15px', marginBottom: '15px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
              <h4 style={{ color: '#1a9f6e', marginBottom: '8px', fontSize: '0.9rem' }}>
                {new Date(entry.date).toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
              </h4>
              {entry.mood && <span style={{ display: 'inline-block', background: '#d1efe1', padding: '3px 10px', borderRadius: '20px', fontSize: '0.85rem', color: '#1a9f6e', marginBottom: '8px' }}>{entry.mood}</span>}
              <p style={{ lineHeight: 1.6, color: '#32325d', margin: 0 }}>{entry.text}</p>
            </div>
          ))}
        </div>
      )}

      {/* Family Journal */}
      {activeTab === 'family' && (
        <div>
          <div style={{ background: 'linear-gradient(135deg, #8b5cf6, #a855f7)', borderRadius: '16px', padding: '20px', color: 'white', textAlign: 'center', marginBottom: '20px' }}>
            <div style={{ fontSize: '2rem', marginBottom: '10px' }}>👨‍👩‍👧‍👦</div>
            <h3 style={{ margin: '0 0 8px', fontSize: '1.2rem' }}>{t('fj.title')}</h3>
            <p style={{ margin: 0, fontSize: '0.85rem', opacity: 0.95 }}>{t('fj.subtitle')}</p>
          </div>

          <div style={{ background: 'white', borderRadius: '16px', padding: '20px', marginBottom: '20px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
            <h4 style={{ color: '#8b5cf6', marginBottom: '15px' }}>👤 {t('fj.select_role')}</h4>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginBottom: '15px' }}>
              {familyRoles.map(role => (
                <button key={role.id} onClick={() => setFamilyRole(role.id)} style={{
                  padding: '10px 14px', borderRadius: '12px', border: familyRole === role.id ? '2px solid #8b5cf6' : 'none',
                  background: familyRole === role.id ? '#8b5cf6' : '#f0f4ff', color: familyRole === role.id ? 'white' : '#32325d',
                  fontWeight: 500, fontSize: '0.85rem', cursor: 'pointer', fontFamily: 'Poppins, sans-serif'
                }}>
                  {role.icon} {t(role.key)}
                </button>
              ))}
            </div>

            {familyRole && (
              <>
                <input type="text" value={familyName} onChange={e => setFamilyName(e.target.value)} placeholder={t('fj.name_placeholder')}
                  style={{ width: '100%', padding: '12px', border: '1px solid #e0e0e0', borderRadius: '12px', marginBottom: '12px', fontFamily: 'Poppins, sans-serif', boxSizing: 'border-box' }} />
                
                <textarea value={familyWishes} onChange={e => setFamilyWishes(e.target.value)} placeholder={t('fj.wishes_placeholder')}
                  style={{ width: '100%', padding: '12px', border: '2px solid #8b5cf6', borderRadius: '12px', marginBottom: '12px', fontFamily: 'Poppins, sans-serif', minHeight: '80px', resize: 'vertical', boxSizing: 'border-box' }} />
                
                <textarea value={familyLessons} onChange={e => setFamilyLessons(e.target.value)} placeholder={t('fj.lessons_placeholder')}
                  style={{ width: '100%', padding: '12px', border: '1px solid #e0e0e0', borderRadius: '12px', marginBottom: '12px', fontFamily: 'Poppins, sans-serif', minHeight: '80px', resize: 'vertical', boxSizing: 'border-box' }} />
                
                <textarea value={familyGuidance} onChange={e => setFamilyGuidance(e.target.value)} placeholder={t('fj.guidance_placeholder')}
                  style={{ width: '100%', padding: '12px', border: '1px solid #e0e0e0', borderRadius: '12px', marginBottom: '15px', fontFamily: 'Poppins, sans-serif', minHeight: '80px', resize: 'vertical', boxSizing: 'border-box' }} />
                
                <button onClick={saveFamilyEntry} style={{ width: '100%', padding: '14px', background: 'linear-gradient(135deg, #8b5cf6, #a855f7)', color: 'white', border: 'none', borderRadius: '12px', fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif' }}>
                  {t('fj.save')}
                </button>
              </>
            )}
          </div>

          <h4 style={{ color: '#32325d', marginBottom: '15px' }}>📖 {t('fj.history')}</h4>
          {familyEntries.length === 0 && <p style={{ color: '#8898aa', textAlign: 'center' }}>{t('fj.empty')}</p>}
          {familyEntries.map(entry => (
            <div key={entry.id} style={{ background: 'white', borderRadius: '16px', padding: '15px', marginBottom: '15px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)', borderLeft: '4px solid #8b5cf6' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
                <span style={{ background: '#f0e7ff', color: '#8b5cf6', padding: '4px 12px', borderRadius: '20px', fontSize: '0.85rem', fontWeight: 600 }}>
                  {familyRoles.find(r => r.id === entry.role)?.icon} {t(`fj.${entry.role}`)} {entry.name && `- ${entry.name}`}
                </span>
                <span style={{ fontSize: '0.7rem', color: '#aaa' }}>{new Date(entry.date).toLocaleDateString()}</span>
              </div>
              {entry.wishes && (
                <div style={{ marginBottom: '8px' }}>
                  <span style={{ fontWeight: 600, color: '#8b5cf6', fontSize: '0.8rem' }}>💫 {t('fj.wishes_label')}:</span>
                  <p style={{ margin: '4px 0 0', color: '#32325d', fontSize: '0.9rem' }}>{entry.wishes}</p>
                </div>
              )}
              {entry.lessons && (
                <div style={{ marginBottom: '8px' }}>
                  <span style={{ fontWeight: 600, color: '#f59e0b', fontSize: '0.8rem' }}>📚 {t('fj.lessons_label')}:</span>
                  <p style={{ margin: '4px 0 0', color: '#32325d', fontSize: '0.9rem' }}>{entry.lessons}</p>
                </div>
              )}
              {entry.guidance && (
                <div>
                  <span style={{ fontWeight: 600, color: '#10b981', fontSize: '0.8rem' }}>💡 {t('fj.guidance_label')}:</span>
                  <p style={{ margin: '4px 0 0', color: '#32325d', fontSize: '0.9rem' }}>{entry.guidance}</p>
                </div>
              )}
            </div>
          ))}

          {/* Family Bonding Tip */}
          <div style={{ background: 'linear-gradient(135deg, #fef3c7, #fde68a)', borderRadius: '16px', padding: '15px', marginTop: '15px', borderLeft: '4px solid #f59e0b' }}>
            <h4 style={{ color: '#b45309', marginBottom: '8px' }}>💕 {t('fj.tip_title')}</h4>
            <p style={{ color: '#92400e', fontSize: '0.85rem', lineHeight: 1.6, margin: 0 }}>{t('fj.tip_desc')}</p>
          </div>
        </div>
      )}
      <InlineAIChat context="journal" lang={lang} />
    </div>
  );
}
