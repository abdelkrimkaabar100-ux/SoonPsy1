import { useEffect, useRef, useState } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { supabase } from '@/integrations/supabase/client';

interface PsycheWarsPageProps { onBack: () => void; }

interface ActionStats { strike: number; analyze: number; special: number; heal: number; total: number; }
interface ProfileLog { date: string; victory: boolean; monster: string; stats: ActionStats; insight: string; archetype?: string; }

export default function PsycheWarsPage({ onBack }: PsycheWarsPageProps) {
  const { lang } = useLanguage();
  const isAr = lang === 'ar';
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [log, setLog] = useLocalStorage<ProfileLog[]>('soon-psyche-wars-log', []);
  const [unlocked, setUnlocked] = useLocalStorage<string[]>('soon-psyche-wars-affirmations', []);
  const [insight, setInsight] = useState<string>('');
  const [loading, setLoading] = useState(false);

  const affirmationPool = isAr ? [
    '🌿 أنا أستحق اللطف، خصوصاً من نفسي.',
    '🕊️ مشاعري ليست عدواً — هي رسائل تطلب الإصغاء.',
    '🔥 شجاعتي ليست في إخفاء ظلي، بل في احتضانه.',
    '💧 السماح للضعف أن يُرى هو أعلى أشكال القوة.',
    '🌱 كل معركة داخلية تزرع جذراً أعمق في وعيي.',
  ] : [
    '🌿 I deserve kindness — especially from myself.',
    '🕊️ My emotions are not enemies, they are messengers.',
    '🔥 Courage is not hiding my shadow but embracing it.',
    '💧 Letting weakness be seen is the highest strength.',
    '🌱 Each inner battle grows a deeper root in me.',
  ];

  useEffect(() => {
    const onMsg = async (e: MessageEvent) => {
      const d = e.data; if (!d || d.source !== 'psyche-wars') return;
      if (d.kind === 'battle-end') {
        const entry: ProfileLog = {
          date: new Date().toISOString(), victory: d.victory, monster: d.monster,
          stats: d.stats, insight: d.insight, archetype: d.archetype,
        };
        setLog(prev => [entry, ...prev].slice(0, 50));

        // Unlock affirmation on victory
        if (d.victory) {
          const next = affirmationPool[unlocked.length % affirmationPool.length];
          if (next && !unlocked.includes(next)) setUnlocked(prev => [...prev, next]);
        }

        // Psycho-AI profiling via Lovable/Groq AI
        setLoading(true); setInsight('');
        try {
          const s: ActionStats = d.stats;
          const ratio = (k: keyof ActionStats) => s.total ? Math.round(((s[k] as number) / s.total) * 100) : 0;
          const profile = `Confront ${ratio('strike')}%, Analyze ${ratio('analyze')}%, Special ${ratio('special')}%, Self-Compassion ${ratio('heal')}%`;
          const sys = isAr
            ? `أنت معالج نفسي يحلل أسلوب لعب المستخدم في لعبة Psyche Wars. حلل توزيع اختياراته واستنتج نمطه النفسي (مثل: قاسٍ على نفسه، يهرب من المواجهة، متوازن، فضولي). أعطه رسالة دافئة (3-4 جمل) بصيغة المخاطب، ثم نصيحة عملية واحدة. بدون ماركداون.`
            : `You are a therapist analyzing the user's Psyche Wars playstyle. Read the action distribution and infer a psychological pattern (e.g. harsh on self, avoidant, balanced, curious). Write a warm 3-4 sentence message in second person, then one concrete suggestion. No markdown.`;
          const prompt = `Battle: ${d.monster} | Outcome: ${d.victory ? 'victory' : 'defeat'} | Action distribution: ${profile} | Archetype: ${d.archetype}`;
          const { data, error } = await supabase.functions.invoke('groq-chat', {
            body: { messages: [{ role: 'user', content: prompt }], systemPrompt: sys },
          });
          if (error) throw error;
          setInsight(data?.content || '');
        } catch {
          setInsight(isAr ? 'لم أستطع تحليل أسلوبك الآن، حاول مرة أخرى.' : 'Could not analyze your style right now.');
        } finally { setLoading(false); }
      }
    };
    window.addEventListener('message', onMsg);
    return () => window.removeEventListener('message', onMsg);
  }, [unlocked, isAr]);

  // Quick aggregate
  const agg = log.reduce((acc, l) => {
    (['strike','analyze','special','heal'] as const).forEach(k => { acc[k] += l.stats[k] || 0; });
    acc.total += l.stats.total || 0; return acc;
  }, { strike:0, analyze:0, special:0, heal:0, total:0 });

  const pct = (k: keyof typeof agg) => agg.total ? Math.round(((agg[k] as number)/agg.total)*100) : 0;

  return (
    <div style={{ paddingTop: 10, direction: isAr ? 'rtl' : 'ltr' }}>
      <button onClick={onBack} style={{ background:'none', border:'none', color:'#8b5cf6', fontSize:'1rem', cursor:'pointer', marginBottom:12 }}>
        <i className={`fas fa-arrow-${isAr ? 'right' : 'left'}`}></i> {isAr ? 'رجوع' : 'Back'}
      </button>

      <div style={{ background:'linear-gradient(135deg,#06030f,#1a1035,#241848)', borderRadius:20, padding:20, color:'#f0eaff', marginBottom:15, textAlign:'center' }}>
        <div style={{ fontSize:'2.4rem' }}>⚔️</div>
        <h2 style={{ margin:'4px 0 6px', fontFamily:'Cinzel Decorative, serif', fontSize:'1.4rem', color:'#c8a2ff' }}>Psyche Wars</h2>
        <p style={{ margin:0, fontSize:'0.85rem', opacity:0.85 }}>{isAr ? 'حارب وحوشك الداخلية. الذكاء الاصطناعي يحلل أسلوبك بعد كل معركة.' : 'Battle your inner monsters. The AI analyzes your style after each battle.'}</p>
      </div>

      <div style={{ position:'relative', width:'100%', height:'70vh', minHeight:520, borderRadius:18, overflow:'hidden', border:'2px solid #4a3870', boxShadow:'0 10px 30px rgba(0,0,0,0.4)', marginBottom:15 }}>
        <iframe ref={iframeRef} src="/psyche-wars.html" title="Psyche Wars" style={{ width:'100%', height:'100%', border:'none', display:'block', background:'#06030f' }} />
      </div>

      {(loading || insight) && (
        <div style={{ background:'linear-gradient(135deg,#1a1035,#241848)', borderRadius:16, padding:16, color:'#f0eaff', marginBottom:15, border:'1px solid #6d28d9' }}>
          <h4 style={{ margin:'0 0 8px', color:'#c8a2ff', fontSize:'0.95rem' }}>🧠 {isAr ? 'تحليل Psycho-AI لأسلوبك' : 'Psycho-AI Style Analysis'}</h4>
          <p style={{ margin:0, fontSize:'0.9rem', lineHeight:1.7, color:'#e2e8f0' }}>{loading ? (isAr ? 'جاري التحليل...' : 'Analyzing...') : insight}</p>
        </div>
      )}

      {agg.total > 0 && (
        <div style={{ background:'white', borderRadius:16, padding:14, marginBottom:15, boxShadow:'0 4px 15px rgba(0,0,0,0.08)' }}>
          <h4 style={{ margin:'0 0 10px', color:'#32325d', textAlign:'center' }}>📊 {isAr ? 'بصمتك السلوكية' : 'Your Behavioral Profile'}</h4>
          {([
            { k:'strike', label: isAr ? '🗡 المواجهة' : '🗡 Confront', color:'#e0304a' },
            { k:'analyze', label: isAr ? '🔍 التحليل' : '🔍 Analyze', color:'#40d8c8' },
            { k:'special', label: isAr ? '✨ الخاص' : '✨ Special', color:'#f0c060' },
            { k:'heal', label: isAr ? '🌿 التعاطف الذاتي' : '🌿 Self-Compassion', color:'#10b981' },
          ] as const).map(b => (
            <div key={b.k} style={{ marginBottom:6 }}>
              <div style={{ display:'flex', justifyContent:'space-between', fontSize:'0.8rem', color:'#525f7f', marginBottom:2 }}>
                <span>{b.label}</span><span>{pct(b.k as any)}%</span>
              </div>
              <div style={{ height:8, background:'#f0f4ff', borderRadius:6, overflow:'hidden' }}>
                <div style={{ width:`${pct(b.k as any)}%`, height:'100%', background:b.color, transition:'width 0.4s' }} />
              </div>
            </div>
          ))}
        </div>
      )}

      {unlocked.length > 0 && (
        <div style={{ background:'linear-gradient(135deg,#fefce8,#fef9c3)', borderRadius:16, padding:14, marginBottom:15, border:'1px solid #fde047' }}>
          <h4 style={{ margin:'0 0 8px', color:'#854d0e' }}>🏆 {isAr ? 'الغنيمة: تأكيدات أُفتحت' : 'Loot: Unlocked Affirmations'}</h4>
          {unlocked.map((a,i)=> (
            <div key={i} style={{ background:'white', borderRadius:10, padding:'8px 12px', marginBottom:6, fontSize:'0.88rem', color:'#525f7f' }}>{a}</div>
          ))}
        </div>
      )}
    </div>
  );
}
