import { useState, useEffect } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { supabase } from '@/integrations/supabase/client';

interface WhatNotToDoPageProps { onBack: () => void; }

export default function WhatNotToDoPage({ onBack }: WhatNotToDoPageProps) {
  const { lang } = useLanguage();
  const isAr = lang === 'ar';
  const [advice, setAdvice] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [generated, setGenerated] = useState(false);

  const labels: Record<string, Record<string, string>> = {
    en: { title: '🚫 What You Shouldn\'t Do', subtitle: 'AI analyzes your data and warns you', back: 'Back', generate: 'Analyze My Data', loading: 'Analyzing your habits...', disclaimer: 'This is AI-generated guidance, not medical advice.' },
    ar: { title: '🚫 ما لا ينبغي عليك فعله', subtitle: 'الذكاء الاصطناعي يحلل بياناتك وينبهك', back: 'رجوع', generate: 'حلل بياناتي', loading: 'جاري تحليل عاداتك...', disclaimer: 'هذا توجيه من الذكاء الاصطناعي وليس نصيحة طبية.' },
    es: { title: '🚫 Lo Que No Deberías Hacer', subtitle: 'La IA analiza tus datos y te advierte', back: 'Volver', generate: 'Analizar Mis Datos', loading: 'Analizando...', disclaimer: 'Orientación de IA, no consejo médico.' },
    fr: { title: '🚫 Ce Que Vous Ne Devriez Pas Faire', subtitle: 'L\'IA analyse vos données et vous avertit', back: 'Retour', generate: 'Analyser Mes Données', loading: 'Analyse en cours...', disclaimer: 'Guidance IA, pas un avis médical.' },
  };
  const l = labels[lang] || labels.en;

  const generateAdvice = async () => {
    setLoading(true);
    try {
      const read = (key: string, fb: any) => { try { return JSON.parse(localStorage.getItem(key) || JSON.stringify(fb)); } catch { return fb; } };
      const moodHistory = read('soon-mood-history', []);
      const sleepLog = read('soon-sleep', []);
      const tasks = read('soon-tasks', []);
      const anxiety = read('soon-anxiety', []);
      const name = read('soon-user-name', '') || '';

      const dataContext = `User: ${name}. Recent moods: ${moodHistory.slice(0, 5).map((m: any) => m.mood).join(', ')}. Sleep hours recently: ${sleepLog.slice(0, 5).map((s: any) => s.value).join(', ')}. Pending tasks: ${tasks.filter((t: any) => !t.completed).length}. Anxiety entries: ${anxiety.length}.`;

      const prompt = lang === 'ar'
        ? `بناءً على بيانات المستخدم التالية، أعطِ 5-7 أشياء لا ينبغي عليه فعلها لتحسين صحته النفسية. كن محدداً ومباشراً. أجب بالعربية. كل نقطة في سطر منفصل تبدأ بـ 🚫. ${dataContext}`
        : `Based on this user data, give 5-7 things they should NOT do to improve mental health. Be specific and direct. Each point on a separate line starting with 🚫. ${dataContext}`;

      const { data, error } = await supabase.functions.invoke('groq-chat', {
        body: { messages: [{ role: 'user', content: prompt }] }
      });

      if (data?.content) {
        const lines = data.content.split('\n').filter((l: string) => l.trim().length > 0);
        setAdvice(lines);
      } else {
        // Fallback
        setAdvice(isAr ? [
          '🚫 لا تنام أقل من 7 ساعات',
          '🚫 لا تتجاهل مشاعرك السلبية',
          '🚫 لا تقارن نفسك بالآخرين على وسائل التواصل',
          '🚫 لا تؤجل مهامك المهمة',
          '🚫 لا تهمل التمارين الرياضية',
          '🚫 لا تتناول الطعام عند الشعور بالتوتر',
        ] : [
          '🚫 Don\'t sleep less than 7 hours',
          '🚫 Don\'t ignore your negative emotions',
          '🚫 Don\'t compare yourself to others on social media',
          '🚫 Don\'t procrastinate on important tasks',
          '🚫 Don\'t skip physical exercise',
          '🚫 Don\'t stress-eat',
        ]);
      }
      setGenerated(true);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ paddingTop: '15px', direction: isAr ? 'rtl' : 'ltr' }}>
      <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#e11d48', cursor: 'pointer', fontSize: '1rem', fontFamily: 'Poppins, sans-serif', marginBottom: '15px' }}>
        <i className={`fas fa-arrow-${isAr ? 'right' : 'left'}`}></i> {l.back}
      </button>

      <div style={{ background: 'linear-gradient(135deg, #fef2f2, #fee2e2)', borderRadius: '20px', padding: '25px', textAlign: 'center', marginBottom: '20px' }}>
        <h2 style={{ color: '#dc2626', margin: '0 0 8px', fontSize: '1.4rem' }}>{l.title}</h2>
        <p style={{ color: '#ef4444', fontSize: '0.9rem', margin: 0 }}>{l.subtitle}</p>
      </div>

      {!generated && (
        <button onClick={generateAdvice} disabled={loading} style={{
          width: '100%', background: loading ? '#9ca3af' : 'linear-gradient(135deg, #dc2626, #b91c1c)',
          color: 'white', border: 'none', borderRadius: '16px', padding: '16px',
          fontWeight: 600, fontSize: '1rem', cursor: loading ? 'wait' : 'pointer',
          fontFamily: 'Poppins, sans-serif',
        }}>
          {loading ? `⏳ ${l.loading}` : `🔍 ${l.generate}`}
        </button>
      )}

      {advice.map((item, i) => (
        <div key={i} style={{
          background: 'white', borderRadius: '14px', padding: '15px', marginBottom: '10px',
          boxShadow: '0 3px 10px rgba(0,0,0,0.06)', borderLeft: '4px solid #ef4444',
          fontSize: '0.9rem', color: '#32325d', lineHeight: 1.6,
        }}>
          {item}
        </div>
      ))}

      {generated && (
        <>
          <button onClick={() => { setGenerated(false); setAdvice([]); }} style={{
            width: '100%', background: '#ef4444', color: 'white', border: 'none',
            borderRadius: '16px', padding: '14px', fontWeight: 600, cursor: 'pointer',
            fontFamily: 'Poppins, sans-serif', marginTop: '10px',
          }}>
            🔄 {l.generate}
          </button>
          <p style={{ textAlign: 'center', color: '#9ca3af', fontSize: '0.75rem', marginTop: '10px' }}>⚠️ {l.disclaimer}</p>
        </>
      )}
    </div>
  );
}
