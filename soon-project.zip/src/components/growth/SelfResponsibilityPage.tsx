import { useState } from 'react';
import InlineAIChat from '../shared/InlineAIChat';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';

interface GrowthEntry {
  id: string;
  area: string;
  commitment: string;
  steps: string;
  deadline: string;
  done: boolean;
  date: string;
}

interface HabitEntry {
  id: string;
  name: string;
  dates: string[]; // array of date strings when done
}

interface SelfResponsibilityPageProps {
  onBack: () => void;
}

export default function SelfResponsibilityPage({ onBack }: SelfResponsibilityPageProps) {
  const { lang } = useLanguage();
  const isRTL = lang === 'ar';
  const [entries, setEntries] = useLocalStorage<GrowthEntry[]>('soon-self-responsibility', []);
  const [habits, setHabits] = useLocalStorage<HabitEntry[]>('soon-resp-habits', []);
  const [area, setArea] = useState('mindset');
  const [commitment, setCommitment] = useState('');
  const [steps, setSteps] = useState('');
  const [deadline, setDeadline] = useState('');
  const [newHabit, setNewHabit] = useState('');
  const [showHabits, setShowHabits] = useState(false);

  const areas = [
    { id: 'mindset', icon: '🧠', label: isRTL ? 'عقلية' : 'Mindset' },
    { id: 'health', icon: '💪', label: isRTL ? 'صحة' : 'Health' },
    { id: 'skills', icon: '📖', label: isRTL ? 'مهارات' : 'Skills' },
    { id: 'habits', icon: '🔄', label: isRTL ? 'عادات' : 'Habits' },
    { id: 'relations', icon: '🤝', label: isRTL ? 'علاقات' : 'Relations' },
    { id: 'spirit', icon: '🌟', label: isRTL ? 'روحانية' : 'Spiritual' },
  ];

  const save = () => {
    if (!commitment.trim()) return;
    setEntries(prev => [{ id: Date.now().toString(), area, commitment: commitment.trim(), steps: steps.trim(), deadline, done: false, date: new Date().toISOString() }, ...prev]);
    setCommitment(''); setSteps(''); setDeadline('');
  };

  const toggleDone = (id: string) => {
    setEntries(prev => prev.map(e => e.id === id ? { ...e, done: !e.done } : e));
  };

  const addHabit = () => {
    if (!newHabit.trim()) return;
    setHabits(prev => [...prev, { id: Date.now().toString(), name: newHabit.trim(), dates: [] }]);
    setNewHabit('');
  };

  const toggleHabitToday = (habitId: string) => {
    const today = new Date().toDateString();
    setHabits(prev => prev.map(h => {
      if (h.id !== habitId) return h;
      return { ...h, dates: h.dates.includes(today) ? h.dates.filter(d => d !== today) : [...h.dates, today] };
    }));
  };

  const getWeekDays = () => {
    const days = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(); d.setDate(d.getDate() - i);
      days.push(d);
    }
    return days;
  };

  const getStreak = (habit: HabitEntry) => {
    let streak = 0;
    const today = new Date();
    for (let i = 0; i < 365; i++) {
      const d = new Date(today); d.setDate(d.getDate() - i);
      if (habit.dates.includes(d.toDateString())) streak++;
      else if (i > 0) break; // allow today to be unchecked
    }
    return streak;
  };

  const doneCount = entries.filter(e => e.done).length;
  const weekDays = getWeekDays();
  const dayNames = isRTL ? ['أحد','إثن','ثلا','أرب','خمي','جمع','سبت'] : ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];

  const principles = isRTL ? [
    '🎯 أنا المسؤول الأول عن حياتي وقراراتي',
    '🌱 كل يوم فرصة جديدة للنمو والتطور',
    '💎 التغيير يبدأ من الداخل',
    '🦁 الشجاعة ليست غياب الخوف بل مواجهته',
    '⭐ أعترف بأخطائي وأتعلم منها',
    '🔥 لا ألوم الآخرين، بل أبحث عن الحلول',
  ] : [
    '🎯 I am the first responsible for my life and decisions',
    '🌱 Every day is a new opportunity for growth',
    '💎 Change starts from within',
    '🦁 Courage is not the absence of fear but facing it',
    '⭐ I acknowledge my mistakes and learn from them',
    '🔥 I don\'t blame others, I look for solutions',
  ];

  return (
    <div style={{ paddingTop: '20px', direction: isRTL ? 'rtl' : 'ltr' }}>
      <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#6366f1', fontSize: '1rem', cursor: 'pointer', marginBottom: '15px' }}>
        <i className={`fas fa-arrow-${isRTL ? 'right' : 'left'}`}></i> {isRTL ? 'الرئيسية' : 'Home'}
      </button>

      <div style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6)', borderRadius: '20px', padding: '25px', color: 'white', textAlign: 'center', marginBottom: '20px' }}>
        <div style={{ fontSize: '2.5rem', marginBottom: '10px' }}>🦁🎯</div>
        <h2 style={{ fontSize: '1.3rem', fontWeight: 700, margin: '0 0 8px' }}>{isRTL ? 'تحمّل المسؤولية' : 'Self-Responsibility'}</h2>
        <p style={{ fontSize: '0.85rem', opacity: 0.9, margin: 0 }}>{isRTL ? 'كن مسؤولاً عن نفسك وطوّرها نحو الأفضل' : 'Take charge of yourself & grow towards the better'}</p>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: '6px', marginBottom: '15px' }}>
        <button onClick={() => setShowHabits(false)} style={{ flex: 1, padding: '10px', border: 'none', borderRadius: '12px', cursor: 'pointer', fontWeight: 600, fontSize: '0.85rem', background: !showHabits ? '#6366f1' : '#f1f5f9', color: !showHabits ? 'white' : '#64748b' }}>
          📋 {isRTL ? 'التزامات' : 'Commitments'}
        </button>
        <button onClick={() => setShowHabits(true)} style={{ flex: 1, padding: '10px', border: 'none', borderRadius: '12px', cursor: 'pointer', fontWeight: 600, fontSize: '0.85rem', background: showHabits ? '#6366f1' : '#f1f5f9', color: showHabits ? 'white' : '#64748b' }}>
          🔄 {isRTL ? 'تعقب العادات' : 'Habit Tracker'}
        </button>
      </div>

      {showHabits ? (
        <>
          {/* Add habit */}
          <div style={{ display: 'flex', gap: '8px', marginBottom: '15px' }}>
            <input value={newHabit} onChange={e => setNewHabit(e.target.value)} onKeyDown={e => e.key === 'Enter' && addHabit()}
              placeholder={isRTL ? 'أضف عادة جديدة...' : 'Add new habit...'}
              style={{ flex: 1, padding: '10px 14px', border: '2px solid #ede9fe', borderRadius: '12px', fontSize: '0.85rem', boxSizing: 'border-box' }} />
            <button onClick={addHabit} style={{ background: '#6366f1', color: 'white', border: 'none', borderRadius: '12px', padding: '10px 16px', fontWeight: 600, cursor: 'pointer', flexShrink: 0 }}>+</button>
          </div>

          {habits.length === 0 && <p style={{ textAlign: 'center', color: '#8898aa' }}>{isRTL ? 'أضف عادات لتتبعها يومياً' : 'Add habits to track daily'}</p>}

          {habits.map(habit => {
            const streak = getStreak(habit);
            const today = new Date().toDateString();
            const doneToday = habit.dates.includes(today);
            return (
              <div key={habit.id} style={{ background: 'white', borderRadius: '16px', padding: '15px', marginBottom: '12px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
                  <span style={{ fontWeight: 600, color: '#32325d', fontSize: '0.95rem' }}>{habit.name}</span>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span style={{ fontSize: '0.75rem', color: '#f59e0b', fontWeight: 700 }}>🔥 {streak}</span>
                    <button onClick={() => toggleHabitToday(habit.id)} style={{
                      width: 32, height: 32, borderRadius: '50%', border: 'none', cursor: 'pointer',
                      background: doneToday ? '#2DCE89' : '#e5e7eb', color: 'white', fontSize: '1rem',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                    }}>
                      {doneToday ? '✓' : ''}
                    </button>
                  </div>
                </div>
                {/* Weekly chart */}
                <div style={{ display: 'flex', gap: '4px', justifyContent: 'space-between' }}>
                  {weekDays.map((d, i) => {
                    const done = habit.dates.includes(d.toDateString());
                    const isToday = d.toDateString() === today;
                    return (
                      <div key={i} style={{ textAlign: 'center', flex: 1 }}>
                        <div style={{ fontSize: '0.6rem', color: '#8898aa', marginBottom: '4px' }}>{dayNames[d.getDay()]}</div>
                        <div style={{
                          width: '100%', height: '24px', borderRadius: '6px',
                          background: done ? '#2DCE89' : isToday ? '#fef3c7' : '#f1f5f9',
                          display: 'flex', alignItems: 'center', justifyContent: 'center',
                          fontSize: '0.7rem', color: done ? 'white' : '#aaa',
                          border: isToday ? '2px solid #f59e0b' : 'none',
                        }}>
                          {done ? '✓' : d.getDate()}
                        </div>
                      </div>
                    );
                  })}
                </div>
                <div style={{ marginTop: '8px', fontSize: '0.75rem', color: '#8898aa', textAlign: 'center' }}>
                  {isRTL ? `${habit.dates.length} مرة إجمالاً` : `${habit.dates.length} total completions`}
                </div>
              </div>
            );
          })}
        </>
      ) : (
        <>
          {/* Principles */}
          <div style={{ background: 'white', borderRadius: '16px', padding: '20px', marginBottom: '15px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)' }}>
            <h4 style={{ color: '#6366f1', marginBottom: '15px' }}>📜 {isRTL ? 'مبادئ المسؤولية' : 'Responsibility Principles'}</h4>
            {principles.map((p, i) => (
              <div key={i} style={{ padding: '10px', borderBottom: i < principles.length - 1 ? '1px solid #f0f0f0' : 'none', fontSize: '0.9rem', color: '#32325d', lineHeight: 1.6 }}>
                {p}
              </div>
            ))}
          </div>

          {/* Progress */}
          <div style={{ background: 'linear-gradient(135deg, #ede9fe, #e0e7ff)', borderRadius: '16px', padding: '15px', marginBottom: '15px', display: 'flex', justifyContent: 'space-around', textAlign: 'center' }}>
            <div><div style={{ fontSize: '1.5rem', fontWeight: 700, color: '#6366f1' }}>{entries.length}</div><div style={{ fontSize: '0.7rem', color: '#8898aa' }}>{isRTL ? 'التزامات' : 'Commitments'}</div></div>
            <div><div style={{ fontSize: '1.5rem', fontWeight: 700, color: '#2DCE89' }}>{doneCount}</div><div style={{ fontSize: '0.7rem', color: '#8898aa' }}>{isRTL ? 'منجزة' : 'Completed'}</div></div>
            <div><div style={{ fontSize: '1.5rem', fontWeight: 700, color: '#f59e0b' }}>{entries.length - doneCount}</div><div style={{ fontSize: '0.7rem', color: '#8898aa' }}>{isRTL ? 'جارية' : 'Ongoing'}</div></div>
          </div>

          {/* New commitment */}
          <div style={{ background: 'white', borderRadius: '16px', padding: '20px', marginBottom: '15px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)' }}>
            <h4 style={{ color: '#6366f1', marginBottom: '15px' }}>✍️ {isRTL ? 'التزام جديد' : 'New Commitment'}</h4>
            <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', marginBottom: '15px' }}>
              {areas.map(a => (
                <button key={a.id} onClick={() => setArea(a.id)} style={{
                  padding: '8px 12px', borderRadius: '20px', border: 'none', cursor: 'pointer',
                  background: area === a.id ? '#6366f1' : '#f7f8fa',
                  color: area === a.id ? 'white' : '#32325d', fontSize: '0.75rem', fontWeight: 600
                }}>{a.icon} {a.label}</button>
              ))}
            </div>
            <input type="text" value={commitment} onChange={e => setCommitment(e.target.value)}
              placeholder={isRTL ? 'ماذا ستلتزم به؟' : 'What will you commit to?'}
              style={{ width: '100%', padding: '12px', border: '2px solid #ede9fe', borderRadius: '12px', marginBottom: '10px', fontSize: '0.95rem', boxSizing: 'border-box' }} />
            <textarea value={steps} onChange={e => setSteps(e.target.value)}
              placeholder={isRTL ? 'خطوات التنفيذ (اختياري)' : 'Steps to achieve (optional)'}
              style={{ width: '100%', padding: '12px', border: '2px solid #ede9fe', borderRadius: '12px', marginBottom: '10px', fontSize: '0.9rem', minHeight: '80px', resize: 'vertical', boxSizing: 'border-box' }} />
            <input type="date" value={deadline} onChange={e => setDeadline(e.target.value)}
              style={{ width: '100%', padding: '10px', border: '2px solid #ede9fe', borderRadius: '12px', marginBottom: '15px', boxSizing: 'border-box' }} />
            <button onClick={save} style={{ width: '100%', background: 'linear-gradient(135deg, #6366f1, #8b5cf6)', color: 'white', border: 'none', borderRadius: '12px', padding: '14px', fontWeight: 600, cursor: 'pointer' }}>
              {isRTL ? '🎯 سجّل التزامي' : '🎯 Log Commitment'}
            </button>
          </div>

          <h4 style={{ color: '#32325d', marginBottom: '10px' }}>📋 {isRTL ? 'التزاماتي' : 'My Commitments'}</h4>
          {entries.length === 0 && <p style={{ textAlign: 'center', color: '#8898aa' }}>{isRTL ? 'ابدأ رحلة المسؤولية!' : 'Start your responsibility journey!'}</p>}
          {entries.slice(0, 15).map(e => (
            <div key={e.id} onClick={() => toggleDone(e.id)} style={{ background: 'white', borderRadius: '12px', padding: '15px', marginBottom: '10px', borderLeft: `4px solid ${e.done ? '#2DCE89' : '#6366f1'}`, cursor: 'pointer', opacity: e.done ? 0.7 : 1 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '5px' }}>
                <span style={{ fontSize: '0.75rem', background: '#ede9fe', color: '#6366f1', padding: '2px 8px', borderRadius: '10px' }}>
                  {areas.find(a => a.id === e.area)?.icon} {areas.find(a => a.id === e.area)?.label}
                </span>
                <span style={{ fontSize: '1.2rem' }}>{e.done ? '✅' : '⭕'}</span>
              </div>
              <p style={{ color: '#32325d', margin: '5px 0', fontWeight: 500, textDecoration: e.done ? 'line-through' : 'none' }}>{e.commitment}</p>
              {e.steps && <p style={{ color: '#8898aa', margin: 0, fontSize: '0.8rem' }}>{e.steps}</p>}
              {e.deadline && <span style={{ fontSize: '0.7rem', color: '#aaa' }}>📅 {new Date(e.deadline).toLocaleDateString()}</span>}
            </div>
          ))}
        </>
      )}
      <InlineAIChat context="growth" lang={lang} />
    </div>
  );
}
