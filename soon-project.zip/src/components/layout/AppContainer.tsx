import React, { useState, useRef, useEffect } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { useGlobalMusic } from '../../hooks/useGlobalMusic';
import { useAppTheme, getThemeStyles } from '../home/ThemeSwitcher';
import type { Lang } from '../../i18n/translations';

type Page = 'home' | 'journal' | 'dreams' | 'relaxation' | 'meditation' | 'nature' | 'music' | 'piano' | 'affirmations-relax' | 'walk' | 'food' | 'reflection' | 'articles' | 'pet' | 'smile-challenge' | 'honesty' | 'resilience' | 'parent-child' | 'positive-self' | 'life-story' | 'attention-games' | 'special-needs' | 'earth-care' | 'community' | 'spirituality' | 'family' | 'experiences' | 'love-page' | 'movies' | 'hobbies' | 'goals' | 'donate' | 'learning' | 'women-wellness' | 'finance' | 'anxiety' | 'imagination' | 'kind-words' | 'anger' | 'community-dev' | 'self-responsibility' | 'tasks' | 'mindfulness' | 'detox-challenge' | 'gratitude-thanks' | 'holiday-greetings' | 'groups' | 'decision-ai' | 'crying' | 'what-not-to-do' | 'future-self' | 'fasting-tracker' | 'traditional-cooking' | 'forgiveness' | 'unconscious-mind' | 'myths' | 'sad-knowledge' | 'primordial-witness' | 'psyche-wars';

interface AppContainerProps {
  children: React.ReactNode;
  currentPage: Page;
  onNavigate: (page: Page) => void;
  hasUnreadAI?: boolean;
}

const langLabels: Record<Lang, string> = { en: 'EN', ar: 'عر', es: 'ES', fr: 'FR' };
const langOrder: Lang[] = ['en', 'ar', 'es', 'fr'];
const mainNavPages = ['home', 'journal', 'dreams', 'relaxation', 'pet', 'articles'];

export default function AppContainer({ children, currentPage, onNavigate, hasUnreadAI }: AppContainerProps) {
  const { t, lang, setLang } = useLanguage();
  const music = useGlobalMusic();
  const { theme } = useAppTheme();
  const themeStyles = getThemeStyles(theme);
  const [userName, setUserName] = useLocalStorage<string>('soon-user-name', '');
  const [userPhoto, setUserPhoto] = useLocalStorage<string>('soon-user-photo', '');
  const [editingName, setEditingName] = useState(false);
  const [nameInput, setNameInput] = useState(userName);
  const photoInputRef = useRef<HTMLInputElement>(null);
  const mainRef = useRef<HTMLElement>(null);
  const [headerCollapsed, setHeaderCollapsed] = useState(false);

  // Always collapse header after initial render - stays collapsed permanently
  useEffect(() => {
    const timer = setTimeout(() => setHeaderCollapsed(true), 1500);
    return () => clearTimeout(timer);
  }, []);
  
  const saveName = () => {
    setUserName(nameInput.trim());
    setEditingName(false);
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const result = ev.target?.result as string;
      if (result) setUserPhoto(result);
    };
    reader.readAsDataURL(file);
  };

  const navItems = [
    { id: 'home' as Page, icon: 'fas fa-home', labelKey: 'nav.home' },
    { id: 'journal' as Page, icon: 'fas fa-book', labelKey: 'nav.journal' },
    { id: 'dreams' as Page, icon: 'fas fa-moon', labelKey: 'nav.dreams' },
    { id: 'relaxation' as Page, icon: 'fas fa-spa', labelKey: 'nav.relax' },
    { id: 'pet' as Page, icon: 'fas fa-paw', labelKey: 'nav.pet' },
    { id: 'articles' as Page, icon: 'fas fa-newspaper', labelKey: 'nav.insights' },
  ];

  const activeNav = mainNavPages.includes(currentPage) ? currentPage :
    (['meditation', 'nature', 'music', 'piano', 'affirmations-relax', 'walk', 'food', 'movies', 'mindfulness'].includes(currentPage)) ? 'relaxation' : currentPage;

  const nameLabels: Record<string, string> = {
    en: 'Enter your name...', ar: 'أدخل اسمك...', es: 'Tu nombre...', fr: 'Votre nom...',
  };

  return (
    <div className="soon-app-wrapper" style={{ background: themeStyles.appBg, minHeight: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center', padding: '20px' }} role="application" aria-label="Soon - Mental Wellness App" lang={lang}>
      <div className="soon-container" style={{ backgroundColor: themeStyles.containerBg }}>
        <header role="banner" aria-label="Soon App Header" style={{
          background: themeStyles.headerGradient, color: 'white',
          padding: headerCollapsed ? '8px 20px' : '30px 20px 20px',
          borderBottomLeftRadius: headerCollapsed ? '0' : '24px', borderBottomRightRadius: headerCollapsed ? '0' : '24px',
          position: 'sticky', top: 0, textAlign: 'center',
          boxShadow: '0 4px 15px rgba(0,0,0,0.1)', zIndex: 20, flexShrink: 0,
          transition: 'padding 0.3s ease, max-height 0.3s ease, border-radius 0.3s ease',
          overflow: 'hidden',
          maxHeight: headerCollapsed ? '50px' : '400px',
        }}>
          <div style={{ position: 'absolute', top: headerCollapsed ? '8px' : '10px', left: '10px', display: 'flex', gap: '8px', transition: 'top 0.3s ease' }}>
            <button onClick={() => onNavigate('relaxation')} aria-label={t('nav.relax')} style={{ background: 'rgba(255,255,255,0.2)', border: 'none', borderRadius: '50%', width: 32, height: 32, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontSize: '1rem', cursor: 'pointer' }}>
              <i className="fas fa-tree" aria-hidden="true"></i>
            </button>
            {music.currentTrackName && (
              <button onClick={music.toggleMute} aria-label={music.isMuted ? 'Unmute' : 'Mute'} style={{ background: music.isMuted ? 'white' : 'rgba(255,255,255,0.2)', border: 'none', borderRadius: '50%', width: 32, height: 32, display: 'flex', alignItems: 'center', justifyContent: 'center', color: music.isMuted ? '#2DCE89' : 'white', fontSize: '1rem', cursor: 'pointer', transition: 'all 0.3s ease' }}>
                <i className={`fas fa-volume-${music.isMuted ? 'mute' : 'up'}`} aria-hidden="true"></i>
              </button>
            )}
          </div>

          <div style={{ position: 'absolute', top: headerCollapsed ? '8px' : '10px', right: '10px', display: 'flex', gap: '4px', transition: 'top 0.3s ease' }}>
            {langOrder.map(l => (
              <button key={l} onClick={() => setLang(l)} aria-label={`Switch to ${l}`} style={{ background: lang === l ? 'white' : 'rgba(255,255,255,0.2)', color: lang === l ? '#1a9f6e' : 'white', border: 'none', borderRadius: '8px', padding: '4px 8px', fontSize: '0.7rem', fontWeight: 700, cursor: 'pointer', transition: 'all 0.3s ease', fontFamily: 'Poppins, sans-serif' }}>
                {langLabels[l]}
              </button>
            ))}
          </div>

          {/* Collapsed mini header */}
          {headerCollapsed && (
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', height: '34px' }}>
              <img src={userPhoto || '/soon-logo.webp'} alt="Soon" style={{ width: 28, height: 28, borderRadius: '50%', objectFit: 'cover' }} />
              <span style={{ fontWeight: 700, fontSize: '1rem' }}>{t('app.name')}</span>
              {userName && <span style={{ opacity: 0.8, fontSize: '0.75rem' }}>• {userName}</span>}
            </div>
          )}

          {/* Full header content */}
          <div style={{ opacity: headerCollapsed ? 0 : 1, transition: 'opacity 0.3s ease', pointerEvents: headerCollapsed ? 'none' : 'auto' }}>
            <div style={{ marginBottom: '10px' }}>
              {editingName || !userName ? (
                <div style={{ display: 'flex', justifyContent: 'center', gap: '6px', alignItems: 'center' }}>
                  <input type="text" value={nameInput} onChange={e => setNameInput(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && saveName()}
                    placeholder={nameLabels[lang] || nameLabels.en}
                    aria-label="Your name"
                    style={{ background: 'rgba(255,255,255,0.25)', border: '1px solid rgba(255,255,255,0.4)', borderRadius: '20px', padding: '6px 14px', color: 'white', fontFamily: 'Poppins, sans-serif', fontSize: '0.85rem', textAlign: 'center', outline: 'none', width: '160px' } as any} />
                  <button onClick={saveName} aria-label="Save name" style={{ background: 'white', border: 'none', borderRadius: '50%', width: 28, height: 28, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#2DCE89', cursor: 'pointer', fontSize: '0.8rem' }}>
                    <i className="fas fa-check" aria-hidden="true"></i>
                  </button>
                </div>
              ) : (
                <button onClick={() => { setNameInput(userName); setEditingName(true); }} style={{ background: 'rgba(255,255,255,0.15)', border: '1px solid rgba(255,255,255,0.3)', borderRadius: '20px', padding: '4px 16px', color: 'white', cursor: 'pointer', fontFamily: 'Poppins, sans-serif', fontSize: '0.85rem', fontWeight: 600 }}>
                  👋 {lang === 'ar' ? `مرحباً ${userName}` : `Hi ${userName}`}
                </button>
              )}
            </div>

            <div style={{ marginBottom: '8px' }}>
              <p style={{ fontSize: '0.75rem', fontWeight: 600, margin: 0, opacity: 0.95 }}>{t('app.motto')}</p>
            </div>

            <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '10px', position: 'relative' }}>
              <input type="file" accept="image/*" ref={photoInputRef} onChange={handlePhotoUpload} style={{ display: 'none' }} />
              <div onClick={() => photoInputRef.current?.click()} style={{ cursor: 'pointer', position: 'relative' }}>
                <img src={userPhoto || '/soon-logo.webp'} alt="Soon Logo" style={{ width: 80, height: 80, borderRadius: '50%', border: '3px solid white', objectFit: 'cover', boxShadow: '0 4px 15px rgba(0,0,0,0.2)' }} />
                <div style={{ position: 'absolute', bottom: 0, right: 0, background: 'white', borderRadius: '50%', width: 24, height: 24, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 2px 8px rgba(0,0,0,0.2)' }}>
                  <i className="fas fa-camera" style={{ fontSize: '0.6rem', color: '#2DCE89' }}></i>
                </div>
              </div>
            </div>
            <h1 style={{ margin: '10px 0 0', fontSize: '1.5rem', fontWeight: 700 }}>{t('app.name')}</h1>
            <p style={{ margin: 0, fontSize: '1rem', opacity: 0.9 }}>{t('app.tagline')}</p>
            <p style={{ margin: '5px 0 0', fontSize: '0.6rem', opacity: 0.85 }}>{t('app.reviewed_by')}</p>
          </div>
        </header>

        {/* Global Mini Music Player */}
        {music.currentTrackName && currentPage !== 'music' && (
          <div onClick={() => onNavigate('music')} style={{
            background: 'linear-gradient(135deg, #8965e0, #2DCE89)', color: 'white',
            padding: '8px 16px', display: 'flex', alignItems: 'center', gap: '10px',
            cursor: 'pointer', zIndex: 10, flexShrink: 0,
          }}>
            <i className={`fas fa-${music.isPlaying ? 'pause' : 'play'}`} style={{ fontSize: '0.9rem' }}></i>
            <div style={{ flex: 1, overflow: 'hidden', whiteSpace: 'nowrap', textOverflow: 'ellipsis', fontSize: '0.8rem', fontWeight: 600 }}>
              🎵 {music.currentTrackName}
            </div>
            <button onClick={(e) => { e.stopPropagation(); music.stop(); }} style={{ background: 'rgba(255,255,255,0.2)', border: 'none', color: 'white', borderRadius: '50%', width: 24, height: 24, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', fontSize: '0.7rem', flexShrink: 0 }}>
              <i className="fas fa-times"></i>
            </button>
          </div>
        )}

        <main ref={mainRef} className="soon-main" role="main" aria-label="Main Content" style={{ flexGrow: 1, overflowY: 'auto', overflowX: 'hidden', padding: '0 20px', paddingBottom: 'calc(20px + 70px)' }}>
          {children}
        </main>

        <nav role="navigation" aria-label="Main Navigation" style={{ display: 'flex', justifyContent: 'space-around', alignItems: 'center', height: '70px', backgroundColor: themeStyles.navBg, borderTop: `1px solid ${themeStyles.navBorder}`, position: 'absolute', bottom: 0, left: 0, right: 0, boxShadow: '0 -5px 20px rgba(0,0,0,0.05)', zIndex: 100 }}>
          {navItems.map(item => (
            <button key={item.id} onClick={() => onNavigate(item.id)} aria-label={t(item.labelKey)} aria-current={activeNav === item.id ? 'page' : undefined} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', flex: 1, background: 'none', border: 'none', color: activeNav === item.id ? themeStyles.accent : themeStyles.textSecondary, fontSize: '0.75rem', padding: '8px 0', cursor: 'pointer', transition: 'all 0.3s ease', fontFamily: 'Poppins, sans-serif', position: 'relative' }}>
              <i className={item.icon} aria-hidden="true" style={{ fontSize: '1.4rem', marginBottom: '4px', transform: activeNav === item.id ? 'scale(1.2)' : 'scale(1)', transition: 'transform 0.3s ease' }}></i>
              {item.id === 'home' && hasUnreadAI && currentPage !== 'home' && (
                <div style={{ position: 'absolute', top: '4px', right: '50%', marginRight: '-18px', width: '10px', height: '10px', background: '#ef4444', borderRadius: '50%', border: '2px solid white', animation: 'pulse 1.5s infinite' }} />
              )}
              <span>{t(item.labelKey)}</span>
            </button>
          ))}
        </nav>
      </div>
    </div>
  );
}

export type { Page };
