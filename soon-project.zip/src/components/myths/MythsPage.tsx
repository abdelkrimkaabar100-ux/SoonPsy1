import { useState } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { supabase } from '@/integrations/supabase/client';
import InlineAIChat from '../shared/InlineAIChat';

interface MythsPageProps { onBack: () => void; }

export default function MythsPage({ onBack }: MythsPageProps) {
  const { lang } = useLanguage();
  const isAr = lang === 'ar';
  const [problem, setProblem] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [tab, setTab] = useState<'human' | 'animal'>('human');

  const labels = {
    en: { title: '🏛️ Myths of Humanity', subtitle: 'Your emotions echo through ancient stories', input: 'Describe your emotional struggle...', examples: 'Examples: Fear of rejection, feeling misunderstood, abandonment, guilt, rage', analyze: 'Find My Myth', back: 'Back', story: 'The Story', feelings: 'What They Felt', coping: 'How They Coped', connection: 'Your Connection', discuss: 'Discuss with AI', human: '🏛️ Human Myths', animal: '🐾 Animal Myths', animalInput: 'Describe your pet\'s behavior or your worry about them...', animalExamples: 'Examples: My cat hides when stressed, my dog fears strangers, separation anxiety', ethicsNote: '⚠️ Ethics: This feature uses mythology as a reflective tool, not as clinical diagnosis. Stories are simplified for therapeutic metaphor. If you are in crisis, please seek professional help.' },
    ar: { title: '🏛️ أساطير الإنسانية', subtitle: 'مشاعرك تتردد في قصص قديمة', input: 'صف صراعك العاطفي...', examples: 'أمثلة: الخوف من الرفض، الشعور بعدم الفهم، الهجر، الذنب، الغضب', analyze: 'اكتشف أسطورتي', back: 'رجوع', story: 'القصة', feelings: 'ما شعروا به', coping: 'كيف تعاملوا', connection: 'صلتك', discuss: 'ناقش مع الذكاء الاصطناعي', human: '🏛️ أساطير بشرية', animal: '🐾 أساطير حيوانية', animalInput: 'صف سلوك حيوانك أو قلقك بشأنه...', animalExamples: 'أمثلة: قطتي تختبئ عند التوتر، كلبي يخاف من الغرباء، قلق الانفصال', ethicsNote: '⚠️ ملاحظة أخلاقية: هذه الميزة تستخدم الأساطير كأداة تأملية وليست تشخيصاً سريرياً. القصص مبسطة للاستعارة العلاجية. إذا كنت في أزمة، يرجى طلب مساعدة متخصصة.' },
    es: { title: '🏛️ Mitos de la Humanidad', subtitle: 'Tus emociones resuenan en historias antiguas', input: 'Describe tu lucha emocional...', examples: 'Ejemplos: Miedo al rechazo, sentirse incomprendido', analyze: 'Encontrar Mi Mito', back: 'Volver', story: 'La Historia', feelings: 'Lo Que Sintieron', coping: 'Cómo Lo Afrontaron', connection: 'Tu Conexión', discuss: 'Discutir con IA', human: '🏛️ Mitos Humanos', animal: '🐾 Mitos Animales', animalInput: 'Describe el comportamiento de tu mascota...', animalExamples: 'Ejemplos: Mi gato se esconde, mi perro teme a extraños', ethicsNote: '⚠️ Ética: Esta función usa mitología como herramienta reflexiva, no como diagnóstico clínico.' },
    fr: { title: '🏛️ Mythes de l\'Humanité', subtitle: 'Vos émotions résonnent dans les histoires anciennes', input: 'Décrivez votre lutte émotionnelle...', examples: 'Exemples: Peur du rejet, sentiment d\'incompréhension', analyze: 'Trouver Mon Mythe', back: 'Retour', story: 'L\'Histoire', feelings: 'Ce Qu\'ils Ont Ressenti', coping: 'Comment Ils Ont Géré', connection: 'Votre Connexion', discuss: 'Discuter avec l\'IA', human: '🏛️ Mythes Humains', animal: '🐾 Mythes Animaux', animalInput: 'Décrivez le comportement de votre animal...', animalExamples: 'Exemples: Mon chat se cache, mon chien craint les étrangers', ethicsNote: '⚠️ Éthique: Cette fonction utilise la mythologie comme outil réflexif, pas comme diagnostic clinique.' },
  };
  const l = (labels as any)[lang] || labels.en;

  const analyzeMyth = async () => {
    if (!problem.trim() || loading) return;
    setLoading(true);
    setResult(null);
    try {
      const isAnimal = tab === 'animal';
      // Variation seed prevents the AI from always returning the same character.
      const seed = Math.random().toString(36).slice(2, 8);
      const humanPool = 'Greek (Sisyphus, Persephone, Medea, Icarus, Orpheus, Cassandra, Narcissus, Achilles), Egyptian (Isis, Osiris, Set, Horus), Norse (Loki, Freya, Odin, Baldr), Mesopotamian (Gilgamesh, Inanna, Ereshkigal), Hindu (Karna, Arjuna, Sita, Shiva), Japanese (Izanami, Amaterasu, Susanoo), African (Anansi, Mawu), Native American (Coyote, White Buffalo Woman), Celtic (Cú Chulainn, Rhiannon), Slavic (Baba Yaga), Arabian (Antarah, Layla)';
      const animalPool = 'Anubis (jackal), Bastet (cat), Sekhmet (lioness), Horus (falcon), Phoenix, Cerberus, Fenrir (wolf), Sleipnir (horse), Garuda (eagle), Kitsune (fox), Raven (trickster), Coyote, Quetzalcoatl (serpent), Ouroboros, Pegasus, Griffin, Thunderbird';

      const systemPrompt = isAr
        ? `أنت عالم أساطير عالمي تربط المشاعر بشخصيات أسطورية من ثقافات متعددة.
${isAnimal ? `اختر من أساطير الحيوانات: ${animalPool}.` : `اختر من أساطير متنوعة عبر الحضارات: ${humanPool}.`}
قواعد صارمة:
- حلّل بعمق المشاعر المحددة التي ذكرها المستخدم ثم اختر شخصية تطابق *جوهر* تجربته (وليس مجرد كلمة عامة كالخوف).
- نوّع اختياراتك؛ لا تستخدم نفس الشخصية لكل مشاعر متشابهة. تجنّب الشخصيات الشائعة جداً إن أمكن.
- لا تستخدم رموز ماركداون أبداً.
معرّف التنويع: ${seed}
أجب بهذا التنسيق فقط:
[الشخصية]: اسم الشخصية (والثقافة بين قوسين)
[القصة]: قصة مختصرة (3-4 جمل)
[المشاعر]: ما شعرت به الشخصية
[التعامل]: كيف تعاملت مع مشاعرها
[الربط]: كيف ترتبط قصتها تحديداً بمشاعر المستخدم`
        : `You are a world mythology expert connecting emotions to mythological figures across cultures.
${isAnimal ? `Choose from animal myths: ${animalPool}.` : `Choose across diverse traditions: ${humanPool}.`}
Strict rules:
- Deeply analyze the *specific* nuance the user described, then pick a character whose core experience matches it (not just a generic keyword like "fear").
- Vary your choices; never give the same character for every similar feeling. Avoid the most obvious figure when a less common one fits better.
- Never use markdown symbols.
Variation id: ${seed}
Reply in exactly this format:
[Character]: Character name (culture in parentheses)
[Story]: Brief story (3-4 sentences)
[Feelings]: What they felt
[Coping]: How they dealt with it
[Connection]: How their story specifically connects to the user`;

      const { data, error } = await supabase.functions.invoke('groq-chat', {
        body: {
          messages: [{ role: 'user', content: problem }],
          systemPrompt
        }
      });
      if (error) throw error;

      const content = data.content || '';
      const parse = (tag: string) => {
        const regex = new RegExp(`\\[${tag}\\]:\\s*(.+?)(?=\\[|$)`, 's');
        return regex.exec(content)?.[1]?.trim() || '';
      };

      setResult({
        character: parse(isAr ? 'الشخصية' : 'Character'),
        story: parse(isAr ? 'القصة' : 'Story'),
        feelings: parse(isAr ? 'المشاعر' : 'Feelings'),
        coping: parse(isAr ? 'التعامل' : 'Coping'),
        connection: parse(isAr ? 'الربط' : 'Connection'),
        raw: content,
      });
    } catch {
      setResult({ error: true });
    } finally {
      setLoading(false);
    }
  };


  const sectionStyle = (color: string, bg: string) => ({
    borderRadius: '14px', padding: '14px', marginBottom: '10px',
    background: bg, border: `2px solid ${color}`,
  });

  return (
    <div style={{ paddingTop: '10px', direction: isAr ? 'rtl' : 'ltr' }}>
      <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#8b5cf6', fontSize: '1rem', cursor: 'pointer', marginBottom: '12px', fontFamily: 'Poppins, sans-serif' }}>
        <i className={`fas fa-arrow-${isAr ? 'right' : 'left'}`}></i> {l.back}
      </button>

      <div style={{ textAlign: 'center', marginBottom: '20px', background: 'linear-gradient(135deg, #1a1a2e, #16213e, #0f3460)', borderRadius: '20px', padding: '25px 15px', color: 'white' }}>
        <div style={{ fontSize: '2.5rem', marginBottom: '8px' }}>🏛️</div>
        <h2 style={{ margin: '0 0 6px', fontSize: '1.4rem', fontWeight: 800 }}>{l.title}</h2>
        <p style={{ margin: 0, fontSize: '0.85rem', opacity: 0.85 }}>{l.subtitle}</p>
      </div>

      {/* Tab: Human vs Animal */}
      <div style={{ display: 'flex', gap: '8px', marginBottom: '15px' }}>
        {(['human', 'animal'] as const).map(t => (
          <button key={t} onClick={() => setTab(t)} style={{
            flex: 1, padding: '10px', borderRadius: '12px', border: 'none', cursor: 'pointer', fontWeight: 700,
            background: tab === t ? 'linear-gradient(135deg, #6d28d9, #8b5cf6)' : '#f3f4f6',
            color: tab === t ? 'white' : '#6b7280', fontSize: '0.85rem', fontFamily: 'Poppins, sans-serif',
          }}>
            {l[t]}
          </button>
        ))}
      </div>

      {/* Input */}
      <div style={{ background: 'white', borderRadius: '16px', padding: '18px', marginBottom: '15px', boxShadow: '0 6px 25px rgba(0,0,0,0.08)', border: '2px solid #e9d5ff' }}>
        <textarea value={problem} onChange={e => setProblem(e.target.value)} rows={3}
          placeholder={tab === 'animal' ? l.animalInput : l.input}
          style={{ width: '100%', border: '2px solid #ddd6fe', borderRadius: '12px', padding: '12px', fontFamily: 'Poppins, sans-serif', fontSize: '0.9rem', resize: 'none', boxSizing: 'border-box', direction: isAr ? 'rtl' : 'ltr' }} />
        <p style={{ color: '#a78bfa', fontSize: '0.72rem', margin: '6px 0 10px' }}>{tab === 'animal' ? l.animalExamples : l.examples}</p>
        <button onClick={analyzeMyth} disabled={!problem.trim() || loading} style={{
          width: '100%', padding: '14px', border: 'none', borderRadius: '14px', cursor: 'pointer', fontWeight: 700,
          background: problem.trim() ? 'linear-gradient(135deg, #1a1a2e, #6d28d9)' : '#d1d5db',
          color: 'white', fontSize: '0.95rem', fontFamily: 'Poppins, sans-serif',
        }}>
          {loading ? '⏳ ...' : `🔮 ${l.analyze}`}
        </button>
      </div>

      {/* Loading */}
      {loading && (
        <div style={{ textAlign: 'center', padding: '30px', background: 'linear-gradient(135deg, #1a1a2e, #0f3460)', borderRadius: '16px', color: 'white', marginBottom: '15px' }}>
          <div style={{ fontSize: '3rem', animation: 'pulse 2s infinite' }}>🏛️</div>
          <p style={{ fontSize: '0.9rem', opacity: 0.9 }}>{isAr ? 'جاري البحث في الأساطير القديمة...' : 'Searching through ancient myths...'}</p>
        </div>
      )}

      {/* Result */}
      {result && !result.error && (
        <div style={{ background: 'linear-gradient(135deg, #1a1a2e, #16213e)', borderRadius: '20px', padding: '20px', color: 'white', marginBottom: '15px', border: '2px solid #6d28d9' }}>
          <div style={{ textAlign: 'center', marginBottom: '15px' }}>
            <div style={{ fontSize: '2.5rem', marginBottom: '6px' }}>{tab === 'animal' ? '🐾' : '⚡'}</div>
            <h3 style={{ margin: 0, fontSize: '1.3rem', color: '#c4b5fd' }}>{result.character}</h3>
          </div>

          <div style={sectionStyle('#7c3aed', 'rgba(124,58,237,0.15)')}>
            <h4 style={{ color: '#c4b5fd', margin: '0 0 6px', fontSize: '0.85rem' }}>📜 {l.story}</h4>
            <p style={{ margin: 0, fontSize: '0.85rem', lineHeight: 1.7, color: '#e2e8f0' }}>{result.story}</p>
          </div>

          <div style={sectionStyle('#ec4899', 'rgba(236,72,153,0.12)')}>
            <h4 style={{ color: '#f9a8d4', margin: '0 0 6px', fontSize: '0.85rem' }}>💔 {l.feelings}</h4>
            <p style={{ margin: 0, fontSize: '0.85rem', lineHeight: 1.7, color: '#e2e8f0' }}>{result.feelings}</p>
          </div>

          <div style={sectionStyle('#10b981', 'rgba(16,185,129,0.12)')}>
            <h4 style={{ color: '#6ee7b7', margin: '0 0 6px', fontSize: '0.85rem' }}>🛡️ {l.coping}</h4>
            <p style={{ margin: 0, fontSize: '0.85rem', lineHeight: 1.7, color: '#e2e8f0' }}>{result.coping}</p>
          </div>

          <div style={sectionStyle('#f59e0b', 'rgba(245,158,11,0.12)')}>
            <h4 style={{ color: '#fcd34d', margin: '0 0 6px', fontSize: '0.85rem' }}>🔗 {l.connection}</h4>
            <p style={{ margin: 0, fontSize: '0.85rem', lineHeight: 1.7, color: '#e2e8f0' }}>{result.connection}</p>
          </div>
        </div>
      )}

      {result?.error && (
        <div style={{ textAlign: 'center', padding: '20px', color: '#ef4444' }}>
          {isAr ? '❌ حدث خطأ، حاول مرة أخرى' : '❌ An error occurred, try again'}
        </div>
      )}

      {/* Ethics note */}
      <div style={{ background: '#fffbeb', borderRadius: '12px', padding: '12px', marginBottom: '15px', border: '1px solid #fbbf24', fontSize: '0.75rem', color: '#92400e', lineHeight: 1.6 }}>
        {l.ethicsNote}
      </div>

      <InlineAIChat context={`myths-of-humanity ${tab}`} lang={lang} />
    </div>
  );
}
