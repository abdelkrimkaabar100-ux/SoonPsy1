import { useState } from 'react';
import InlineAIChat from '../shared/InlineAIChat';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';

type Tool = 'menu' | 'breathing' | 'emotions' | 'social' | 'routine' | 'sensory';

interface BreathingLog { date: string; duration: number; type: string }
interface EmotionLog { date: string; emotion: string; intensity: number; note: string }
interface RoutineStep { id: string; label: string; done: boolean }

export default function SpecialNeedsPage({ onBack }: { onBack: () => void }) {
  const { t, lang } = useLanguage();
  const [activeTool, setActiveTool] = useState<Tool>('menu');

  if (activeTool === 'breathing') return <BreathingExercise onBack={() => setActiveTool('menu')} />;
  if (activeTool === 'emotions') return <EmotionRecognition onBack={() => setActiveTool('menu')} />;
  if (activeTool === 'social') return <SocialStories onBack={() => setActiveTool('menu')} />;
  if (activeTool === 'routine') return <VisualRoutine onBack={() => setActiveTool('menu')} />;
  if (activeTool === 'sensory') return <SensoryCalm onBack={() => setActiveTool('menu')} />;

  const tools = [
    { id: 'breathing' as Tool, icon: '🫁', color: '#42a5f5', title: t('special.breathing_title'), desc: t('special.breathing_desc') },
    { id: 'emotions' as Tool, icon: '😊', color: '#66bb6a', title: t('special.emotions_title'), desc: t('special.emotions_desc') },
    { id: 'social' as Tool, icon: '🤝', color: '#ab47bc', title: t('special.social_title'), desc: t('special.social_desc') },
    { id: 'routine' as Tool, icon: '📋', color: '#ff7043', title: t('special.routine_title'), desc: t('special.routine_desc') },
    { id: 'sensory' as Tool, icon: '🌈', color: '#26c6da', title: t('special.sensory_title'), desc: t('special.sensory_desc') },
  ];

  return (
    <div style={{ padding: '10px 0' }}>
      <button onClick={onBack} style={{
        background: 'none', border: 'none', color: '#01579b', fontSize: '1rem',
        cursor: 'pointer', marginBottom: '15px', fontFamily: 'Poppins, sans-serif',
      }}>← {t('games.back')}</button>

      <div style={{
        background: 'linear-gradient(135deg, #e8f5e9, #c8e6c9)',
        borderRadius: '20px', padding: '25px', marginBottom: '20px', textAlign: 'center',
      }}>
        <div style={{ fontSize: '3rem', marginBottom: '10px' }}>💚</div>
        <h2 style={{ color: '#2e7d32', margin: '0 0 8px', fontSize: '1.4rem' }}>{t('special.title')}</h2>
        <p style={{ color: '#388e3c', fontSize: '0.9rem', margin: 0 }}>{t('special.subtitle')}</p>
      </div>

      <div style={{
        background: '#fff8e1', borderRadius: '12px', padding: '15px', marginBottom: '20px',
        fontSize: '0.85rem', color: '#f57f17', lineHeight: 1.6,
      }}>
        💡 {t('special.info')}
      </div>

      {tools.map(tool => (
        <div key={tool.id} onClick={() => setActiveTool(tool.id)} style={{
          background: 'white', borderRadius: '16px', padding: '20px',
          boxShadow: '0 4px 15px rgba(0,0,0,0.08)', marginBottom: '12px',
          cursor: 'pointer', borderLeft: `5px solid ${tool.color}`, transition: 'transform 0.2s',
        }}
        onMouseEnter={e => e.currentTarget.style.transform = 'translateY(-3px)'}
        onMouseLeave={e => e.currentTarget.style.transform = 'translateY(0)'}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
            <div style={{ fontSize: '2.2rem' }}>{tool.icon}</div>
            <div>
              <h3 style={{ margin: '0 0 4px', color: tool.color, fontSize: '1.05rem' }}>{tool.title}</h3>
              <p style={{ margin: 0, fontSize: '0.82rem', color: '#757575' }}>{tool.desc}</p>
            </div>
          </div>
        </div>
      ))}
      <InlineAIChat context="special-needs" lang={lang} />
    </div>
  );
}

// === Breathing Exercise (Box Breathing - evidence-based) ===
function BreathingExercise({ onBack }: { onBack: () => void }) {
  const { t } = useLanguage();
  const [phase, setPhase] = useState<'ready' | 'inhale' | 'hold1' | 'exhale' | 'hold2' | 'done'>('ready');
  const [cycles, setCycles] = useState(0);
  const [timer, setTimer] = useState(4);
  const [totalCycles, setTotalCycles] = useState(4);
  const [intervalId, setIntervalId] = useState<NodeJS.Timeout | null>(null);
  const [logs, setLogs] = useLocalStorage<BreathingLog[]>('soon-breathing-logs', []);

  const phaseColors: Record<string, string> = {
    inhale: '#42a5f5', hold1: '#7e57c2', exhale: '#66bb6a', hold2: '#ffb74d',
  };
  const phaseEmojis: Record<string, string> = {
    inhale: '🌬️', hold1: '⏸️', exhale: '💨', hold2: '⏸️',
  };

  const startBreathing = () => {
    setCycles(0);
    runPhase('inhale', 0);
  };

  const runPhase = (p: 'inhale' | 'hold1' | 'exhale' | 'hold2', cycleCount: number) => {
    setPhase(p);
    setTimer(4);
    if (intervalId) clearInterval(intervalId);
    const id = setInterval(() => {
      setTimer(prev => {
        if (prev <= 1) {
          clearInterval(id);
          const next = p === 'inhale' ? 'hold1' : p === 'hold1' ? 'exhale' : p === 'exhale' ? 'hold2' : null;
          if (next) {
            runPhase(next, cycleCount);
          } else {
            const newCount = cycleCount + 1;
            setCycles(newCount);
            if (newCount >= totalCycles) {
              setPhase('done');
              setLogs(prev => [...prev.slice(-29), { date: new Date().toISOString(), duration: totalCycles * 16, type: 'box' }]);
            } else {
              runPhase('inhale', newCount);
            }
          }
          return 4;
        }
        return prev - 1;
      });
    }, 1000);
    setIntervalId(id);
  };

  const stop = () => {
    if (intervalId) clearInterval(intervalId);
    setPhase('ready');
  };

  const circleSize = 180;
  const activePhase = phase !== 'ready' && phase !== 'done';

  return (
    <div style={{ padding: '10px 0' }}>
      <button onClick={() => { stop(); onBack(); }} style={{
        background: 'none', border: 'none', color: '#01579b', fontSize: '1rem',
        cursor: 'pointer', marginBottom: '15px', fontFamily: 'Poppins, sans-serif',
      }}>← {t('games.back')}</button>

      <div style={{
        background: 'linear-gradient(135deg, #e3f2fd, #bbdefb)',
        borderRadius: '20px', padding: '20px', marginBottom: '15px', textAlign: 'center',
      }}>
        <h3 style={{ color: '#1565c0', margin: '0 0 5px' }}>🫁 {t('special.breathing_title')}</h3>
        <p style={{ color: '#1976d2', fontSize: '0.8rem', margin: 0 }}>{t('special.breathing_info')}</p>
      </div>

      <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '20px' }}>
        <div style={{
          width: circleSize, height: circleSize, borderRadius: '50%',
          background: activePhase ? phaseColors[phase] : '#e0e0e0',
          display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
          transition: 'all 0.5s ease',
          transform: phase === 'inhale' ? 'scale(1.15)' : phase === 'exhale' ? 'scale(0.85)' : 'scale(1)',
          boxShadow: activePhase ? `0 0 40px ${phaseColors[phase]}50` : 'none',
        }}>
          <div style={{ fontSize: '2.5rem' }}>{activePhase ? phaseEmojis[phase] : '🫁'}</div>
          {activePhase && <div style={{ fontSize: '2rem', fontWeight: 700, color: 'white' }}>{timer}</div>}
          {activePhase && <div style={{ fontSize: '0.85rem', color: 'white', fontWeight: 600 }}>{t(`special.phase_${phase}`)}</div>}
        </div>
      </div>

      {phase === 'ready' && (
        <div>
          <div style={{ display: 'flex', gap: '8px', marginBottom: '15px', justifyContent: 'center' }}>
            {[3, 4, 6].map(n => (
              <button key={n} onClick={() => setTotalCycles(n)} style={{
                padding: '10px 20px', borderRadius: '12px', border: 'none',
                background: totalCycles === n ? '#42a5f5' : '#e3f2fd',
                color: totalCycles === n ? 'white' : '#1565c0',
                fontWeight: 700, cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
              }}>{n} {t('special.cycles')}</button>
            ))}
          </div>
          <button onClick={startBreathing} style={{
            width: '100%', background: '#42a5f5', color: 'white', border: 'none',
            borderRadius: '25px', padding: '15px', fontSize: '1.1rem', fontWeight: 600,
            cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
          }}>▶️ {t('games.start')}</button>
        </div>
      )}

      {activePhase && (
        <div style={{ textAlign: 'center' }}>
          <p style={{ color: '#757575', fontSize: '0.9rem' }}>{t('special.cycle')} {cycles + 1} / {totalCycles}</p>
          <button onClick={stop} style={{
            background: '#ef5350', color: 'white', border: 'none',
            borderRadius: '25px', padding: '10px 30px', fontWeight: 600, cursor: 'pointer',
            fontFamily: 'Poppins, sans-serif',
          }}>⏹️ {t('special.stop')}</button>
        </div>
      )}

      {phase === 'done' && (
        <div style={{ background: '#e8f5e9', borderRadius: '16px', padding: '25px', textAlign: 'center' }}>
          <div style={{ fontSize: '2.5rem', marginBottom: '8px' }}>🎉</div>
          <h4 style={{ color: '#2e7d32', margin: '0 0 10px' }}>{t('special.breathing_done')}</h4>
          <p style={{ color: '#616161', fontSize: '0.9rem' }}>{totalCycles} {t('special.cycles')} ✅</p>
          <button onClick={() => setPhase('ready')} style={{
            marginTop: '15px', background: '#42a5f5', color: 'white', border: 'none',
            borderRadius: '25px', padding: '12px 30px', fontWeight: 600, cursor: 'pointer',
            fontFamily: 'Poppins, sans-serif',
          }}>🔄 {t('games.retry')}</button>
        </div>
      )}
    </div>
  );
}

// === Emotion Recognition (based on CBT emotion identification) ===
function EmotionRecognition({ onBack }: { onBack: () => void }) {
  const { t } = useLanguage();
  const [logs, setLogs] = useLocalStorage<EmotionLog[]>('soon-emotion-logs', []);
  const [selected, setSelected] = useState('');
  const [intensity, setIntensity] = useState(3);
  const [note, setNote] = useState('');
  const [saved, setSaved] = useState(false);

  const emotions = [
    { emoji: '😊', key: 'happy', color: '#fdd835' },
    { emoji: '😢', key: 'sad', color: '#42a5f5' },
    { emoji: '😠', key: 'angry', color: '#ef5350' },
    { emoji: '😨', key: 'scared', color: '#ab47bc' },
    { emoji: '😮', key: 'surprised', color: '#ff7043' },
    { emoji: '🤢', key: 'disgusted', color: '#66bb6a' },
    { emoji: '😌', key: 'calm', color: '#26c6da' },
    { emoji: '😴', key: 'tired', color: '#78909c' },
  ];

  const save = () => {
    if (!selected) return;
    setLogs(prev => [...prev.slice(-49), {
      date: new Date().toISOString(), emotion: selected, intensity, note,
    }]);
    setSaved(true);
    setTimeout(() => { setSaved(false); setSelected(''); setNote(''); setIntensity(3); }, 2000);
  };

  return (
    <div style={{ padding: '10px 0' }}>
      <button onClick={onBack} style={{
        background: 'none', border: 'none', color: '#01579b', fontSize: '1rem',
        cursor: 'pointer', marginBottom: '15px', fontFamily: 'Poppins, sans-serif',
      }}>← {t('games.back')}</button>

      <div style={{
        background: 'linear-gradient(135deg, #e8f5e9, #c8e6c9)',
        borderRadius: '20px', padding: '20px', marginBottom: '15px', textAlign: 'center',
      }}>
        <h3 style={{ color: '#2e7d32', margin: '0 0 5px' }}>😊 {t('special.emotions_title')}</h3>
        <p style={{ color: '#388e3c', fontSize: '0.8rem', margin: 0 }}>{t('special.emotions_info')}</p>
      </div>

      <p style={{ textAlign: 'center', fontSize: '0.95rem', fontWeight: 600, color: '#424242', marginBottom: '15px' }}>
        {t('special.how_feeling')}
      </p>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '10px', marginBottom: '20px' }}>
        {emotions.map(e => (
          <div key={e.key} onClick={() => setSelected(e.key)} style={{
            textAlign: 'center', padding: '12px 5px', borderRadius: '16px',
            background: selected === e.key ? `${e.color}20` : 'white',
            border: selected === e.key ? `3px solid ${e.color}` : '2px solid #e0e0e0',
            cursor: 'pointer', transition: 'all 0.2s',
          }}>
            <div style={{ fontSize: '2rem' }}>{e.emoji}</div>
            <div style={{ fontSize: '0.7rem', color: '#616161', marginTop: '4px', fontWeight: 600 }}>
              {t(`special.emotion_${e.key}`)}
            </div>
          </div>
        ))}
      </div>

      {selected && (
        <div style={{ marginBottom: '15px' }}>
          <p style={{ fontSize: '0.85rem', color: '#616161', marginBottom: '8px' }}>{t('special.intensity')}</p>
          <div style={{ display: 'flex', gap: '6px', justifyContent: 'center' }}>
            {[1, 2, 3, 4, 5].map(n => (
              <button key={n} onClick={() => setIntensity(n)} style={{
                width: 40, height: 40, borderRadius: '50%', border: 'none',
                background: n <= intensity ? '#66bb6a' : '#e0e0e0',
                color: n <= intensity ? 'white' : '#9e9e9e',
                fontWeight: 700, cursor: 'pointer', fontSize: '1rem',
              }}>{n}</button>
            ))}
          </div>
          <textarea value={note} onChange={e => setNote(e.target.value)}
            placeholder={t('special.emotion_note')}
            style={{
              width: '100%', marginTop: '12px', padding: '12px', borderRadius: '12px',
              border: '2px solid #e0e0e0', fontSize: '0.9rem', minHeight: '60px',
              fontFamily: 'Poppins, sans-serif', resize: 'vertical', boxSizing: 'border-box',
            }} />
          <button onClick={save} style={{
            width: '100%', marginTop: '10px', background: '#66bb6a', color: 'white',
            border: 'none', borderRadius: '25px', padding: '12px', fontWeight: 600,
            cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
          }}>{saved ? '✅' : `💾 ${t('special.save')}`}</button>
        </div>
      )}

      {logs.length > 0 && (
        <div>
          <h4 style={{ color: '#424242', marginBottom: '10px' }}>{t('special.emotion_history')}</h4>
          {logs.slice(-5).reverse().map((log, i) => (
            <div key={i} style={{
              background: 'white', borderRadius: '12px', padding: '12px', marginBottom: '8px',
              boxShadow: '0 2px 8px rgba(0,0,0,0.06)', display: 'flex', alignItems: 'center', gap: '10px',
            }}>
              <span style={{ fontSize: '1.5rem' }}>{emotions.find(e => e.key === log.emotion)?.emoji}</span>
              <div>
                <div style={{ fontSize: '0.85rem', fontWeight: 600, color: '#424242' }}>
                  {t(`special.emotion_${log.emotion}`)} ({log.intensity}/5)
                </div>
                {log.note && <div style={{ fontSize: '0.75rem', color: '#9e9e9e' }}>{log.note}</div>}
                <div style={{ fontSize: '0.7rem', color: '#bdbdbd' }}>
                  {new Date(log.date).toLocaleDateString()}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// === Social Stories (evidence-based for autism spectrum) ===
function SocialStories({ onBack }: { onBack: () => void }) {
  const { t } = useLanguage();
  const [active, setActive] = useState<number | null>(null);

  const stories = [
    { icon: '👋', titleKey: 'special.story_greeting', color: '#42a5f5' },
    { icon: '🤲', titleKey: 'special.story_sharing', color: '#66bb6a' },
    { icon: '⏳', titleKey: 'special.story_waiting', color: '#ff7043' },
    { icon: '😔', titleKey: 'special.story_upset', color: '#ab47bc' },
    { icon: '🔊', titleKey: 'special.story_noise', color: '#26c6da' },
  ];

  return (
    <div style={{ padding: '10px 0' }}>
      <button onClick={onBack} style={{
        background: 'none', border: 'none', color: '#01579b', fontSize: '1rem',
        cursor: 'pointer', marginBottom: '15px', fontFamily: 'Poppins, sans-serif',
      }}>← {t('games.back')}</button>

      <div style={{
        background: 'linear-gradient(135deg, #f3e5f5, #e1bee7)',
        borderRadius: '20px', padding: '20px', marginBottom: '15px', textAlign: 'center',
      }}>
        <h3 style={{ color: '#6a1b9a', margin: '0 0 5px' }}>🤝 {t('special.social_title')}</h3>
        <p style={{ color: '#7b1fa2', fontSize: '0.8rem', margin: 0 }}>{t('special.social_info')}</p>
      </div>

      {stories.map((story, i) => (
        <div key={i}>
          <div onClick={() => setActive(active === i ? null : i)} style={{
            background: 'white', borderRadius: '16px', padding: '18px',
            boxShadow: '0 3px 12px rgba(0,0,0,0.06)', marginBottom: '10px',
            cursor: 'pointer', borderLeft: `5px solid ${story.color}`,
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <span style={{ fontSize: '1.8rem' }}>{story.icon}</span>
              <span style={{ fontWeight: 600, color: '#424242' }}>{t(story.titleKey)}</span>
              <span style={{ marginLeft: 'auto', color: '#bdbdbd' }}>{active === i ? '▲' : '▼'}</span>
            </div>
          </div>
          {active === i && (
            <div style={{
              background: '#fafafa', borderRadius: '12px', padding: '15px',
              marginBottom: '12px', marginTop: '-5px', fontSize: '0.9rem',
              color: '#616161', lineHeight: 1.8,
            }}>
              {t(`${story.titleKey}_content`)}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

// === Visual Routine (ABA-based visual schedule) ===
function VisualRoutine({ onBack }: { onBack: () => void }) {
  const { t } = useLanguage();
  const defaultSteps = [
    { id: '1', label: t('special.routine_wake'), done: false },
    { id: '2', label: t('special.routine_brush'), done: false },
    { id: '3', label: t('special.routine_dress'), done: false },
    { id: '4', label: t('special.routine_eat'), done: false },
    { id: '5', label: t('special.routine_ready'), done: false },
  ];
  const [steps, setSteps] = useLocalStorage<RoutineStep[]>('soon-routine-steps', defaultSteps);
  const completed = steps.filter(s => s.done).length;

  const toggle = (id: string) => {
    setSteps(prev => prev.map(s => s.id === id ? { ...s, done: !s.done } : s));
  };

  const reset = () => setSteps(defaultSteps);

  return (
    <div style={{ padding: '10px 0' }}>
      <button onClick={onBack} style={{
        background: 'none', border: 'none', color: '#01579b', fontSize: '1rem',
        cursor: 'pointer', marginBottom: '15px', fontFamily: 'Poppins, sans-serif',
      }}>← {t('games.back')}</button>

      <div style={{
        background: 'linear-gradient(135deg, #fff3e0, #ffe0b2)',
        borderRadius: '20px', padding: '20px', marginBottom: '15px', textAlign: 'center',
      }}>
        <h3 style={{ color: '#e65100', margin: '0 0 5px' }}>📋 {t('special.routine_title')}</h3>
        <p style={{ color: '#ef6c00', fontSize: '0.8rem', margin: 0 }}>{t('special.routine_info')}</p>
      </div>

      <div style={{
        background: '#e8f5e9', borderRadius: '12px', padding: '12px', textAlign: 'center',
        marginBottom: '15px', fontWeight: 700, color: '#2e7d32',
      }}>
        ✅ {completed} / {steps.length} {t('special.completed')}
      </div>

      {steps.map((step, i) => (
        <div key={step.id} onClick={() => toggle(step.id)} style={{
          display: 'flex', alignItems: 'center', gap: '15px',
          background: step.done ? '#e8f5e9' : 'white', borderRadius: '16px',
          padding: '18px', marginBottom: '10px', cursor: 'pointer',
          boxShadow: '0 2px 10px rgba(0,0,0,0.06)',
          transition: 'all 0.2s',
        }}>
          <div style={{
            width: 40, height: 40, borderRadius: '50%',
            background: step.done ? '#66bb6a' : '#e0e0e0',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: 'white', fontWeight: 700, fontSize: '1.1rem',
          }}>{step.done ? '✓' : i + 1}</div>
          <span style={{
            fontWeight: 600, fontSize: '1rem',
            color: step.done ? '#66bb6a' : '#424242',
            textDecoration: step.done ? 'line-through' : 'none',
          }}>{step.label}</span>
        </div>
      ))}

      {completed === steps.length && (
        <div style={{ background: '#e8f5e9', borderRadius: '16px', padding: '20px', textAlign: 'center', marginTop: '10px' }}>
          <div style={{ fontSize: '2.5rem' }}>🌟</div>
          <h4 style={{ color: '#2e7d32', margin: '8px 0' }}>{t('special.routine_done')}</h4>
        </div>
      )}

      <button onClick={reset} style={{
        width: '100%', marginTop: '15px', background: '#ff7043', color: 'white',
        border: 'none', borderRadius: '25px', padding: '12px', fontWeight: 600,
        cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
      }}>🔄 {t('special.reset')}</button>
    </div>
  );
}

// === Sensory Calming (sensory regulation techniques) ===
function SensoryCalm({ onBack }: { onBack: () => void }) {
  const { t } = useLanguage();
  const [active, setActive] = useState<string | null>(null);

  const techniques = [
    { id: 'grounding', icon: '🌍', color: '#66bb6a', titleKey: 'special.grounding_title', descKey: 'special.grounding_desc' },
    { id: 'muscle', icon: '💪', color: '#42a5f5', titleKey: 'special.muscle_title', descKey: 'special.muscle_desc' },
    { id: 'safe_place', icon: '🏡', color: '#ff7043', titleKey: 'special.safe_title', descKey: 'special.safe_desc' },
    { id: 'counting', icon: '🔢', color: '#ab47bc', titleKey: 'special.counting_title', descKey: 'special.counting_desc' },
  ];

  return (
    <div style={{ padding: '10px 0' }}>
      <button onClick={onBack} style={{
        background: 'none', border: 'none', color: '#01579b', fontSize: '1rem',
        cursor: 'pointer', marginBottom: '15px', fontFamily: 'Poppins, sans-serif',
      }}>← {t('games.back')}</button>

      <div style={{
        background: 'linear-gradient(135deg, #e0f7fa, #b2ebf2)',
        borderRadius: '20px', padding: '20px', marginBottom: '15px', textAlign: 'center',
      }}>
        <h3 style={{ color: '#00695c', margin: '0 0 5px' }}>🌈 {t('special.sensory_title')}</h3>
        <p style={{ color: '#00897b', fontSize: '0.8rem', margin: 0 }}>{t('special.sensory_info')}</p>
      </div>

      {techniques.map(tech => (
        <div key={tech.id}>
          <div onClick={() => setActive(active === tech.id ? null : tech.id)} style={{
            background: 'white', borderRadius: '16px', padding: '18px',
            boxShadow: '0 3px 12px rgba(0,0,0,0.06)', marginBottom: '10px',
            cursor: 'pointer', borderLeft: `5px solid ${tech.color}`,
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <span style={{ fontSize: '1.8rem' }}>{tech.icon}</span>
              <span style={{ fontWeight: 600, color: '#424242' }}>{t(tech.titleKey)}</span>
              <span style={{ marginLeft: 'auto', color: '#bdbdbd' }}>{active === tech.id ? '▲' : '▼'}</span>
            </div>
          </div>
          {active === tech.id && (
            <div style={{
              background: '#fafafa', borderRadius: '12px', padding: '15px',
              marginBottom: '12px', marginTop: '-5px', fontSize: '0.9rem',
              color: '#616161', lineHeight: 1.8,
            }}>
              {t(tech.descKey)}
            </div>
          )}
        </div>
      ))}
      
    </div>
  );
}
