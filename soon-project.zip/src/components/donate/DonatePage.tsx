import { useLanguage } from '../../i18n/LanguageContext';
import InlineAIChat from '../shared/InlineAIChat';

interface DonatePageProps {
  onBack: () => void;
}

const donationLinks = [
  {
    id: 'unhcr',
    name: 'UNHCR',
    nameKey: 'donate.unhcr',
    descKey: 'donate.unhcr_desc',
    icon: '🏠',
    url: 'https://donate.unhcr.org',
    color: '#0072BC',
  },
  {
    id: 'unicef',
    name: 'UNICEF',
    nameKey: 'donate.unicef',
    descKey: 'donate.unicef_desc',
    icon: '👶',
    url: 'https://www.unicef.org/donate',
    color: '#00AEEF',
  },
  {
    id: 'wfp',
    name: 'WFP',
    nameKey: 'donate.wfp',
    descKey: 'donate.wfp_desc',
    icon: '🍞',
    url: 'https://www.wfp.org/donate',
    color: '#E3393A',
  },
  {
    id: 'who',
    name: 'WHO',
    nameKey: 'donate.who',
    descKey: 'donate.who_desc',
    icon: '🏥',
    url: 'https://www.who.int/donate',
    color: '#009FDA',
  },
  {
    id: 'unep',
    name: 'UNEP',
    nameKey: 'donate.unep',
    descKey: 'donate.unep_desc',
    icon: '🌍',
    url: 'https://www.unep.org/donate',
    color: '#00A651',
  },
  {
    id: 'redcross',
    name: 'Red Cross',
    nameKey: 'donate.redcross',
    descKey: 'donate.redcross_desc',
    icon: '❤️',
    url: 'https://www.icrc.org/en/donate',
    color: '#ED1B2E',
  },
];

export default function DonatePage({ onBack }: DonatePageProps) {
  const { t, lang } = useLanguage();
  const isRTL = lang === 'ar';

  return (
    <div style={{ paddingTop: '20px', direction: isRTL ? 'rtl' : 'ltr' }}>
      <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#2DCE89', fontSize: '1rem', cursor: 'pointer', marginBottom: '15px', fontFamily: 'Poppins, sans-serif' }}>
        <i className={`fas fa-arrow-${isRTL ? 'right' : 'left'}`}></i> {t('nav.home')}
      </button>

      <div style={{ textAlign: 'center', marginBottom: '20px' }}>
        <h2 style={{ color: '#32325d', fontSize: '1.5rem', margin: '0 0 5px' }}>🤲 {t('donate.title')}</h2>
        <p style={{ color: '#8898aa', fontSize: '0.85rem', margin: 0 }}>{t('donate.subtitle')}</p>
      </div>

      {/* Quote */}
      <div style={{ background: 'linear-gradient(135deg, #ffecd2, #fcb69f)', borderRadius: '16px', padding: '15px', marginBottom: '20px', textAlign: 'center' }}>
        <p style={{ color: '#8b4513', fontSize: '0.9rem', fontWeight: 600, fontStyle: 'italic', margin: 0, lineHeight: 1.6 }}>
          {t('donate.quote')}
        </p>
      </div>

      {/* Info */}
      <div style={{ background: '#f0f9ff', borderRadius: '12px', padding: '12px 15px', marginBottom: '20px', borderLeft: '4px solid #0072BC' }}>
        <p style={{ margin: 0, fontSize: '0.8rem', color: '#32325d', lineHeight: 1.5 }}>{t('donate.info')}</p>
      </div>

      {/* Donation cards */}
      {donationLinks.map(link => (
        <a key={link.id} href={link.url} target="_blank" rel="noopener noreferrer" style={{ textDecoration: 'none' }}>
          <div style={{
            background: 'white', borderRadius: '16px', padding: '15px', marginBottom: '12px',
            boxShadow: '0 4px 15px rgba(0,0,0,0.06)', cursor: 'pointer',
            borderLeft: `4px solid ${link.color}`, transition: 'all 0.3s ease',
            display: 'flex', alignItems: 'center', gap: '15px',
          }}
          onMouseEnter={e => e.currentTarget.style.transform = 'translateY(-3px)'}
          onMouseLeave={e => e.currentTarget.style.transform = 'translateY(0)'}
          >
            <div style={{
              width: 50, height: 50, borderRadius: '12px', background: `${link.color}15`,
              display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.8rem', flexShrink: 0,
            }}>{link.icon}</div>
            <div style={{ flex: 1 }}>
              <h5 style={{ margin: '0 0 4px', color: '#32325d', fontSize: '0.95rem' }}>{t(link.nameKey)}</h5>
              <p style={{ margin: 0, fontSize: '0.75rem', color: '#8898aa', lineHeight: 1.4 }}>{t(link.descKey)}</p>
            </div>
            <i className={`fas fa-external-link-alt`} style={{ color: link.color, fontSize: '0.9rem' }}></i>
          </div>
        </a>
      ))}

      {/* Mental health benefit */}
      <div style={{ background: 'linear-gradient(135deg, #d1efe1, #e8f5e8)', borderRadius: '16px', padding: '15px', marginTop: '10px', borderLeft: '4px solid #2DCE89' }}>
        <h4 style={{ color: '#1a9f6e', marginBottom: '8px' }}>💚 {t('donate.benefit_title')}</h4>
        <p style={{ color: '#32325d', fontSize: '0.85rem', lineHeight: 1.6, margin: 0 }}>{t('donate.benefit_desc')}</p>
      </div>
      <InlineAIChat context="donate" lang={lang} />
    </div>
  );
}
