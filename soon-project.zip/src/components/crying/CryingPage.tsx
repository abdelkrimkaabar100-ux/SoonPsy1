import { useState } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';

interface CryingPageProps { onBack: () => void; }

export default function CryingPage({ onBack }: CryingPageProps) {
  const { lang } = useLanguage();
  const [cryLog, setCryLog] = useLocalStorage<{ date: string; reason: string; feeling: string }[]>('soon-cry-log', []);
  const [reason, setReason] = useState('');
  const [feeling, setFeelingAfter] = useState('');
  const [phase, setPhase] = useState<'intro' | 'session' | 'log'>('intro');
  const [timer, setTimer] = useState(0);
  const [timerActive, setTimerActive] = useState(false);
  const isAr = lang === 'ar';

  const labels: Record<string, Record<string, string>> = {
    en: { title: '😢 Crying Therapy', subtitle: 'Release your pain through tears', intro1: 'Crying is not weakness — it\'s a powerful healing mechanism', intro2: '✅ Reduces stress hormones by 40%', intro3: '✅ Releases endorphins (natural painkillers)', intro4: '✅ Improves mood and emotional clarity', intro5: '✅ Strengthens emotional resilience', start: 'Start Session', back: 'Back', reason_ph: 'What\'s weighing on you?', feeling_ph: 'How do you feel after crying?', save: 'Save & Close', log: 'My Cry Journal', no_log: 'No entries yet', felt: 'I felt:', breathe: 'Take a deep breath...', letgo: 'Let it all out. You are safe. 💚', timer_label: 'Session time' },
    ar: { title: '😢 علاج البكاء', subtitle: 'حرر ألمك من خلال الدموع', intro1: 'البكاء ليس ضعفاً — إنه آلية شفاء قوية', intro2: '✅ يقلل هرمونات التوتر بنسبة 40%', intro3: '✅ يفرز الإندورفين (مسكنات طبيعية)', intro4: '✅ يحسن المزاج والوضوح العاطفي', intro5: '✅ يقوي المرونة النفسية', start: 'ابدأ الجلسة', back: 'رجوع', reason_ph: 'ما الذي يثقل عليك؟', feeling_ph: 'كيف تشعر بعد البكاء؟', save: 'حفظ وإغلاق', log: 'سجل البكاء', no_log: 'لا توجد مدخلات بعد', felt: 'شعرت:', breathe: 'خذ نفساً عميقاً...', letgo: 'أطلق كل شيء. أنت بأمان. 💚', timer_label: 'وقت الجلسة' },
    es: { title: '😢 Terapia del Llanto', subtitle: 'Libera tu dolor a través de las lágrimas', intro1: 'Llorar no es debilidad — es un poderoso mecanismo de sanación', intro2: '✅ Reduce hormonas del estrés un 40%', intro3: '✅ Libera endorfinas', intro4: '✅ Mejora el ánimo', intro5: '✅ Fortalece la resiliencia', start: 'Iniciar sesión', back: 'Volver', reason_ph: '¿Qué te pesa?', feeling_ph: '¿Cómo te sientes después?', save: 'Guardar', log: 'Mi diario', no_log: 'Sin entradas', felt: 'Sentí:', breathe: 'Respira profundo...', letgo: 'Déjalo todo salir. Estás seguro. 💚', timer_label: 'Tiempo' },
    fr: { title: '😢 Thérapie par les Pleurs', subtitle: 'Libérez votre douleur par les larmes', intro1: 'Pleurer n\'est pas une faiblesse — c\'est un mécanisme de guérison', intro2: '✅ Réduit les hormones de stress de 40%', intro3: '✅ Libère des endorphines', intro4: '✅ Améliore l\'humeur', intro5: '✅ Renforce la résilience', start: 'Commencer', back: 'Retour', reason_ph: 'Qu\'est-ce qui vous pèse?', feeling_ph: 'Comment vous sentez-vous après?', save: 'Sauvegarder', log: 'Mon journal', no_log: 'Pas d\'entrées', felt: 'J\'ai ressenti:', breathe: 'Respirez profondément...', letgo: 'Laissez tout sortir. Vous êtes en sécurité. 💚', timer_label: 'Temps' },
  };
  const l = labels[lang] || labels.en;

  // Timer
  useState(() => {
    if (!timerActive) return;
    const id = setInterval(() => setTimer(t => t + 1), 1000);
    return () => clearInterval(id);
  });

  const saveEntry = () => {
    if (reason.trim() || feeling.trim()) {
      setCryLog(prev => [{ date: new Date().toISOString(), reason: reason.trim(), feeling: feeling.trim() }, ...prev]);
    }
    setPhase('intro');
    setReason('');
    setFeelingAfter('');
    setTimer(0);
  };

  const inputStyle = { width: '100%', padding: '12px', border: '2px solid #e5e7eb', borderRadius: '12px', fontSize: '0.9rem', outline: 'none', boxSizing: 'border-box' as const, fontFamily: 'Poppins, sans-serif', direction: isAr ? 'rtl' as const : 'ltr' as const };

  return (
    <div style={{ paddingTop: '15px', direction: isAr ? 'rtl' : 'ltr' }}>
      <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#6366f1', cursor: 'pointer', fontSize: '1rem', fontFamily: 'Poppins, sans-serif', marginBottom: '15px' }}>
        <i className={`fas fa-arrow-${isAr ? 'right' : 'left'}`}></i> {l.back}
      </button>

      {phase === 'intro' && (
        <div>
          <div style={{ background: 'linear-gradient(135deg, #dbeafe, #bfdbfe)', borderRadius: '20px', padding: '25px', textAlign: 'center', marginBottom: '20px' }}>
            <h2 style={{ color: '#1e40af', margin: '0 0 8px', fontSize: '1.4rem' }}>{l.title}</h2>
            <p style={{ color: '#3b82f6', fontSize: '0.9rem', margin: 0 }}>{l.subtitle}</p>
          </div>
          <div style={{ background: 'white', borderRadius: '16px', padding: '20px', boxShadow: '0 4px 15px rgba(0,0,0,0.08)', marginBottom: '15px' }}>
            <p style={{ fontWeight: 600, color: '#1e40af', marginBottom: '12px' }}>{l.intro1}</p>
            {[l.intro2, l.intro3, l.intro4, l.intro5].map((t, i) => (
              <p key={i} style={{ margin: '8px 0', color: '#4b5563', fontSize: '0.9rem' }}>{t}</p>
            ))}
          </div>
          <button onClick={() => setPhase('session')} style={{ width: '100%', background: 'linear-gradient(135deg, #3b82f6, #1d4ed8)', color: 'white', border: 'none', borderRadius: '16px', padding: '15px', fontWeight: 600, fontSize: '1rem', cursor: 'pointer', fontFamily: 'Poppins, sans-serif', marginBottom: '15px' }}>
            😢 {l.start}
          </button>
          <button onClick={() => setPhase('log')} style={{ width: '100%', background: '#f1f5f9', color: '#475569', border: 'none', borderRadius: '16px', padding: '12px', fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif' }}>
            📖 {l.log}
          </button>
        </div>
      )}

      {phase === 'session' && (
        <div style={{ textAlign: 'center' }}>
          <div style={{ background: 'linear-gradient(135deg, #1e3a5f, #2d5a87)', borderRadius: '20px', padding: '30px', color: 'white', marginBottom: '20px' }}>
            <div style={{ fontSize: '4rem', marginBottom: '15px', animation: 'pulse 2s infinite' }}>😢</div>
            <p style={{ fontSize: '1.2rem', fontWeight: 600, marginBottom: '10px' }}>{l.letgo}</p>
            <p style={{ opacity: 0.8, fontSize: '0.9rem' }}>{l.breathe}</p>
          </div>
          <textarea value={reason} onChange={e => setReason(e.target.value)} placeholder={l.reason_ph} style={{ ...inputStyle, minHeight: '80px', marginBottom: '12px', resize: 'vertical' }} />
          <textarea value={feeling} onChange={e => setFeelingAfter(e.target.value)} placeholder={l.feeling_ph} style={{ ...inputStyle, minHeight: '60px', marginBottom: '15px', resize: 'vertical' }} />
          <button onClick={saveEntry} style={{ width: '100%', background: '#2DCE89', color: 'white', border: 'none', borderRadius: '16px', padding: '14px', fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif', fontSize: '1rem' }}>
            ✅ {l.save}
          </button>
        </div>
      )}

      {phase === 'log' && (
        <div>
          <h3 style={{ color: '#1e40af', marginBottom: '15px' }}>📖 {l.log}</h3>
          {cryLog.length === 0 && <p style={{ textAlign: 'center', color: '#8898aa', padding: '30px' }}>{l.no_log}</p>}
          {cryLog.map((entry, i) => (
            <div key={i} style={{ background: 'white', borderRadius: '12px', padding: '15px', marginBottom: '10px', boxShadow: '0 2px 8px rgba(0,0,0,0.06)', borderLeft: '4px solid #3b82f6' }}>
              <div style={{ fontSize: '0.7rem', color: '#8898aa', marginBottom: '6px' }}>{new Date(entry.date).toLocaleDateString()}</div>
              {entry.reason && <p style={{ margin: '0 0 4px', color: '#32325d', fontSize: '0.85rem' }}>{entry.reason}</p>}
              {entry.feeling && <p style={{ margin: 0, color: '#3b82f6', fontSize: '0.8rem' }}>{l.felt} {entry.feeling}</p>}
            </div>
          ))}
          <button onClick={() => setPhase('intro')} style={{ width: '100%', background: '#f1f5f9', color: '#475569', border: 'none', borderRadius: '16px', padding: '12px', fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif', marginTop: '10px' }}>
            <i className={`fas fa-arrow-${isAr ? 'right' : 'left'}`}></i> {l.back}
          </button>
        </div>
      )}
    </div>
  );
}
