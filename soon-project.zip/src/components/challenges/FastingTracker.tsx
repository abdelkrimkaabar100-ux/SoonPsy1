import { useState, useEffect } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';

interface FastingEntry {
  date: string;
  type: 'sunset' | 'intermittent';
  startTime: string;
  endTime: string;
  completed: boolean;
  waterReminders: string[];
  note: string;
}

export default function FastingTracker() {
  const { lang } = useLanguage();
  const isAr = lang === 'ar';
  const [entries, setEntries] = useLocalStorage<FastingEntry[]>('soon-fasting-log', []);
  const [fastType, setFastType] = useState<'sunset' | 'intermittent'>('sunset');
  const [startTime, setStartTime] = useState('05:00');
  const [endTime, setEndTime] = useState('18:30');
  const [isFasting, setIsFasting] = useState(false);
  const [waterInterval, setWaterInterval] = useState(2); // hours for intermittent
  const [showHistory, setShowHistory] = useState(false);
  const [elapsed, setElapsed] = useState('');

  const today = new Date().toDateString();
  const todayEntry = entries.find(e => e.date === today);

  // Timer
  useEffect(() => {
    if (!isFasting || !todayEntry) return;
    const interval = setInterval(() => {
      const now = new Date();
      const [eh, em] = todayEntry.endTime.split(':').map(Number);
      const end = new Date(); end.setHours(eh, em, 0, 0);
      const diff = end.getTime() - now.getTime();
      if (diff <= 0) {
        setElapsed(isAr ? '🎉 انتهى وقت الصيام!' : '🎉 Fasting time is over!');
        setIsFasting(false);
        // Mark completed
        setEntries(entries.map(e => e.date === today ? { ...e, completed: true } : e));
      } else {
        const h = Math.floor(diff / 3600000);
        const m = Math.floor((diff % 3600000) / 60000);
        setElapsed(isAr ? `⏳ متبقي ${h} ساعة و ${m} دقيقة` : `⏳ ${h}h ${m}m remaining`);
      }
    }, 30000);
    return () => clearInterval(interval);
  }, [isFasting, todayEntry, today, isAr, entries, setEntries]);

  const startFasting = () => {
    const entry: FastingEntry = {
      date: today,
      type: fastType,
      startTime,
      endTime: fastType === 'sunset' ? endTime : calculateEndTime(startTime, 16),
      completed: false,
      waterReminders: [],
      note: '',
    };
    if (todayEntry) {
      setEntries(entries.map(e => e.date === today ? entry : e));
    } else {
      setEntries([...entries, entry]);
    }
    setIsFasting(true);
  };

  const calculateEndTime = (start: string, hours: number) => {
    const [h, m] = start.split(':').map(Number);
    const endH = (h + hours) % 24;
    return `${String(endH).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
  };

  const logWater = () => {
    if (!todayEntry) return;
    const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setEntries(entries.map(e => e.date === today ? { ...e, waterReminders: [...e.waterReminders, now] } : e));
  };

  const markCompleted = () => {
    if (!todayEntry) return;
    setEntries(entries.map(e => e.date === today ? { ...e, completed: true } : e));
    setIsFasting(false);
  };

  // Streak
  const sorted = [...entries].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  let streak = 0;
  for (const e of sorted) { if (e.completed) streak++; else break; }

  const intermittentSchedules = [
    { label: '16:8', fasting: 16, eating: 8 },
    { label: '18:6', fasting: 18, eating: 6 },
    { label: '20:4', fasting: 20, eating: 4 },
  ];

  const benefits = isAr ? [
    { icon: '🧠', text: 'الصيام يعيد ضبط مستقبلات الدوبامين ويزيد حساسية الدماغ للمتع الطبيعية' },
    { icon: '🔄', text: 'الأوتوفاجي (التنظيف الذاتي للخلايا) يبدأ بعد 12-16 ساعة صيام' },
    { icon: '💪', text: 'يقلل الالتهابات ويحسن المزاج والتركيز والطاقة' },
    { icon: '😌', text: 'يعزز الانضباط الذاتي والقوة الإرادية' },
    { icon: '🌙', text: 'الصيام حتى المغرب يربط بين الممارسة الروحانية والصحة الجسدية' },
  ] : [
    { icon: '🧠', text: 'Fasting resets dopamine receptors and increases brain sensitivity to natural pleasures' },
    { icon: '🔄', text: 'Autophagy (cellular self-cleaning) begins after 12-16 hours of fasting' },
    { icon: '💪', text: 'Reduces inflammation and improves mood, focus, and energy' },
    { icon: '😌', text: 'Strengthens self-discipline and willpower' },
    { icon: '🌙', text: 'Fasting until sunset connects spiritual practice with physical health' },
  ];

  return (
    <div style={{ margin: '15px 0' }}>
      {/* ========== FASTING BENEFITS ========== */}
      <div style={{ background: 'linear-gradient(135deg, #fdf4ff, #fae8ff)', borderRadius: '18px', padding: '20px', marginBottom: '15px', boxShadow: '0 4px 15px rgba(168,85,247,0.12)', border: '1px solid #e9d5ff' }}>
        <h3 style={{ color: '#7c3aed', textAlign: 'center', marginBottom: '6px', fontSize: '1.15rem' }}>
          🌙 {isAr ? 'الصيام وإعادة ضبط الدوبامين' : 'Fasting & Dopamine Reset'}
        </h3>
        <p style={{ color: '#6b7280', fontSize: '0.8rem', textAlign: 'center', marginBottom: '14px' }}>
          {isAr ? 'الصيام من أقوى الأدوات لإعادة برمجة دماغك' : 'Fasting is one of the most powerful tools to reprogram your brain'}
        </p>
        {benefits.map((b, i) => (
          <div key={i} style={{ background: 'rgba(255,255,255,0.6)', borderRadius: '12px', padding: '10px 12px', marginBottom: '8px', display: 'flex', alignItems: 'flex-start', gap: '10px' }}>
            <span style={{ fontSize: '1.3rem', flexShrink: 0 }}>{b.icon}</span>
            <p style={{ margin: 0, fontSize: '0.82rem', color: '#4c1d95', lineHeight: 1.5 }}>{b.text}</p>
          </div>
        ))}
      </div>

      {/* ========== FASTING TYPE SELECTOR ========== */}
      <div style={{ background: 'white', borderRadius: '18px', padding: '20px', marginBottom: '15px', boxShadow: '0 4px 15px rgba(0,0,0,0.06)' }}>
        <h3 style={{ color: '#32325d', marginBottom: '14px', fontSize: '1.05rem', textAlign: 'center' }}>
          {isAr ? 'اختر نوع الصيام' : 'Choose Fasting Type'}
        </h3>

        <div style={{ display: 'flex', gap: '10px', marginBottom: '16px' }}>
          <button onClick={() => setFastType('sunset')} style={{
            flex: 1, padding: '14px 10px', borderRadius: '14px', cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
            background: fastType === 'sunset' ? 'linear-gradient(135deg, #7c3aed, #6d28d9)' : '#f5f3ff',
            color: fastType === 'sunset' ? 'white' : '#7c3aed',
            border: fastType === 'sunset' ? 'none' : '2px solid #e9d5ff',
            fontWeight: 700, fontSize: '0.85rem', transition: 'all 0.3s',
          }}>
            🌅 {isAr ? 'صيام حتى المغرب' : 'Fast Until Sunset'}
          </button>
          <button onClick={() => setFastType('intermittent')} style={{
            flex: 1, padding: '14px 10px', borderRadius: '14px', cursor: 'pointer', fontFamily: 'Poppins, sans-serif',
            background: fastType === 'intermittent' ? 'linear-gradient(135deg, #0891b2, #0e7490)' : '#ecfeff',
            color: fastType === 'intermittent' ? 'white' : '#0891b2',
            border: fastType === 'intermittent' ? 'none' : '2px solid #a5f3fc',
            fontWeight: 700, fontSize: '0.85rem', transition: 'all 0.3s',
          }}>
            ⏰ {isAr ? 'صيام متقطع' : 'Intermittent Fasting'}
          </button>
        </div>

        {/* Sunset fasting config */}
        {fastType === 'sunset' && (
          <div style={{ background: '#faf5ff', borderRadius: '14px', padding: '14px', marginBottom: '12px' }}>
            <p style={{ color: '#7c3aed', fontSize: '0.82rem', fontWeight: 600, marginBottom: '10px' }}>
              🌅 {isAr ? 'من الفجر حتى المغرب — صيام كامل عن الطعام والشراب' : 'From dawn to sunset — full fast from food & drink'}
            </p>
            <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
              <div style={{ flex: 1 }}>
                <label style={{ fontSize: '0.75rem', color: '#6b7280', display: 'block', marginBottom: '4px' }}>
                  {isAr ? 'بداية (الفجر)' : 'Start (Dawn)'}
                </label>
                <input type="time" value={startTime} onChange={e => setStartTime(e.target.value)}
                  style={{ width: '100%', padding: '8px', borderRadius: '10px', border: '1px solid #e9d5ff', fontSize: '0.9rem', fontFamily: 'Poppins' }} />
              </div>
              <div style={{ flex: 1 }}>
                <label style={{ fontSize: '0.75rem', color: '#6b7280', display: 'block', marginBottom: '4px' }}>
                  {isAr ? 'نهاية (المغرب)' : 'End (Sunset)'}
                </label>
                <input type="time" value={endTime} onChange={e => setEndTime(e.target.value)}
                  style={{ width: '100%', padding: '8px', borderRadius: '10px', border: '1px solid #e9d5ff', fontSize: '0.9rem', fontFamily: 'Poppins' }} />
              </div>
            </div>
          </div>
        )}

        {/* Intermittent fasting config */}
        {fastType === 'intermittent' && (
          <div style={{ background: '#ecfeff', borderRadius: '14px', padding: '14px', marginBottom: '12px' }}>
            <p style={{ color: '#0891b2', fontSize: '0.82rem', fontWeight: 600, marginBottom: '10px' }}>
              ⏰ {isAr ? 'اختر جدول الصيام المتقطع' : 'Choose intermittent schedule'}
            </p>
            <div style={{ display: 'flex', gap: '8px', marginBottom: '12px', justifyContent: 'center' }}>
              {intermittentSchedules.map(s => (
                <button key={s.label} onClick={() => {
                  setEndTime(calculateEndTime(startTime, s.fasting));
                }} style={{
                  padding: '8px 16px', borderRadius: '20px', cursor: 'pointer', fontWeight: 700, fontSize: '0.9rem',
                  background: 'white', color: '#0891b2', border: '2px solid #a5f3fc', fontFamily: 'Poppins',
                  transition: 'all 0.2s',
                }}>
                  {s.label}
                </button>
              ))}
            </div>
            <div style={{ display: 'flex', gap: '10px', alignItems: 'center', marginBottom: '10px' }}>
              <div style={{ flex: 1 }}>
                <label style={{ fontSize: '0.75rem', color: '#6b7280', display: 'block', marginBottom: '4px' }}>
                  {isAr ? 'بداية الصيام' : 'Fasting Start'}
                </label>
                <input type="time" value={startTime} onChange={e => setStartTime(e.target.value)}
                  style={{ width: '100%', padding: '8px', borderRadius: '10px', border: '1px solid #a5f3fc', fontSize: '0.9rem', fontFamily: 'Poppins' }} />
              </div>
              <div style={{ flex: 1 }}>
                <label style={{ fontSize: '0.75rem', color: '#6b7280', display: 'block', marginBottom: '4px' }}>
                  {isAr ? 'نهاية الصيام' : 'Fasting End'}
                </label>
                <input type="time" value={endTime} onChange={e => setEndTime(e.target.value)}
                  style={{ width: '100%', padding: '8px', borderRadius: '10px', border: '1px solid #a5f3fc', fontSize: '0.9rem', fontFamily: 'Poppins' }} />
              </div>
            </div>

            {/* Water reminder interval */}
            <div style={{ background: 'rgba(255,255,255,0.7)', borderRadius: '12px', padding: '12px', marginTop: '8px' }}>
              <p style={{ fontSize: '0.8rem', color: '#0891b2', fontWeight: 600, marginBottom: '8px' }}>
                💧 {isAr ? 'تذكير شرب الماء خلال فترة الأكل (كل X ساعة)' : 'Water reminder during eating window (every X hours)'}
              </p>
              <div style={{ display: 'flex', gap: '8px', justifyContent: 'center' }}>
                {[1, 2, 3].map(h => (
                  <button key={h} onClick={() => setWaterInterval(h)} style={{
                    background: waterInterval === h ? '#0891b2' : 'white',
                    color: waterInterval === h ? 'white' : '#0891b2',
                    border: `2px solid ${waterInterval === h ? '#0891b2' : '#a5f3fc'}`,
                    borderRadius: '50%', width: 40, height: 40, fontWeight: 700, cursor: 'pointer', fontSize: '0.9rem',
                  }}>
                    {h}{isAr ? 'س' : 'h'}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Start / Complete buttons */}
        {!todayEntry || !isFasting ? (
          <button onClick={startFasting} style={{
            background: fastType === 'sunset'
              ? 'linear-gradient(135deg, #7c3aed, #6d28d9)'
              : 'linear-gradient(135deg, #0891b2, #0e7490)',
            color: 'white', border: 'none', borderRadius: '25px', padding: '14px', fontWeight: 700,
            cursor: 'pointer', width: '100%', fontSize: '1rem', fontFamily: 'Poppins, sans-serif',
            transition: 'all 0.3s',
          }}>
            {todayEntry?.completed
              ? (isAr ? '✅ أكملت صيام اليوم! ما شاء الله' : '✅ Fasting completed today!')
              : (isAr ? '🚀 ابدأ الصيام الآن' : '🚀 Start Fasting Now')}
          </button>
        ) : (
          <div>
            {/* Active fasting state */}
            <div style={{
              background: 'linear-gradient(135deg, #fefce8, #fef9c3)', borderRadius: '14px',
              padding: '16px', textAlign: 'center', marginBottom: '10px', border: '2px solid #fde68a',
            }}>
              <div style={{ fontSize: '1.1rem', fontWeight: 700, color: '#92400e', marginBottom: '4px' }}>
                {isAr ? '🔥 أنت صائم الآن' : '🔥 You are fasting now'}
              </div>
              <div style={{ fontSize: '0.9rem', color: '#a16207' }}>
                {todayEntry.startTime} → {todayEntry.endTime}
              </div>
              {elapsed && <div style={{ fontSize: '0.95rem', fontWeight: 600, color: '#92400e', marginTop: '6px' }}>{elapsed}</div>}
            </div>

            <div style={{ display: 'flex', gap: '8px' }}>
              {fastType === 'intermittent' && (
                <button onClick={logWater} style={{
                  flex: 1, background: '#ecfeff', color: '#0891b2', border: '2px solid #a5f3fc',
                  borderRadius: '25px', padding: '10px', fontWeight: 700, cursor: 'pointer', fontSize: '0.85rem',
                }}>
                  💧 {isAr ? 'شربت ماء' : 'Drank Water'}
                </button>
              )}
              <button onClick={markCompleted} style={{
                flex: 1, background: 'linear-gradient(135deg, #16a34a, #15803d)',
                color: 'white', border: 'none', borderRadius: '25px', padding: '10px',
                fontWeight: 700, cursor: 'pointer', fontSize: '0.85rem',
              }}>
                ✅ {isAr ? 'أكملت الصيام' : 'Complete Fast'}
              </button>
            </div>

            {/* Water log for today */}
            {todayEntry.waterReminders.length > 0 && (
              <div style={{ marginTop: '10px', display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                {todayEntry.waterReminders.map((t, i) => (
                  <span key={i} style={{ background: '#ecfeff', color: '#0891b2', padding: '3px 10px', borderRadius: '15px', fontSize: '0.75rem', fontWeight: 600 }}>
                    💧 {t}
                  </span>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* ========== STREAK ========== */}
      {streak > 0 && (
        <div style={{ textAlign: 'center', background: 'linear-gradient(135deg, #fdf4ff, #fae8ff)', borderRadius: '16px', padding: '16px', marginBottom: '15px', border: '1px solid #e9d5ff' }}>
          <div style={{ fontSize: '2rem', marginBottom: '4px' }}>🔥</div>
          <div style={{ fontSize: '1.3rem', fontWeight: 700, color: '#7c3aed' }}>
            {streak} {isAr ? 'يوم صيام متتالي!' : 'fasting day streak!'}
          </div>
          <p style={{ color: '#6b7280', fontSize: '0.8rem', margin: '4px 0 0' }}>
            {isAr ? 'كل يوم تزداد قوة إرادتك وصفاء ذهنك' : 'Each day your willpower and mental clarity grows'}
          </p>
        </div>
      )}

      {/* ========== HISTORY ========== */}
      {entries.length > 0 && (
        <button onClick={() => setShowHistory(!showHistory)} style={{
          background: 'none', border: '1px solid #7c3aed', color: '#7c3aed', borderRadius: '25px',
          padding: '10px 20px', fontWeight: 600, cursor: 'pointer', width: '100%', fontFamily: 'Poppins, sans-serif', fontSize: '0.85rem', marginBottom: '15px',
        }}>
          <i className={`fas fa-${showHistory ? 'chevron-up' : 'history'}`} style={{ marginRight: '6px' }}></i>
          {showHistory ? (isAr ? 'إخفاء السجل' : 'Hide History') : (isAr ? 'عرض سجل الصيام' : 'View Fasting History')}
        </button>
      )}
      {showHistory && (
        <div style={{ maxHeight: '300px', overflowY: 'auto', marginBottom: '15px' }}>
          {sorted.map((e, i) => (
            <div key={i} style={{ background: '#f9fafb', borderRadius: '12px', padding: '12px', marginBottom: '8px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <span style={{ fontSize: '0.8rem', color: '#6b7280' }}>{new Date(e.date).toLocaleDateString(isAr ? 'ar' : 'en')}</span>
                  <span style={{ marginLeft: '8px', fontSize: '0.75rem', color: '#9ca3af' }}>{e.startTime} → {e.endTime}</span>
                </div>
                <div style={{ display: 'flex', gap: '6px', alignItems: 'center' }}>
                  <span style={{
                    background: e.type === 'sunset' ? '#f3e8ff' : '#ecfeff',
                    color: e.type === 'sunset' ? '#7c3aed' : '#0891b2',
                    padding: '2px 8px', borderRadius: '10px', fontSize: '0.7rem', fontWeight: 600,
                  }}>
                    {e.type === 'sunset' ? '🌅' : '⏰'}
                  </span>
                  {e.completed && <span style={{ background: '#dcfce7', color: '#166534', padding: '2px 8px', borderRadius: '10px', fontSize: '0.7rem', fontWeight: 600 }}>✅</span>}
                  {e.waterReminders.length > 0 && (
                    <span style={{ background: '#ecfeff', color: '#0891b2', padding: '2px 8px', borderRadius: '10px', fontSize: '0.7rem', fontWeight: 600 }}>
                      💧×{e.waterReminders.length}
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
