import { useState } from 'react';
import InlineAIChat from '../shared/InlineAIChat';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { useLanguage } from '../../i18n/LanguageContext';
import { supabase } from '@/integrations/supabase/client';

interface HonestyEntry { id: string; person: string; feelings: string; likes: string; dislikes: string; changes: string; date: string; }

interface HonestyPageProps { onShareWithAI?: (text: string) => void; }

export default function HonestyPage({ onShareWithAI }: HonestyPageProps) {
  const { t, lang } = useLanguage();
  const [entries, setEntries] = useLocalStorage<HonestyEntry[]>('soon-honesty', []);
  const [person, setPerson] = useState('');
  const [feelings, setFeelings] = useState('');
  const [likes, setLikes] = useState('');
  const [dislikes, setDislikes] = useState('');
  const [changes, setChanges] = useState('');

  const labels = {
    en: { likes: 'Things I love about this person...', dislikes: 'Things I don\'t like...', changes: 'What I wish they would change...', share_person: 'Share with this person', share_copy: 'Copied! Share it with them 💌' },
    ar: { likes: 'أشياء أحبها في هذا الشخص...', dislikes: 'أشياء لا تعجبني فيه...', changes: 'ما أتمنى أن يغيره...', share_person: 'شارك مع هذا الشخص', share_copy: 'تم النسخ! شاركه معه 💌' },
    es: { likes: 'Lo que me encanta de esta persona...', dislikes: 'Lo que no me gusta...', changes: 'Lo que desearía que cambiara...', share_person: 'Compartir con esta persona', share_copy: '¡Copiado! Compártelo 💌' },
    fr: { likes: 'Ce que j\'aime chez cette personne...', dislikes: 'Ce que je n\'aime pas...', changes: 'Ce que j\'aimerais qu\'il/elle change...', share_person: 'Partager avec cette personne', share_copy: 'Copié! Partagez-le 💌' },
  };
  const l = labels[lang] || labels.en;

  const saveEntry = () => {
    if (!person.trim() || !feelings.trim()) return;
    setEntries([{ id: Date.now().toString(), person: person.trim(), feelings: feelings.trim(), likes: likes.trim(), dislikes: dislikes.trim(), changes: changes.trim(), date: new Date().toISOString() }, ...entries]);
    setPerson(''); setFeelings(''); setLikes(''); setDislikes(''); setChanges('');
  };

  const deleteEntry = (id: string) => setEntries(entries.filter(e => e.id !== id));

  const shareEntry = (entry: HonestyEntry) => {
    if (!onShareWithAI) return;
    const text = lang === 'ar'
      ? `أريد مشاركة مشاعري تجاه ${entry.person}: ${entry.feelings}. ما أحبه: ${entry.likes}. ما لا يعجبني: ${entry.dislikes}. ما أتمنى تغييره: ${entry.changes}`
      : `I want to share my feelings about ${entry.person}: ${entry.feelings}. What I love: ${entry.likes}. What I don't like: ${entry.dislikes}. What I wish they'd change: ${entry.changes}`;
    onShareWithAI(text);
  };

  const shareWithPerson = (entry: HonestyEntry) => {
    const message = lang === 'ar'
      ? `💌 رسالة صراحة لـ ${entry.person}:\n\n❤️ ما أحبه فيك: ${entry.likes}\n💭 مشاعري: ${entry.feelings}\n🔄 ما أتمنى: ${entry.changes}\n\n— من تطبيق Soon للصحة النفسية`
      : `💌 Honesty message for ${entry.person}:\n\n❤️ What I love about you: ${entry.likes}\n💭 My feelings: ${entry.feelings}\n🔄 What I wish: ${entry.changes}\n\n— From Soon Mental Health App`;
    navigator.clipboard.writeText(message);
    alert(l.share_copy);
  };

  const shareLink = async (entry: HonestyEntry) => {
    const content = lang === 'ar'
      ? `❤️ ما أحبه فيك: ${entry.likes}\n💭 مشاعري: ${entry.feelings}\n🔄 ما أتمنى: ${entry.changes}`
      : `❤️ What I love about you: ${entry.likes}\n💭 My feelings: ${entry.feelings}\n🔄 What I wish: ${entry.changes}`;
    try {
      const { data } = await supabase.from('shared_messages').insert({
        type: 'honesty', recipient_name: entry.person, content,
        sender_name: localStorage.getItem('soon-user-name') || '',
      }).select('id').single();
      if (data) {
        const link = `${window.location.origin}/shared/${data.id}`;
        if (navigator.share) navigator.share({ url: link, title: 'Honesty Message' });
        else { navigator.clipboard.writeText(link); alert(lang === 'ar' ? 'تم نسخ الرابط!' : 'Link copied!'); }
      }
    } catch (err) { console.error(err); }
  };

  const inputStyle = { width: '100%', padding: '12px 15px', border: '1px solid #ddd', borderRadius: '12px', fontFamily: 'Poppins, sans-serif', fontSize: '0.9rem', outline: 'none', marginBottom: '10px', boxSizing: 'border-box' as const };

  return (
    <div>
      <h2 style={{ fontSize: '1.8rem', fontWeight: 700, color: '#32325d', margin: '25px 0', textAlign: 'center', position: 'relative' }}>
        {t('honesty.title')}
        <div style={{ position: 'absolute', bottom: '-10px', left: '50%', transform: 'translateX(-50%)', width: '80px', height: '4px', background: '#8965e0', borderRadius: '2px' }}></div>
      </h2>

      <div style={{ background: 'linear-gradient(135deg, #8965e0, #5e55e0)', borderRadius: '16px', padding: '20px', marginBottom: '20px', color: 'white', textAlign: 'center' }}>
        <div style={{ fontSize: '2.5rem', marginBottom: '10px' }}>💭</div>
        <p style={{ opacity: 0.9, fontSize: '0.95rem', lineHeight: 1.6 }}>{t('honesty.desc')}</p>
      </div>

      <div style={{ background: 'white', borderRadius: '16px', padding: '20px', marginBottom: '20px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
        <input type="text" value={person} onChange={e => setPerson(e.target.value)} placeholder={t('honesty.person_placeholder')} style={inputStyle} />
        <textarea value={feelings} onChange={e => setFeelings(e.target.value)} placeholder={t('honesty.feelings_placeholder')}
          style={{ ...inputStyle, height: '80px', resize: 'vertical' as const }} />
        <textarea value={likes} onChange={e => setLikes(e.target.value)} placeholder={l.likes}
          style={{ ...inputStyle, height: '60px', resize: 'vertical' as const, borderColor: '#2DCE89' }} />
        <textarea value={dislikes} onChange={e => setDislikes(e.target.value)} placeholder={l.dislikes}
          style={{ ...inputStyle, height: '60px', resize: 'vertical' as const, borderColor: '#f5365c' }} />
        <textarea value={changes} onChange={e => setChanges(e.target.value)} placeholder={l.changes}
          style={{ ...inputStyle, height: '60px', resize: 'vertical' as const, borderColor: '#fbb140' }} />
        <button onClick={saveEntry} style={{ background: 'linear-gradient(to right, #8965e0, #5e55e0)', color: 'white', border: 'none', borderRadius: '25px', padding: '12px', fontWeight: 600, cursor: 'pointer', width: '100%', fontFamily: 'Poppins, sans-serif', marginTop: '5px' }}>
          {t('honesty.save')}
        </button>
      </div>

      {entries.length > 0 && (
        <div style={{ background: 'white', borderRadius: '16px', padding: '15px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
          <h4 style={{ color: '#8965e0', marginBottom: '12px' }}>{t('honesty.previous')}</h4>
          {entries.map(entry => (
            <div key={entry.id} style={{ background: '#f8f6ff', borderRadius: '12px', padding: '14px', marginBottom: '10px', borderLeft: '4px solid #8965e0' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                <strong style={{ color: '#8965e0' }}>💭 {entry.person}</strong>
                <span style={{ fontSize: '0.75rem', color: '#8898aa' }}>{new Date(entry.date).toLocaleDateString()}</span>
              </div>
              <p style={{ margin: '0 0 4px', fontSize: '0.9rem', color: '#32325d', lineHeight: 1.5 }}>{entry.feelings}</p>
              {entry.likes && <p style={{ margin: '4px 0', fontSize: '0.8rem', color: '#2DCE89' }}>❤️ {entry.likes}</p>}
              {entry.dislikes && <p style={{ margin: '4px 0', fontSize: '0.8rem', color: '#f5365c' }}>💔 {entry.dislikes}</p>}
              {entry.changes && <p style={{ margin: '4px 0', fontSize: '0.8rem', color: '#fbb140' }}>🔄 {entry.changes}</p>}
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginTop: '10px' }}>
                {onShareWithAI && (
                  <button onClick={() => shareEntry(entry)} style={{ background: '#8965e0', border: 'none', color: 'white', fontSize: '0.75rem', cursor: 'pointer', borderRadius: '15px', padding: '5px 12px', fontFamily: 'Poppins, sans-serif' }}>
                    🤖 {t('honesty.share_ai')}
                  </button>
                )}
                <button onClick={() => shareWithPerson(entry)} style={{ background: '#2DCE89', border: 'none', color: 'white', fontSize: '0.75rem', cursor: 'pointer', borderRadius: '15px', padding: '5px 12px', fontFamily: 'Poppins, sans-serif' }}>
                  💌 {l.share_person}
                </button>
                <button onClick={() => shareLink(entry)} style={{ background: '#f59e0b', border: 'none', color: 'white', fontSize: '0.75rem', cursor: 'pointer', borderRadius: '15px', padding: '5px 12px', fontFamily: 'Poppins, sans-serif' }}>
                  🔗 {lang === 'ar' ? 'مشاركة رابط' : 'Share Link'}
                </button>
                <button onClick={() => deleteEntry(entry.id)} style={{ background: 'none', border: '1px solid #f5365c', color: '#f5365c', fontSize: '0.75rem', cursor: 'pointer', borderRadius: '15px', padding: '4px 12px', fontFamily: 'Poppins, sans-serif' }}>
                  🗑 {t('honesty.delete')}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
      <InlineAIChat context="honesty" lang={lang} />
    </div>
  );
}
