import { useState, useEffect } from 'react';
import InlineAIChat from '../shared/InlineAIChat';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { useLanguage } from '../../i18n/LanguageContext';

interface SmileEntry { date: string; count: number; note: string; missions: string[]; }

interface DailyMission {
  id: string;
  icon: string;
  text: Record<string, string>;
  category: 'smile' | 'help' | 'kindness' | 'connect';
}

const allMissions: DailyMission[] = [
  { id: 'm1', icon: '😊', category: 'smile', text: { en: 'Smile at 3 strangers today', ar: 'ابتسم في وجه 3 أشخاص غرباء اليوم', es: 'Sonríe a 3 desconocidos hoy', fr: 'Souriez à 3 inconnus aujourd\'hui' } },
  { id: 'm2', icon: '🤝', category: 'help', text: { en: 'Help someone you don\'t know — even with useful information', ar: 'ساعد شخصاً لا تعرفه — ولو بمعلومة مفيدة', es: 'Ayuda a alguien que no conoces', fr: 'Aidez quelqu\'un que vous ne connaissez pas' } },
  { id: 'm3', icon: '💬', category: 'connect', text: { en: 'Compliment someone sincerely today', ar: 'امدح شخصاً بصدق اليوم', es: 'Haz un cumplido sincero hoy', fr: 'Faites un compliment sincère aujourd\'hui' } },
  { id: 'm4', icon: '🎁', category: 'kindness', text: { en: 'Do a random act of kindness', ar: 'قم بعمل لطيف عشوائي', es: 'Haz un acto de bondad al azar', fr: 'Faites un acte de gentillesse au hasard' } },
  { id: 'm5', icon: '👋', category: 'smile', text: { en: 'Greet your neighbors warmly', ar: 'حيّ جيرانك بحرارة', es: 'Saluda a tus vecinos con calidez', fr: 'Saluez vos voisins chaleureusement' } },
  { id: 'm6', icon: '📞', category: 'connect', text: { en: 'Call someone you haven\'t spoken to in a while', ar: 'اتصل بشخص لم تتحدث معه منذ فترة', es: 'Llama a alguien con quien no hablas hace tiempo', fr: 'Appelez quelqu\'un que vous n\'avez pas contacté depuis longtemps' } },
  { id: 'm7', icon: '🌟', category: 'kindness', text: { en: 'Share something valuable with a colleague', ar: 'شارك شيئاً قيماً مع زميل', es: 'Comparte algo valioso con un colega', fr: 'Partagez quelque chose de précieux avec un collègue' } },
  { id: 'm8', icon: '🫂', category: 'help', text: { en: 'Listen to someone who needs to talk', ar: 'استمع لشخص يحتاج للحديث', es: 'Escucha a alguien que necesite hablar', fr: 'Écoutez quelqu\'un qui a besoin de parler' } },
  { id: 'm9', icon: '☕', category: 'kindness', text: { en: 'Buy a coffee or treat for someone', ar: 'اشترِ قهوة أو هدية صغيرة لشخص', es: 'Invita a alguien a un café', fr: 'Offrez un café à quelqu\'un' } },
  { id: 'm10', icon: '✉️', category: 'connect', text: { en: 'Send an encouraging message to a friend', ar: 'أرسل رسالة تشجيعية لصديق', es: 'Envía un mensaje de ánimo a un amigo', fr: 'Envoyez un message d\'encouragement à un ami' } },
];

export default function SmileChallenge() {
  const { t, lang } = useLanguage();
  const [entries, setEntries] = useLocalStorage<SmileEntry[]>('soon-smile-challenge', []);
  const [note, setNote] = useState('');
  const [todayMissions, setTodayMissions] = useState<DailyMission[]>([]);

  const today = new Date().toDateString();
  const todayEntry = entries.find(e => new Date(e.date).toDateString() === today);

  useEffect(() => {
    const seed = new Date().getDate() + new Date().getMonth() * 31;
    const shuffled = [...allMissions].sort((a, b) => {
      const ha = ((seed * 31 + a.id.charCodeAt(1)) % 100);
      const hb = ((seed * 31 + b.id.charCodeAt(1)) % 100);
      return ha - hb;
    });
    setTodayMissions(shuffled.slice(0, 3));
  }, []);

  const logSmile = () => {
    const existing = entries.filter(e => new Date(e.date).toDateString() !== today);
    const newCount = (todayEntry?.count || 0) + 1;
    setEntries([{ date: new Date().toISOString(), count: newCount, note: note || todayEntry?.note || '', missions: todayEntry?.missions || [] }, ...existing]);
  };

  const completeMission = (missionId: string) => {
    const existing = entries.filter(e => new Date(e.date).toDateString() !== today);
    const currentMissions = todayEntry?.missions || [];
    if (currentMissions.includes(missionId)) return;
    const newMissions = [...currentMissions, missionId];
    setEntries([{ date: new Date().toISOString(), count: (todayEntry?.count || 0) + 1, note: todayEntry?.note || '', missions: newMissions }, ...existing]);
  };

  const saveNote = () => {
    if (!note.trim()) return;
    const existing = entries.filter(e => new Date(e.date).toDateString() !== today);
    setEntries([{ date: new Date().toISOString(), count: todayEntry?.count || 0, note: note.trim(), missions: todayEntry?.missions || [] }, ...existing]);
    setNote('');
  };

  const totalSmiles = entries.reduce((s, e) => s + e.count, 0);
  const streak = (() => {
    let count = 0;
    const d = new Date();
    for (let i = 0; i < 365; i++) {
      if (entries.some(e => new Date(e.date).toDateString() === d.toDateString() && e.count > 0)) count++;
      else if (i > 0) break;
      d.setDate(d.getDate() - 1);
    }
    return count;
  })();

  const categoryColors: Record<string, string> = { smile: '#fbb140', help: '#2DCE89', kindness: '#f5365c', connect: '#8965e0' };
  const categoryLabels: Record<string, Record<string, string>> = {
    smile: { en: 'Smile', ar: 'ابتسامة', es: 'Sonrisa', fr: 'Sourire' },
    help: { en: 'Help', ar: 'مساعدة', es: 'Ayuda', fr: 'Aide' },
    kindness: { en: 'Kindness', ar: 'لطف', es: 'Amabilidad', fr: 'Gentillesse' },
    connect: { en: 'Connect', ar: 'تواصل', es: 'Conectar', fr: 'Connecter' },
  };

  return (
    <div>
      <h2 style={{ fontSize: '1.8rem', fontWeight: 700, color: '#32325d', margin: '25px 0', textAlign: 'center', position: 'relative' }}>
        {t('smile.title')}
        <div style={{ position: 'absolute', bottom: '-10px', left: '50%', transform: 'translateX(-50%)', width: '80px', height: '4px', background: '#fbb140', borderRadius: '2px' }}></div>
      </h2>

      {/* Stats Card */}
      <div style={{ background: 'linear-gradient(135deg, #fbb140, #fb6340)', borderRadius: '16px', padding: '25px', marginBottom: '20px', textAlign: 'center', color: 'white', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
        <div style={{ fontSize: '4rem', marginBottom: '10px' }}>😊</div>
        <h3 style={{ color: 'white', marginBottom: '5px' }}>{t('smile.today')}: {todayEntry?.count || 0}</h3>
        <p style={{ opacity: 0.9, margin: '5px 0' }}>{t('smile.total')}: {totalSmiles} | {t('smile.streak')}: {streak} {t('data.days')}</p>
        <button onClick={logSmile} style={{ background: 'white', color: '#fb6340', border: 'none', borderRadius: '25px', padding: '15px 30px', fontWeight: 700, cursor: 'pointer', fontFamily: 'Poppins, sans-serif', fontSize: '1.1rem', marginTop: '15px', boxShadow: '0 4px 15px rgba(0,0,0,0.2)' }}>
          😊 {t('smile.log')}
        </button>
      </div>

      {/* Daily Positive Missions */}
      <div style={{ background: 'white', borderRadius: '16px', padding: '20px', marginBottom: '20px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
        <h4 style={{ color: '#32325d', marginBottom: '15px', textAlign: 'center' }}>
          🎯 {lang === 'ar' ? 'مهمات اليوم الإيجابية' : lang === 'es' ? 'Misiones Positivas de Hoy' : lang === 'fr' ? 'Missions Positives du Jour' : 'Today\'s Positive Missions'}
        </h4>
        <p style={{ color: '#8898aa', fontSize: '0.8rem', textAlign: 'center', marginBottom: '15px' }}>
          {lang === 'ar' ? 'العطاء ومساعدة الآخرين يدعم صحتنا النفسية 💚' : lang === 'es' ? 'Dar y ayudar a otros fortalece nuestra salud mental 💚' : lang === 'fr' ? 'Donner et aider les autres renforce notre santé mentale 💚' : 'Giving and helping others strengthens our mental health 💚'}
        </p>
        {todayMissions.map(mission => {
          const done = todayEntry?.missions?.includes(mission.id);
          return (
            <div key={mission.id} onClick={() => !done && completeMission(mission.id)} style={{
              display: 'flex', alignItems: 'center', gap: '12px', padding: '14px', borderRadius: '14px', marginBottom: '10px',
              background: done ? '#f0fdf4' : '#fafafa', border: done ? '2px solid #2DCE89' : '2px solid #eee',
              cursor: done ? 'default' : 'pointer', transition: 'all 0.3s ease', opacity: done ? 0.8 : 1,
            }}>
              <span style={{ fontSize: '1.5rem' }}>{done ? '✅' : mission.icon}</span>
              <div style={{ flex: 1 }}>
                <p style={{ margin: 0, fontSize: '0.9rem', color: '#32325d', textDecoration: done ? 'line-through' : 'none' }}>
                  {mission.text[lang] || mission.text.en}
                </p>
                <span style={{ fontSize: '0.7rem', color: categoryColors[mission.category], fontWeight: 600, background: `${categoryColors[mission.category]}20`, padding: '2px 8px', borderRadius: '10px', marginTop: '4px', display: 'inline-block' }}>
                  {categoryLabels[mission.category][lang] || categoryLabels[mission.category].en}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Note */}
      <div style={{ background: 'white', borderRadius: '16px', padding: '20px', marginBottom: '20px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
        <h4 style={{ color: '#32325d', marginBottom: '10px' }}>{t('smile.note_title')}</h4>
        <textarea value={note} onChange={e => setNote(e.target.value)} placeholder={t('smile.note_placeholder')}
          style={{ width: '100%', height: '80px', border: '1px solid #ddd', borderRadius: '12px', padding: '12px', fontFamily: 'Poppins, sans-serif', resize: 'vertical', outline: 'none', boxSizing: 'border-box' }} />
        <button onClick={saveNote} style={{ background: '#fbb140', color: 'white', border: 'none', borderRadius: '25px', padding: '10px 20px', fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif', marginTop: '10px', width: '100%' }}>{t('smile.save_note')}</button>
      </div>

      {/* History */}
      <div style={{ background: 'white', borderRadius: '16px', padding: '15px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
        <h4 style={{ color: '#1a9f6e', marginBottom: '10px' }}>{t('smile.history')}</h4>
        {entries.slice(0, 14).map((e, i) => (
          <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 0', borderBottom: '1px solid #f0f0f0', fontSize: '0.85rem' }}>
            <span style={{ color: '#32325d' }}>{new Date(e.date).toLocaleDateString()}</span>
            <span style={{ color: '#fbb140', fontWeight: 600 }}>😊 ×{e.count}</span>
            {e.missions?.length > 0 && <span style={{ fontSize: '0.7rem', color: '#2DCE89' }}>✅ {e.missions.length} missions</span>}
            {e.note && <span style={{ color: '#8898aa', fontSize: '0.75rem', maxWidth: '30%', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{e.note}</span>}
          </div>
        ))}
      </div>
      <InlineAIChat context="smile" lang={lang} />
    </div>
  );
}
