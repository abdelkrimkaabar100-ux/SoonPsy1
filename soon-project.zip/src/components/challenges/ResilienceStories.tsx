import { useLanguage } from '../../i18n/LanguageContext';
import InlineAIChat from '../shared/InlineAIChat';

const stories = [
  {
    name: { en: 'Stephen Hawking', ar: 'ستيفن هوكينغ', es: 'Stephen Hawking', fr: 'Stephen Hawking' },
    condition: { en: 'ALS (Motor Neuron Disease)', ar: 'التصلب الجانبي الضموري', es: 'ELA', fr: 'SLA' },
    story: {
      en: 'Diagnosed with ALS at 21 and given 2 years to live, Stephen Hawking went on to become one of the greatest physicists in history. He maintained his curiosity, humor, and determination for over 50 years, proving that the mind has no limits.',
      ar: 'شُخِّص بمرض التصلب الجانبي الضموري وعمره 21 عاماً وأُعطي سنتين للعيش، لكنه أصبح أحد أعظم الفيزيائيين في التاريخ. حافظ على فضوله وروح الدعابة لأكثر من 50 عاماً.',
      es: 'Diagnosticado con ELA a los 21 años, Stephen Hawking se convirtió en uno de los más grandes físicos de la historia.',
      fr: 'Diagnostiqué avec la SLA à 21 ans, Stephen Hawking est devenu l\'un des plus grands physiciens de l\'histoire.',
    },
    lesson: { en: 'Your body may have limits, but your mind and spirit are infinite.', ar: 'جسدك قد يكون محدوداً، لكن عقلك وروحك لا حدود لهما.', es: 'Tu cuerpo puede tener límites, pero tu mente es infinita.', fr: 'Votre corps peut avoir des limites, mais votre esprit est infini.' },
    source: 'https://www.biography.com/scientist/stephen-hawking',
  },
  {
    name: { en: 'Malala Yousafzai', ar: 'ملالا يوسفزاي', es: 'Malala Yousafzai', fr: 'Malala Yousafzai' },
    condition: { en: 'Gunshot wound to the head', ar: 'إصابة بطلق ناري في الرأس', es: 'Herida de bala en la cabeza', fr: 'Blessure par balle à la tête' },
    story: {
      en: 'Shot by the Taliban at age 15 for advocating girls\' education, Malala survived, recovered, and became the youngest Nobel Prize laureate. She turned her trauma into a global movement for education.',
      ar: 'أُطلقت عليها النار من قبل طالبان وعمرها 15 عاماً بسبب دفاعها عن تعليم الفتيات. نجت وتعافت وأصبحت أصغر حائزة على جائزة نوبل.',
      es: 'Disparada por los talibanes a los 15 años, Malala sobrevivió y se convirtió en la ganadora más joven del Premio Nobel.',
      fr: 'Tirée par les talibans à 15 ans, Malala a survécu et est devenue la plus jeune lauréate du prix Nobel.',
    },
    lesson: { en: 'One voice can change the world. Your pain can become your purpose.', ar: 'صوت واحد يمكن أن يغير العالم. ألمك يمكن أن يصبح هدفك.', es: 'Una voz puede cambiar el mundo.', fr: 'Une voix peut changer le monde.' },
    source: 'https://www.malala.org/malalas-story',
  },
  {
    name: { en: 'Nick Vujicic', ar: 'نيك فوييتش', es: 'Nick Vujicic', fr: 'Nick Vujicic' },
    condition: { en: 'Born without arms or legs', ar: 'وُلد بدون ذراعين أو ساقين', es: 'Nacido sin brazos ni piernas', fr: 'Né sans bras ni jambes' },
    story: {
      en: 'Born without limbs, Nick struggled with depression and attempted suicide at age 10. He transformed his life through faith and determination, becoming a motivational speaker who has inspired millions worldwide.',
      ar: 'وُلد بدون أطراف، عانى من الاكتئاب وحاول الانتحار في سن العاشرة. حوّل حياته من خلال الإيمان والتصميم وأصبح متحدثاً تحفيزياً ألهم الملايين.',
      es: 'Nacido sin extremidades, Nick luchó contra la depresión. Transformó su vida y se convirtió en orador motivacional.',
      fr: 'Né sans membres, Nick a lutté contre la dépression. Il a transformé sa vie et inspire des millions de personnes.',
    },
    lesson: { en: 'Your limitations don\'t define you. Your attitude does.', ar: 'قيودك لا تحددك. موقفك هو من يحددك.', es: 'Tus limitaciones no te definen.', fr: 'Vos limites ne vous définissent pas.' },
    source: 'https://www.nickvujicic.com/about',
  },
  {
    name: { en: 'Frida Kahlo', ar: 'فريدا كاهلو', es: 'Frida Kahlo', fr: 'Frida Kahlo' },
    condition: { en: 'Polio, severe bus accident, chronic pain', ar: 'شلل أطفال، حادث حافلة خطير، ألم مزمن', es: 'Polio, accidente de autobús, dolor crónico', fr: 'Polio, accident de bus, douleur chronique' },
    story: {
      en: 'Frida Kahlo contracted polio at 6 and survived a devastating bus accident at 18 that left her in chronic pain. She channeled her suffering into art, becoming one of the most influential artists of the 20th century.',
      ar: 'أصيبت بشلل الأطفال في سن السادسة ونجت من حادث حافلة مدمر في 18. حولت معاناتها إلى فن وأصبحت من أكثر الفنانين تأثيراً.',
      es: 'Frida contrajo polio a los 6 años y sobrevivió un accidente devastador. Canalizó su sufrimiento en arte.',
      fr: 'Frida a contracté la polio à 6 ans et a survécu à un accident dévastateur. Elle a canalisé sa souffrance dans l\'art.',
    },
    lesson: { en: 'Pain can be transformed into beauty and meaning.', ar: 'الألم يمكن تحويله إلى جمال ومعنى.', es: 'El dolor puede transformarse en belleza.', fr: 'La douleur peut se transformer en beauté.' },
    source: 'https://www.fridakahlo.org/frida-kahlo-biography.jsp',
  },
  {
    name: { en: 'J.K. Rowling', ar: 'ج.ك. رولينغ', es: 'J.K. Rowling', fr: 'J.K. Rowling' },
    condition: { en: 'Severe depression, poverty, single mother', ar: 'اكتئاب حاد، فقر، أم عزباء', es: 'Depresión severa, pobreza', fr: 'Dépression sévère, pauvreté' },
    story: {
      en: 'Before creating Harry Potter, J.K. Rowling battled severe clinical depression and even contemplated suicide. Living on welfare as a single mother, she turned her darkest period into the fuel for one of the greatest literary achievements ever.',
      ar: 'قبل إنشاء هاري بوتر، عانت رولينغ من اكتئاب سريري حاد وفكرت في الانتحار. عاشت على المساعدات كأم عزباء، وحولت أحلك فتراتها إلى وقود لأحد أعظم الإنجازات الأدبية.',
      es: 'Antes de Harry Potter, Rowling luchó contra la depresión severa. Convirtió su período más oscuro en un logro literario.',
      fr: 'Avant Harry Potter, Rowling a combattu la dépression sévère. Elle a transformé sa période la plus sombre en succès.',
    },
    lesson: { en: 'Rock bottom became the solid foundation on which I rebuilt my life.', ar: 'القاع أصبح الأساس الصلب الذي أعدت بناء حياتي عليه.', es: 'Tocar fondo fue la base sólida para reconstruir mi vida.', fr: 'Toucher le fond est devenu la base solide sur laquelle j\'ai reconstruit ma vie.' },
    source: 'https://www.jkrowling.com/about/',
  },
  {
    name: { en: 'Yusra Mardini', ar: 'يسرا مارديني', es: 'Yusra Mardini', fr: 'Yusra Mardini' },
    condition: { en: 'War refugee, near-drowning at sea', ar: 'لاجئة حرب، كادت تغرق في البحر', es: 'Refugiada de guerra', fr: 'Réfugiée de guerre' },
    story: {
      en: 'Syrian swimmer Yusra Mardini fled war, and when her boat began sinking in the sea with 20 passengers, she jumped in and swam for 3 hours to save everyone. She went on to compete in the Olympics as a refugee athlete.',
      ar: 'السباحة السورية يسرا مارديني فرت من الحرب، وعندما بدأ قاربها بالغرق مع 20 راكباً، قفزت وسبحت لمدة 3 ساعات لإنقاذ الجميع. شاركت لاحقاً في الأولمبياد كرياضية لاجئة.',
      es: 'La nadadora siria Yusra huyó de la guerra y nadó 3 horas para salvar a 20 pasajeros. Compitió en los Juegos Olímpicos.',
      fr: 'La nageuse syrienne Yusra a fui la guerre et nagé 3 heures pour sauver 20 passagers. Elle a participé aux Jeux Olympiques.',
    },
    lesson: { en: 'Your skills and courage can save lives, including your own.', ar: 'مهاراتك وشجاعتك يمكن أن تنقذ أرواحاً، بما فيها حياتك.', es: 'Tus habilidades y coraje pueden salvar vidas.', fr: 'Vos compétences et votre courage peuvent sauver des vies.' },
    source: 'https://www.unhcr.org/yusra-mardini',
  },
];

export default function ResilienceStories() {
  const { t, lang } = useLanguage();

  return (
    <div>
      <h2 style={{ fontSize: '1.8rem', fontWeight: 700, color: '#32325d', margin: '25px 0', textAlign: 'center', position: 'relative' }}>
        {t('resilience.title')}
        <div style={{ position: 'absolute', bottom: '-10px', left: '50%', transform: 'translateX(-50%)', width: '80px', height: '4px', background: '#f5365c', borderRadius: '2px' }}></div>
      </h2>

      <div style={{ background: 'linear-gradient(135deg, #f5365c, #fb6340)', borderRadius: '16px', padding: '20px', marginBottom: '20px', color: 'white', textAlign: 'center' }}>
        <div style={{ fontSize: '2.5rem', marginBottom: '10px' }}>🦋</div>
        <p style={{ opacity: 0.9, fontSize: '0.95rem', lineHeight: 1.6 }}>{t('resilience.desc')}</p>
      </div>

      {stories.map((story, i) => (
        <div key={i} style={{ background: 'white', borderRadius: '16px', padding: '20px', marginBottom: '20px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)', borderLeft: '4px solid #f5365c' }}>
          <h3 style={{ color: '#32325d', marginBottom: '5px' }}>{story.name[lang] || story.name.en}</h3>
          <span style={{ background: '#ffe0e6', color: '#f5365c', padding: '2px 10px', borderRadius: '12px', fontSize: '0.8rem', fontWeight: 600 }}>
            {story.condition[lang] || story.condition.en}
          </span>
          <p style={{ color: '#32325d', lineHeight: 1.7, marginTop: '15px', fontSize: '0.95rem' }}>
            {story.story[lang] || story.story.en}
          </p>
          <div style={{ background: '#f0fdf4', borderRadius: '12px', padding: '12px', borderLeft: '4px solid #2DCE89', marginBottom: '10px' }}>
            <strong style={{ color: '#1a9f6e' }}>💡 {t('resilience.lesson')}:</strong>
            <p style={{ margin: '5px 0 0', color: '#166534', fontStyle: 'italic' }}>{story.lesson[lang] || story.lesson.en}</p>
          </div>
          <a href={story.source} target="_blank" rel="noopener noreferrer" style={{ fontSize: '0.8rem', color: '#8965e0', textDecoration: 'none', fontWeight: 600 }}>
            🔗 {t('resilience.source')}
          </a>
        </div>
      ))}
      <InlineAIChat context="resilience" lang={lang} />
    </div>
  );
}
