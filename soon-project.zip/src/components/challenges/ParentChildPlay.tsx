import { useState, useEffect } from 'react';
import InlineAIChat from '../shared/InlineAIChat';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { useLanguage } from '../../i18n/LanguageContext';

interface PlayMission {
  id: string;
  title: Record<string, string>;
  instructions: Record<string, string>;
  childTask: Record<string, string>;
  reflectionQuestions: Record<string, string[]>;
  category: 'story' | 'feelings' | 'problem-solving' | 'creativity';
  duration: string;
  ageRange: string;
  icon: string;
}

interface CompletedMission {
  missionId: string;
  date: string;
  answers: string[];
  emotionalProgress: number;
  communicationScore: number;
  creativityScore: number;
}

const missions: PlayMission[] = [
  {
    id: 'pm1', icon: '📖', category: 'story', duration: '10-15', ageRange: '6-10',
    title: { en: 'The Story Builder', ar: 'بناء القصة', es: 'Constructor de Historias', fr: 'Constructeur d\'Histoires' },
    instructions: {
      en: 'Sit with your child. Start a story with one sentence, then take turns adding a sentence each. The story should include a character facing a challenge and finding a solution.',
      ar: 'اجلس مع طفلك. ابدأ قصة بجملة واحدة، ثم تبادلا إضافة جملة. يجب أن تتضمن القصة شخصية تواجه تحدياً وتجد حلاً.',
      es: 'Siéntate con tu hijo. Empieza una historia y túrnense añadiendo una oración.',
      fr: 'Asseyez-vous avec votre enfant. Commencez une histoire et alternez les phrases.',
    },
    childTask: {
      en: 'Create characters, describe feelings, and suggest solutions for the story\'s challenge.',
      ar: 'ابتكر شخصيات، صف المشاعر، واقترح حلولاً لتحدي القصة.',
      es: 'Crea personajes y describe sentimientos.',
      fr: 'Créez des personnages et décrivez les sentiments.',
    },
    reflectionQuestions: {
      en: ['What emotion did your child express most during the story?', 'How creative was the solution your child suggested?', 'Did your child show empathy toward the story\'s character?'],
      ar: ['ما المشاعر التي عبر عنها طفلك أكثر أثناء القصة؟', 'ما مدى إبداع الحل الذي اقترحه طفلك؟', 'هل أظهر طفلك تعاطفاً تجاه شخصية القصة؟'],
      es: ['¿Qué emoción expresó más tu hijo?', '¿Qué tan creativa fue su solución?', '¿Mostró empatía?'],
      fr: ['Quelle émotion votre enfant a-t-il exprimée?', 'La solution était-elle créative?', 'A-t-il montré de l\'empathie?'],
    },
  },
  {
    id: 'pm2', icon: '🎭', category: 'feelings', duration: '10-15', ageRange: '6-10',
    title: { en: 'Feelings Detective', ar: 'محقق المشاعر', es: 'Detective de Sentimientos', fr: 'Détective des Sentiments' },
    instructions: {
      en: 'Show your child different facial expressions (happy, sad, surprised, angry, scared). Ask them to guess the emotion, then share a time they felt that way. Validate their feelings.',
      ar: 'أظهر لطفلك تعبيرات وجه مختلفة. اطلب منه تخمين المشاعر، ثم شارك وقتاً شعر فيه بهذا الشعور.',
      es: 'Muestra expresiones faciales y pide a tu hijo que identifique las emociones.',
      fr: 'Montrez des expressions faciales et demandez à votre enfant d\'identifier les émotions.',
    },
    childTask: {
      en: 'Identify emotions from facial expressions, share personal experiences with those emotions, and practice expressing feelings safely.',
      ar: 'حدد المشاعر من تعبيرات الوجه، شارك تجاربك الشخصية، وتدرب على التعبير عن مشاعرك بأمان.',
      es: 'Identifica emociones y comparte experiencias personales.',
      fr: 'Identifiez les émotions et partagez des expériences.',
    },
    reflectionQuestions: {
      en: ['How easily did your child identify emotions?', 'Did they share personal feelings openly?', 'What emotion seemed most challenging for them to discuss?'],
      ar: ['ما مدى سهولة تعرف طفلك على المشاعر؟', 'هل شاركوا مشاعرهم بصراحة؟', 'أي مشاعر بدت الأصعب في مناقشتها؟'],
      es: ['¿Identificó las emociones fácilmente?', '¿Compartió sentimientos abiertamente?', '¿Qué emoción fue la más difícil?'],
      fr: ['A-t-il identifié les émotions facilement?', 'A-t-il partagé ses sentiments?', 'Quelle émotion était la plus difficile?'],
    },
  },
  {
    id: 'pm3', icon: '🧩', category: 'problem-solving', duration: '10-15', ageRange: '6-10',
    title: { en: 'The Problem Solver', ar: 'حلال المشاكل', es: 'El Solucionador', fr: 'Le Résolveur de Problèmes' },
    instructions: {
      en: 'Present a simple real-life scenario (e.g., "Your friend is sad because someone said something mean"). Ask your child to think of 3 different solutions and discuss which would be best and why.',
      ar: 'قدم سيناريو واقعي بسيط (مثل: "صديقك حزين لأن أحداً قال شيئاً مؤذياً"). اطلب من طفلك التفكير في 3 حلول مختلفة.',
      es: 'Presenta un escenario y pide 3 soluciones diferentes.',
      fr: 'Présentez un scénario et demandez 3 solutions différentes.',
    },
    childTask: {
      en: 'Think of creative solutions, evaluate consequences, and choose the best approach while explaining their reasoning.',
      ar: 'فكر في حلول إبداعية، قيم العواقب، واختر أفضل نهج مع شرح منطقك.',
      es: 'Piensa en soluciones creativas y evalúa consecuencias.',
      fr: 'Pensez à des solutions créatives et évaluez les conséquences.',
    },
    reflectionQuestions: {
      en: ['How many solutions did your child generate?', 'Did they consider other people\'s feelings in their solutions?', 'How confident were they in their chosen solution?'],
      ar: ['كم حلاً ابتكر طفلك؟', 'هل أخذوا بعين الاعتبار مشاعر الآخرين؟', 'ما مدى ثقتهم في الحل المختار؟'],
      es: ['¿Cuántas soluciones generó?', '¿Consideró los sentimientos de otros?', '¿Qué tan seguro estaba?'],
      fr: ['Combien de solutions a-t-il trouvées?', 'A-t-il considéré les sentiments des autres?', 'Était-il confiant?'],
    },
  },
  {
    id: 'pm4', icon: '🎨', category: 'creativity', duration: '15', ageRange: '6-10',
    title: { en: 'Draw Your Feelings', ar: 'ارسم مشاعرك', es: 'Dibuja Tus Sentimientos', fr: 'Dessinez Vos Sentiments' },
    instructions: {
      en: 'Give your child paper and colors. Ask them to draw how they feel today using colors, shapes, and images — no words needed. Then discuss the drawing together.',
      ar: 'أعط طفلك ورقة وألوان. اطلب منه رسم ما يشعر به اليوم باستخدام الألوان والأشكال — بدون كلمات. ثم ناقشوا الرسم معاً.',
      es: 'Dale papel y colores para dibujar cómo se siente hoy.',
      fr: 'Donnez-lui du papier et des couleurs pour dessiner ses sentiments.',
    },
    childTask: {
      en: 'Express feelings through art, explain their drawing, and explore emotions in a safe, creative way.',
      ar: 'عبر عن مشاعرك من خلال الفن، اشرح رسمتك، واستكشف مشاعرك بطريقة آمنة وإبداعية.',
      es: 'Expresa sentimientos a través del arte.',
      fr: 'Exprimez les sentiments à travers l\'art.',
    },
    reflectionQuestions: {
      en: ['What colors did your child use most?', 'How well did they explain their drawing?', 'Did the activity help them open up about their feelings?'],
      ar: ['ما الألوان التي استخدمها طفلك أكثر؟', 'ما مدى جودة شرحه لرسمته؟', 'هل ساعدهم النشاط في الانفتاح عن مشاعرهم؟'],
      es: ['¿Qué colores usó más?', '¿Explicó bien su dibujo?', '¿Le ayudó a abrirse?'],
      fr: ['Quelles couleurs a-t-il utilisées?', 'A-t-il bien expliqué son dessin?', 'Cela l\'a-t-il aidé à s\'ouvrir?'],
    },
  },
];

const categoryIcons = { story: '📖', feelings: '🎭', 'problem-solving': '🧩', creativity: '🎨' };

export default function ParentChildPlay() {
  const { t, lang } = useLanguage();
  const [completed, setCompleted] = useLocalStorage<CompletedMission[]>('soon-parent-child-missions', []);
  const [activeMission, setActiveMission] = useState<PlayMission | null>(null);
  const [answers, setAnswers] = useState<string[]>(['', '', '']);
  const [scores, setScores] = useState({ emotional: 3, communication: 3, creativity: 3 });

  // Get this week's mission
  const weekNumber = Math.floor((Date.now() - new Date('2024-01-01').getTime()) / (7 * 24 * 60 * 60 * 1000));
  const weekMission = missions[weekNumber % missions.length];
  const thisWeekCompleted = completed.some(c => {
    const d = new Date(c.date);
    const now = new Date();
    const weekStart = new Date(now); weekStart.setDate(now.getDate() - now.getDay());
    return c.missionId === weekMission.id && d >= weekStart;
  });

  const completeMission = () => {
    if (!activeMission) return;
    const entry: CompletedMission = {
      missionId: activeMission.id, date: new Date().toISOString(),
      answers, emotionalProgress: scores.emotional, communicationScore: scores.communication, creativityScore: scores.creativity,
    };
    setCompleted([entry, ...completed]);
    setActiveMission(null); setAnswers(['', '', '']);
  };

  const totalCompleted = completed.length;
  const avgEmotional = completed.length > 0 ? (completed.reduce((s, c) => s + c.emotionalProgress, 0) / completed.length).toFixed(1) : '0';
  const avgCommunication = completed.length > 0 ? (completed.reduce((s, c) => s + c.communicationScore, 0) / completed.length).toFixed(1) : '0';
  const avgCreativity = completed.length > 0 ? (completed.reduce((s, c) => s + c.creativityScore, 0) / completed.length).toFixed(1) : '0';

  const labels = {
    en: { title: 'Parent-Child Play Missions', subtitle: 'Play-based learning for emotional growth (ages 6-10)', thisWeek: 'This Week\'s Mission', start: 'Start Mission', completed: 'Completed!', dashboard: 'Growth Dashboard', missionsCompleted: 'Missions', emotional: 'Emotional Expression', communication: 'Communication', creativity: 'Creativity', reflection: 'Reflection Questions', submit: 'Complete Mission', score: 'Rate 1-5', history: 'Previous Sessions', childTask: 'Child\'s Task', instructions: 'Parent Instructions', duration: 'min' },
    ar: { title: 'مهمات اللعب بين الوالدين والطفل', subtitle: 'التعلم القائم على اللعب للنمو العاطفي (6-10 سنوات)', thisWeek: 'مهمة هذا الأسبوع', start: 'ابدأ المهمة', completed: 'مكتملة!', dashboard: 'لوحة النمو', missionsCompleted: 'المهمات', emotional: 'التعبير العاطفي', communication: 'التواصل', creativity: 'الإبداع', reflection: 'أسئلة التفكير', submit: 'أكمل المهمة', score: 'قيّم 1-5', history: 'الجلسات السابقة', childTask: 'مهمة الطفل', instructions: 'تعليمات الوالد', duration: 'دقيقة' },
    es: { title: 'Misiones de Juego Padres-Hijos', subtitle: 'Aprendizaje basado en el juego (6-10 años)', thisWeek: 'Misión de Esta Semana', start: 'Iniciar', completed: '¡Completada!', dashboard: 'Panel de Crecimiento', missionsCompleted: 'Misiones', emotional: 'Expresión Emocional', communication: 'Comunicación', creativity: 'Creatividad', reflection: 'Preguntas de Reflexión', submit: 'Completar', score: 'Califica 1-5', history: 'Sesiones Anteriores', childTask: 'Tarea del Niño', instructions: 'Instrucciones', duration: 'min' },
    fr: { title: 'Missions de Jeu Parent-Enfant', subtitle: 'Apprentissage par le jeu (6-10 ans)', thisWeek: 'Mission de la Semaine', start: 'Commencer', completed: 'Terminée!', dashboard: 'Tableau de Croissance', missionsCompleted: 'Missions', emotional: 'Expression Émotionnelle', communication: 'Communication', creativity: 'Créativité', reflection: 'Questions de Réflexion', submit: 'Terminer', score: 'Note 1-5', history: 'Sessions Précédentes', childTask: 'Tâche de l\'Enfant', instructions: 'Instructions', duration: 'min' },
  };
  const l = labels[lang] || labels.en;

  const renderStars = (value: number, onChange: (v: number) => void) => (
    <div style={{ display: 'flex', gap: '6px' }}>
      {[1, 2, 3, 4, 5].map(v => (
        <button key={v} onClick={() => onChange(v)} style={{
          width: 32, height: 32, borderRadius: '50%', border: 'none', cursor: 'pointer',
          background: v <= value ? '#fbb140' : '#eee', color: v <= value ? 'white' : '#aaa',
          fontSize: '0.9rem', fontWeight: 700, transition: 'all 0.2s',
        }}>⭐</button>
      ))}
    </div>
  );

  if (activeMission) {
    const q = activeMission.reflectionQuestions[lang] || activeMission.reflectionQuestions.en;
    return (
      <div>
        <button onClick={() => setActiveMission(null)} style={{ background: 'none', border: 'none', color: '#2DCE89', fontSize: '1.2rem', cursor: 'pointer', marginBottom: '10px' }}>
          <i className="fas fa-arrow-left"></i> {lang === 'ar' ? 'رجوع' : 'Back'}
        </button>
        <div style={{ background: 'linear-gradient(135deg, #ff9a56, #ff6b6b)', borderRadius: '16px', padding: '20px', color: 'white', textAlign: 'center', marginBottom: '20px' }}>
          <span style={{ fontSize: '3rem' }}>{activeMission.icon}</span>
          <h3 style={{ color: 'white', margin: '10px 0 5px' }}>{activeMission.title[lang] || activeMission.title.en}</h3>
          <span style={{ opacity: 0.9, fontSize: '0.85rem' }}>⏱ {activeMission.duration} {l.duration}</span>
        </div>

        <div style={{ background: 'white', borderRadius: '16px', padding: '18px', marginBottom: '15px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
          <h4 style={{ color: '#ff6b6b', marginBottom: '8px' }}>👨‍👩‍👧 {l.instructions}</h4>
          <p style={{ color: '#32325d', fontSize: '0.9rem', lineHeight: 1.6 }}>{activeMission.instructions[lang] || activeMission.instructions.en}</p>
        </div>

        <div style={{ background: 'white', borderRadius: '16px', padding: '18px', marginBottom: '15px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
          <h4 style={{ color: '#fbb140', marginBottom: '8px' }}>🧒 {l.childTask}</h4>
          <p style={{ color: '#32325d', fontSize: '0.9rem', lineHeight: 1.6 }}>{activeMission.childTask[lang] || activeMission.childTask.en}</p>
        </div>

        <div style={{ background: 'white', borderRadius: '16px', padding: '18px', marginBottom: '15px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
          <h4 style={{ color: '#8965e0', marginBottom: '12px' }}>📝 {l.reflection}</h4>
          {q.map((question, i) => (
            <div key={i} style={{ marginBottom: '12px' }}>
              <p style={{ color: '#32325d', fontSize: '0.85rem', fontWeight: 600, marginBottom: '6px' }}>{i + 1}. {question}</p>
              <textarea value={answers[i]} onChange={e => { const a = [...answers]; a[i] = e.target.value; setAnswers(a); }}
                style={{ width: '100%', height: '60px', border: '1px solid #ddd', borderRadius: '10px', padding: '10px', fontFamily: 'Poppins, sans-serif', resize: 'vertical', outline: 'none', boxSizing: 'border-box', fontSize: '0.85rem' }} />
            </div>
          ))}
        </div>

        <div style={{ background: 'white', borderRadius: '16px', padding: '18px', marginBottom: '15px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
          <h4 style={{ color: '#2DCE89', marginBottom: '12px' }}>📊 {l.score}</h4>
          <div style={{ marginBottom: '12px' }}><span style={{ fontSize: '0.85rem', color: '#32325d', fontWeight: 600 }}>🎭 {l.emotional}</span>{renderStars(scores.emotional, v => setScores({ ...scores, emotional: v }))}</div>
          <div style={{ marginBottom: '12px' }}><span style={{ fontSize: '0.85rem', color: '#32325d', fontWeight: 600 }}>💬 {l.communication}</span>{renderStars(scores.communication, v => setScores({ ...scores, communication: v }))}</div>
          <div><span style={{ fontSize: '0.85rem', color: '#32325d', fontWeight: 600 }}>🎨 {l.creativity}</span>{renderStars(scores.creativity, v => setScores({ ...scores, creativity: v }))}</div>
        </div>

        <button onClick={completeMission} style={{ background: 'linear-gradient(135deg, #ff9a56, #ff6b6b)', color: 'white', border: 'none', borderRadius: '25px', padding: '14px', fontWeight: 700, cursor: 'pointer', width: '100%', fontFamily: 'Poppins, sans-serif', fontSize: '1rem' }}>
          ✅ {l.submit}
        </button>
      </div>
    );
  }

  return (
    <div>
      <h2 style={{ fontSize: '1.6rem', fontWeight: 700, color: '#32325d', margin: '25px 0', textAlign: 'center', position: 'relative' }}>
        🎮 {l.title}
        <div style={{ position: 'absolute', bottom: '-10px', left: '50%', transform: 'translateX(-50%)', width: '80px', height: '4px', background: '#ff6b6b', borderRadius: '2px' }}></div>
      </h2>
      <p style={{ textAlign: 'center', color: '#8898aa', fontSize: '0.85rem', marginBottom: '20px' }}>{l.subtitle}</p>

      {/* This Week's Mission */}
      <div style={{ background: 'linear-gradient(135deg, #ff9a56, #ff6b6b)', borderRadius: '16px', padding: '22px', marginBottom: '20px', color: 'white', textAlign: 'center', boxShadow: '0 6px 20px rgba(0,0,0,0.1)' }}>
        <span style={{ fontSize: '3rem' }}>{weekMission.icon}</span>
        <h3 style={{ color: 'white', margin: '10px 0 5px' }}>{l.thisWeek}</h3>
        <h4 style={{ color: 'white', margin: '0 0 10px', opacity: 0.95 }}>{weekMission.title[lang] || weekMission.title.en}</h4>
        <p style={{ opacity: 0.9, fontSize: '0.85rem', margin: '0 0 15px' }}>⏱ {weekMission.duration} {l.duration} | 👶 {weekMission.ageRange}</p>
        {thisWeekCompleted ? (
          <span style={{ background: 'rgba(255,255,255,0.3)', padding: '8px 20px', borderRadius: '20px', fontWeight: 600 }}>✅ {l.completed}</span>
        ) : (
          <button onClick={() => setActiveMission(weekMission)} style={{ background: 'white', color: '#ff6b6b', border: 'none', borderRadius: '25px', padding: '12px 30px', fontWeight: 700, cursor: 'pointer', fontFamily: 'Poppins, sans-serif', fontSize: '1rem' }}>
            🎯 {l.start}
          </button>
        )}
      </div>

      {/* Growth Dashboard */}
      <div style={{ background: 'white', borderRadius: '16px', padding: '20px', marginBottom: '20px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
        <h4 style={{ color: '#32325d', marginBottom: '15px', textAlign: 'center' }}>📊 {l.dashboard}</h4>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
          <div style={{ background: '#fff5f5', borderRadius: '12px', padding: '15px', textAlign: 'center' }}>
            <div style={{ fontSize: '1.8rem', fontWeight: 700, color: '#ff6b6b' }}>{totalCompleted}</div>
            <div style={{ fontSize: '0.75rem', color: '#ff6b6b', fontWeight: 600 }}>🎮 {l.missionsCompleted}</div>
          </div>
          <div style={{ background: '#f0f5ff', borderRadius: '12px', padding: '15px', textAlign: 'center' }}>
            <div style={{ fontSize: '1.8rem', fontWeight: 700, color: '#8965e0' }}>{avgEmotional}</div>
            <div style={{ fontSize: '0.75rem', color: '#8965e0', fontWeight: 600 }}>🎭 {l.emotional}</div>
          </div>
          <div style={{ background: '#f0fdf4', borderRadius: '12px', padding: '15px', textAlign: 'center' }}>
            <div style={{ fontSize: '1.8rem', fontWeight: 700, color: '#2DCE89' }}>{avgCommunication}</div>
            <div style={{ fontSize: '0.75rem', color: '#2DCE89', fontWeight: 600 }}>💬 {l.communication}</div>
          </div>
          <div style={{ background: '#fff8f0', borderRadius: '12px', padding: '15px', textAlign: 'center' }}>
            <div style={{ fontSize: '1.8rem', fontWeight: 700, color: '#fbb140' }}>{avgCreativity}</div>
            <div style={{ fontSize: '0.75rem', color: '#fbb140', fontWeight: 600 }}>🎨 {l.creativity}</div>
          </div>
        </div>
        {/* Simple visual progress bars */}
        {totalCompleted > 0 && (
          <div style={{ marginTop: '15px' }}>
            {[
              { label: l.emotional, value: Number(avgEmotional), color: '#8965e0' },
              { label: l.communication, value: Number(avgCommunication), color: '#2DCE89' },
              { label: l.creativity, value: Number(avgCreativity), color: '#fbb140' },
            ].map((item, i) => (
              <div key={i} style={{ marginBottom: '8px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', color: '#32325d', marginBottom: '3px' }}>
                  <span>{item.label}</span><span style={{ fontWeight: 600 }}>{item.value}/5</span>
                </div>
                <div style={{ height: '8px', background: '#f0f0f0', borderRadius: '4px', overflow: 'hidden' }}>
                  <div style={{ height: '100%', width: `${(item.value / 5) * 100}%`, background: item.color, borderRadius: '4px', transition: 'width 0.5s ease' }}></div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* All Missions */}
      <div style={{ background: 'white', borderRadius: '16px', padding: '15px', marginBottom: '20px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
        <h4 style={{ color: '#32325d', marginBottom: '12px' }}>🎯 {lang === 'ar' ? 'جميع المهمات' : 'All Missions'}</h4>
        {missions.map(m => {
          const done = completed.some(c => c.missionId === m.id);
          return (
            <div key={m.id} onClick={() => !done && setActiveMission(m)} style={{
              display: 'flex', alignItems: 'center', gap: '12px', padding: '12px', borderRadius: '12px', marginBottom: '8px',
              background: done ? '#f0fdf4' : '#fafafa', border: done ? '2px solid #2DCE89' : '2px solid transparent',
              cursor: done ? 'default' : 'pointer', opacity: done ? 0.7 : 1,
            }}>
              <span style={{ fontSize: '1.8rem' }}>{m.icon}</span>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600, color: '#32325d', fontSize: '0.9rem' }}>{m.title[lang] || m.title.en}</div>
                <div style={{ fontSize: '0.75rem', color: '#8898aa' }}>⏱ {m.duration} {l.duration} | 👶 {m.ageRange}</div>
              </div>
              {done && <span style={{ color: '#2DCE89', fontSize: '1.2rem' }}>✅</span>}
            </div>
          );
        })}
      </div>

      {/* History */}
      {completed.length > 0 && (
        <div style={{ background: 'white', borderRadius: '16px', padding: '15px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
          <h4 style={{ color: '#32325d', marginBottom: '10px' }}>📋 {l.history}</h4>
          {completed.slice(0, 10).map((c, i) => {
            const m = missions.find(m => m.id === c.missionId);
            return (
              <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 0', borderBottom: '1px solid #f0f0f0', fontSize: '0.8rem' }}>
                <span>{m?.icon} {m?.title[lang] || m?.title.en}</span>
                <span style={{ color: '#8898aa' }}>{new Date(c.date).toLocaleDateString()}</span>
                <span style={{ color: '#fbb140' }}>⭐ {((c.emotionalProgress + c.communicationScore + c.creativityScore) / 3).toFixed(1)}</span>
              </div>
            );
          })}
        </div>
      )}
      <InlineAIChat context="parent-child" lang={lang} />
    </div>
  );
}
