import { useState } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import InlineAIChat from '../shared/InlineAIChat';
import FastingTracker from './FastingTracker';

interface DetoxChallengePageProps {
  onBack: () => void;
}

interface DetoxDay {
  date: string;
  sugarFree: boolean;
  dopamineFree: boolean;
  screenTimeGoal: number;
  actualScreenTime: number;
  note: string;
}

const newDay = (date: string, overrides?: Partial<DetoxDay>): DetoxDay => ({
  date, sugarFree: false, dopamineFree: false, screenTimeGoal: 60, actualScreenTime: 0, note: '', ...overrides,
});

export default function DetoxChallengePage({ onBack }: DetoxChallengePageProps) {
  const { lang } = useLanguage();
  const isAr = lang === 'ar';
  const [days, setDays] = useLocalStorage<DetoxDay[]>('soon-detox-days', []);
  const [note, setNote] = useState('');
  const [showHistory, setShowHistory] = useState(false);
  const [screenInput, setScreenInput] = useState('');

  const today = new Date().toDateString();
  const todayEntry = days.find(d => d.date === today);

  const toggleToday = (field: 'sugarFree' | 'dopamineFree') => {
    if (todayEntry) {
      setDays(days.map(d => d.date === today ? { ...d, [field]: !d[field] } : d));
    } else {
      setDays([...days, newDay(today, { [field]: true })]);
    }
  };

  const logScreenTime = () => {
    const mins = parseInt(screenInput);
    if (isNaN(mins) || mins < 0) return;
    if (todayEntry) {
      setDays(days.map(d => d.date === today ? { ...d, actualScreenTime: mins } : d));
    } else {
      setDays([...days, newDay(today, { actualScreenTime: mins })]);
    }
    setScreenInput('');
  };

  const setGoal = (mins: number) => {
    if (todayEntry) {
      setDays(days.map(d => d.date === today ? { ...d, screenTimeGoal: mins } : d));
    } else {
      setDays([...days, newDay(today, { screenTimeGoal: mins })]);
    }
  };

  const saveNote = () => {
    if (!note.trim()) return;
    if (todayEntry) {
      setDays(days.map(d => d.date === today ? { ...d, note: note.trim() } : d));
    } else {
      setDays([...days, newDay(today, { note: note.trim() })]);
    }
    setNote('');
  };

  const sorted = [...days].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  let sugarStreak = 0, dopamineStreak = 0;
  for (const d of sorted) { if (d.sugarFree) sugarStreak++; else break; }
  for (const d of sorted) { if (d.dopamineFree) dopamineStreak++; else break; }

  const screenGoal = todayEntry?.screenTimeGoal || 60;
  const screenActual = todayEntry?.actualScreenTime || 0;
  const screenSuccess = screenActual > 0 && screenActual <= screenGoal;

  const sugarTips = isAr ? [
    '🍬 السكر يسبب ارتفاعاً مؤقتاً في الطاقة يتبعه انخفاض حاد يؤثر على المزاج',
    '🧠 الإفراط في السكر يضعف الذاكرة والتركيز ويزيد القلق',
    '💪 بعد 3 أيام بدون سكر مضاف، تبدأ براعم التذوق بالتعافي',
    '🌿 استبدل السكر بالفواكه الطبيعية والتمر',
    '😴 السكر قبل النوم يسبب اضطرابات في النوم وكوابيس',
  ] : [
    '🍬 Sugar causes temporary energy spikes followed by crashes that affect mood',
    '🧠 Excess sugar weakens memory, focus, and increases anxiety',
    '💪 After 3 days without added sugar, taste buds start recovering',
    '🌿 Replace sugar with natural fruits and dates',
    '😴 Sugar before bed causes sleep disturbances and nightmares',
  ];

  const algorithmFacts = isAr ? [
    { icon: '🎯', title: 'سرقة الانتباه', desc: 'الخوارزميات مصممة لإبقائك تتصفح أطول فترة ممكنة. كل إشعار وكل فيديو قصير هو فخ للدوبامين.' },
    { icon: '🧊', title: 'تجميد التعاطف', desc: 'التعرض المستمر للمحتوى السلبي والعنيف يُبلّد مشاعر التعاطف تدريجياً. دماغك يتعلم "اللامبالاة" كآلية دفاع.' },
    { icon: '🔄', title: 'حلقة الإدمان', desc: 'التصفح اللانهائي → دوبامين مؤقت → ملل → تصفح أكثر. الخوارزمية تعرف نقاط ضعفك أكثر منك.' },
    { icon: '🪞', title: 'غرفة الصدى', desc: 'الخوارزميات تحبسك في فقاعة تؤكد معتقداتك فقط، مما يقلل التفكير النقدي والتعاطف مع المختلفين.' },
    { icon: '⏰', title: 'سرقة الوقت الثمين', desc: 'متوسط استخدام السوشال ميديا 2.5 ساعة يومياً = 38 يوماً كاملاً سنوياً! وقت كان يمكن أن يُستثمر في نمو حقيقي.' },
    { icon: '😶', title: 'المقارنة السامة', desc: 'الخوارزمية تعرض لك حياة "مثالية" مزيفة تجعلك تشعر بالنقص. الواقع: 90% من المحتوى مُعدّل ومُبالغ فيه.' },
  ] : [
    { icon: '🎯', title: 'Attention Theft', desc: 'Algorithms are designed to keep you scrolling as long as possible. Every notification is a dopamine trap.' },
    { icon: '🧊', title: 'Empathy Freeze', desc: 'Constant exposure to negative content gradually numbs your empathy. Your brain learns "indifference" as a defense mechanism.' },
    { icon: '🔄', title: 'Addiction Loop', desc: 'Endless scrolling → temporary dopamine → boredom → more scrolling. The algorithm knows your weaknesses better than you.' },
    { icon: '🪞', title: 'Echo Chamber', desc: 'Algorithms trap you in a bubble that only confirms your beliefs, reducing critical thinking and empathy for others.' },
    { icon: '⏰', title: 'Stolen Time', desc: 'Average social media use: 2.5h/day = 38 full days/year! Time that could fuel real growth.' },
    { icon: '😶', title: 'Toxic Comparison', desc: 'Algorithms show you "perfect" fake lives making you feel inadequate. Reality: 90% of content is edited and exaggerated.' },
  ];

  const healthyAlternatives = isAr ? [
    { emoji: '📖', text: 'اقرأ كتاباً حقيقياً بدلاً من التصفح' },
    { emoji: '🚶', text: 'امشِ 30 دقيقة في الطبيعة' },
    { emoji: '🎨', text: 'مارس هواية إبداعية (رسم، كتابة، موسيقى)' },
    { emoji: '👥', text: 'تحدث وجهاً لوجه مع شخص تحبه' },
    { emoji: '🧘', text: 'تأمل 10 دقائق واستمع لأنفاسك' },
    { emoji: '✍️', text: 'اكتب في دفتر يومياتك' },
    { emoji: '🐾', text: 'اقضِ وقتاً مع حيوانك الأليف أو حيوانات الشارع' },
    { emoji: '🌱', text: 'ازرع نبتة واعتنِ بها' },
  ] : [
    { emoji: '📖', text: 'Read a real book instead of scrolling' },
    { emoji: '🚶', text: 'Walk 30 minutes in nature' },
    { emoji: '🎨', text: 'Practice a creative hobby (drawing, writing, music)' },
    { emoji: '👥', text: 'Have a face-to-face conversation with someone you love' },
    { emoji: '🧘', text: 'Meditate 10 minutes and listen to your breath' },
    { emoji: '✍️', text: 'Write in your journal' },
    { emoji: '🐾', text: 'Spend time with your pet or street animals' },
    { emoji: '🌱', text: 'Plant something and care for it' },
  ];

  const goalOptions = [30, 60, 90, 120];

  return (
    <div>
      <div style={{ position: 'relative', textAlign: 'center', padding: '15px 0' }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', fontSize: '1.5rem', color: '#e11d48', position: 'absolute', left: '20px', top: '20px', cursor: 'pointer' }}>
          <i className="fas fa-arrow-left"></i>
        </button>
        <h2 style={{ color: '#32325d', fontWeight: 700, fontSize: '1.3rem' }}>
          {isAr ? '🚫 تحدي الامتناع' : '🚫 Detox Challenge'}
        </h2>
        <p style={{ color: '#8898aa', fontSize: '0.85rem', margin: '5px 0 0' }}>
          {isAr ? 'حرر عقلك وجسدك من السكر والدوبامين الزائف' : 'Free your mind & body from sugar and artificial dopamine'}
        </p>
      </div>

      {/* ========== ALGORITHM AWARENESS SECTION ========== */}
      <div style={{ background: 'linear-gradient(135deg, #0f172a, #1e293b)', borderRadius: '20px', padding: '22px', margin: '15px 0', boxShadow: '0 8px 25px rgba(15,23,42,0.3)', color: 'white' }}>
        <h3 style={{ textAlign: 'center', marginBottom: '6px', fontSize: '1.15rem' }}>
          ⚠️ {isAr ? 'كيف تسرقك الخوارزميات؟' : 'How Algorithms Steal From You'}
        </h3>
        <p style={{ textAlign: 'center', fontSize: '0.78rem', color: '#94a3b8', marginBottom: '18px' }}>
          {isAr ? 'أثمن مواردك: الانتباه والتعاطف — والخوارزميات تريدهما' : 'Your most precious resources: Attention & Empathy — algorithms want them'}
        </p>
        {algorithmFacts.map((fact, i) => (
          <div key={i} style={{ background: 'rgba(255,255,255,0.07)', borderRadius: '14px', padding: '14px', marginBottom: '10px', borderLeft: '4px solid #f59e0b' }}>
            <div style={{ fontWeight: 700, fontSize: '0.95rem', marginBottom: '4px' }}>
              {fact.icon} {fact.title}
            </div>
            <p style={{ fontSize: '0.8rem', color: '#cbd5e1', margin: 0, lineHeight: 1.5 }}>{fact.desc}</p>
          </div>
        ))}
      </div>

      {/* ========== SCREEN TIME TRACKER ========== */}
      <div style={{ background: 'linear-gradient(135deg, #fefce8, #fef9c3)', borderRadius: '16px', padding: '20px', margin: '15px 0', boxShadow: '0 4px 15px rgba(234,179,8,0.15)', border: '1px solid #fde68a' }}>
        <h3 style={{ color: '#92400e', marginBottom: '12px', fontSize: '1.05rem', textAlign: 'center' }}>
          📱 {isAr ? 'متتبع وقت الشاشة اليومي' : 'Daily Screen Time Tracker'}
        </h3>

        {/* Goal selector */}
        <p style={{ color: '#92400e', fontSize: '0.82rem', fontWeight: 600, marginBottom: '8px' }}>
          {isAr ? 'هدفك اليوم (دقائق):' : 'Your goal today (minutes):'}
        </p>
        <div style={{ display: 'flex', gap: '8px', marginBottom: '14px', justifyContent: 'center' }}>
          {goalOptions.map(g => (
            <button key={g} onClick={() => setGoal(g)} style={{
              background: screenGoal === g ? '#f59e0b' : 'white',
              color: screenGoal === g ? 'white' : '#92400e',
              border: `2px solid ${screenGoal === g ? '#f59e0b' : '#fde68a'}`,
              borderRadius: '20px', padding: '6px 16px', fontWeight: 700, cursor: 'pointer', fontSize: '0.85rem',
              transition: 'all 0.2s',
            }}>
              {g}{isAr ? 'د' : 'm'}
            </button>
          ))}
        </div>

        {/* Log actual */}
        <div style={{ display: 'flex', gap: '8px', marginBottom: '10px' }}>
          <input type="number" value={screenInput} onChange={e => setScreenInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && logScreenTime()}
            placeholder={isAr ? 'كم دقيقة استخدمت السوشال؟' : 'Minutes on social media today?'}
            style={{ flexGrow: 1, padding: '10px 15px', border: '2px solid #fde68a', borderRadius: '25px', fontSize: '0.9rem', outline: 'none', fontFamily: 'Poppins, sans-serif', background: 'white' }}
          />
          <button onClick={logScreenTime} style={{ background: '#f59e0b', color: 'white', border: 'none', borderRadius: '50%', width: 40, height: 40, cursor: 'pointer', flexShrink: 0, fontWeight: 700 }}>
            <i className="fas fa-check"></i>
          </button>
        </div>

        {screenActual > 0 && (
          <div style={{
            textAlign: 'center', padding: '12px', borderRadius: '14px', fontWeight: 700,
            background: screenSuccess ? 'linear-gradient(135deg, #dcfce7, #bbf7d0)' : 'linear-gradient(135deg, #fef2f2, #fecaca)',
            color: screenSuccess ? '#166534' : '#991b1b', fontSize: '0.95rem',
          }}>
            {screenSuccess
              ? (isAr ? `🎉 ممتاز! ${screenActual} دقيقة فقط من أصل ${screenGoal}. أنت تسترد انتباهك!` : `🎉 Great! Only ${screenActual}m out of ${screenGoal}m. You're reclaiming attention!`)
              : (isAr ? `📱 ${screenActual} دقيقة — تجاوزت هدفك (${screenGoal}). غداً يمكنك أن تكون أفضل!` : `📱 ${screenActual}m — exceeded goal (${screenGoal}m). Tomorrow you can do better!`)}
          </div>
        )}
      </div>

      {/* ========== HEALTHY ALTERNATIVES ========== */}
      <div style={{ background: 'linear-gradient(135deg, #ecfdf5, #d1fae5)', borderRadius: '16px', padding: '20px', margin: '15px 0', boxShadow: '0 4px 15px rgba(16,185,129,0.1)' }}>
        <h3 style={{ color: '#065f46', marginBottom: '12px', fontSize: '1.05rem', textAlign: 'center' }}>
          🌿 {isAr ? 'بدائل صحية بدلاً من التصفح' : 'Healthy Alternatives to Scrolling'}
        </h3>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
          {healthyAlternatives.map((alt, i) => (
            <div key={i} style={{ background: 'rgba(255,255,255,0.7)', borderRadius: '12px', padding: '10px', textAlign: 'center', fontSize: '0.8rem', color: '#065f46', fontWeight: 500 }}>
              <div style={{ fontSize: '1.4rem', marginBottom: '4px' }}>{alt.emoji}</div>
              {alt.text}
            </div>
          ))}
        </div>
      </div>

      {/* ========== DOPAMINE DETOX TOGGLE ========== */}
      <div style={{ background: 'linear-gradient(135deg, #f5f3ff, #ede9fe)', borderRadius: '16px', padding: '20px', margin: '15px 0', boxShadow: '0 4px 15px rgba(99,102,241,0.1)' }}>
        <h3 style={{ color: '#6366f1', marginBottom: '12px', fontSize: '1.1rem' }}>
          🧠 {isAr ? 'تحدي صيام الدوبامين' : 'Dopamine Fasting Challenge'}
        </h3>
        <p style={{ color: '#6b7280', fontSize: '0.82rem', marginBottom: '12px' }}>
          {isAr ? 'امتنع عن: سوشال ميديا، ألعاب، أخبار، أفلام مفرطة، وجبات سريعة' : 'Abstain from: social media, games, news, excessive streaming, junk food'}
        </p>
        <button onClick={() => toggleToday('dopamineFree')} style={{
          background: todayEntry?.dopamineFree ? 'linear-gradient(135deg, #6366f1, #4f46e5)' : 'white',
          color: todayEntry?.dopamineFree ? 'white' : '#6366f1',
          border: todayEntry?.dopamineFree ? 'none' : '2px solid #6366f1',
          borderRadius: '25px', padding: '12px 24px', fontWeight: 700, cursor: 'pointer',
          width: '100%', fontSize: '1rem', marginBottom: '12px', fontFamily: 'Poppins, sans-serif',
          transition: 'all 0.3s ease',
        }}>
          {todayEntry?.dopamineFree
            ? (isAr ? '✅ يوم صيام دوبامين!' : '✅ Dopamine detox today!')
            : (isAr ? 'سجّل يوم صيام الدوبامين' : 'Log dopamine detox day')}
        </button>
        {dopamineStreak > 0 && (
          <div style={{ textAlign: 'center', color: '#6366f1', fontWeight: 700, fontSize: '1.2rem', margin: '8px 0' }}>
            🔥 {dopamineStreak} {isAr ? 'يوم متتالي!' : 'day streak!'}
          </div>
        )}
      </div>

      {/* ========== SUGAR-FREE CHALLENGE ========== */}
      <div style={{ background: 'linear-gradient(135deg, #fff5f5, #ffe4e6)', borderRadius: '16px', padding: '20px', margin: '15px 0', boxShadow: '0 4px 15px rgba(225,29,72,0.1)' }}>
        <h3 style={{ color: '#e11d48', marginBottom: '12px', fontSize: '1.1rem' }}>
          🍬 {isAr ? 'تحدي الامتناع عن السكر' : 'Sugar-Free Challenge'}
        </h3>
        <button onClick={() => toggleToday('sugarFree')} style={{
          background: todayEntry?.sugarFree ? 'linear-gradient(135deg, #e11d48, #be123c)' : 'white',
          color: todayEntry?.sugarFree ? 'white' : '#e11d48',
          border: todayEntry?.sugarFree ? 'none' : '2px solid #e11d48',
          borderRadius: '25px', padding: '12px 24px', fontWeight: 700, cursor: 'pointer',
          width: '100%', fontSize: '1rem', marginBottom: '12px', fontFamily: 'Poppins, sans-serif',
          transition: 'all 0.3s ease',
        }}>
          {todayEntry?.sugarFree
            ? (isAr ? '✅ يوم بدون سكر!' : '✅ Sugar-free today!')
            : (isAr ? 'سجّل يومك بدون سكر' : 'Log sugar-free day')}
        </button>
        {sugarStreak > 0 && (
          <div style={{ textAlign: 'center', color: '#e11d48', fontWeight: 700, fontSize: '1.2rem', margin: '8px 0' }}>
            🔥 {sugarStreak} {isAr ? 'يوم متتالي!' : 'day streak!'}
          </div>
        )}
        <div style={{ marginTop: '10px' }}>
          {sugarTips.map((tip, i) => (
            <p key={i} style={{ color: '#6b2135', fontSize: '0.82rem', marginBottom: '6px', padding: '6px 10px', background: 'rgba(255,255,255,0.6)', borderRadius: '10px' }}>
              {tip}
            </p>
          ))}
        </div>
      </div>

      {/* ========== DAILY NOTE ========== */}
      <div style={{ background: 'white', borderRadius: '16px', padding: '20px', margin: '15px 0', boxShadow: '0 4px 15px rgba(0,0,0,0.06)' }}>
        <h4 style={{ color: '#32325d', marginBottom: '10px' }}>
          📝 {isAr ? 'ملاحظاتك اليوم' : "Today's Notes"}
        </h4>
        <div style={{ display: 'flex', gap: '8px' }}>
          <input type="text" value={note} onChange={e => setNote(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && saveNote()}
            placeholder={isAr ? 'كيف شعرت اليوم بدون شاشات؟' : 'How did you feel without screens?'}
            style={{ flexGrow: 1, padding: '10px 15px', border: '1px solid #ddd', borderRadius: '25px', fontSize: '0.9rem', outline: 'none', fontFamily: 'Poppins, sans-serif' }}
          />
          <button onClick={saveNote} style={{ background: '#e11d48', color: 'white', border: 'none', borderRadius: '50%', width: 40, height: 40, cursor: 'pointer', flexShrink: 0 }}>
            <i className="fas fa-plus"></i>
          </button>
        </div>
        {todayEntry?.note && (
          <p style={{ color: '#6b7280', fontSize: '0.85rem', marginTop: '10px', padding: '8px 12px', background: '#f9fafb', borderRadius: '10px' }}>
            💬 {todayEntry.note}
          </p>
        )}
      </div>

      {/* ========== HISTORY ========== */}
      {days.length > 0 && (
        <button onClick={() => setShowHistory(!showHistory)} style={{
          background: 'none', border: '1px solid #e11d48', color: '#e11d48', borderRadius: '25px',
          padding: '10px 20px', fontWeight: 600, cursor: 'pointer', width: '100%', fontFamily: 'Poppins, sans-serif', fontSize: '0.85rem', marginBottom: '15px',
        }}>
          <i className={`fas fa-${showHistory ? 'chevron-up' : 'history'}`} style={{ marginRight: '6px' }}></i>
          {showHistory ? (isAr ? 'إخفاء السجل' : 'Hide History') : (isAr ? 'عرض السجل' : 'View History')}
        </button>
      )}
      {showHistory && (
        <div style={{ maxHeight: '300px', overflowY: 'auto', marginBottom: '15px' }}>
          {sorted.map((d, i) => (
            <div key={i} style={{ background: '#f9fafb', borderRadius: '12px', padding: '12px', marginBottom: '8px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '4px' }}>
                <span style={{ fontSize: '0.8rem', color: '#6b7280' }}>{new Date(d.date).toLocaleDateString(isAr ? 'ar' : 'en')}</span>
                <div style={{ display: 'flex', gap: '6px' }}>
                  {d.sugarFree && <span style={{ background: '#fecdd3', color: '#e11d48', padding: '2px 8px', borderRadius: '10px', fontSize: '0.7rem', fontWeight: 600 }}>🍬✅</span>}
                  {d.dopamineFree && <span style={{ background: '#e0e7ff', color: '#6366f1', padding: '2px 8px', borderRadius: '10px', fontSize: '0.7rem', fontWeight: 600 }}>🧠✅</span>}
                  {d.actualScreenTime > 0 && (
                    <span style={{
                      background: d.actualScreenTime <= d.screenTimeGoal ? '#dcfce7' : '#fef2f2',
                      color: d.actualScreenTime <= d.screenTimeGoal ? '#166534' : '#991b1b',
                      padding: '2px 8px', borderRadius: '10px', fontSize: '0.7rem', fontWeight: 600,
                    }}>
                      📱 {d.actualScreenTime}{isAr ? 'د' : 'm'}
                    </span>
                  )}
                </div>
              </div>
              {d.note && <div style={{ fontSize: '0.75rem', color: '#9ca3af' }}>💬 {d.note}</div>}
            </div>
          ))}
        </div>
      )}

      {/* ========== FASTING TRACKER ========== */}
      <FastingTracker />

      <InlineAIChat context="detox" lang={lang} />
    </div>
  );
}
