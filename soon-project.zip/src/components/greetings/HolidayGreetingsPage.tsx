import { useState } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { supabase } from '@/integrations/supabase/client';

interface HolidayGreetingsPageProps {
  onBack: () => void;
}

const occasions = [
  { id: 'eid', icon: '🌙', en: 'Eid', ar: 'عيد مبارك', es: 'Eid', fr: 'Aïd' },
  { id: 'newyear', icon: '🎆', en: 'New Year', ar: 'رأس السنة', es: 'Año Nuevo', fr: 'Nouvel An' },
  { id: 'birthday', icon: '🎂', en: 'Birthday', ar: 'عيد ميلاد', es: 'Cumpleaños', fr: 'Anniversaire' },
  { id: 'ramadan', icon: '🕌', en: 'Ramadan', ar: 'رمضان', es: 'Ramadán', fr: 'Ramadan' },
  { id: 'christmas', icon: '🎄', en: 'Christmas', ar: 'عيد الميلاد', es: 'Navidad', fr: 'Noël' },
  { id: 'wedding', icon: '💍', en: 'Wedding', ar: 'زفاف', es: 'Boda', fr: 'Mariage' },
  { id: 'graduation', icon: '🎓', en: 'Graduation', ar: 'تخرج', es: 'Graduación', fr: 'Diplôme' },
  { id: 'general', icon: '🎉', en: 'Celebration', ar: 'احتفال', es: 'Celebración', fr: 'Célébration' },
];

export default function HolidayGreetingsPage({ onBack }: HolidayGreetingsPageProps) {
  const { lang } = useLanguage();
  const [userName] = useLocalStorage<string>('soon-user-name', '');
  const [senderName, setSenderName] = useState(userName);
  const [recipientName, setRecipientName] = useState('');
  const [message, setMessage] = useState('');
  const [occasion, setOccasion] = useState('');
  const [shareLink, setShareLink] = useState('');
  const [loading, setLoading] = useState(false);
  const [addSenderName, setAddSenderName] = useState(true);

  const isAr = lang === 'ar';
  const labels = {
    en: { title: '🎉 Holiday Greetings', subtitle: 'Send beautiful greetings to loved ones', sender: 'Your name (optional)', recipient: 'Recipient name', message: 'Your greeting message...', occasion_label: 'Choose occasion', send: 'Create Greeting Link', copied: 'Link copied!', copy: 'Copy Link', share: 'Share', add_name: 'Add my name', back: 'Back' },
    ar: { title: '🎉 تهنئة بالأعياد', subtitle: 'أرسل تهاني جميلة لأحبائك', sender: 'اسمك (اختياري)', recipient: 'اسم المُهنّأ', message: 'رسالة التهنئة...', occasion_label: 'اختر المناسبة', send: 'إنشاء رابط التهنئة', copied: 'تم نسخ الرابط!', copy: 'نسخ الرابط', share: 'مشاركة', add_name: 'أضف اسمي', back: 'رجوع' },
    es: { title: '🎉 Felicitaciones', subtitle: 'Envía felicitaciones a tus seres queridos', sender: 'Tu nombre (opcional)', recipient: 'Nombre del destinatario', message: 'Tu mensaje...', occasion_label: 'Elige ocasión', send: 'Crear enlace', copied: '¡Enlace copiado!', copy: 'Copiar enlace', share: 'Compartir', add_name: 'Agregar mi nombre', back: 'Volver' },
    fr: { title: '🎉 Vœux de Fêtes', subtitle: 'Envoyez de beaux vœux à vos proches', sender: 'Votre nom (optionnel)', recipient: 'Nom du destinataire', message: 'Votre message...', occasion_label: 'Choisir l\'occasion', send: 'Créer le lien', copied: 'Lien copié!', copy: 'Copier le lien', share: 'Partager', add_name: 'Ajouter mon nom', back: 'Retour' },
  };
  const l = labels[lang] || labels.en;

  const createGreeting = async () => {
    if (!recipientName.trim() || !message.trim() || !occasion) return;
    setLoading(true);
    try {
      const { data, error } = await supabase.from('holiday_greetings').insert({
        sender_name: addSenderName ? senderName.trim() : '',
        recipient_name: recipientName.trim(),
        message: message.trim(),
        occasion,
      }).select('id').single();
      if (error) throw error;
      const link = `${window.location.origin}/greeting/${data.id}`;
      setShareLink(link);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const copyLink = () => {
    navigator.clipboard.writeText(shareLink);
    alert(l.copied);
  };

  const inputStyle = { width: '100%', padding: '12px 15px', border: '1px solid #e5e7eb', borderRadius: '12px', fontFamily: 'Poppins, sans-serif', fontSize: '0.9rem', outline: 'none', marginBottom: '10px', boxSizing: 'border-box' as const, direction: isAr ? 'rtl' as const : 'ltr' as const };

  return (
    <div style={{ paddingTop: '20px', direction: isAr ? 'rtl' : 'ltr' }}>
      <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#f59e0b', fontSize: '1rem', cursor: 'pointer', marginBottom: '15px', fontFamily: 'Poppins, sans-serif' }}>
        <i className={`fas fa-arrow-${isAr ? 'right' : 'left'}`}></i> {l.back}
      </button>

      <div style={{ textAlign: 'center', marginBottom: '20px' }}>
        <h2 style={{ color: '#f59e0b', fontSize: '1.5rem', margin: '0 0 5px' }}>{l.title}</h2>
        <p style={{ color: '#8898aa', fontSize: '0.85rem', margin: 0 }}>{l.subtitle}</p>
      </div>

      {/* Occasion selector */}
      <div style={{ background: 'white', borderRadius: '16px', padding: '15px', marginBottom: '15px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
        <h4 style={{ color: '#f59e0b', marginBottom: '10px', textAlign: 'center' }}>{l.occasion_label}</h4>
        <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', justifyContent: 'center' }}>
          {occasions.map(o => (
            <button key={o.id} onClick={() => setOccasion(o.id)} style={{
              background: occasion === o.id ? 'linear-gradient(135deg, #f59e0b, #d97706)' : '#fffbeb',
              color: occasion === o.id ? 'white' : '#92400e',
              border: 'none', borderRadius: '20px', padding: '8px 14px', fontSize: '0.8rem', fontWeight: 600,
              cursor: 'pointer', fontFamily: 'Poppins, sans-serif', transition: 'all 0.3s ease',
            }}>
              {o.icon} {o[lang] || o.en}
            </button>
          ))}
        </div>
      </div>

      {/* Form */}
      <div style={{ background: 'white', borderRadius: '16px', padding: '20px', marginBottom: '15px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '10px' }}>
          <label style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.85rem', color: '#32325d', cursor: 'pointer' }}>
            <input type="checkbox" checked={addSenderName} onChange={e => setAddSenderName(e.target.checked)} />
            {l.add_name}
          </label>
        </div>
        {addSenderName && (
          <input type="text" value={senderName} onChange={e => setSenderName(e.target.value)} placeholder={l.sender} style={inputStyle} />
        )}
        <input type="text" value={recipientName} onChange={e => setRecipientName(e.target.value)} placeholder={l.recipient} style={inputStyle} />
        <textarea value={message} onChange={e => setMessage(e.target.value)} placeholder={l.message}
          style={{ ...inputStyle, height: '100px', resize: 'vertical' as const }} />
        <button onClick={createGreeting} disabled={loading || !recipientName.trim() || !message.trim() || !occasion} style={{
          background: 'linear-gradient(135deg, #f59e0b, #d97706)', color: 'white', border: 'none',
          borderRadius: '25px', padding: '12px', fontWeight: 600, cursor: 'pointer', width: '100%',
          fontFamily: 'Poppins, sans-serif', opacity: loading ? 0.6 : 1,
        }}>
          {loading ? '⏳' : l.send}
        </button>
      </div>

      {/* Share link */}
      {shareLink && (
        <div style={{ background: 'linear-gradient(135deg, #fef3c7, #fde68a)', borderRadius: '16px', padding: '20px', marginBottom: '20px', textAlign: 'center' }}>
          <div style={{ fontSize: '2rem', marginBottom: '10px' }}>🎉</div>
          <p style={{ fontSize: '0.85rem', color: '#92400e', marginBottom: '12px', wordBreak: 'break-all' }}>{shareLink}</p>
          <div style={{ display: 'flex', gap: '8px', justifyContent: 'center' }}>
            <button onClick={copyLink} style={{ background: '#f59e0b', color: 'white', border: 'none', borderRadius: '20px', padding: '8px 20px', fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif' }}>
              📋 {l.copy}
            </button>
            <button onClick={() => { if (navigator.share) navigator.share({ url: shareLink, title: l.title }); else copyLink(); }} style={{ background: '#2DCE89', color: 'white', border: 'none', borderRadius: '20px', padding: '8px 20px', fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif' }}>
              📤 {l.share}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
