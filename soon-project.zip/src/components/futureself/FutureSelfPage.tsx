import { useState } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';

interface FutureSelfPageProps { onBack: () => void; }

export default function FutureSelfPage({ onBack }: FutureSelfPageProps) {
  const { lang } = useLanguage();
  const isAr = lang === 'ar';
  const [photo] = useLocalStorage<string>('soon-user-photo', '');
  const [userName] = useLocalStorage<string>('soon-user-name', '');
  const [goals] = useLocalStorage<any[]>('soon-goals', []);
  const [tasks] = useLocalStorage<any[]>('soon-tasks', []);
  const [vision5, setVision5] = useLocalStorage<string>('soon-future-5y', '');
  const [vision10, setVision10] = useLocalStorage<string>('soon-future-10y', '');
  const [letterToSelf, setLetterToSelf] = useLocalStorage<string>('soon-future-letter', '');
  const [tab, setTab] = useState<'vision' | 'progress' | 'letter'>('vision');

  const labels: Record<string, Record<string, string>> = {
    en: { title: '🔮 My Future Self', subtitle: 'Visualize who you want to become', back: 'Back', vision: 'Vision', progress: 'Progress', letter: 'Letter', y5: 'Where do you see yourself in 5 years?', y10: 'Where do you see yourself in 10 years?', save: 'Save', letter_ph: 'Write a letter to your future self...', goals_done: 'Goals completed', tasks_done: 'Tasks completed', keep_going: 'Keep going! Every step counts 🚀' },
    ar: { title: '🔮 نفسي المستقبلية', subtitle: 'تصور من تريد أن تكون', back: 'رجوع', vision: 'الرؤية', progress: 'التقدم', letter: 'رسالة', y5: 'أين ترى نفسك بعد 5 سنوات؟', y10: 'أين ترى نفسك بعد 10 سنوات؟', save: 'حفظ', letter_ph: 'اكتب رسالة لنفسك المستقبلية...', goals_done: 'أهداف مكتملة', tasks_done: 'مهام مكتملة', keep_going: 'استمر! كل خطوة مهمة 🚀' },
    es: { title: '🔮 Mi Yo Futuro', subtitle: 'Visualiza quién quieres ser', back: 'Volver', vision: 'Visión', progress: 'Progreso', letter: 'Carta', y5: '¿Dónde te ves en 5 años?', y10: '¿Dónde te ves en 10 años?', save: 'Guardar', letter_ph: 'Escribe una carta a tu yo futuro...', goals_done: 'Metas completadas', tasks_done: 'Tareas completadas', keep_going: '¡Sigue adelante! 🚀' },
    fr: { title: '🔮 Mon Moi Futur', subtitle: 'Visualisez qui vous voulez devenir', back: 'Retour', vision: 'Vision', progress: 'Progrès', letter: 'Lettre', y5: 'Où vous voyez-vous dans 5 ans?', y10: 'Où vous voyez-vous dans 10 ans?', save: 'Sauvegarder', letter_ph: 'Écrivez une lettre à votre moi futur...', goals_done: 'Objectifs accomplis', tasks_done: 'Tâches accomplies', keep_going: 'Continuez! Chaque pas compte 🚀' },
  };
  const l = labels[lang] || labels.en;

  const completedGoals = goals.filter((g: any) => g.completed).length;
  const completedTasks = tasks.filter((t: any) => t.completed).length;
  const totalGoals = goals.length || 1;
  const totalTasks = tasks.length || 1;
  const overallProgress = Math.round(((completedGoals / totalGoals) + (completedTasks / totalTasks)) / 2 * 100);

  const inputStyle = { width: '100%', padding: '12px', border: '2px solid #e5e7eb', borderRadius: '12px', fontSize: '0.9rem', outline: 'none', boxSizing: 'border-box' as const, fontFamily: 'Poppins, sans-serif', direction: isAr ? 'rtl' as const : 'ltr' as const };
  const tabStyle = (active: boolean) => ({ flex: 1, padding: '10px', border: 'none', borderRadius: '12px', cursor: 'pointer', fontWeight: 600, fontFamily: 'Poppins, sans-serif', fontSize: '0.8rem', background: active ? '#8b5cf6' : '#f1f5f9', color: active ? 'white' : '#64748b', transition: 'all 0.3s' });

  return (
    <div style={{ paddingTop: '15px', direction: isAr ? 'rtl' : 'ltr' }}>
      <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#8b5cf6', cursor: 'pointer', fontSize: '1rem', fontFamily: 'Poppins, sans-serif', marginBottom: '15px' }}>
        <i className={`fas fa-arrow-${isAr ? 'right' : 'left'}`}></i> {l.back}
      </button>

      {/* Avatar */}
      <div style={{ textAlign: 'center', marginBottom: '20px' }}>
        <div style={{ position: 'relative', display: 'inline-block' }}>
          <img src={photo || '/soon-logo.webp'} alt="Future Self" style={{
            width: 100, height: 100, borderRadius: '50%', objectFit: 'cover',
            border: '4px solid #8b5cf6', boxShadow: `0 0 0 ${overallProgress / 10}px rgba(139,92,246,0.2)`,
          }} />
          <div style={{ position: 'absolute', bottom: -5, left: '50%', transform: 'translateX(-50%)', background: '#8b5cf6', color: 'white', borderRadius: '20px', padding: '2px 12px', fontSize: '0.7rem', fontWeight: 700 }}>
            {overallProgress}%
          </div>
        </div>
        <h2 style={{ color: '#8b5cf6', margin: '12px 0 4px', fontSize: '1.3rem' }}>{l.title}</h2>
        <p style={{ color: '#8898aa', fontSize: '0.85rem', margin: 0 }}>{l.subtitle}</p>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: '6px', marginBottom: '20px' }}>
        <button onClick={() => setTab('vision')} style={tabStyle(tab === 'vision')}>🎯 {l.vision}</button>
        <button onClick={() => setTab('progress')} style={tabStyle(tab === 'progress')}>📊 {l.progress}</button>
        <button onClick={() => setTab('letter')} style={tabStyle(tab === 'letter')}>✉️ {l.letter}</button>
      </div>

      {tab === 'vision' && (
        <div>
          <div style={{ background: 'white', borderRadius: '16px', padding: '20px', boxShadow: '0 4px 15px rgba(0,0,0,0.08)', marginBottom: '15px' }}>
            <h4 style={{ color: '#8b5cf6', margin: '0 0 10px' }}>🎯 5 {isAr ? 'سنوات' : 'Years'}</h4>
            <textarea value={vision5} onChange={e => setVision5(e.target.value)} placeholder={l.y5} style={{ ...inputStyle, minHeight: '100px', resize: 'vertical' }} />
          </div>
          <div style={{ background: 'white', borderRadius: '16px', padding: '20px', boxShadow: '0 4px 15px rgba(0,0,0,0.08)' }}>
            <h4 style={{ color: '#8b5cf6', margin: '0 0 10px' }}>🌟 10 {isAr ? 'سنوات' : 'Years'}</h4>
            <textarea value={vision10} onChange={e => setVision10(e.target.value)} placeholder={l.y10} style={{ ...inputStyle, minHeight: '100px', resize: 'vertical' }} />
          </div>
        </div>
      )}

      {tab === 'progress' && (
        <div>
          <div style={{ background: 'linear-gradient(135deg, #8b5cf6, #7c3aed)', borderRadius: '16px', padding: '20px', color: 'white', textAlign: 'center', marginBottom: '15px' }}>
            <div style={{ fontSize: '3rem', fontWeight: 700 }}>{overallProgress}%</div>
            <p style={{ opacity: 0.9, margin: '5px 0 0' }}>{l.keep_going}</p>
          </div>
          <div style={{ display: 'flex', gap: '10px' }}>
            <div style={{ flex: 1, background: 'white', borderRadius: '16px', padding: '20px', textAlign: 'center', boxShadow: '0 4px 15px rgba(0,0,0,0.08)' }}>
              <div style={{ fontSize: '2rem', fontWeight: 700, color: '#2DCE89' }}>{completedGoals}/{goals.length}</div>
              <p style={{ color: '#8898aa', fontSize: '0.8rem', margin: '5px 0 0' }}>{l.goals_done}</p>
            </div>
            <div style={{ flex: 1, background: 'white', borderRadius: '16px', padding: '20px', textAlign: 'center', boxShadow: '0 4px 15px rgba(0,0,0,0.08)' }}>
              <div style={{ fontSize: '2rem', fontWeight: 700, color: '#0ea5e9' }}>{completedTasks}/{tasks.length}</div>
              <p style={{ color: '#8898aa', fontSize: '0.8rem', margin: '5px 0 0' }}>{l.tasks_done}</p>
            </div>
          </div>
        </div>
      )}

      {tab === 'letter' && (
        <div style={{ background: 'white', borderRadius: '16px', padding: '20px', boxShadow: '0 4px 15px rgba(0,0,0,0.08)' }}>
          <h4 style={{ color: '#8b5cf6', margin: '0 0 10px' }}>✉️ {isAr ? `رسالة إلى ${userName || 'نفسي'} المستقبلية` : `Letter to future ${userName || 'me'}`}</h4>
          <textarea value={letterToSelf} onChange={e => setLetterToSelf(e.target.value)} placeholder={l.letter_ph} style={{ ...inputStyle, minHeight: '200px', resize: 'vertical' }} />
        </div>
      )}
    </div>
  );
}
