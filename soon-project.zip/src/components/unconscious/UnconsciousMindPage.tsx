import { useState } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { supabase } from '@/integrations/supabase/client';

interface Session {
  id: string;
  problem: string;
  freeWriting: string;
  pastMemory: string;
  hiddenPattern: string;
  aiInsight: string;
  innerChildLetter: string;
  date: string;
}

export default function UnconsciousMindPage({ onBack }: { onBack: () => void }) {
  const { lang } = useLanguage();
  const isAr = lang === 'ar';
  const [sessions, setSessions] = useLocalStorage<Session[]>('soon-unconscious', []);
  const [step, setStep] = useState(0); // 0=intro, 1=problem, 2=free-write, 3=past, 4=ai-analysis, 5=inner-child
  const [problem, setProblem] = useState('');
  const [freeWriting, setFreeWriting] = useState('');
  const [pastMemory, setPastMemory] = useState('');
  const [hiddenPattern, setHiddenPattern] = useState('');
  const [aiInsight, setAiInsight] = useState('');
  const [innerChildLetter, setInnerChildLetter] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const l = {
    en: {
      title: '🧠 The Unconscious Mind', subtitle: 'Uncover what drives you beneath the surface',
      back: 'Home', start: 'Begin Session', step1: 'What problem are you struggling with right now?',
      step1_placeholder: 'Describe freely what bothers you...',
      step2: 'Free Association: Write whatever comes to mind without filtering. Don\'t think, just write.',
      step2_placeholder: 'Let your thoughts flow freely...',
      step3: 'Go back in time. When did you first feel this way? What childhood memory surfaces?',
      step3_placeholder: 'Describe the earliest memory connected to this feeling...',
      analyzing: 'AI is analyzing your unconscious patterns...',
      step5: 'Write a letter to your inner child who experienced that event. Forgive them. Let them go.',
      step5_placeholder: 'Dear little me...',
      save: '🕊️ Complete & Release', next: 'Next →', history: 'Past Sessions', empty: 'No sessions yet.',
      benefit: 'How This Works', benefit_desc: 'Based on psychoanalytic free association (Freud) and inner child therapy. By writing freely, your unconscious reveals hidden patterns. The AI helps you see connections you may miss. The final step — forgiving your inner child — releases trapped emotions.',
    },
    ar: {
      title: '🧠 اللاوعي', subtitle: 'اكتشف ما يحركك من الداخل',
      back: 'الرئيسية', start: 'ابدأ الجلسة', step1: 'ما المشكل الذي تعاني منه الآن؟',
      step1_placeholder: 'صِف بحرية ما يزعجك...',
      step2: 'التداعي الحر: اكتب كل ما يخطر في بالك بدون تصفية. لا تفكر، فقط اكتب.',
      step2_placeholder: 'دع أفكارك تتدفق بحرية...',
      step3: 'عُد بالزمن للوراء. متى شعرت بهذا لأول مرة؟ ما ذكرى الطفولة التي تظهر؟',
      step3_placeholder: 'صِف أقدم ذكرى مرتبطة بهذا الشعور...',
      analyzing: 'الذكاء الاصطناعي يحلل أنماط لاوعيك...',
      step5: 'اكتب رسالة لطفلك الداخلي الذي عاش ذلك الحدث. سامحه. اسمح له بالرحيل.',
      step5_placeholder: 'عزيزي أنا الصغير...',
      save: '🕊️ أكمل وتحرر', next: 'التالي ←', history: 'الجلسات السابقة', empty: 'لا توجد جلسات بعد.',
      benefit: 'كيف يعمل هذا', benefit_desc: 'مبني على التداعي الحر (فرويد) وعلاج الطفل الداخلي. بالكتابة بحرية، يكشف لاوعيك عن أنماط مخفية. يساعدك الذكاء الاصطناعي على رؤية روابط قد تفوتك. الخطوة الأخيرة — مسامحة طفلك الداخلي — تحرر المشاعر المحبوسة.',
    },
    es: {
      title: '🧠 El Inconsciente', subtitle: 'Descubre qué te impulsa bajo la superficie',
      back: 'Inicio', start: 'Iniciar Sesión', step1: '¿Qué problema enfrentas ahora?',
      step1_placeholder: 'Describe libremente...', step2: 'Asociación libre: escribe sin filtrar.',
      step2_placeholder: 'Deja fluir tus pensamientos...', step3: '¿Cuándo sentiste esto por primera vez?',
      step3_placeholder: 'Describe el recuerdo más antiguo...', analyzing: 'El AI analiza tus patrones...',
      step5: 'Escribe una carta a tu niño interior.', step5_placeholder: 'Querido yo pequeño...',
      save: '🕊️ Completar', next: 'Siguiente →', history: 'Sesiones', empty: 'Sin sesiones.',
      benefit: 'Cómo funciona', benefit_desc: 'Basado en la asociación libre de Freud y la terapia del niño interior.',
    },
    fr: {
      title: '🧠 L\'Inconscient', subtitle: 'Découvrez ce qui vous motive en profondeur',
      back: 'Accueil', start: 'Commencer', step1: 'Quel problème vous préoccupe?',
      step1_placeholder: 'Décrivez librement...', step2: 'Association libre: écrivez sans filtrer.',
      step2_placeholder: 'Laissez couler vos pensées...', step3: 'Quand avez-vous ressenti cela pour la première fois?',
      step3_placeholder: 'Décrivez le souvenir le plus ancien...', analyzing: 'L\'IA analyse vos schémas...',
      step5: 'Écrivez une lettre à votre enfant intérieur.', step5_placeholder: 'Cher petit moi...',
      save: '🕊️ Terminer', next: 'Suivant →', history: 'Sessions', empty: 'Pas de sessions.',
      benefit: 'Comment ça marche', benefit_desc: 'Basé sur l\'association libre de Freud et la thérapie de l\'enfant intérieur.',
    },
  };
  const t = l[lang as keyof typeof l] || l.en;

  const analyzeWithAI = async () => {
    setIsLoading(true);
    try {
      const prompt = isAr
        ? `أنت محلل نفسي. لدي مريض كتب ما يلي:\n\nالمشكل الحالي: ${problem}\n\nالتداعي الحر: ${freeWriting}\n\nذكرى من الماضي: ${pastMemory}\n\nحلل الأنماط اللاواعية. اكشف عن الشيء المتخفي الذي كان يدير حياته. اشرح كيف أن ذلك الطفل الذي عاش ذلك الحدث لا يزال يؤثر على قراراته اليوم. كن عطوفاً وعميقاً. أجب بالعربية.`
        : `You are a psychoanalyst. A patient wrote:\n\nCurrent problem: ${problem}\n\nFree association: ${freeWriting}\n\nPast memory: ${pastMemory}\n\nAnalyze the unconscious patterns. Reveal the hidden thing that has been driving their life. Explain how the child who experienced that event is still influencing their decisions today. Be compassionate and deep.`;

      const { data, error } = await supabase.functions.invoke('groq-chat', {
        body: {
          messages: [{ role: 'user', content: prompt }],
          systemPrompt: isAr
            ? 'أنت محلل نفسي متخصص في التحليل النفسي واللاوعي. تقدم رؤى عميقة وعطوفة.'
            : 'You are a psychoanalyst specializing in unconscious analysis. Provide deep, compassionate insights.'
        }
      });
      if (error) throw error;
      const insight = data.content || '';
      setAiInsight(insight);
      setHiddenPattern(insight);
      setStep(5);
    } catch {
      setAiInsight(isAr ? 'عذراً، حاول مرة أخرى.' : 'Sorry, please try again.');
      setStep(5);
    } finally {
      setIsLoading(false);
    }
  };

  const completeSession = () => {
    setSessions(prev => [{
      id: Date.now().toString(), problem, freeWriting, pastMemory, hiddenPattern, aiInsight, innerChildLetter: innerChildLetter.trim(),
      date: new Date().toISOString(),
    }, ...prev]);
    setStep(0); setProblem(''); setFreeWriting(''); setPastMemory(''); setHiddenPattern(''); setAiInsight(''); setInnerChildLetter('');
  };

  const inputStyle = { width: '100%', padding: '12px', border: '2px solid #c4b5fd', borderRadius: '12px', fontSize: '0.9rem', boxSizing: 'border-box' as const, fontFamily: 'Poppins, sans-serif', direction: isAr ? 'rtl' as const : 'ltr' as const };
  const stepColors = ['#7c3aed', '#6d28d9', '#5b21b6', '#4c1d95', '#3b0764', '#2e1065'];

  return (
    <div style={{ paddingTop: '20px', direction: isAr ? 'rtl' : 'ltr' }}>
      <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#7c3aed', fontSize: '1rem', cursor: 'pointer', marginBottom: '15px' }}>
        <i className={`fas fa-arrow-${isAr ? 'right' : 'left'}`}></i> {t.back}
      </button>

      <div style={{ background: 'linear-gradient(135deg, #4c1d95, #7c3aed)', borderRadius: '20px', padding: '25px', color: 'white', textAlign: 'center', marginBottom: '20px' }}>
        <div style={{ fontSize: '2.5rem', marginBottom: '10px' }}>🧠🔮</div>
        <h2 style={{ fontSize: '1.3rem', fontWeight: 700, margin: '0 0 8px' }}>{t.title}</h2>
        <p style={{ fontSize: '0.85rem', opacity: 0.9, margin: 0 }}>{t.subtitle}</p>
      </div>

      {/* Progress bar */}
      {step > 0 && (
        <div style={{ display: 'flex', gap: '4px', marginBottom: '15px' }}>
          {[1,2,3,4,5].map(s => (
            <div key={s} style={{ flex: 1, height: '6px', borderRadius: '3px', background: s <= step ? '#7c3aed' : '#e5e7eb', transition: 'background 0.3s' }} />
          ))}
        </div>
      )}

      {step === 0 && (
        <>
          <div style={{ background: 'linear-gradient(135deg, #ede9fe, #ddd6fe)', borderRadius: '16px', padding: '20px', marginBottom: '15px', textAlign: 'center' }}>
            <p style={{ color: '#4c1d95', fontSize: '0.9rem', lineHeight: 1.8, margin: 0 }}>
              {t.benefit_desc}
            </p>
          </div>
          <button onClick={() => setStep(1)} style={{ width: '100%', background: 'linear-gradient(135deg, #7c3aed, #4c1d95)', color: 'white', border: 'none', borderRadius: '16px', padding: '18px', fontWeight: 700, fontSize: '1.1rem', cursor: 'pointer' }}>
            🔮 {t.start}
          </button>
        </>
      )}

      {step === 1 && (
        <div style={{ background: 'white', borderRadius: '16px', padding: '20px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)' }}>
          <h4 style={{ color: stepColors[0], marginBottom: '12px' }}>1️⃣ {t.step1}</h4>
          <textarea value={problem} onChange={e => setProblem(e.target.value)} placeholder={t.step1_placeholder} style={{ ...inputStyle, minHeight: '120px', resize: 'vertical', marginBottom: '15px' }} />
          <button onClick={() => setStep(2)} disabled={!problem.trim()} style={{ width: '100%', background: problem.trim() ? stepColors[0] : '#ccc', color: 'white', border: 'none', borderRadius: '12px', padding: '14px', fontWeight: 600, cursor: problem.trim() ? 'pointer' : 'not-allowed' }}>{t.next}</button>
        </div>
      )}

      {step === 2 && (
        <div style={{ background: 'white', borderRadius: '16px', padding: '20px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)' }}>
          <h4 style={{ color: stepColors[1], marginBottom: '12px' }}>2️⃣ {t.step2}</h4>
          <textarea value={freeWriting} onChange={e => setFreeWriting(e.target.value)} placeholder={t.step2_placeholder} style={{ ...inputStyle, minHeight: '180px', resize: 'vertical', marginBottom: '15px' }} />
          <button onClick={() => setStep(3)} disabled={!freeWriting.trim()} style={{ width: '100%', background: freeWriting.trim() ? stepColors[1] : '#ccc', color: 'white', border: 'none', borderRadius: '12px', padding: '14px', fontWeight: 600, cursor: freeWriting.trim() ? 'pointer' : 'not-allowed' }}>{t.next}</button>
        </div>
      )}

      {step === 3 && (
        <div style={{ background: 'white', borderRadius: '16px', padding: '20px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)' }}>
          <h4 style={{ color: stepColors[2], marginBottom: '12px' }}>3️⃣ {t.step3}</h4>
          <textarea value={pastMemory} onChange={e => setPastMemory(e.target.value)} placeholder={t.step3_placeholder} style={{ ...inputStyle, minHeight: '150px', resize: 'vertical', marginBottom: '15px' }} />
          <button onClick={() => { setStep(4); analyzeWithAI(); }} disabled={!pastMemory.trim()} style={{ width: '100%', background: pastMemory.trim() ? stepColors[2] : '#ccc', color: 'white', border: 'none', borderRadius: '12px', padding: '14px', fontWeight: 600, cursor: pastMemory.trim() ? 'pointer' : 'not-allowed' }}>{t.next}</button>
        </div>
      )}

      {step === 4 && (
        <div style={{ background: 'linear-gradient(135deg, #ede9fe, #ddd6fe)', borderRadius: '16px', padding: '30px', textAlign: 'center' }}>
          <div style={{ fontSize: '2.5rem', marginBottom: '15px', animation: 'pulseBeat 1.5s infinite' }}>🔮</div>
          <p style={{ color: '#4c1d95', fontWeight: 600 }}>{t.analyzing}</p>
        </div>
      )}

      {step === 5 && (
        <div style={{ background: 'white', borderRadius: '16px', padding: '20px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)' }}>
          {aiInsight && (
            <div style={{ background: '#faf5ff', borderRadius: '12px', padding: '15px', marginBottom: '15px', borderLeft: '4px solid #7c3aed' }}>
              <h4 style={{ color: '#7c3aed', margin: '0 0 8px' }}>🔮 {isAr ? 'تحليل اللاوعي' : 'Unconscious Analysis'}</h4>
              <p style={{ color: '#32325d', fontSize: '0.85rem', lineHeight: 1.7, margin: 0, whiteSpace: 'pre-wrap' }}>{aiInsight}</p>
            </div>
          )}
          <h4 style={{ color: stepColors[4], marginBottom: '12px' }}>5️⃣ {t.step5}</h4>
          <textarea value={innerChildLetter} onChange={e => setInnerChildLetter(e.target.value)} placeholder={t.step5_placeholder} style={{ ...inputStyle, minHeight: '150px', resize: 'vertical', marginBottom: '15px' }} />
          <button onClick={completeSession} style={{ width: '100%', background: 'linear-gradient(135deg, #7c3aed, #4c1d95)', color: 'white', border: 'none', borderRadius: '12px', padding: '14px', fontWeight: 600, cursor: 'pointer' }}>{t.save}</button>
        </div>
      )}

      {/* History */}
      {step === 0 && sessions.length > 0 && (
        <>
          <h4 style={{ color: '#32325d', marginTop: '20px', marginBottom: '10px' }}>📜 {t.history}</h4>
          {sessions.map(s => (
            <div key={s.id} style={{ background: 'white', borderRadius: '12px', padding: '15px', marginBottom: '10px', borderLeft: '4px solid #a78bfa' }}>
              <div style={{ fontSize: '0.75rem', color: '#8898aa', marginBottom: '5px' }}>{new Date(s.date).toLocaleDateString()}</div>
              <p style={{ color: '#32325d', margin: '0 0 5px', fontWeight: 500 }}>{s.problem}</p>
              <p style={{ color: '#7c3aed', margin: 0, fontSize: '0.8rem' }}>🕊️ {isAr ? 'تم التحرر' : 'Released'}</p>
            </div>
          ))}
        </>
      )}
    </div>
  );
}
