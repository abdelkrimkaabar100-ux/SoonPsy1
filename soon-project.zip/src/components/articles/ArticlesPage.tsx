import { useState } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';

interface Article {
  title: string;
  source: string;
  date: string;
  content: string;
  url: string;
}

const staticArticles: Article[] = [
  { title: 'The Science of Happiness', source: 'Science Daily', date: 'May 2, 2025', content: 'What is the secret to happiness? A new study shows that happiness can come from within or from external influences.', url: 'https://www.sciencedaily.com/releases/2025/05/250502102702.htm' },
  { title: 'Understanding Anxiety Disorders', source: 'Clinical Neuropsychology', date: '2023', content: 'A comprehensive review of anxiety disorders reveals new insights into effective treatment approaches including CBT and mindfulness.', url: 'https://www.omicsonline.org/open-access-pdfs/a-comprehensive-review-of-anxiety-disorders-understanding-diagnosis-and-treatment.pdf' },
  { title: 'The Power of Mindfulness Meditation', source: 'JAMA Internal Medicine', date: 'Aug 2023', content: 'Meta-analysis of 47 clinical trials found that mindfulness meditation programs can reduce symptoms of anxiety and depression.', url: 'https://jamanetwork.com/journals/jamainternalmedicine/fullarticle/1809754' },
  { title: 'Sleep and Mental Health Connection', source: 'Sleep Medicine Reviews', date: 'Feb 2025', content: 'This study demonstrates the bidirectional relationship between sleep quality and mental health outcomes.', url: 'https://www.sciencedirect.com/science/article/pii/S0168010223000871' },
  { title: 'How Pets Improve Mental Health', source: 'APA Monitor', date: 'Apr 2024', content: 'Scientific evidence shows the human-animal bond reduces cortisol, lowers blood pressure, and combats loneliness.', url: 'https://www.apa.org/monitor/2024/04/pets-mental-health' },
  { title: 'Animal-Assisted Therapy for PTSD', source: 'HABRI Research', date: '2024', content: 'Service dogs significantly reduce PTSD symptoms in combat veterans, improving sleep and reducing anxiety attacks.', url: 'https://habri.org/research/ptsd' },
];

export default function ArticlesPage() {
  const { t } = useLanguage();
  const [articles] = useState<Article[]>(staticArticles);

  const copyArticle = (article: Article) => {
    const text = `${article.title}\n\nSource: ${article.source} (${article.date})\n\n${article.content}\n\nRead more: ${article.url}`;
    navigator.clipboard.writeText(text).then(() => alert('Article copied! 📋'));
  };

  return (
    <div>
      <h2 style={{ fontSize: '1.8rem', fontWeight: 700, color: '#32325d', margin: '25px 0', textAlign: 'center', position: 'relative' }}>
        {t('nav.insights')}
        <div style={{ position: 'absolute', bottom: '-10px', left: '50%', transform: 'translateX(-50%)', width: '80px', height: '4px', background: '#2DCE89', borderRadius: '2px' }}></div>
      </h2>


      {articles.map((article, i) => (
        <div key={i} style={{ background: 'white', borderRadius: '16px', padding: '20px', marginBottom: '15px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
          <h4 style={{ color: '#32325d', marginBottom: '8px' }}>{article.title}</h4>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '12px', fontSize: '0.8rem', color: '#8898aa' }}>
            <span>{article.source}</span><span>{article.date}</span>
          </div>
          <p style={{ lineHeight: 1.6, marginBottom: '12px', color: '#32325d', fontSize: '0.9rem' }}>{article.content}</p>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <a href={article.url} target="_blank" rel="noopener noreferrer" style={{ color: '#2DCE89', textDecoration: 'none', fontWeight: 600, fontSize: '0.9rem' }}>
              {t('articles.read_more')} →
            </a>
            <button onClick={() => copyArticle(article)} style={{ background: '#d1efe1', color: '#2DCE89', border: 'none', borderRadius: '20px', padding: '6px 12px', cursor: 'pointer', fontWeight: 600, fontFamily: 'Poppins, sans-serif', fontSize: '0.8rem' }}>
              <i className="fas fa-copy" style={{ marginRight: '4px' }}></i>Copy
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
