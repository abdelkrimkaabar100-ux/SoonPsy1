import { useState } from 'react';
import InlineAIChat from '../shared/InlineAIChat';
import { useLanguage } from '../../i18n/LanguageContext';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { supabase } from '@/integrations/supabase/client';

interface Movie {
  id: string;
  title: string;
  type: 'movie' | 'cartoon' | 'series';
  genre: string;
  note: string;
  date: string;
}

interface MoviesPageProps {
  onBack: () => void;
}

export default function MoviesPage({ onBack }: MoviesPageProps) {
  const { t, lang } = useLanguage();
  const isRTL = lang === 'ar';
  const [movies, setMovies] = useLocalStorage<Movie[]>('soon-movies', []);
  const [title, setTitle] = useState('');
  const [type, setType] = useState<'movie' | 'cartoon' | 'series'>('movie');
  const [genre, setGenre] = useState('');
  const [note, setNote] = useState('');
  const [showAdd, setShowAdd] = useState(false);
  const [aiSuggestions, setAiSuggestions] = useState('');
  const [loadingAI, setLoadingAI] = useState(false);
  const [activeTab, setActiveTab] = useState<'my' | 'ai'>('my');

  const saveMovie = () => {
    if (!title.trim()) return;
    setMovies(prev => [{
      id: Date.now().toString(), title: title.trim(), type, genre, note, date: new Date().toISOString(),
    }, ...prev]);
    setTitle(''); setGenre(''); setNote(''); setShowAdd(false);
  };

  const deleteMovie = (id: string) => setMovies(prev => prev.filter(m => m.id !== id));

  const getAISuggestions = async () => {
    setLoadingAI(true);
    setActiveTab('ai');
    const interests = movies.map(m => `${m.title} (${m.type}, ${m.genre})`).join(', ');
    const prompt = lang === 'ar'
      ? `بناءً على اهتمامات المستخدم في الأفلام والرسوم المتحركة: ${interests || 'لا توجد أفلام مسجلة بعد'}. اقترح 5 أفلام أو مسلسلات أو رسوم متحركة مفيدة للصحة النفسية. اذكر لكل اقتراح: الاسم، النوع، ولماذا هو مفيد للصحة النفسية. رد بالعربية.`
      : `Based on user's movie interests: ${interests || 'No movies logged yet'}. Suggest 5 movies, series, or cartoons beneficial for mental health. For each: name, type, and why it's good for mental health.`;

    try {
      const { data, error } = await supabase.functions.invoke('groq-chat', {
        body: { messages: [{ role: 'user', content: prompt }], systemPrompt: 'You are a mental health movie advisor. Suggest films and shows that support emotional wellbeing.' },
      });
      if (error) throw error;
      setAiSuggestions(data.content);
    } catch {
      setAiSuggestions(lang === 'ar' ? 'حدث خطأ. حاول مرة أخرى.' : 'An error occurred. Please try again.');
    }
    setLoadingAI(false);
  };

  const typeIcons = { movie: '🎬', cartoon: '🎨', series: '📺' };

  return (
    <div style={{ paddingTop: '20px', direction: isRTL ? 'rtl' : 'ltr' }}>
      <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#2DCE89', fontSize: '1rem', cursor: 'pointer', marginBottom: '15px', fontFamily: 'Poppins, sans-serif' }}>
        <i className={`fas fa-arrow-${isRTL ? 'right' : 'left'}`}></i> {t('nav.home')}
      </button>

      <div style={{ textAlign: 'center', marginBottom: '20px' }}>
        <h2 style={{ color: '#32325d', fontSize: '1.5rem', margin: '0 0 5px' }}>🎬 {t('movies.title')}</h2>
        <p style={{ color: '#8898aa', fontSize: '0.85rem', margin: 0 }}>{t('movies.subtitle')}</p>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: '8px', marginBottom: '20px' }}>
        {(['my', 'ai'] as const).map(tab => (
          <button key={tab} onClick={() => tab === 'ai' ? getAISuggestions() : setActiveTab('my')} style={{
            flex: 1, padding: '10px', borderRadius: '12px', border: 'none', cursor: 'pointer',
            background: activeTab === tab ? 'linear-gradient(135deg, #8965e0, #5e72e4)' : '#f8f9fe',
            color: activeTab === tab ? 'white' : '#32325d', fontWeight: 600, fontSize: '0.85rem', fontFamily: 'Poppins, sans-serif',
          }}>
            {tab === 'my' ? `📋 ${t('movies.my_list')}` : `🤖 ${t('movies.ai_suggest')}`}
          </button>
        ))}
      </div>

      {activeTab === 'my' && (
        <>
          {/* Add button */}
          {!showAdd && (
            <button onClick={() => setShowAdd(true)} style={{
              width: '100%', padding: '12px', borderRadius: '12px', border: '2px dashed #2DCE89',
              background: 'transparent', color: '#2DCE89', fontWeight: 600, cursor: 'pointer',
              fontFamily: 'Poppins, sans-serif', marginBottom: '15px', fontSize: '0.9rem',
            }}>
              + {t('movies.add')}
            </button>
          )}

          {/* Add form */}
          {showAdd && (
            <div style={{ background: 'white', borderRadius: '16px', padding: '15px', marginBottom: '15px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
              <input type="text" value={title} onChange={e => setTitle(e.target.value)} placeholder={t('movies.name_placeholder')}
                style={{ width: '100%', padding: '10px 14px', border: '1px solid #e0e0e0', borderRadius: '10px', marginBottom: '10px', fontFamily: 'Poppins, sans-serif', fontSize: '0.85rem', boxSizing: 'border-box' }} />
              <div style={{ display: 'flex', gap: '6px', marginBottom: '10px' }}>
                {(['movie', 'cartoon', 'series'] as const).map(t2 => (
                  <button key={t2} onClick={() => setType(t2)} style={{
                    flex: 1, padding: '8px', borderRadius: '8px', border: 'none', cursor: 'pointer',
                    background: type === t2 ? '#2DCE89' : '#f0f0f0', color: type === t2 ? 'white' : '#32325d',
                    fontWeight: 600, fontSize: '0.75rem', fontFamily: 'Poppins, sans-serif',
                  }}>
                    {typeIcons[t2]} {t(`movies.type_${t2}`)}
                  </button>
                ))}
              </div>
              <input type="text" value={genre} onChange={e => setGenre(e.target.value)} placeholder={t('movies.genre_placeholder')}
                style={{ width: '100%', padding: '10px 14px', border: '1px solid #e0e0e0', borderRadius: '10px', marginBottom: '10px', fontFamily: 'Poppins, sans-serif', fontSize: '0.85rem', boxSizing: 'border-box' }} />
              <textarea value={note} onChange={e => setNote(e.target.value)} placeholder={t('movies.note_placeholder')}
                style={{ width: '100%', padding: '10px 14px', border: '1px solid #e0e0e0', borderRadius: '10px', marginBottom: '10px', fontFamily: 'Poppins, sans-serif', fontSize: '0.85rem', minHeight: '60px', resize: 'vertical', boxSizing: 'border-box' }} />
              <div style={{ display: 'flex', gap: '8px' }}>
                <button onClick={saveMovie} style={{ flex: 1, background: '#2DCE89', color: 'white', border: 'none', borderRadius: '20px', padding: '10px', fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins, sans-serif' }}>
                  {t('movies.save')}
                </button>
                <button onClick={() => setShowAdd(false)} style={{ flex: 1, background: '#f0f0f0', color: '#666', border: 'none', borderRadius: '20px', padding: '10px', cursor: 'pointer', fontFamily: 'Poppins, sans-serif' }}>
                  {t('family.cancel')}
                </button>
              </div>
            </div>
          )}

          {/* Movie List */}
          {movies.length === 0 && <p style={{ textAlign: 'center', color: '#8898aa', padding: '20px' }}>{t('movies.empty')}</p>}
          {movies.map(m => (
            <div key={m.id} style={{ background: 'white', borderRadius: '12px', padding: '12px 15px', marginBottom: '10px', boxShadow: '0 2px 8px rgba(0,0,0,0.05)', borderLeft: `4px solid ${m.type === 'movie' ? '#5e72e4' : m.type === 'cartoon' ? '#f5576c' : '#2DCE89'}` }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <h5 style={{ margin: 0, color: '#32325d', fontSize: '0.95rem' }}>{typeIcons[m.type]} {m.title}</h5>
                  {m.genre && <span style={{ fontSize: '0.7rem', color: '#8898aa' }}>{m.genre}</span>}
                </div>
                <button onClick={() => deleteMovie(m.id)} style={{ background: 'none', border: 'none', color: '#f5576c', cursor: 'pointer', fontSize: '0.8rem' }}>
                  <i className="fas fa-trash"></i>
                </button>
              </div>
              {m.note && <p style={{ margin: '8px 0 0', fontSize: '0.8rem', color: '#666' }}>{m.note}</p>}
              <div style={{ fontSize: '0.7rem', color: '#aaa', marginTop: '5px' }}>{new Date(m.date).toLocaleDateString()}</div>
            </div>
          ))}
        </>
      )}

      {/* AI Tab */}
      {activeTab === 'ai' && (
        <div style={{ background: 'white', borderRadius: '16px', padding: '20px', boxShadow: '0 6px 20px rgba(0,0,0,0.08)' }}>
          {loadingAI ? (
            <div style={{ textAlign: 'center', padding: '30px', color: '#8898aa' }}>
              <div style={{ fontSize: '2rem', marginBottom: '10px' }}>🤖</div>
              {t('movies.ai_loading')}
            </div>
          ) : aiSuggestions ? (
            <div style={{ whiteSpace: 'pre-wrap', lineHeight: 1.7, color: '#32325d', fontSize: '0.9rem' }}>
              {aiSuggestions}
            </div>
          ) : (
            <div style={{ textAlign: 'center', padding: '20px', color: '#8898aa' }}>
              {t('movies.ai_empty')}
            </div>
          )}
          <button onClick={getAISuggestions} disabled={loadingAI} style={{
            width: '100%', marginTop: '15px', background: 'linear-gradient(135deg, #8965e0, #5e72e4)',
            color: 'white', border: 'none', borderRadius: '20px', padding: '10px', fontWeight: 600,
            cursor: loadingAI ? 'default' : 'pointer', fontFamily: 'Poppins, sans-serif', opacity: loadingAI ? 0.7 : 1,
          }}>
            🔄 {t('movies.ai_refresh')}
          </button>
        </div>
      )}
      <InlineAIChat context="movies" lang={lang} />
    </div>
  );
}
