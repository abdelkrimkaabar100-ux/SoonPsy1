export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      community_comments: {
        Row: {
          anonymous_name: string
          content: string
          created_at: string
          id: string
          post_id: string
        }
        Insert: {
          anonymous_name?: string
          content: string
          created_at?: string
          id?: string
          post_id: string
        }
        Update: {
          anonymous_name?: string
          content?: string
          created_at?: string
          id?: string
          post_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "community_comments_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "community_posts"
            referencedColumns: ["id"]
          },
        ]
      }
      community_posts: {
        Row: {
          anonymous_name: string
          category: string
          content: string
          created_at: string
          hearts: number
          id: string
        }
        Insert: {
          anonymous_name?: string
          category?: string
          content: string
          created_at?: string
          hearts?: number
          id?: string
        }
        Update: {
          anonymous_name?: string
          category?: string
          content?: string
          created_at?: string
          hearts?: number
          id?: string
        }
        Relationships: []
      }
      gratitude_messages: {
        Row: {
          created_at: string
          id: string
          is_self_thanks: boolean
          message: string
          recipient_name: string
          sender_name: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_self_thanks?: boolean
          message: string
          recipient_name?: string
          sender_name?: string
        }
        Update: {
          created_at?: string
          id?: string
          is_self_thanks?: boolean
          message?: string
          recipient_name?: string
          sender_name?: string
        }
        Relationships: []
      }
      group_messages: {
        Row: {
          content: string
          created_at: string
          group_id: string
          id: string
          sender_name: string
        }
        Insert: {
          content: string
          created_at?: string
          group_id: string
          id?: string
          sender_name?: string
        }
        Update: {
          content?: string
          created_at?: string
          group_id?: string
          id?: string
          sender_name?: string
        }
        Relationships: [
          {
            foreignKeyName: "group_messages_group_id_fkey"
            columns: ["group_id"]
            isOneToOne: false
            referencedRelation: "groups"
            referencedColumns: ["id"]
          },
        ]
      }
      groups: {
        Row: {
          created_at: string
          created_by: string
          description: string
          group_type: string
          icon: string
          id: string
          invite_code: string
          name: string
        }
        Insert: {
          created_at?: string
          created_by?: string
          description?: string
          group_type?: string
          icon?: string
          id?: string
          invite_code?: string
          name: string
        }
        Update: {
          created_at?: string
          created_by?: string
          description?: string
          group_type?: string
          icon?: string
          id?: string
          invite_code?: string
          name?: string
        }
        Relationships: []
      }
      holiday_greetings: {
        Row: {
          created_at: string
          id: string
          message: string
          occasion: string
          recipient_name: string
          sender_name: string
        }
        Insert: {
          created_at?: string
          id?: string
          message: string
          occasion?: string
          recipient_name?: string
          sender_name?: string
        }
        Update: {
          created_at?: string
          id?: string
          message?: string
          occasion?: string
          recipient_name?: string
          sender_name?: string
        }
        Relationships: []
      }
      published_articles: {
        Row: {
          article_title: string
          article_url: string
          id: string
          published_at: string
          source_name: string | null
          telegram_message_id: number | null
          topic: string
        }
        Insert: {
          article_title: string
          article_url: string
          id?: string
          published_at?: string
          source_name?: string | null
          telegram_message_id?: number | null
          topic: string
        }
        Update: {
          article_title?: string
          article_url?: string
          id?: string
          published_at?: string
          source_name?: string | null
          telegram_message_id?: number | null
          topic?: string
        }
        Relationships: []
      }
      shared_messages: {
        Row: {
          content: string
          created_at: string
          extra_data: Json | null
          id: string
          recipient_name: string
          sender_name: string
          type: string
        }
        Insert: {
          content: string
          created_at?: string
          extra_data?: Json | null
          id?: string
          recipient_name?: string
          sender_name?: string
          type?: string
        }
        Update: {
          content?: string
          created_at?: string
          extra_data?: Json | null
          id?: string
          recipient_name?: string
          sender_name?: string
          type?: string
        }
        Relationships: []
      }
      telegram_settings: {
        Row: {
          channel_name: string | null
          chat_id: string
          created_at: string
          id: string
          is_active: boolean
          topics: string[]
          updated_at: string
        }
        Insert: {
          channel_name?: string | null
          chat_id: string
          created_at?: string
          id?: string
          is_active?: boolean
          topics?: string[]
          updated_at?: string
        }
        Update: {
          channel_name?: string | null
          chat_id?: string
          created_at?: string
          id?: string
          is_active?: boolean
          topics?: string[]
          updated_at?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
