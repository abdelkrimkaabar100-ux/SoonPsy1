/**
 * SoonPsy Service Worker
 * Enables PWA installability with auto-update support
 */

const CACHE_NAME = 'soonpsy-v2';
const ASSETS_TO_CACHE = [
    '/icon.png',
    '/manifest.json',
];

// Install - cache minimal assets and activate immediately
self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then((cache) => cache.addAll(ASSETS_TO_CACHE))
            .then(() => self.skipWaiting())
    );
});

// Activate - clear old caches and take control immediately
self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches.keys()
            .then((cacheNames) => Promise.all(
                cacheNames
                    .filter((name) => name !== CACHE_NAME)
                    .map((name) => caches.delete(name))
            ))
            .then(() => self.clients.claim())
    );
});

// Fetch - Network First strategy for HTML/JS/CSS, Cache First for static assets only
self.addEventListener('fetch', (event) => {
    const url = new URL(event.request.url);

    // Skip non-GET and cross-origin
    if (event.request.method !== 'GET' || !url.origin.startsWith(self.location.origin)) {
        return;
    }

    // For navigation (HTML pages) and JS/CSS - always try network first
    if (event.request.mode === 'navigate' || 
        url.pathname.endsWith('.js') || 
        url.pathname.endsWith('.css') ||
        url.pathname === '/') {
        event.respondWith(
            fetch(event.request)
                .then((response) => {
                    // Cache the fresh response
                    const clone = response.clone();
                    caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
                    return response;
                })
                .catch(() => caches.match(event.request).then((r) => r || caches.match('/index.html')))
        );
        return;
    }

    // For static assets (images, fonts) - cache first, network fallback
    if (url.pathname.match(/\.(png|jpg|jpeg|webp|svg|ico|woff2?|ttf)$/)) {
        event.respondWith(
            caches.match(event.request).then((cached) => {
                if (cached) return cached;
                return fetch(event.request).then((response) => {
                    if (response.ok) {
                        const clone = response.clone();
                        caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
                    }
                    return response;
                });
            })
        );
        return;
    }

    // Everything else - network only
    event.respondWith(fetch(event.request));
});

// Handle messages
let scheduledTimers = [];

self.addEventListener('message', (event) => {
    if (event.data === 'skipWaiting') {
        self.skipWaiting();
    }

    if (event.data && event.data.type === 'SCHEDULE_NOTIFICATION') {
        scheduledTimers.forEach(t => clearTimeout(t));
        scheduledTimers = [];

        const { time, lang, userName, types } = event.data;
        const scheduleNext = () => {
            const now = new Date();
            const [h, m] = time.split(':').map(Number);
            const target = new Date(now);
            target.setHours(h, m, 0, 0);
            if (target <= now) target.setDate(target.getDate() + 1);
            const delay = target.getTime() - now.getTime();

            const timer = setTimeout(() => {
                const name = userName ? ` ${userName}` : '';
                const msgs = {
                    general: { ar: [`كيف حالك${name}؟ 💚`], en: [`How are you${name}? 💚`] },
                    water: { ar: [`${name}، لا تنسَ شرب الماء! 💧`], en: [`${name}, drink water! 💧`] },
                    fasting: { ar: [`${name}، هل بدأت صيامك؟ 🌙`], en: [`${name}, start your fast! 🌙`] },
                    detox: { ar: [`${name}، سجل تحدي الامتناع! 🚫`], en: [`${name}, log your detox! 🚫`] },
                    tasks: { ar: [`${name}، لديك مهام! 📋`], en: [`${name}, check tasks! 📋`] },
                    mood: { ar: [`${name}، كيف مزاجك؟ 🎭`], en: [`${name}, how's your mood? 🎭`] },
                    dreams: { ar: [`${name}، سجل حلمك! 🌙`], en: [`${name}, log your dream! 🌙`] },
                };
                const selType = (types || ['general'])[Math.floor(Math.random() * (types || ['general']).length)];
                const langMsgs = (msgs[selType] && msgs[selType][lang]) || msgs.general.en;
                const msg = langMsgs[Math.floor(Math.random() * langMsgs.length)];

                self.registration.showNotification('Soon 🌿', {
                    body: msg, icon: '/icon.png', badge: '/icon.png',
                    tag: 'soon-daily', renotify: true, vibrate: [100, 50, 100],
                });
                scheduleNext();
            }, delay);
            scheduledTimers.push(timer);
        };
        scheduleNext();
    }

    if (event.data && event.data.type === 'SCHEDULE_INTERVAL_REMINDER') {
        const { id, intervalMs, title, body } = event.data;
        if (self._intervalReminders && self._intervalReminders[id]) {
            clearInterval(self._intervalReminders[id]);
        }
        if (!self._intervalReminders) self._intervalReminders = {};
        self._intervalReminders[id] = setInterval(() => {
            self.registration.showNotification(title || 'Soon 🌿', {
                body, icon: '/icon.png', badge: '/icon.png',
                tag: `soon-${id}`, renotify: true, vibrate: [100, 50, 100],
            });
        }, intervalMs);
    }

    if (event.data && event.data.type === 'STOP_INTERVAL_REMINDER') {
        if (self._intervalReminders && self._intervalReminders[event.data.id]) {
            clearInterval(self._intervalReminders[event.data.id]);
            delete self._intervalReminders[event.data.id];
        }
    }
});

// Background sync
self.addEventListener('sync', (event) => {
    if (event.tag === 'background-sync') {
        event.waitUntil(Promise.resolve());
    }
});

// Push notifications
self.addEventListener('push', (event) => {
    if (event.data) {
        const data = event.data.json();
        event.waitUntil(
            self.registration.showNotification(data.title, {
                body: data.body, icon: '/icon.png', badge: '/icon.png',
                vibrate: [100, 50, 100],
            })
        );
    }
});

// Notification click
self.addEventListener('notificationclick', (event) => {
    event.notification.close();
    event.waitUntil(clients.openWindow('/'));
});
